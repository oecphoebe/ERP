# AR_INV_2508001031 External Payload Verification - Session Handover A_01

## Project Overview
Add comprehensive external payload verification to AR Invoice integration test, with special focus on buyerTaxNo field validation against expected external system JSON.

## Current Context
- **Test file**: `src/test/java/oec/lis/erpportal/addon/compliance/controller/ARInvoice2508001031IntegrationTestV2.java`
- **Expected result**: `reference/AR_INV_2508001031-external.json`
- **Critical issue**: buyerTaxNo="913706855690363661" needs to be verified in external payload
- **Current gap**: VAT data is commented out in test-schema-postgresql.sql line 446

## Problem Statement
The integration test for AR_INV_2508001031 needs to verify that the external payload sent to Kafka contains the correct buyerTaxNo value. Currently:
1. The VAT number lookup fails because test data is commented out
2. No mechanism exists to capture and verify the external payload
3. All 45+ attributes in the external JSON need comprehensive verification

## Session 1 Objective
Establish test data foundation and mock infrastructure to enable external payload capture.

## Session 1 Tasks
1. **Enable VAT Data**: Uncomment VAT data insertion in test-schema-postgresql.sql line 446 for YANTFUSHA organization
2. **Add Mock Infrastructure**: Add KafkaTemplate mock bean to the test class
3. **Setup Capture Mechanism**: Setup ArgumentCaptor<RetryRecord> for capturing Kafka messages
4. **Prepare Foundation**: Ensure all infrastructure is ready for payload capture implementation

## Expected Deliverables for Session 1
- [ ] Modified test-schema-postgresql.sql with VAT data enabled
- [ ] Updated ARInvoice2508001031IntegrationTestV2.java with mock infrastructure
- [ ] ArgumentCaptor ready for message capture
- [ ] Test compiles without errors
- [ ] Foundation ready for Session 2 implementation

## Data Specifications
### VAT Data to Enable
```sql
INSERT INTO cw_org_cus_code(org_cus_code_id, org_header_id, cus_country_code, cus_code_type, cus_code_value, etl_create_time, etl_update_time)
VALUES('df8e100b-b76f-451b-8ce6-9ce47fd7a624'::uuid, 'd9e232b5-bbe5-4681-b747-040f24fa4af6'::uuid, 'CN', 'VAT', '913706855690363661', '2025-05-12 02:33:12.219', '2025-06-16 03:52:13.324');
```

### Mock Infrastructure Requirements
- KafkaTemplate<String, Object> mock bean
- ArgumentCaptor<RetryRecord> for message capture
- Proper test setup in @BeforeEach method

## Success Criteria for Session 1
- [ ] VAT data available in test database for YANTFUSHA organization
- [ ] Mock infrastructure compiles without errors  
- [ ] Test class setup ready for external payload capture
- [ ] All existing tests continue to pass
- [ ] Clear handover document prepared for Session 2

## Technical Notes
- The buyerTaxNo is retrieved via `TransactionQueryService.getBuyerTaxNo()` method
- External payload is sent via Kafka as RetryRecord containing List<TransactionChargeLineRequestBean>
- Each TransactionChargeLineRequestBean extends TransactionInfoRequestBean with additional line-specific fields

## Next Session Preview
Session 2 will focus on implementing the mechanisms to capture and extract the external payload from the mocked Kafka messages, preparing for comprehensive attribute verification in Session 3.