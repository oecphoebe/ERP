# AR Invoice Integration Test Debugging Checklist
## Quick Reference for Common Issues

This checklist provides rapid troubleshooting guidance for AR invoice integration test development based on lessons learned from `AR_INV_2508001031` test creation.

---

## 🚨 Emergency Diagnostics (60 Second Check)

### Test Failures - Start Here
```bash
# 1. Check test execution results
cat target/surefire-reports/oec.lis.erpportal.addon.compliance.controller.*IntegrationTestV2.txt

# 2. Verify basic test data loading  
./mvnw test -Dtest=YourTestClass -Dtest.debug=true

# 3. Check container startup logs
docker logs $(docker ps -q --filter ancestor=postgres) | tail -20
docker logs $(docker ps -q --filter ancestor=mcr.microsoft.com/mssql/server) | tail -20
```

---

## 📋 Schema Compatibility Issues

### Problem: "Cannot modify computed column" Errors
**Error Pattern:** `The column 'X' cannot be modified because it is either a computed column`

**Immediate Action:**
1. **Remove computed columns from INSERT statements:**
   - `JS_HouseBill_Reversed` 
   - `JS_UniqueConsignRef_Reversed`
   - `AH_SystemCreateBranch`
   - `AH_SystemCreateDepartment`

2. **Validation Command:**
   ```bash
   # Check for computed columns in test data
   grep -n "JS_HouseBill_Reversed\|JS_UniqueConsignRef_Reversed\|AH_SystemCreateBranch" src/test/resources/test-data-cargowise-*.sql
   ```

3. **Fix Pattern:**
   ```sql
   -- WRONG:
   INSERT INTO JobShipment (..., JS_HouseBill_Reversed, ...)
   VALUES (..., 'some_value', ...);
   
   -- CORRECT:
   INSERT INTO JobShipment (...) -- Remove computed columns entirely
   VALUES (...); -- Remove corresponding values
   ```

### Problem: "Invalid column name" Errors  
**Error Pattern:** `Invalid column name 'X'`

**Immediate Action:**
1. **Check schema file has required columns:**
   ```bash
   # Verify column exists in schema
   grep -n "column_name" src/test/resources/test-schema-sqlserver-minimal.sql
   ```

2. **Add missing columns to schema:**
   ```sql
   -- For transaction support
   CREATE TABLE JobCharge (
       JR_APInvoiceNum NVARCHAR(38),  -- For AP invoices
       -- ... other columns
   );
   ```

---

## 🔍 Data Persistence Issues

### Problem: Expected Records Not Found (0 actual vs N expected)

**Root Cause Priority Order:**
1. **Business Logic Flags (MOST COMMON)**
2. **Transaction Type Differentiation**  
3. **Foreign Key Relationship Issues**
4. **Query Logic Bugs**

#### Diagnostic Steps:

**Step 1: Check Business Flags**
```sql
-- Verify transaction is active (not cancelled)
SELECT AH_TransactionNum, AH_IsCancelled, AH_IsReversed 
FROM AccTransactionHeader 
WHERE AH_TransactionNum = 'YOUR_TRANSACTION_NUM';

-- Expected: AH_IsCancelled = 0, AH_IsReversed = 0
```

**Step 2: Verify Transaction Type Handling**
```sql  
-- Check AR vs AP invoice number linking
SELECT 
    jc.JR_APInvoiceNum,
    ath.AH_TransactionNum,
    ath.AH_Ledger,  -- Should be 'AR' for AR invoices
    jh.JH_JobNum    -- Job number for relationship tracking
FROM JobCharge jc
JOIN JobHeader jh ON jh.JH_PK = jc.JR_JH
JOIN AccTransactionHeader ath ON ath.AH_JobNumber = jh.JH_JobNum
WHERE ath.AH_TransactionNum = 'YOUR_TRANSACTION_NUM';
```

**Step 3: Validate Foreign Key Relationships**
```sql
-- Check job and shipment linkage (CRITICAL: JobShipment links via JH_ParentID)
SELECT 
    jh.JH_JobNum,
    jh.JH_PK,
    js.JS_PK,  -- JobShipment primary key
    jc.JR_JH   -- JobCharge should match JH_PK  
FROM JobHeader jh
LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID  -- CORRECT relationship
LEFT JOIN JobCharge jc ON jc.JR_JH = jh.JH_PK
WHERE jh.JH_JobNum = 'YOUR_JOB_NUM';

-- Verify the critical relationship used in production queries
-- TransactionQueryService.java line 241: js.JS_PK = jh.JH_ParentID
SELECT COUNT(*) as linked_records
FROM JobHeader jh
INNER JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID  -- Production JOIN pattern
WHERE jh.JH_JobNum = 'YOUR_JOB_NUM';
-- Expected: Should return 1 for properly linked records
```

### Problem: Shipment Info Not Persisting

**Critical Check: AH_IsCancelled Flag**
```sql
-- This is the #1 cause of shipment info persistence failure
UPDATE AccTransactionHeader 
SET AH_IsCancelled = 0  -- Must be 0 (false) for active transactions
WHERE AH_TransactionNum = 'YOUR_TRANSACTION_NUM';
```

**Validation Query:**
```sql
-- Test the actual shipment info query
-- Mirror the EXACT production query from TransactionQueryService.java
SELECT COUNT(*) as shipment_count
FROM AccTransactionHeader ath
LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK
LEFT JOIN JobHeader jh ON jh.JH_PK = atl.AL_JH
LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID  -- Line 241: CRITICAL relationship
INNER JOIN AccChargeCode c ON c.ac_pk = atl.al_ac
LEFT JOIN JobCharge jc2 ON jc2.JR_JH = jh.jh_pk AND jc2.jr_ac = c.ac_pk AND jc2.JR_APInvoiceNum = ath.AH_TransactionNum  -- Line 245: AR invoice limitation
WHERE ath.AH_TransactionNum = 'YOUR_TRANSACTION_NUM'
  AND ath.AH_IsCancelled = 0;

-- CRITICAL: Verify the JobShipment → JobHeader relationship is properly established
-- This is the #1 cause of "RefNoInfo not found" errors in AR invoice processing
SELECT 
    jh.JH_JobNum,
    jh.JH_PK as JobHeaderPK,
    jh.JH_ParentID as JobHeaderParentID,
    js.JS_PK as JobShipmentPK,
    'MATCH' as relationship_status
FROM JobHeader jh
INNER JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID  -- Must match for queries to succeed
WHERE jh.JH_JobNum = 'YOUR_JOB_NUM';
-- Expected: Should return exactly 1 row with relationship_status = 'MATCH'
```

---

## 🔧 Common Fix Patterns

### AR Invoice Processing Architecture - CRITICAL UNDERSTANDING
**Primary Issue:** AR invoices fail to persist due to business flag configuration

**Root Cause Analysis:** LEFT JOIN structure in `TransactionQueryService.getRefNo()` method (lines 240-245)

**Actual Production Query (TransactionQueryService.java lines 240-245):**
```java
.append(" LEFT JOIN JobHeader jh ON jh.JH_PK = atl.AL_JH ")
.append(" LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID ")  // CRITICAL: JobShipment links to JobHeader via ParentID
.append(" LEFT JOIN JobCharge jc2 ON jc2.JR_JH = jh.jh_pk AND jc2.jr_ac = c.ac_pk AND jc2.JR_APInvoiceNum = ath.AH_TransactionNum ")
```

**Impact:** 
- LEFT JOIN ensures results are returned regardless of JobCharge records
- JobCharge matching provides additional context but is NOT required for basic query execution
- Missing JobCharge records return NULL values, not empty results
- The query hardcodes `JR_APInvoiceNum = ath.AH_TransactionNum` for both AP and AR transactions
- **CRITICAL**: The primary cause of persistence failures is `AH_IsCancelled = 1`, not missing JobCharge records

### Test Data Business State Fixes
**Critical Flags for Active Transactions:**
```sql
INSERT INTO AccTransactionHeader (
    AH_IsCancelled,   -- Must be 0 for active transactions
    AH_IsReversed,    -- Should be 0 for normal transactions  
    AH_IsPosted,      -- Can be 1 for posted transactions
    -- ... other fields
) VALUES (
    0,  -- AH_IsCancelled = FALSE
    0,  -- AH_IsReversed = FALSE  
    1,  -- AH_IsPosted = TRUE
    -- ... other values
);
```

### JobCharge Linking for AR Invoices
```sql
-- Ensure JobCharge records link to AR invoice
INSERT INTO JobCharge (
    JR_PK,
    JR_JH,              -- Links to JobHeader.JH_PK
    JR_APInvoiceNum,    -- For AP invoices (NULL for others)
    -- ... other fields
) VALUES (
    'JR-GUID',
    'JH-GUID',  
    NULL,          -- No direct invoice linkage for AR
    -- ... other values  
);
```

---

## 🎯 Performance Optimization

### Target Metrics
- **Total Test Time:** < 20 seconds
- **Individual Test:** < 3 seconds
- **Container Startup:** < 10 seconds

### Quick Performance Checks
```bash
# Check test execution time
grep "Time elapsed" target/surefire-reports/*.txt

# Verify container resource usage
docker stats --no-stream

# Check test data file sizes
ls -lah src/test/resources/test-data-cargowise-*.sql
```

### Optimization Strategies
1. **Use minimal schema** when possible (`test-schema-sqlserver-minimal.sql`)
2. **Consolidate reference data** (don't duplicate in individual test files)
3. **Clean up test data** between methods to avoid interference
4. **Reuse containers** within test class when possible

---

## 📝 Development Workflow

### Before Making Changes
- [ ] Run existing tests to establish baseline
- [ ] Identify specific failure patterns  
- [ ] Plan incremental fixes (schema → business logic → validation)

### During Development  
- [ ] Make ONE logical change at a time
- [ ] Run tests after each change
- [ ] Document what worked and what didn't
- [ ] Commit working states frequently

### After Changes
- [ ] Verify all tests pass consistently (run 3 times)
- [ ] Check execution time hasn't regressed
- [ ] Clean up debug code and temporary changes
- [ ] Document lessons learned

---

## 🚨 Emergency Rollback Procedures

### Quick Revert Commands
```bash
# Revert specific file changes
git checkout HEAD -- src/test/resources/test-data-cargowise-*.sql

# Revert business logic changes  
git checkout HEAD -- src/main/java/oec/lis/erpportal/addon/compliance/transaction/impl/

# Clean build and test
./mvnw clean test -Dtest=YourTestClass
```

### Safe Testing Strategy
```bash
# Test individual components first
./mvnw test -Dtest=YourTestClass#specificTestMethod

# Then test full class
./mvnw test -Dtest=YourTestClass  

# Finally test related functionality
./mvnw test -Dtest="*IntegrationTestV2"
```

---

## 📞 Escalation Paths

### When to Escalate
- **Schema changes fail repeatedly** → Database architecture review needed
- **Business logic unclear** → Domain expert consultation required  
- **Performance severely degraded** → Infrastructure team involvement
- **Test framework issues** → V2 framework maintainer support

### Information to Gather Before Escalation
1. **Exact error messages** with full stack traces
2. **Test execution logs** with timing information
3. **Database state** before and after test execution  
4. **Environment details** (Java version, Spring Boot version, etc.)
5. **Recent changes** made to codebase or infrastructure

---

This checklist should be your first resource when encountering AR invoice integration test issues. Follow the diagnostic steps systematically, and you'll resolve most issues within minutes rather than hours.