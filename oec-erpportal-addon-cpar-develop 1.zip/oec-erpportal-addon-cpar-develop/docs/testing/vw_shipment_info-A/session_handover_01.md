# vw_shipment_info Migration - Session 1 Handover

## Task Overview
**Task Key**: vw_shipment_info-A
**Objective**: Migrate from `at_shipment_info` table to `vw_shipment_info` view with feature flag support and backward compatibility.

## Background Context
The CPAR service currently manages shipment information by:
1. Fetching data from Cargowise using complex SQL queries (lines 213-222 in `AtAccountTransactionTableServiceImpl`)
2. Saving to `at_shipment_info` table with 24 columns
3. Providing read access via `findShipmentByJobNumber()`

The migration shifts responsibility to an external view while maintaining API compatibility.

## Migration Requirements

### 1. View Structure (vw_shipment_info)
The new view contains **10 columns** (reduced from 24):
```sql
-- View columns (database names)
shipment_no     varchar(20)
cnsl_no         varchar(20)
hbl_no          varchar(20)
mbl_no          varchar(35)
master_mbl      varchar(35)
carrier_book_no varchar(35)
shipment_type   varchar(3)
cnsl_type       varchar(3)
cnsl_first_leg_vssl varchar(35)
cnsl_first_leg_voy  varchar(10)
```

### 2. Lookup Strategy
Based on `ref_no` prefix:
- **'C' prefix**: Query `vw_shipment_info.cnsl_no = ref_no`
- **'S' prefix**: Query `vw_shipment_info.shipment_no = ref_no`
- **Other prefix**: Log warning and use fallback mechanism

### 3. Feature Flag Configuration
```yaml
shipment:
  use-view: false  # Default: use existing table implementation
                   # true: use new view implementation
```

### 4. Key Implementation Points
- **Java Naming**: `cnsl_no` (DB) → `consolNo` (Java field)
- **Backward Compatibility**: Keep existing code intact for rollback
- **Fallback Strategy**: Retry mechanism when view returns no data
- **Performance**: Monitor view vs table performance
- **Testing**: Mock table for integration tests

## Current Implementation Analysis

### Files Requiring Changes
1. **Model Layer**
   - Create: `VwShipmentInfoBean.java`
   - Existing: `AtShipmentInfoBean.java` (keep unchanged)

2. **Service Layer**
   - Modify: `AtAccountTransactionTableServiceImpl.java` (lines 213-222)
   - Keep: `fetchShipmentInfoFromCW()` and `saveAtShipmentInfo()` methods

3. **Configuration**
   - Update: `application.yml` (add feature flag)
   - Update: `test-schema-postgresql.sql` (add mock view)

4. **Testing**
   - Update: Integration test base classes
   - Create: View-specific test cases

### Current Code Context (Lines 213-222)
```java
if (headerBean.getRefNo()!=null && !headerBean.getRefNo().isEmpty()) {
    List<AtShipmentInfoBean> availableShipmentInfoList = fetchShipmentInfoFromCW(
        headerBean.getTransactionNo(), headerBean.getTransactionType(),
        headerBean.isCancelled(), headerBean.getCompanyCode(), headerBean.getCompanyBranch()
    );
    log.debug("availableShipmentInfoList.size() = [{}] at_shipment_info :",
        availableShipmentInfoList.isEmpty() ? 0 : availableShipmentInfoList.size());
    JsonUtils.print(availableShipmentInfoList);
    if (!availableShipmentInfoList.isEmpty()) {
        int[] result = saveAtShipmentInfo( availableShipmentInfoList );
        log.debug("result of saveAtShipmentInfo() [{}]", result);
    }
}
```

## Session 1 Objectives

### Primary Tasks
- [ ] **Create VwShipmentInfoBean.java**
  - 10 fields matching view columns
  - Proper Java naming conventions (consolNo, etc.)
  - Lombok annotations (@Data)
  - Field validation annotations if needed

- [ ] **Add Feature Flag Configuration**
  - Add to `application.yml` in all profiles
  - Default value: `false` (use table)
  - Document configuration option

- [ ] **Create Mock View Table for Tests**
  - Update `test-schema-postgresql.sql`
  - Create `vw_shipment_info` as table (not view in tests)
  - Include sample test data for both 'C' and 'S' prefixes

- [ ] **Create Initial Service Interface**
  - Define `ShipmentViewService` interface
  - Method signatures for view-based operations
  - Document API contracts

### Secondary Tasks
- [ ] **Documentation**
  - Update this handover with implementation details
  - Document all new files created
  - List any issues or concerns discovered

## Technical Specifications

### VwShipmentInfoBean Field Mapping
```java
// Database Column -> Java Field
shipment_no         -> shipmentNo
cnsl_no            -> consolNo              // Note: special naming
hbl_no             -> hblNo
mbl_no             -> mblNo
master_mbl         -> masterMbl
carrier_book_no    -> carrierBookNo
shipment_type      -> shipmentType
cnsl_type          -> consolType
cnsl_first_leg_vssl -> consolFirstLegVessel
cnsl_first_leg_voy  -> consolFirstLegVoyage
```

### Configuration Structure
```yaml
# application.yml
shipment:
  use-view: false

# application-local.yml
shipment:
  use-view: false

# application-osit.yml (for testing)
shipment:
  use-view: true
```

### Mock Table Schema
```sql
-- For integration tests only
CREATE TABLE IF NOT EXISTS vw_shipment_info (
    shipment_no VARCHAR(20),
    cnsl_no VARCHAR(20),
    hbl_no VARCHAR(20),
    mbl_no VARCHAR(35),
    master_mbl VARCHAR(35),
    carrier_book_no VARCHAR(35),
    shipment_type VARCHAR(3),
    cnsl_type VARCHAR(3),
    cnsl_first_leg_vssl VARCHAR(35),
    cnsl_first_leg_voy VARCHAR(10)
);
```

## Critical Notes

### 1. Backward Compatibility
- **MUST NOT** break existing API contracts
- **MUST KEEP** existing methods intact for rollback
- **MUST ENSURE** existing callers continue working

### 2. Performance Considerations
- View queries may be slower than table queries
- Monitor query execution time during testing
- Consider indexing strategy for the view

### 3. Data Integrity
- View is guaranteed to have data (managed by data team)
- Implement retry mechanism for edge cases
- Log when fallback mechanisms are triggered

### 4. Testing Strategy
- Test both feature flag states (true/false)
- Test prefix-based routing ('C' vs 'S')
- Test fallback scenarios
- Performance comparison tests

## Expected Deliverables

### Files to Create
1. `src/main/java/oec/lis/erpportal/addon/compliance/model/transaction/VwShipmentInfoBean.java`
2. `src/main/java/oec/lis/erpportal/addon/compliance/service/ShipmentViewService.java`
3. Updates to `src/main/resources/application.yml`
4. Updates to `src/test/resources/test-schema-postgresql.sql`

### Files to Document
- All changes made during this session
- Any issues or concerns discovered
- Recommendations for next session

## Next Session Preparation
Session 2 will focus on:
1. Implementing the ShipmentViewService
2. Adding prefix-based routing logic
3. Implementing retry mechanisms
4. Modifying AtAccountTransactionTableServiceImpl with feature flag

## Implementation Guidelines

### Code Quality Standards
- Follow existing project conventions
- Use meaningful variable names
- Add comprehensive logging
- Include error handling
- Write self-documenting code

### Testing Requirements
- Unit tests for all new classes
- Integration tests for feature flag scenarios
- Performance benchmarks
- Error case testing

## Session 1 Status: READY TO START

All requirements, specifications, and guidelines are documented. Proceed with implementation tasks.