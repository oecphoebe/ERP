# Session Handover 1: Reference Data Consolidation Analysis

**Date:** August 23, 2025  
**Session ID:** Consolidation_Analysis_1  
**Status:** Analysis Complete - Ready for Execution  

## Executive Summary

This document provides a comprehensive analysis of duplicate reference data found across 3 non-minimal test data files. The analysis identified specific records that are duplicates of schema files, unique records that need schema consolidation, and test-specific data that should remain in individual files.

**Key Findings:**
- 3 AccChargeCode records are duplicates (DOC, FRT, AMS)
- 2 AccChargeCode records are unique and need schema addition (OCHC, OCLR)  
- 2 OrgHeader records are duplicates (OECGRPORD, CMACGMORF)
- 2 OrgHeader records are unique and need schema addition (MEISINYTN, YANTFUSHA)
- All GlbCompany, GlbBranch, GlbDepartment records are already in schema files

## Files Analyzed

### Source Files
1. **test-data-cargowise-AS20250818_2.sql** (AP Invoice test)
2. **test-data-cargowise-AS20250819_3.sql** (AP Credit Note test)  
3. **test-data-cargowise-AR_INV_AS20250819_3.sql** (AR Invoice test)

### Schema Reference Files
1. **test-schema-sqlserver.sql** (Full schema with reference data)
2. **test-schema-sqlserver-minimal.sql** (Minimal schema with reference data)

## Current State Analysis

### AccChargeCode Records

| AC_Code | AC_PK | Description | AS20250818_2 | AS20250819_3 | AR_INV_AS20250819_3 | Schema Files | Status |
|---------|-------|-------------|--------------|--------------|---------------------|--------------|---------|
| DOC | C725B20C-1CE9-497E-84BD-2D79EB697067 | Destination Documentation Fee | ✓ | ✓ | ✗ | ✓ | **DUPLICATE** |
| FRT | CE0AF0E4-E31D-40B0-8F9B-12E189F3348A | International Freight | ✓ | ✗ | ✗ | ✓ | **DUPLICATE** |  
| AMS | E74937FD-FE45-401A-8728-795D85A69A0A | AMS Security Surcharge | ✗ | ✓ | ✗ | ✓ | **DUPLICATE** |
| OCHC | 6EFBC528-6B4E-41F8-A84F-67096D0CE8FA | Origin Container Handling Charge | ✗ | ✗ | ✓ | ✗ | **UNIQUE** |
| OCLR | 7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C | Origin Customs Clearance Fee | ✗ | ✗ | ✓ | ✗ | **UNIQUE** |

### OrgHeader Records

| OH_Code | OH_PK | Full Name | AS20250818_2 | AS20250819_3 | AR_INV_AS20250819_3 | Schema Files | Status |
|---------|-------|-----------|--------------|--------------|---------------------|--------------|---------|
| OECGRPORD | 3C52A1A4-F0C6-406B-A70E-7342305013CE | OEC FREIGHT (NY), INC. | ✓ | ✗ | ✗ | ✓ | **DUPLICATE** |
| CMACGMORF | C00543BE-015E-4D10-98B8-D9079CF2B314 | CMA CGM S.A. | ✗ | ✗ | ✗ | ✓ | **DUPLICATE** |
| MEISINYTN | B7DF88AA-ED24-4163-B439-0D10D7623649 | MEIYUME (SINGAPORE) PTE.LIMITED | ✗ | ✓ | ✗ | ✗ | **UNIQUE** |
| YANTFUSHA | D9E232B5-BBE5-4681-B747-040F24FA4AF6 | (Referenced in AR_INV) | ✗ | ✗ | ✓ | ✗ | **UNIQUE** |

### GlbCompany, GlbBranch, GlbDepartment Records

| Table | Code | PK | Status | Note |
|-------|------|----|--------|------|
| GlbCompany | SH1 | 15C1F416-01D2-4ED2-9B5B-D032C4796DC4 | **IN SCHEMA** | Already present |
| GlbBranch | SH1 | 9652C78F-53ED-4DC2-B70D-D921C165A3B0 | **IN SCHEMA** | Already present |
| GlbDepartment | FES | 57F778C1-DAF6-46E0-B7DC-AF01C161C936 | **IN SCHEMA** | Already present |

## Detailed Record Analysis

### 1. Duplicate Records (Remove from Test Files)

#### AccChargeCode Duplicates

**DOC Record - REMOVE from AS20250818_2.sql and AS20250819_3.sql**
```sql
-- Lines to remove from both files:
INSERT INTO AccChargeCode(AC_PK, AC_Code, AC_Desc, ...)
VALUES(N'C725B20C-1CE9-497E-84BD-2D79EB697067', N'DOC', N'Destination Documentation Fee', ...);
```

**FRT Record - REMOVE from AS20250818_2.sql**
```sql
-- Lines to remove:
(N'CE0AF0E4-E31D-40B0-8F9B-12E189F3348A', N'FRT', N'International Freight', N'國際代理運費', ...);
```

**AMS Record - REMOVE from AS20250819_3.sql**  
```sql
-- Lines to remove:
INSERT INTO AccChargeCode(AC_PK, AC_Code, AC_Desc, ...)
VALUES(N'E74937FD-FE45-401A-8728-795D85A69A0A', N'AMS', N'AMS Security Surcharge', N'安檢費', ...);
```

#### OrgHeader Duplicates

**OECGRPORD Record - REMOVE from AS20250818_2.sql**
```sql 
-- Lines to remove:
INSERT INTO OrgHeader (OH_PK, OH_Code, OH_RL_NKClosestPort, ...)
VALUES(N'3C52A1A4-F0C6-406B-A70E-7342305013CE', N'OECGRPORD', N'USITS', N'EN', ...);
```

### 2. Unique Records (Add to Schema Files)

#### AccChargeCode Unique Records - ADD to schema files

**OCHC Record - ADD to both schema files**
```sql
-- Add to test-schema-sqlserver.sql (after existing AccChargeCode inserts):
INSERT INTO AccChargeCode (AC_PK, AC_Code, AC_Desc, AC_LocalLanguageDescription, AC_ChargeType, AC_MarginPercentage, AC_AW_WithholdingTaxRate, AC_AT_GSTRate, AC_AG_RevenueAccount, AC_AG_WIPAccount, AC_AG_CostAccount, AC_AG_AccrualAccount, AC_PrintSequence, AC_AR_SalesGroup, AC_AR_ExpenseGroup, AC_ChargeGroup, AC_ChargeSubGroup, AC_RateCalculator, AC_DepartmentFilterList, AC_IATA_ChargeCodeMap, AC_GC, AC_ENettChargeCodeMap, AC_GoodsServiceType, AC_ChargeOtherGroups, AC_AX_TaxOverrideGroup, AC_IsActive, AC_IsGroupageCharge, AC_ShowOnQuotation, AC_SuppressOnQuoteIfZero, AC_AllowDescriptionOvertype, AC_IsCommissionable, AC_InputGSTVATRecoverable, AC_EnergySourceGroup, AC_DefaultCommissionProduct, AC_DefaultCommissionService, AC_DefaultCommissionSubModule, AC_AC_RevenueChargeCode, AC_GovtChargeCode, AC_IsAdhocServiceCharge, AC_AG_CostClearingAccount, AC_AG_RevenueClearingAccount, AC_AutoVersion, AC_AG_DisbursementShortfallAccount, AC_AG_DisbursementSurplusAccount, AC_SystemCreateTimeUtc, AC_SystemCreateUser, AC_SystemLastEditTimeUtc, AC_SystemLastEditUser)
VALUES
('6EFBC528-6B4E-41F8-A84F-67096D0CE8FA', 'OCHC', 'Origin Container Handling Charge', '', 'MJA', 0.00, NULL, '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 1, '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 'ORG', '', 'FLT', 'ALL', '', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '', 'SRV', 'PRC', '00000000-0000-0000-0000-000000000000', 1, 0, 1, 1, 1, 1, 1.0000, '', '', '', '', NULL, '', 0, NULL, NULL, 1, NULL, NULL, '2021-10-22 01:45:00.000', 'ACH', '2025-05-15 03:47:00.000', '~AD'),
('7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C', 'OCLR', 'Origin Customs Clearance Fee', '启运港清关费', 'MJA', 0.00, NULL, '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 1, '00000000-0000-0000-0000-000000000000', '00000000-0000-0000-0000-000000000000', 'ORG', '', 'FLT', 'ALL', '', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '', 'SRV', 'PRC', '00000000-0000-0000-0000-000000000000', 1, 0, 1, 1, 1, 1, 1.0000, '', '', '', '', NULL, '', 0, NULL, NULL, 1, NULL, NULL, '2021-10-22 01:45:00.000', 'ACH', '2025-06-11 01:46:00.000', '~AD');
```

**Add to test-schema-sqlserver-minimal.sql (after existing AccChargeCode inserts):**
```sql
INSERT INTO AccChargeCode (AC_PK, AC_Code, AC_Desc, AC_ChargeType, AC_IsActive, AC_SystemCreateTimeUtc, AC_SystemCreateUser, AC_SystemLastEditTimeUtc, AC_SystemLastEditUser)
VALUES
('6EFBC528-6B4E-41F8-A84F-67096D0CE8FA', 'OCHC', 'Origin Container Handling Charge', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-05-15 03:47:00.000', '~AD'),
('7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C', 'OCLR', 'Origin Customs Clearance Fee', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-06-11 01:46:00.000', '~AD');
```

#### OrgHeader Unique Records - ADD to schema files

**MEISINYTN Record - ADD to both schema files**

**Add to test-schema-sqlserver.sql (after existing OrgHeader inserts):**
```sql
INSERT INTO OrgHeader (OH_PK, OH_Code, OH_RL_NKClosestPort, OH_Language, OH_SystemLastEditTimeUtc, OH_SystemLastEditUser, OH_SystemCreateTimeUtc, OH_SystemCreateUser, OH_IsActive, OH_IsConsignee, OH_IsConsignor, OH_IsTransportClient, OH_IsWarehouseClient, OH_IsForwarder, OH_IsShippingProvider, OH_IsAirWholesaler, OH_IsSeaWholesaler, OH_IsRailProvider, OH_IsLineHaulProvider, OH_IsMiscFreightServices, OH_IsAirCTO, OH_IsAirLine, OH_IsBroker, OH_IsContainerYard, OH_IsLocalTransport, OH_IsPackDepot, OH_IsSeaCTO, OH_IsShippingLine, OH_IsUnpackDepot, OH_IsRailHead, OH_IsRoadFreightDepot, OH_IsShippingConsortium, OH_IsFumigationContractor, OH_IsNationalAccount, OH_IsSalesLead, OH_IsUserFlag13, OH_IsUserFlag12, OH_IsUserFlag14, OH_IsUserFlag11, OH_IsCompetitor, OH_IsTempAccount, OH_IsPersonalEffectsAccount, OH_IsUserFlag1, OH_IsUserFlag2, OH_IsUserFlag3, OH_IsUserFlag4, OH_IsUserFlag5, OH_IsUserFlag6, OH_IsUserFlag7, OH_IsUserFlag8, OH_IsUserFlag9, OH_IsUserFlag10, OH_IsValid, OH_IsGlobalAccount, OH_FullName, OH_IsDistributionCentre, OH_IsUserFlag15, OH_IsUserFlag16, OH_IsUserFlag17, OH_IsUserFlag18, OH_IsUserFlag19, OH_IsUserFlag20, OH_IsUserFlag21, OH_IsUserFlag22, OH_IsUserFlag23, OH_IsUserFlag24, OH_IsControllingCustomer, OH_IsControllingAgent, OH_Category, OH_ScreeningStatus, OH_RSL_ShippingLine, OH_AutoVersion, OH_IsUserFlag25, OH_IsUserFlag26, OH_IsUserFlag27, OH_IsUserFlag28, OH_IsUserFlag29, OH_IsUserFlag30, OH_IsUserFlag31, OH_IsUserFlag32, OH_IsFerryWaterTerminal, OH_IsContainerLeasingCompany, OH_OverrideAdditionalAddressInformation, OH_IsInlandWaterwayProvider, OH_IsVGMContractor)
VALUES
('B7DF88AA-ED24-4163-B439-0D10D7623649', 'MEISINYTN', 'CNYTN', 'EN', '2025-08-20 23:36:00.000', '~AD', '2021-12-09 16:49:00.000', 'CLL', 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 'MEIYUME (SINGAPORE) PTE.LIMITED', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'BUS', 'UNK', NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
```

**Add to test-schema-sqlserver-minimal.sql (after existing OrgHeader inserts):**
```sql
INSERT INTO OrgHeader (OH_PK, OH_Code, OH_SystemLastEditTimeUtc, OH_SystemLastEditUser, OH_SystemCreateTimeUtc, OH_SystemCreateUser, OH_IsActive, OH_IsValid, OH_FullName)
VALUES
('B7DF88AA-ED24-4163-B439-0D10D7623649', 'MEISINYTN', '2025-08-20 23:36:00.000', '~AD', '2021-12-09 16:49:00.000', 'CLL', 1, 1, 'MEIYUME (SINGAPORE) PTE.LIMITED');
```

**Note about YANTFUSHA:** This organization is referenced in the AR_INV test file but the full OrgHeader record is not present in the test data files analyzed. Need to investigate further to get complete record details.

### 3. Test-Specific Records (Keep in Individual Files)

The following records contain test-specific transaction data and should remain in their respective files:

#### AccTransactionHeader Records
- All transaction header records are test-specific
- Each contains unique transaction numbers and job references
- **Action:** KEEP in individual test files

#### AccTransactionLines Records  
- All transaction line records are test-specific
- Link to specific AccTransactionHeader records
- **Action:** KEEP in individual test files

#### JobHeader, JobShipment Records
- All job-related records are test-specific
- Contain unique job numbers and shipment details
- **Action:** KEEP in individual test files

#### JobCharge Records
- All job charge records are test-specific
- Link to specific jobs and transactions
- **Action:** KEEP in individual test files

## Consolidation Execution Plan

### Phase 1: Schema File Updates

**Step 1.1: Update test-schema-sqlserver.sql**
```bash
# Add OCHC and OCLR AccChargeCode records
# Add MEISINYTN OrgHeader record  
# Location: After existing reference data inserts
```

**Step 1.2: Update test-schema-sqlserver-minimal.sql** 
```bash
# Add OCHC and OCLR AccChargeCode records (minimal columns)
# Add MEISINYTN OrgHeader record (minimal columns)
# Location: After existing reference data inserts
```

### Phase 2: Test File Cleanup

**Step 2.1: Clean test-data-cargowise-AS20250818_2.sql**
```bash
# Remove DOC AccChargeCode insert (lines 5-7)
# Remove FRT AccChargeCode insert (line 9) 
# Remove OECGRPORD OrgHeader insert (lines 12-13)
```

**Step 2.2: Clean test-data-cargowise-AS20250819_3.sql**
```bash
# Remove DOC AccChargeCode insert (lines 6)
# Remove AMS AccChargeCode insert (lines 8)
# Remove MEISINYTN OrgHeader insert (lines 13)
```

**Step 2.3: Clean test-data-cargowise-AR_INV_AS20250819_3.sql**
```bash
# Remove OCHC AccChargeCode insert (lines 6)
# Remove OCLR AccChargeCode insert (lines 7)
# Note: Keep transaction and job records as they are test-specific
```

### Phase 3: Validation Steps

**Step 3.1: Schema Validation**
```sql
-- Verify new records exist in schema files
SELECT AC_Code, AC_Desc FROM AccChargeCode WHERE AC_Code IN ('OCHC', 'OCLR');
SELECT OH_Code, OH_FullName FROM OrgHeader WHERE OH_Code IN ('MEISINYTN');
```

**Step 3.2: Test File Validation** 
```bash
# Verify no duplicate INSERT statements remain
grep -n "INSERT INTO AccChargeCode.*DOC\|FRT\|AMS\|OCHC\|OCLR" test-data-cargowise-*.sql
grep -n "INSERT INTO OrgHeader.*OECGRPORD\|MEISINYTN" test-data-cargowise-*.sql
```

**Step 3.3: Integration Test Validation**
```bash
# Run affected integration tests to ensure they still pass
./mvnw test -Dtest=APInvoiceAS20250818_2IntegrationTest
./mvnw test -Dtest=APCreditNoteAS20250819_3IntegrationTest  
./mvnw test -Dtest=ARInvoiceAS20250819_3IntegrationTest
```

## Risk Assessment

### Low Risk
- AccChargeCode consolidation (well-defined structure)
- GlbCompany/GlbBranch/GlbDepartment (already consolidated)

### Medium Risk  
- OrgHeader consolidation (complex structure with many columns)
- YANTFUSHA record investigation needed

### High Risk
- None identified at this stage

## Next Steps for Execution Session

1. **Immediate Actions:**
   - Update both schema files with new AccChargeCode records (OCHC, OCLR)
   - Update both schema files with new OrgHeader record (MEISINYTN)
   - Remove duplicate records from test files per cleanup plan

2. **Investigation Required:**
   - Locate complete YANTFUSHA OrgHeader record details
   - Verify no other unique records were missed in minimal test files

3. **Testing Required:**
   - Run all affected integration tests
   - Verify no test failures after consolidation
   - Check for any runtime dependency issues

## File Change Summary

| File | Add Lines | Remove Lines | Net Change |
|------|-----------|--------------|------------|
| test-schema-sqlserver.sql | +6 | 0 | +6 |
| test-schema-sqlserver-minimal.sql | +4 | 0 | +4 |
| test-data-cargowise-AS20250818_2.sql | 0 | -6 | -6 |
| test-data-cargowise-AS20250819_3.sql | 0 | -4 | -4 |
| test-data-cargowise-AR_INV_AS20250819_3.sql | 0 | -2 | -2 |
| **Total** | **+10** | **-12** | **-2** |

## Success Criteria

✅ All duplicate reference data removed from test files  
✅ All unique reference data added to schema files  
✅ All integration tests continue to pass  
✅ No new test failures introduced  
✅ Reference data properly centralized  

---

**Session Handover Status:** ✅ COMPLETE - Ready for Execution  
**Next Session Owner:** Execute consolidation plan above  
**Estimated Execution Time:** 30-45 minutes  
**Priority:** Medium (improves maintainability, reduces duplication)