# Currency Code Enhancement - Session 01

## Objective
Modify TransactionChargeLineRequestBean.java constructors to extract currency from charge-line level instead of inheriting from header.

## Requirements
- For AP ledger: Extract currency from `$.CostOSCurrency.Code`
- For AR ledger: Extract currency from `$.SellOSCurrency.Code`  
- Ensure graceful fallback to header currency if charge-line currency is missing

## Current Implementation Analysis
- `TransactionChargeLineRequestBean` currently inherits currency from `TransactionInfoRequestBean` via `BeanUtils.copyProperties()`
- Currency is set at header level and all charge lines inherit the same currency
- Need to modify constructors to extract currency at individual charge line level

## JSON Structure Analysis
Based on real payload examples:

### AR Transaction Structure
```json
"ChargeLine": {
    "ChargeCode": {...},
    "SellOSAmount": 360.0,
    "SellOSCurrency": {
        "Code": "CNY",
        "Description": "Chinese Yuan"
    }
}
```

### AP Transaction Structure  
```json
"ChargeLine": {
    "ChargeCode": {...},
    "CostOSAmount": -450.0,
    "CostOSCurrency": {
        "Code": "CNY", 
        "Description": "Chinese Yuan"
    }
}
```

## Implementation Plan
1. Modify the main constructor in `TransactionChargeLineRequestBean.java`
2. Add currency extraction logic based on ledger type
3. Implement graceful fallback to header currency
4. Test the changes

## Files to Modify
- `/home/yinchao/erpportal/cpar/src/main/java/oec/lis/erpportal/addon/compliance/model/transaction/TransactionChargeLineRequestBean.java`

## Next Steps
Proceed with implementation in session 02.