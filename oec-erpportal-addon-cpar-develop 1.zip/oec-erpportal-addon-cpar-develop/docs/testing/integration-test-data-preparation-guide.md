# Integration Test Data Preparation Guide

## Overview

This guide provides a comprehensive step-by-step procedure for preparing data to create new integration tests for the CPAR API system. Following this guide ensures consistent, complete, and maintainable integration tests similar to the successful `APInvoiceAS20250818_2IntegrationTest`.

## Prerequisites

- Access to production Cargowise database (or realistic test data)
- Understanding of the transaction type being tested
- JSON payload from actual system usage
- Knowledge of expected business logic behavior

---

## Step-by-Step Data Preparation Procedure

### **Phase 1: Gather the Transaction Data**

#### Step 1.1: Obtain the JSON Payload
**What you need:**
- The actual JSON request payload that will be sent to `/external/v1/ARTransaction`
- This should be a complete UniversalTransaction JSON structure from real system usage

**Action Items:**
1. **Capture from logs** or export from source system
2. **Save as:** `reference/[TRANSACTION_TYPE]_[TRANSACTION_NUMBER].json`
   - Examples: `reference/AR_INV_SH20250819_1.json`, `reference/AP_CRD_AS20250820_5.json`
3. **Validate JSON structure** using JSON validator
4. **Remove sensitive data** if present (customer details, amounts can be sanitized)

**Key data points to document:**
```json
{
  "TransactionInfo.Number": "Transaction number/reference",
  "TransactionInfo.Ledger": "AP/AR", 
  "TransactionInfo.Type": "INV/CRD/etc",
  "TransactionInfo.Organization.Code": "Organization code",
  "JobCollection.Job[0].JobNumber": "Job/Shipment reference",
  "LocalTotal": "Total amount",
  "LocalCurrency.Code": "Currency code"
}
```

#### Step 1.2: Identify Transaction Characteristics
**Document these details in a text file:**

**Basic Information:**
- Transaction Type: (e.g., AP_INV, AR_INV, AR_CRD, AP_CRD)
- Transaction Number/Reference
- Transaction Date
- Currency and total amount
- Organization Code (creditor/debtor)

**Transaction Properties:**
- Is it a reversal? (contains "_Reversed" suffix or isCancelled = true)
- Job Type: SHIPMENT or CONSOL (affects database queries)
- Number of charge lines
- Contains VAT/Tax? (affects calculations)
- Multi-currency? (requires exchange rate handling)

**Business Context:**
- Expected routing (Database only or External system)
- Special validation rules
- Edge cases or unique requirements

### **Phase 2: Extract Cargowise (SQL Server) Test Data**

#### Step 2.1: Identify Required Database Records
**Use these queries to extract data from production Cargowise database:**

**Start with the main transaction:**
```sql
-- Find the main transaction header
SELECT * FROM AccTransactionHeader 
WHERE AH_TransactionNum = 'YOUR_TRANSACTION_NUMBER'
AND AH_Ledger = 'AP/AR' 
AND AH_TransactionType = 'INV/CRD';
```

**Get transaction lines:**
```sql
-- Find all transaction lines
SELECT * FROM AccTransactionLines 
WHERE AL_AH = 'HEADER_PK_FROM_ABOVE';
```

**Get job information:**
```sql
-- Find job header
SELECT * FROM JobHeader 
WHERE JH_PK = 'JOB_PK_FROM_TRANSACTION_HEADER';

-- Find shipment or consol details
SELECT * FROM JobShipment WHERE JS_PK = 'SHIPMENT_PK';
-- OR
SELECT * FROM jobconsol WHERE jn_pk = 'CONSOL_PK';
```

#### Step 2.2: Extract Supporting Reference Data
**For each unique code/reference in the transaction, extract:**

**Charge Codes:**
```sql
SELECT * FROM AccChargeCode 
WHERE AC_PK IN ('CHARGE_CODE_PKS_FROM_LINES');
```

**Organizations:**
```sql
SELECT * FROM OrgHeader 
WHERE OH_PK IN ('ORG_PKS_FROM_TRANSACTION');
```

**Company Structure:**
```sql
SELECT * FROM GlbCompany WHERE GC_PK = 'COMPANY_PK';
SELECT * FROM GlbBranch WHERE GB_PK = 'BRANCH_PK';  
SELECT * FROM GlbDepartment WHERE GE_PK = 'DEPARTMENT_PK';
```

**Job Charges (if applicable):**
```sql
SELECT * FROM JobCharge 
WHERE JR_JH = 'JOB_HEADER_PK' 
AND JR_APInvoiceNum = 'TRANSACTION_NUM';
```

#### Step 2.3: Create SQL Insert Statements
**Convert extracted data to INSERT statements:**

1. **Generate GUIDs** - Use new UUIDs for test data to avoid conflicts
2. **Maintain relationships** - Keep foreign key relationships intact
3. **Follow dependency order:**
   - AccChargeCode (no dependencies)
   - OrgHeader (no dependencies)  
   - GlbCompany, GlbBranch, GlbDepartment (company structure)
   - JobHeader (references company structure)
   - JobShipment/jobconsol (references JobHeader)
   - AccTransactionHeader (references job, org, company)
   - AccTransactionLines (references header, job, charges)
   - JobCharge (references job, charges, optional)

**Save as:** `src/test/resources/test-data-cargowise-[TRANSACTION_NUMBER].sql`

### **Phase 3: Define Expected Outcomes**

#### Step 3.1: Expected SOPL Database Records
**Document what should be created in PostgreSQL SOPL database:**

**at_account_transaction_header (1 record):**
```markdown
| Field | Expected Value |
|-------|---------------|
| ledger | AP/AR |
| trans_type | INV/CRD |
| trans_no | [Transaction number] |
| inv_org_code | [Organization code] |
| inv_amt | [Invoice amount] |
| outstanding_amt | [Outstanding amount] |
| total_vat_amt | [Total VAT amount] |
| local_crncy_code | [Local currency] |
| ref_no | [Job reference] |
| cmpny_code | [Company code] |
| cancelled | false/true |
```

**at_account_transaction_lines (N records):**
For each charge line, document:
```markdown
| Field | Expected Value |
|-------|---------------|
| trans_line_desc | [Charge description] |
| chrg_amt | [Charge amount] |
| vat_amt | [VAT amount] |
| total_amt | [Total amount] |
| crncy_code | [Currency code] |
| exchg_rate | [Exchange rate] |
```

**at_shipment_info (1 record, if SHIPMENT):**
```markdown
| Field | Expected Value |
|-------|---------------|
| ref_no | [Job number] |
| shipment_no | [Shipment number] |
| hbl_no | [House bill number] |
| mbl_no | [Master bill number] |
| shipment_type | [FCL/LCL/etc] |
```

**sys_api_log (1 record):**
```markdown
| Field | Expected Value |
|-------|---------------|
| action_name | CPAR-API-UniversalTransaction |
| api_name | API14 |
| api_status | DONE/ERROR/REJECTED |
| api_response | JSON with processing results |
```

#### Step 3.2: Routing Decision Expectations
**Specify expected routing behavior:**

**Service Call Expectations:**
- `shouldSendToExternalSystem(ledger, type, number)` → true/false
- Expected number of calls: (Number of charge lines + 1 controller call)
- `getRoutingMode()` → "LEGACY"/"STANDARD"

**External System Integration:**
- Should go to external system? Yes/No
- If yes, Kafka message expected? Yes/No
- Expected Kafka topic: `{profile}-invoice-outbound`
- Number of Kafka messages: (typically 1 per charge line)

**API Response:**
- Expected HTTP status: 202 Accepted
- Response body should contain: Transaction type, processing result, Track ID
- Expected headers: X-Track-ID, X-API-ID

### **Phase 4: Create Test Documentation**

#### Step 4.1: Create Test Description Document
**Create:** `TEST_DESCRIPTION.md`

**Include these sections:**
```markdown
## Transaction Overview
- Type: [AP_INV/AR_INV/etc]
- Number: [Transaction number]
- Amount: [Total amount and currency]
- Organization: [Code and name]
- Job Type: [SHIPMENT/CONSOL]
- Special Handling: [Any unique requirements]

## Business Rules
- Routing: [Database only / External system]
- Validation: [Special validation rules]
- Edge Cases: [What makes this test unique]

## Test Scenarios to Cover
1. [Complete processing flow]
2. [Header data persistence]
3. [Lines data persistence]
4. [Special validations]
...

## Success Criteria
- [Database record expectations]
- [Service call expectations] 
- [Response format expectations]
```

#### Step 4.2: Document Expected Calculations
**If the transaction involves:**

**Currency Conversion:**
```markdown
- Original Amount: 100.00 USD
- Exchange Rate: 7.25
- Expected Local Amount: 725.00 CNY
```

**VAT/Tax Calculations:**
```markdown
- Base Amount: 1000.00 CNY
- VAT Rate: 6%
- VAT Amount: 60.00 CNY
- Total with VAT: 1060.00 CNY
```

**Multi-line Totals:**
```markdown
Line 1: 1000.00 CNY
Line 2: 150.00 CNY  
Line 3: 100.00 USD = 725.00 CNY
Total: 1875.00 CNY
```

### **Phase 5: Organize the Data Package**

#### Step 5.1: Create Folder Structure
**Organize files as:**
```
new_test_data/
├── payload/
│   └── [TRANSACTION_TYPE]_[NUMBER].json
├── cargowise_data/
│   └── test-data-cargowise-[NUMBER].sql
├── expected_results/
│   ├── expected_database_records.md
│   └── expected_routing_behavior.md
├── TEST_DESCRIPTION.md
└── test_preferences.md
```

#### Step 5.2: Create Test Preferences File
**Create:** `test_preferences.md`

**Specify:**
```markdown
## Test Implementation Preferences

### Test Class Decision
- [ ] Add to existing APInvoiceAS20250818_2IntegrationTest
- [x] Create new test class: [ClassName]IntegrationTest

### Test Methods Required
- [x] Complete processing flow
- [x] Header data persistence  
- [x] Lines data persistence
- [ ] VAT calculation validation
- [ ] Currency conversion validation
- [x] Routing decision validation
- [x] API log creation

### Special Requirements
- Performance: < 60 second execution
- Memory: Standard TestContainer requirements
- Cleanup: Full database cleanup after test
- Assertions: Field-level validation required
```

### **Phase 6: Validation and Quality Checks**

#### Step 6.1: Data Validation Checklist
**Before providing the data package, verify:**

**JSON Payload:**
- [ ] Valid JSON syntax
- [ ] Complete UniversalTransaction structure
- [ ] All required fields present
- [ ] Sensitive data removed/sanitized
- [ ] Transaction references match test data

**Cargowise SQL Data:**
- [ ] All INSERT statements have valid syntax
- [ ] GUIDs are properly formatted and unique
- [ ] Foreign key relationships are correct
- [ ] All referenced tables are included
- [ ] Data represents realistic business scenario

**Expected Results:**
- [ ] Database record counts are specified
- [ ] Field-level expectations are documented
- [ ] Amount calculations are verified
- [ ] Currency conversions are correct (if applicable)
- [ ] VAT calculations are accurate (if applicable)

**Routing Expectations:**
- [ ] Service call expectations are clear
- [ ] External system behavior is specified
- [ ] Kafka message expectations are documented
- [ ] API response format is defined

#### Step 6.2: Completeness Review
**Ensure you have provided:**

**Essential Components:**
- [x] JSON payload file
- [x] Complete Cargowise SQL data
- [x] Expected database records documentation  
- [x] Routing behavior expectations
- [x] Test description and business context

**Supporting Information:**
- [x] Test implementation preferences
- [x] Special handling requirements
- [x] Calculation verification (if applicable)
- [x] Edge cases and validation rules

---

## Quick Reference Templates

### **File Naming Conventions**
```
JSON Payload: reference/[LEDGER]_[TYPE]_[IDENTIFIER].json
SQL Data: src/test/resources/test-data-cargowise-[IDENTIFIER].sql
Test Class: [Type][Identifier]IntegrationTest.java
Documentation: TEST_DOCUMENTATION_[TYPE]_[IDENTIFIER].md
```

### **Common Transaction Types**
- **AP_INV**: Accounts Payable Invoice
- **AP_CRD**: Accounts Payable Credit Note  
- **AR_INV**: Accounts Receivable Invoice
- **AR_CRD**: Accounts Receivable Credit Note
- **AP_INV_Reversed**: Reversed AP Invoice
- **AR_INV_Reversed**: Reversed AR Invoice

### **Required Database Tables (Minimum)**
```sql
-- Always needed
AccChargeCode, OrgHeader
GlbCompany, GlbBranch, GlbDepartment  
AccTransactionHeader, AccTransactionLines

-- Job-dependent
JobHeader + (JobShipment OR jobconsol)

-- Optional but recommended
JobCharge (for cost/revenue details)
```

### **Test Method Naming Patterns**
```java
testCompleteProcessingFlow()
testTransactionHeaderDataPersistence()
testTransactionLinesDataPersistence()
testShipmentInfoDataPersistence() // if SHIPMENT
testConsolInfoDataPersistence()   // if CONSOL
testRoutingDecisionValidation()
testApiLogCreation()
testVATCalculation()              // if applicable
testCurrencyConversion()          // if applicable
```

---

## Troubleshooting Common Issues

### **Data Extraction Problems**
- **Missing relationships**: Use proper JOINs to find all related data
- **Incorrect GUIDs**: Ensure foreign key relationships are maintained in test data
- **Incomplete data**: Verify all referenced codes exist in supporting tables

### **JSON Payload Issues**  
- **Invalid structure**: Validate against UniversalTransaction schema
- **Missing fields**: Compare with working examples
- **Wrong transaction type**: Verify Ledger and Type match database records

### **Expected Results Mismatches**
- **Amount calculations**: Verify exchange rates and VAT calculations
- **Field mapping**: Check actual vs expected column names in SOPL schema
- **Record counts**: Account for all charge lines and supporting records

### **Routing Logic Confusion**
- **AP transactions**: Typically database-only in LEGACY mode
- **AR transactions**: May go to external system depending on configuration
- **Service call counts**: Remember N charge lines + 1 controller call
- **Kafka expectations**: Only if external system routing is enabled

---

## Success Indicators

### **Well-Prepared Data Package Has:**
✅ **Complete JSON payload** with realistic transaction data  
✅ **Comprehensive SQL data** with all necessary relationships  
✅ **Clear expected results** with field-level accuracy  
✅ **Documented business rules** and special handling  
✅ **Routing behavior** clearly specified  
✅ **Test preferences** and implementation guidance  

### **Ready for Implementation When:**
✅ All files validate successfully (JSON syntax, SQL syntax)  
✅ Data relationships are consistent and complete  
✅ Expected results match business logic understanding  
✅ Edge cases and special requirements are documented  
✅ Test scenarios are clearly defined  

**Following this guide ensures creation of robust, maintainable integration tests that provide complete confidence in the CPAR API transaction processing pipeline.**