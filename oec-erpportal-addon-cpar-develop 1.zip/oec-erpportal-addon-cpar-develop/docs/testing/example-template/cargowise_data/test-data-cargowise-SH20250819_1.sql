-- Test data for AR_INV_SH20250819_1 integration test
-- Complete Cargowise database records for the transaction
-- IMPORTANT: Use these exact GUIDs to maintain referential integrity

-- AccChargeCode table - Charge codes used in the transaction
-- AccChargeCode records have been moved to schema files

-- OrgHeader table - Customer organization
-- OrgHeader records have been moved to schema files

-- Company structure tables
-- GlbCompany, GlbBranch, and GlbDepartment records have been moved to schema files

-- 4. JobHeader table - Shipment job
INSERT INTO JobHeader (
    JH_PK, JH_JobNum, JH_Status, JH_ParentID, JH_HeaderType, JH_Name, JH_Description,
    JH_JobLocalReference, JH_ClientReference, JH_IsActive, JH_ParentTableCode,
    JH_GB, JH_GE, JH_GC, JH_SystemCreateTimeUtc, JH_SystemCreateUser, 
    JH_SystemLastEditTimeUtc, JH_SystemLastEditUser
)
VALUES(
    '88888888-8888-8888-8888-888888888888', 'SSSH1250819001', 'CMP', 
    '99999999-9999-9999-9999-999999999999', 'JOB', 'Test Shipment Job', 'AR Invoice Test Shipment',
    'PO-2025-08190001', 'PO-2025-08190001', 1, 'JS',
    '66666666-6666-6666-6666-666666666666', '77777777-7777-7777-7777-777777777777',
    '55555555-5555-5555-5555-555555555555', '2025-08-19 02:00:00.000', 'TST',
    '2025-08-19 10:30:00.000', 'TST'
);

-- 5. JobShipment table - Shipment details
INSERT INTO JobShipment (
    JS_PK, JS_ShipmentStatus, JS_UniqueConsignRef, JS_InterimReceipt, JS_HouseBill, 
    JS_MasterBill, JS_BookingReference, JS_GoodsDescription, JS_TransportMode, JS_PackingMode, 
    JS_ActualVolume, JS_DocumentedVolume, JS_ManifestedVolume, JS_UnitOfVolume,
    JS_ActualWeight, JS_DocumentedWeight, JS_ManifestedWeight, JS_UnitOfWeight,
    JS_TotalPackageCount, JS_OuterPacks, JS_IsValid,
    JS_SystemCreateTimeUtc, JS_SystemCreateUser, JS_SystemLastEditTimeUtc, JS_SystemLastEditUser
)
VALUES(
    '99999999-9999-9999-9999-999999999999', 'CMP', 'SSSH1250819001', '', 'OESH202508190001', 
    'MAEU123456789', 'BKG202508190001', 'Test Export Goods', 'SEA', 'FCL',
    28.50, 28.50, 28.50, 'M3', 
    12500.00, 12500.00, 12500.00, 'KG',
    1, 1, 1,
    '2025-08-19 02:00:00.000', 'TST', '2025-08-19 10:30:00.000', 'TST'
);

-- 6. AccTransactionHeader table - Main AR invoice
INSERT INTO AccTransactionHeader (
    AH_PK, AH_Ledger, AH_TransactionType, AH_TransactionNum, AH_TransactionCount,
    AH_TransactionReference, AH_Desc, AH_InvoiceDate, AH_TransactionCategory, AH_DueDate,
    AH_InvoiceAmount, AH_GSTAmount, AH_WithholdingTax, AH_OSTotal, AH_ExchangeRate,
    AH_AgePeriod, AH_PostPeriod, AH_PostDate, AH_ReceiptType, AH_OutstandingAmount,
    AH_PostToGL, AH_InvoiceTerm, AH_InvoiceTermDays, AH_ExportBatchNumber,
    AH_OH, AH_JH, AH_GB, AH_GE, AH_GC, AH_RX_NKTransactionCurrency, AH_IsCancelled,
    AH_SystemCreateTimeUtc, AH_SystemCreateUser, AH_SystemLastEditTimeUtc, AH_SystemLastEditUser
)
VALUES(
    'AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA', 'AR', 'INV', 'SH20250819_1', 1,
    'PO-2025-08190001', 'OESH202508190001', '2025-08-19 00:00:00.000', 'STD', '2025-09-18 00:00:00.000',
    1935.00, 60.00, 0.0000, 100.00, 1.000000000,
    0, 0, '2025-08-19 00:00:00.000', '   ', 1935.00,
    'N', 'NET', 30, 0,
    'D9E232B5-BBE5-4681-B747-040F24FA4AF6', '88888888-8888-8888-8888-888888888888',
    '9652C78F-53ED-4DC2-B70D-D921C165A3B0', '57F778C1-DAF6-46E0-B7DC-AF01C161C936',
    '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', 'CNY', 0,
    '2025-08-19 10:30:00.000', 'TST', '2025-08-19 10:30:00.000', 'TST'
);

-- 7. AccTransactionLines table - Invoice line items
INSERT INTO AccTransactionLines (
    AL_PK, AL_LineType, AL_Sequence, AL_Desc, AL_LineAmount, AL_GSTVAT, AL_WithholdingTax,
    AL_UnitQty, AL_UnitPrice, AL_OSUnitPrice, AL_OSAmount, AL_ExchangeRate,
    AL_PostPeriod, AL_PostDate, AL_PostToGL, AL_AH, AL_JH, AL_AC, AL_GE, AL_GB, AL_OH, AL_GC,
    AL_RX_NKTransactionCurrency, AL_RevRecognitionType, AL_InputGSTVATRecoverable,
    AL_SystemCreateTimeUtc, AL_SystemCreateUser, AL_SystemLastEditTimeUtc, AL_SystemLastEditUser
)
VALUES
-- Line 1: Ocean Freight (with 6% VAT)
(
    'BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB', 'REV', 1, 'Ocean Freight - Shanghai to Los Angeles',
    1000.00, 60.00, 0.0000, 1, 1000.0000, 1000.0000, 1000.00, 1.000000000,
    0, '2025-08-19 00:00:00.000', 'N', 'AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA',
    '88888888-8888-8888-8888-888888888888', 'CE0AF0E4-E31D-40B0-8F9B-12E189F3348A',
    '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0',
    'D9E232B5-BBE5-4681-B747-040F24FA4AF6', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4',
    'CNY', 'DEP', 1.0000,
    '2025-08-19 10:30:00.000', 'TST', '2025-08-19 10:30:00.000', 'TST'
),
-- Line 2: Documentation Fee (no VAT)
(
    'CCCCCCCC-CCCC-CCCC-CCCC-CCCCCCCCCCCC', 'REV', 2, 'Export Documentation',
    150.00, 0.00, 0.0000, 1, 150.0000, 150.0000, 150.00, 1.000000000,
    0, '2025-08-19 00:00:00.000', 'N', 'AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA',
    '88888888-8888-8888-8888-888888888888', 'C725B20C-1CE9-497E-84BD-2D79EB697067',
    '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0',
    'D9E232B5-BBE5-4681-B747-040F24FA4AF6', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4',
    'CNY', 'DEP', 1.0000,
    '2025-08-19 10:30:00.000', 'TST', '2025-08-19 10:30:00.000', 'TST'
),
-- Line 3: Terminal Handling (USD converted to CNY)
(
    'DDDDDDDD-DDDD-DDDD-DDDD-DDDDDDDDDDDD', 'REV', 3, 'Terminal Handling - Shanghai Port',
    725.00, 0.00, 0.0000, 1, 725.0000, 100.0000, 100.00, 7.250000000,
    0, '2025-08-19 00:00:00.000', 'N', 'AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA',
    '88888888-8888-8888-8888-888888888888', '6EFBC528-6B4E-41F8-A84F-67096D0CE8FA',
    '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0',
    'D9E232B5-BBE5-4681-B747-040F24FA4AF6', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4',
    'USD', 'DEP', 1.0000,
    '2025-08-19 10:30:00.000', 'TST', '2025-08-19 10:30:00.000', 'TST'
);

-- JobCharge table - Revenue details (optional but recommended for validation)
-- All records have JR_E6 = NULL indicating SHIPMENT type (not CONSOL)
INSERT INTO JobCharge (
    JR_PK, JR_JH, JR_GE, JR_GB, JR_LineCFX, JR_AC, JR_Desc, JR_OH_CostAccount,
    JR_OSCostAmt, JR_AgentDeclaredCostAmt, JR_LocalCostAmt, JR_OSCostExRate,
    JR_AT_CostGSTRate, JR_OSCostGSTAmt, JR_AW_CostWHTRate, JR_OSCostWHTAmt,
    JR_APLinePostingStatus, JR_APInvoiceNum, JR_APInvoiceDate, JR_PaymentDate,
    JR_PaymentType, JR_AK, JR_AB, JR_AL_APLine, JR_DeclaredOSCostAmt,
    JR_OH_SellAccount, JR_OSSellExRate, JR_OSSellAmt, JR_AgentDeclaredSellAmt,
    JR_LocalSellAmt, JR_AT_SellGSTRate, JR_AW_SellWHTRate, JR_OSSellWHTAmt,
    JR_AL_ARLine, JR_AL_CFXLine, JR_ChargeType, JR_MarginPercentage,
    JR_InvoiceType, JR_DisplaySequence, JR_ARLinePostingStatus, JR_OrderReference,
    JR_OP_Product, JR_ProductQuantity, JR_E6, JR_EstimatedCost, JR_EstimatedRevenue,
    JR_RX_NKCostCurrency, JR_RX_NKSellCurrency, JR_APNumberOfSupportingDocuments,
    JR_ARNumberOfSupportingDocuments, JR_A9_CostVATClass, JR_OA_SellInvoiceAddress,
    JR_OC_SellInvoiceContact, JR_A9_SellVATClass, JR_CostRated, JR_SellRated,
    JR_IsIncludedInProfitShare, JR_PreventInvoicePrintGrouping, JR_IsValid,
    JR_CostRatingOverride, JR_ProFormaCost, JR_SellRatingOverride, JR_ProFormaRevenue,
    JR_ChequeNo, JR_SellReference, JR_CostReference, JR_JH_InternalJob,
    JR_GE_InternalDept, JR_GB_InternalBranch, JR_GC, JR_E6_GatewaySellHeader,
    JR_JR_RevenueLine, JR_LineType, JR_CostGovtChargeCode, JR_RX_NKSellInvoiceCurrency,
    JR_SellGovtChargeCode, JR_IsCostTaxAmountOverridden, JR_CostTaxDate,
    JR_SellTaxDate, JR_CostPlaceOfSupply, JR_CostPlaceOfSupplyType,
    JR_SellPlaceOfSupply, JR_SellPlaceOfSupplyType, JR_APDocumentReceivedDate,
    JR_AutoVersion, JR_SystemCreateTimeUtc, JR_SystemCreateUser,
    JR_SystemLastEditTimeUtc, JR_SystemLastEditUser, JR_CostSupplyType,
    JR_SellSupplyType, JR_CAL_APLine, JR_CAL_ARLine, JR_GB_CostTaxBranch,
    JR_GB_SellTaxBranch, JR_IsAPCashAdvance, JR_IsARCashAdvance, JR_IsSpotCost,
    JR_CostRatingOverrideComment, JR_SellRatingOverrideComment
)
VALUES
-- JobCharge 1: Ocean Freight Revenue
('EEEEEEEE-EEEE-EEEE-EEEE-EEEEEEEEEEEE', '88888888-8888-8888-8888-888888888888',
 '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', 0.000,
 'CE0AF0E4-E31D-40B0-8F9B-12E189F3348A', 'Ocean Freight - Shanghai to Los Angeles', 'D9E232B5-BBE5-4681-B747-040F24FA4AF6',
 0.0000, 0.0000, 0.0000, 1.000000000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', 0.0000, NULL, 0.0000,
 '', 'SH20250819_1', '2025-08-19 00:00:00.000', '2025-08-19 00:00:00.000',
 '   ', NULL, NULL, NULL, 0.0000, 'D9E232B5-BBE5-4681-B747-040F24FA4AF6', 1.000000000, 1000.0000, 0.0000,
 0.0000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', NULL, 0.0000, NULL, NULL, '', 0.00,
 'FIN', 1, '', '', NULL, 0.000, NULL, 1000.0000, 0.0000, 'CNY', 'CNY', 0, 0, NULL, NULL, NULL, NULL, 0, 0,
 0, 0, 0, 1, 0, 0, 0, '', '', '', NULL, NULL, NULL, '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', NULL, NULL, 'BTH', '', 'CNY',
 '', 1, '2025-08-19', NULL, '', '', '', '', NULL, 1, '2025-08-19 02:00:00.000', 'TST',
 '2025-08-19 10:30:00.000', 'TST', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', ''),

-- JobCharge 2: Documentation Fee Revenue  
('FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF', '88888888-8888-8888-8888-888888888888',
 '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', 0.000,
 'C725B20C-1CE9-497E-84BD-2D79EB697067', 'Export Documentation', 'D9E232B5-BBE5-4681-B747-040F24FA4AF6',
 0.0000, 0.0000, 0.0000, 1.000000000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', 0.0000, NULL, 0.0000,
 '', 'SH20250819_1', '2025-08-19 00:00:00.000', '2025-08-19 00:00:00.000',
 '   ', NULL, NULL, NULL, 0.0000, 'D9E232B5-BBE5-4681-B747-040F24FA4AF6', 1.000000000, 150.0000, 0.0000,
 0.0000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', NULL, 0.0000, NULL, NULL, '', 0.00,
 'FIN', 2, '', '', NULL, 0.000, NULL, 150.0000, 0.0000, 'CNY', 'CNY', 0, 0, NULL, NULL, NULL, NULL, 0, 0,
 0, 0, 0, 1, 0, 0, 0, '', '', '', NULL, NULL, NULL, '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', NULL, NULL, 'BTH', '', 'CNY',
 '', 1, '2025-08-19', NULL, '', '', '', '', NULL, 2, '2025-08-19 02:00:00.000', 'TST',
 '2025-08-19 10:30:00.000', 'TST', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', ''),

-- JobCharge 3: Terminal Handling Revenue (USD)
('10101010-1010-1010-1010-101010101010', '88888888-8888-8888-8888-888888888888',
 '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', 0.000,
 '6EFBC528-6B4E-41F8-A84F-67096D0CE8FA', 'Terminal Handling - Shanghai Port', 'D9E232B5-BBE5-4681-B747-040F24FA4AF6',
 0.0000, 0.0000, 0.0000, 7.250000000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', 0.0000, NULL, 0.0000,
 '', 'SH20250819_1', '2025-08-19 00:00:00.000', '2025-08-19 00:00:00.000',
 '   ', NULL, NULL, NULL, 0.0000, 'D9E232B5-BBE5-4681-B747-040F24FA4AF6', 7.250000000, 100.0000, 0.0000,
 0.0000, 'BFE5B8DB-14C0-4DB4-BB6B-B51A1D959C45', NULL, 0.0000, NULL, NULL, '', 0.00,
 'FIN', 3, '', '', NULL, 0.000, NULL, 100.0000, 0.0000, 'USD', 'USD', 0, 0, NULL, NULL, NULL, NULL, 0, 0,
 0, 0, 0, 1, 0, 0, 0, '', '', '', NULL, NULL, NULL, '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', NULL, NULL, 'BTH', '', 'USD',
 '', 1, '2025-08-19', NULL, '', '', '', '', NULL, 3, '2025-08-19 02:00:00.000', 'TST',
 '2025-08-19 10:30:00.000', 'TST', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '');

-- GUID Reference Summary for Validation:
-- 
-- Reference Data (from schema files):
-- AccChargeCode PKs: CE0AF0E4-E31D-40B0-8F9B-12E189F3348A (FRT), C725B20C-1CE9-497E-84BD-2D79EB697067 (DOC), 6EFBC528-6B4E-41F8-A84F-67096D0CE8FA (OCHC)
-- OrgHeader PKs: (refer to schema files - YANTFUSHA, OECGRPORD, etc.)
-- GlbCompany PK: 15C1F416-01D2-4ED2-9B5B-D032C4796DC4 (SH1)
-- GlbBranch PK: 9652C78F-53ED-4DC2-B70D-D921C165A3B0 (SH1)
-- GlbDepartment PK: 57F778C1-DAF6-46E0-B7DC-AF01C161C936 (FES)
-- 
-- Test-Specific Data:
-- JobHeader PK: 88888888-8888-8888-8888-888888888888 (SSSH1250819001)
-- JobShipment PK: 99999999-9999-9999-9999-999999999999 (SSSH1250819001)
-- AccTransactionHeader PK: AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA (SH20250819_1)
-- AccTransactionLines PKs: BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB (Line 1), CCCCCCCC-CCCC-CCCC-CCCC-CCCCCCCCCCCC (Line 2), DDDDDDDD-DDDD-DDDD-DDDD-DDDDDDDDDDDD (Line 3)
-- JobCharge PKs: EEEEEEEE-EEEE-EEEE-EEEE-EEEEEEEEEEEE, FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF, 10101010-1010-1010-1010-101010101010