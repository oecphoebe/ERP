# Expected Database Records for AR_INV_SH20250819_1

## PostgreSQL (SOPL) Database

### at_account_transaction_header (1 record)

| Field | Expected Value | Notes |
|-------|---------------|-------|
| ledger | AR | Accounts Receivable |
| trans_type | INV | Invoice |
| trans_no | SH20250819_1 | Transaction number |
| inv_org_code | TESTCUSTOMER01 | Customer organization code |
| inv_amt | 1935.00 | Total invoice amount |
| outstanding_amt | 1935.00 | Outstanding amount (same as invoice) |
| total_vat_amt | 60.00 | Total VAT amount |
| local_crncy_code | CNY | Local currency |
| ref_no | SSSH1250819001 | Job reference |
| cmpny_code | SH1 | Company code |
| cmpny_branch | SH1 | Branch code |
| cmpny_dept | FES | Department code |
| cancelled | false | Not cancelled |
| create_by | CPAR | Created by system |
| update_by | CPAR | Updated by system |

### at_account_transaction_lines (3 records)

#### Line 1 - Ocean Freight (with VAT)
| Field | Expected Value | Notes |
|-------|---------------|-------|
| trans_line_desc | Ocean Freight - Shanghai to Los Angeles | Charge description |
| chrg_amt | 1000.00 | Charge amount in CNY |
| vat_amt | 60.00 | VAT amount (6%) |
| total_amt | 1060.00 | Total with VAT |
| local_vat_amt | 60.00 | Local VAT amount |
| crncy_code | CNY | Currency code |
| exchg_rate | 1.000000000 | Exchange rate |
| cmpny_code | SH1 | Company code |
| cmpny_branch | SH1 | Branch code |
| cmpny_dept | FES | Department code |

#### Line 2 - Documentation Fee (no VAT)
| Field | Expected Value | Notes |
|-------|---------------|-------|
| trans_line_desc | Export Documentation | Charge description |
| chrg_amt | 150.00 | Charge amount in CNY |
| vat_amt | 0.00 | No VAT |
| total_amt | 150.00 | Total amount |
| local_vat_amt | 0.00 | No local VAT |
| crncy_code | CNY | Currency code |
| exchg_rate | 1.000000000 | Exchange rate |
| cmpny_code | SH1 | Company code |
| cmpny_branch | SH1 | Branch code |
| cmpny_dept | FES | Department code |

#### Line 3 - Terminal Handling (USD converted)
| Field | Expected Value | Notes |
|-------|---------------|-------|
| trans_line_desc | Terminal Handling - Shanghai Port | Charge description |
| chrg_amt | 100.00 | Original charge amount in USD |
| vat_amt | 0.00 | No VAT |
| total_amt | 725.00 | Converted amount in CNY |
| local_vat_amt | 0.00 | No local VAT |
| crncy_code | USD | Original currency |
| exchg_rate | 7.250000000 | USD to CNY exchange rate |
| local_crncy_code | CNY | Local currency |
| cmpny_code | SH1 | Company code |
| cmpny_branch | SH1 | Branch code |
| cmpny_dept | FES | Department code |

### at_shipment_info (1 record)

| Field | Expected Value | Notes |
|-------|---------------|-------|
| ref_no | SSSH1250819001 | Job reference |
| shipment_no | SSSH1250819001 | Shipment number |
| cnsl_no | null | Not a consol |
| hbl_no | OESH202508190001 | House bill number |
| mbl_no | MAEU123456789 | Master bill number |
| master_mbl | null | No master MBL |
| shipment_id | [UUID] | Generated shipment ID |
| master_shipment_id | null | No master shipment |
| carrier_booking_no | BKG202508190001 | Booking reference |
| etd | null | ETD not specified |
| atd | null | ATD not specified |
| ata | null | ATA not specified |
| shipment_type | FCL | Full container load |
| cnsl_type | null | Not a consol |
| container_mode | FCL | Container mode |
| container_list | [Empty string] | Container list |
| cnsl_first_leg_vessel | null | Not applicable |
| cnsl_first_leg_voyage | null | Not applicable |
| create_company | SH1 | Company code |
| create_branch | SH1 | Branch code |
| create_department | FES | Department code |
| create_by | CPAR | Created by system |

### sys_api_log (1 record)

| Field | Expected Value | Notes |
|-------|---------------|-------|
| action_id | [UUID] | Generated action ID |
| api_id | [UUID] | Generated API ID |
| action_name | CPAR-API-UniversalTransaction | Action name |
| api_name | API14 | API name |
| api_type | [Type] | API type |
| api_status | DONE | Successful processing |
| cw_status | null | Cargowise status |
| cnsl_no | null | Consol number |
| shipment_no | SSSH1250819001 | Shipment number |
| cmpny_code | SH1 | Company code |
| agent_org_code | null | Agent org code |
| api_parameters | [JSON] | Input parameters |
| api_response | [JSON] | Response data |
| update_by | CWIS | Updated by |

#### Expected api_response JSON Structure
```json
{
  "status": "DONE",
  "savedToDatabase": true,
  "sentToExternal": true,
  "kafkaEnabled": true,
  "messageCount": 3,
  "transactionProcessing": {
    "headerRecords": 1,
    "lineRecords": 3,
    "shipmentRecords": 1
  },
  "routing": {
    "mode": "STANDARD",
    "shouldSendToExternal": true,
    "externalSystemCalls": 4
  },
  "executionTime": "[execution time in ms]"
}
```

## Record Count Summary

| Table | Expected Count |
|-------|---------------|
| at_account_transaction_header | 1 |
| at_account_transaction_lines | 3 |
| at_shipment_info | 1 |
| sys_api_log | 1 |
| **Total Records** | **6** |

## Amount Calculations Verification

### Line-by-Line Breakdown
```
Line 1 (Ocean Freight):     1000.00 CNY + 60.00 VAT = 1060.00 CNY
Line 2 (Documentation):      150.00 CNY +  0.00 VAT =  150.00 CNY
Line 3 (Terminal Handling):  100.00 USD × 7.25 rate =  725.00 CNY (no VAT)
                           ──────────────────────────────────────────
Total Invoice Amount:                                 1935.00 CNY
Total VAT Amount:                                       60.00 CNY
```

### Currency Conversion Validation
- **USD to CNY Exchange Rate**: 7.25
- **USD Amount**: 100.00
- **Expected CNY Amount**: 725.00
- **Calculation**: 100.00 × 7.25 = 725.00 ✓

### VAT Calculation Validation
- **VAT Base Amount**: 1000.00 CNY (Ocean Freight only)
- **VAT Rate**: 6%
- **Expected VAT Amount**: 60.00 CNY
- **Calculation**: 1000.00 × 0.06 = 60.00 ✓