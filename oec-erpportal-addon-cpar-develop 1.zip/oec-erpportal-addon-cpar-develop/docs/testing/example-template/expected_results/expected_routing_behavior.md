# Expected Routing Behavior for AR_INV_SH20250819_1

## Routing Decision Analysis

### Transaction Classification
- **Ledger**: AR (Accounts Receivable)
- **Transaction Type**: INV (Invoice)  
- **Transaction Number**: SH20250819_1
- **Expected Routing**: External System (typical for AR transactions)

### Service Call Expectations

#### shouldSendToExternalSystem() Calls
- **Expected Result**: `true` (AR invoices typically go to external system)
- **Call Pattern**: Called once per charge line + once at controller level
- **Expected Total Calls**: 4 times
  - Call 1: ChargeLineProcessor for FRT charge
  - Call 2: ChargeLineProcessor for DOC charge  
  - Call 3: ChargeLineProcessor for THC charge
  - Call 4: UniversalController for overall routing decision

#### getRoutingMode() Calls
- **Expected Result**: "STANDARD" (modern routing mode)
- **Call Pattern**: Called at least once during processing
- **Usage**: Determines routing behavior and response message format

### External System Integration

#### Kafka Message Expectations
- **Kafka Enabled**: YES (external system routing requires Kafka)
- **Messages Sent**: YES (should send transaction to external system)
- **Expected Topic**: `{profile}-invoice-outbound` (e.g., `test-invoice-outbound`)
- **Message Count**: 3 messages (one per charge line)
- **Message Format**: Each message contains individual charge line data

#### Message Content Structure
Each Kafka message should contain:
```json
{
  "billNo": "SH20250819_1",
  "transactionType": "INV",
  "billDate": "2025-08-19T00:00:00",
  "companyCode": "SH1",
  "branchCode": "SH1", 
  "departmentCode": "FES",
  "currency": "CNY", // or "USD" for line 3
  "shipmentId": "SSSH1250819001",
  "consolNo": null,
  "debiterCode": "TESTCUSTOMER01",
  "debiterName": "Test Customer Company Ltd.",
  "buyerCode": "TESTCUSTOMER01",
  "buyerName": "Test Customer Company Ltd.",
  "taxRate": 6, // for line 1, 0 for lines 2&3
  "itemCode": "FRT", // "DOC", "THC" respectively
  "itemName": "Ocean Freight", // respective charge names
  "amount": 1000.00 // respective amounts
}
```

### API Response Expectations

#### HTTP Response
- **Status Code**: 202 Accepted
- **Headers**:
  - `X-Track-ID`: [UUID] (action_id from API log)
  - `X-API-ID`: [UUID] (api_id from API log)
- **Content-Type**: text/plain;charset=UTF-8

#### Response Body Format
Expected response message:
```
AR INV Payload received and sent to external system with Track ID: [API-ID] (Routing: STANDARD mode)
```

**Key Elements**:
- Contains "AR INV" (transaction type)
- Contains "sent to external system" (not "saved to DB only")
- Contains Track ID (API ID from headers)
- Contains "STANDARD mode" (routing mode)

### Test Assertions for Service Calls

#### Verify External System Routing
```java
// Should be called 4 times total (3 charge lines + 1 controller)
verify(routingService, times(4)).shouldSendToExternalSystem("AR", "INV", "SH20250819_1");

// Should return STANDARD routing mode
verify(routingService, atLeastOnce()).getRoutingMode();
```

#### Verify Kafka Integration
```java
// Should send messages to Kafka (if Kafka is enabled)
verify(kafkaTemplate, times(3)).send(eq("test-invoice-outbound"), anyString(), any(RetryRecord.class));

// OR verify no Kafka calls if disabled
verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
```

### Routing Logic Flow

#### Decision Tree
```
1. Is transaction AR_INV? → YES
2. Should send to external system? → YES (typical for AR)
3. Is Kafka enabled? → YES (in test environment)
4. Route to external system via Kafka → SUCCESS
5. Update API log with DONE status → SUCCESS
6. Return 202 with success message → SUCCESS
```

#### Alternative Scenarios

**If External System Disabled:**
- Response: "AR INV Payload received and saved to DB only..."
- Kafka calls: None
- API log status: DONE (database-only processing)

**If Kafka Disabled:**
- Response: "AR INV Payload received and saved to DB only (Reason: Kafka is disabled)"
- API log status: PARTIAL
- Database records: Created normally

**If Lookup Errors:**
- Response: "AR INV Payload received and saved to DB only (Reason: lookup errors)"
- API log status: DONE
- Database records: Created with warnings

### Validation Points

#### Service Integration
- [ ] `shouldSendToExternalSystem()` returns `true`
- [ ] `getRoutingMode()` returns "STANDARD"  
- [ ] Service called correct number of times (4)
- [ ] No exceptions during routing decision

#### External System Communication
- [ ] Kafka template is invoked for message sending
- [ ] Correct topic name is used
- [ ] Message count matches charge line count (3)
- [ ] Messages contain correct transaction data

#### Response Validation
- [ ] HTTP 202 status returned
- [ ] Headers contain Track ID and API ID
- [ ] Response body indicates external system processing
- [ ] Response format matches expected pattern

#### API Log Verification
- [ ] API log created with DONE status
- [ ] Response JSON indicates external system success
- [ ] Track ID and API ID are properly set
- [ ] Execution time is recorded

### Performance Expectations

#### Timing
- **Total Processing**: < 5 seconds (includes database + Kafka)
- **Database Operations**: < 2 seconds
- **Kafka Publishing**: < 1 second per message
- **API Response**: < 100ms after processing complete

#### Resource Usage
- **Database Connections**: Efficient connection pooling
- **Kafka Producer**: Async message sending
- **Memory Usage**: Minimal heap impact for single transaction
- **Thread Usage**: Non-blocking operations preferred

### Error Handling Scenarios

#### If External System Fails
- **Expected Behavior**: Graceful degradation to database-only
- **API Log Status**: PARTIAL or ERROR
- **Response Message**: Indicates partial processing
- **Retry Logic**: May trigger retry mechanism

#### If Database Fails
- **Expected Behavior**: Transaction rollback
- **API Log Status**: ERROR
- **Response Code**: 500 Internal Server Error  
- **Cleanup**: No partial data corruption

#### If Kafka Fails
- **Expected Behavior**: Continue with database save
- **API Log Status**: PARTIAL
- **Response Message**: Indicates Kafka unavailable
- **Retry**: Message may be sent to retry topic