# Test Implementation Preferences for AR_INV_SH20250819_1

## Test Class Decision

### Recommended Approach: Create New Test Class
- **Class Name**: `ARInvoiceSH20250819_1IntegrationTest`
- **Rationale**: 
  - Different transaction type (AR vs AP) warrants separate test class
  - AR transactions have different routing behavior than AP
  - External system integration testing requires different setup
  - Allows focused testing of AR-specific business logic

### Alternative: Add to Existing Class
- **Option**: Add methods to `APInvoiceAS20250818_2IntegrationTest`
- **Considerations**:
  - Would mix AP and AR testing in same class
  - May complicate mock setup and test data management
  - Not recommended due to different business logic paths

## Required Test Methods

### Core Test Scenarios
1. **`testARInvoiceCompleteProcessingFlow()`**
   - End-to-end transaction processing validation
   - Database persistence verification (header + 3 lines + shipment + api_log)
   - External system routing verification
   - Kafka message sending validation

2. **`testTransactionHeaderDataPersistence()`**
   - Header record accuracy verification
   - Amount calculations: 1935.00 CNY total
   - Organization and currency mapping
   - AR-specific field validation

3. **`testTransactionLinesDataPersistence()`** 
   - Line item details validation (3 lines)
   - Ocean Freight: 1000.00 CNY + 60.00 VAT
   - Documentation: 150.00 CNY (no VAT)
   - Terminal Handling: 100.00 USD → 725.00 CNY

4. **`testVATCalculationAccuracy()`**
   - VAT calculation verification (6% on freight)
   - VAT exclusion verification (0% on other charges)
   - Total VAT amount validation: 60.00 CNY

5. **`testCurrencyConversionHandling()`**
   - USD to CNY conversion validation
   - Exchange rate application: 7.25 rate
   - Multi-currency line processing

6. **`testShipmentInfoDataPersistence()`**
   - Shipment data extraction and storage
   - HBL: OESH202508190001, MBL: MAEU123456789
   - Container mode: FCL, Transport: SEA

7. **`testExternalSystemRoutingDecision()`** 
   - AR Invoice routing confirmation (should go to external system)
   - Service call verification: 4 calls to shouldSendToExternalSystem()
   - Routing mode verification: STANDARD

8. **`testKafkaMessageSending()`**
   - Kafka integration validation
   - Message count verification: 3 messages (one per charge line)
   - Message content validation

9. **`testApiLogCreationWithExternalSystem()`**
   - API audit trail validation
   - Status: DONE (successful external system processing)
   - Response JSON structure validation

### Optional Enhanced Test Methods
10. **`testCustomerReferenceResolution()`**
    - Organization code lookup validation
    - Buyer information mapping
    - Error handling for missing customer references

11. **`testResponseFormatValidation()`**
    - HTTP response format verification
    - Header validation (X-Track-ID, X-API-ID)
    - Response body content matching

## Special Assertions Required

### Amount and Currency Validation
```java
// Verify total amounts with precise decimal handling
assertThat(headerAmount).isEqualByComparingTo(BigDecimal.valueOf(1935.00));
assertThat(vatAmount).isEqualByComparingTo(BigDecimal.valueOf(60.00));

// Verify currency conversion accuracy
assertThat(usdLine.getChargeAmount()).isEqualByComparingTo(BigDecimal.valueOf(100.00));
assertThat(usdLine.getTotalAmount()).isEqualByComparingTo(BigDecimal.valueOf(725.00));
assertThat(usdLine.getExchangeRate()).isEqualByComparingTo(BigDecimal.valueOf(7.25));
```

### Service Call Verification
```java
// Verify external system routing calls (4 total)
verify(routingService, times(4)).shouldSendToExternalSystem("AR", "INV", "SH20250819_1");
verify(routingService, atLeastOnce()).getRoutingMode();

// Verify Kafka integration
verify(kafkaTemplate, times(3)).send(eq("test-invoice-outbound"), anyString(), any(RetryRecord.class));
```

### Database Record Validation
```java
// Verify exact record counts
assertThat(headerCount).isEqualTo(1);
assertThat(linesCount).isEqualTo(3);
assertThat(shipmentCount).isEqualTo(1);
assertThat(apiLogCount).isEqualTo(1);

// Verify shipment-specific data
assertThat(shipmentInfo.getShipmentType()).isEqualTo("FCL");
assertThat(shipmentInfo.getHblNo()).isEqualTo("OESH202508190001");
```

### VAT-Specific Validation
```java
// Verify VAT calculations
BigDecimal expectedVAT = freightAmount.multiply(BigDecimal.valueOf(0.06));
assertThat(line1.getVatAmount()).isEqualByComparingTo(expectedVAT);
assertThat(line2.getVatAmount()).isEqualByComparingTo(BigDecimal.ZERO);
assertThat(line3.getVatAmount()).isEqualByComparingTo(BigDecimal.ZERO);
```

## Performance Requirements

### Execution Time Expectations
- **Total Test Execution**: < 60 seconds (including TestContainers startup)
- **Individual Test Methods**: < 10 seconds each
- **Database Operations**: < 3 seconds for all record creation
- **Kafka Operations**: < 2 seconds for all message sending

### Resource Requirements
- **Memory**: ~2GB for TestContainers (PostgreSQL + SQL Server)
- **CPU**: Standard integration test requirements
- **Network**: Minimal (mocked external services)
- **Disk**: Temporary TestContainer storage

### Timeout Configuration
```java
@Test
@Timeout(value = 30, unit = TimeUnit.SECONDS) // Individual test timeout
void testARInvoiceCompleteProcessingFlow() throws Exception {
    // Test implementation
}
```

## Mock and Service Configuration

### Services to Mock
```java
@MockitoBean
private CommonGlobalTableService globalTableService;

@MockitoBean  
private TransactionRoutingService routingService;

// Note: Use real ApiLogService for complete integration testing
@Autowired
private ApiLogService apiLogService;
```

### Service Mock Setup
```java
@BeforeEach
void setupMocks() {
    // Configure buyer reference resolution
    BuyerInfo mockBuyer = new BuyerInfo();
    mockBuyer.setBuyerReference("TESTCUSTOMER01");
    mockBuyer.setBuyerName("Test Customer Company Ltd.");
    when(globalTableService.getBuyerInfoByOrgCode("TESTCUSTOMER01")).thenReturn(mockBuyer);
    
    // Configure external system routing (true for AR invoices)
    when(routingService.shouldSendToExternalSystem("AR", "INV", "SH20250819_1")).thenReturn(true);
    when(routingService.getRoutingMode()).thenReturn("STANDARD");
}
```

## Test Data Management

### Cleanup Strategy
```java
@AfterEach
void cleanupTestData() {
    // Clean in dependency order
    deleteFrom("cp_compliance_acct_trans_header_line_link");
    deleteFrom("at_account_transaction_lines");
    deleteFrom("at_account_transaction_header");
    deleteFrom("at_shipment_info");
    deleteFrom("sys_api_log");
    deleteFrom("cp_compliance");
    
    // Reset mocks
    reset(globalTableService, routingService);
}
```

### Test Data Validation
```java
@BeforeEach
void validateTestData() {
    // Ensure test payload exists
    assertThat(Files.exists(Paths.get("reference/AR_INV_SH20250819_1.json"))).isTrue();
    
    // Verify test database is clean
    assertThat(countRecordsInTable("at_account_transaction_header")).isEqualTo(0);
    assertThat(countRecordsInTable("sys_api_log")).isEqualTo(0);
}
```

## Error Handling and Edge Cases

### Test Scenarios for Error Conditions
1. **Missing Customer Reference** - Verify graceful handling
2. **Invalid JSON Structure** - Ensure proper error response  
3. **Database Connection Issues** - Test resilience
4. **Kafka Unavailability** - Verify partial success handling
5. **Currency Conversion Errors** - Validate error messages

### Assertions for Error Conditions
```java
// Test should handle missing customer gracefully
when(globalTableService.getBuyerInfoByOrgCode("MISSING")).thenThrow(new BuyerReferenceNotFoundException());
// Verify transaction still saves to database but logs warning
```

## Documentation Requirements

### Test Documentation
- **Method-level JavaDoc**: Explain what each test validates
- **Business Context Comments**: Why certain assertions matter
- **Data Relationship Explanations**: How test data connects
- **Performance Notes**: Expected execution characteristics

### Example Documentation
```java
/**
 * Tests complete AR Invoice processing flow including:
 * - JSON parsing and validation
 * - Database persistence (4 tables)
 * - External system routing via Kafka
 * - API logging with DONE status
 * 
 * This test validates the full business process for AR invoices
 * which typically go to external compliance systems.
 */
@Test
void testARInvoiceCompleteProcessingFlow() throws Exception {
    // Implementation
}
```

## Integration with Existing Codebase

### Consistency Requirements
- **Follow existing naming patterns**: Similar to APInvoiceAS20250818_2IntegrationTest
- **Use same TestContainer setup**: PostgreSQL + SQL Server configuration
- **Maintain same assertion style**: AssertJ fluent assertions
- **Follow cleanup patterns**: Consistent @AfterEach behavior

### Code Quality Standards
- **No hardcoded values**: Use constants or configuration
- **Proper exception handling**: Meaningful test failure messages
- **Resource management**: Proper connection/resource cleanup
- **Parallel test safety**: Ensure tests can run concurrently

## Success Criteria

### Test Must Pass When:
- [x] All database records created correctly (6 total records)
- [x] All amount calculations are accurate (1935.00 CNY total)
- [x] VAT calculations are correct (60.00 CNY)
- [x] Currency conversion is accurate (7.25 rate applied)
- [x] External system routing works (4 service calls)
- [x] Kafka messages sent successfully (3 messages)
- [x] API logging shows DONE status
- [x] HTTP response format is correct (202 with headers)

### Performance Must Meet:
- [x] Total execution time < 60 seconds
- [x] Individual test methods < 10 seconds
- [x] Database operations < 3 seconds
- [x] Memory usage within TestContainer limits

### Code Quality Must Have:
- [x] 100% test coverage for new functionality
- [x] Clear, descriptive test method names
- [x] Comprehensive assertions for all data
- [x] Proper mock usage and verification
- [x] Complete cleanup after each test