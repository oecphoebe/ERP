# AR Invoice Integration Test Data Package
## Transaction: AR_INV_SH20250819_1

### Transaction Overview
- **Type**: AR_INV (Accounts Receivable Invoice)
- **Number**: SH20250819_1
- **Total Amount**: 1,250.00 CNY
- **Organization**: TESTCUSTOMER01 (Test Customer Company Ltd.)
- **Job Reference**: SSSH1250819001 (Shipment)
- **Transaction Date**: 2025-08-19
- **Currency**: CNY (Chinese Yuan)

### Transaction Characteristics
- **Ledger**: AR
- **Transaction Type**: INV
- **Is Reversal**: No
- **Is Cancelled**: No
- **Job Type**: SHIPMENT (not CONSOL)
- **Number of Charge Lines**: 3
- **Has VAT/Tax**: Yes (6% on some items)

### Business Rules
- **Routing Decision**: Should go to external system (AR transactions typically do)
- **Routing Mode**: STANDARD
- **External System**: China Compliance System
- **Kafka Enabled**: Yes (should send to Kafka topic)
- **Special Validation**: Customer code must exist in reference data

### Expected Behavior
1. Transaction should be parsed successfully
2. Should create records in SOPL database
3. Should be sent to external system via Kafka
4. API log should show status "DONE"
5. shouldSendToExternalSystem() called 4 times (3 lines + 1 controller)

### Test Scenarios to Validate
1. **Complete Processing Flow** - End-to-end validation
2. **Header Persistence** - Verify correct amounts and references
3. **Lines Persistence** - Verify 3 charge lines with correct amounts
4. **VAT Calculation** - Verify 6% VAT on applicable items
5. **External System Routing** - Verify Kafka message sent
6. **Currency Conversion** - USD to CNY conversion at 7.25 rate
7. **API Logging** - Complete audit trail

### Edge Cases / Special Handling
- Contains both CNY and USD charge lines
- Has mixed VAT rates (0% and 6%)
- Customer reference must be resolved from OrgHeader
- Should handle decimal precision correctly

### Success Criteria
- All database records created correctly
- Kafka message sent with correct payload
- API log shows successful processing
- All amounts match expected values

### Calculation Verification

#### Currency Conversion
- **Original Amount**: 100.00 USD
- **Exchange Rate**: 7.25
- **Expected Local Amount**: 725.00 CNY

#### VAT Calculation
- **Base Amount**: 1000.00 CNY
- **VAT Rate**: 6%
- **VAT Amount**: 60.00 CNY
- **Total with VAT**: 1060.00 CNY

#### Total Calculation
```
Line 1 (Ocean Freight):     1000.00 CNY + 60.00 VAT = 1060.00 CNY
Line 2 (Documentation):      150.00 CNY +  0.00 VAT =  150.00 CNY
Line 3 (Terminal Handling):  100.00 USD * 7.25 rate =  725.00 CNY (no VAT)
                             ----------------------------------------
Total Invoice Amount:                                  1935.00 CNY
```

**Note**: The actual total in the JSON should be 1935.00 CNY, not 1250.00 as initially stated. This example shows the importance of calculation verification.