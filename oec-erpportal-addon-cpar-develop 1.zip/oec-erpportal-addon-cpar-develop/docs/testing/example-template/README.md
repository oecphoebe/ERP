# Integration Test Data Package Template

## Overview

This directory contains a complete example of how to prepare data for creating a new integration test for the CPAR API system. This template demonstrates all the required files and information needed to create a comprehensive integration test similar to the successful `APInvoiceAS20250818_2IntegrationTest`.

## Template Structure

```
example-template/
├── README.md                           # This file - template overview
├── TEST_DESCRIPTION.md                 # Complete transaction description and business rules
├── payload/
│   └── AR_INV_SH20250819_1.json      # Example JSON payload for AR Invoice
├── cargowise_data/
│   └── test-data-cargowise-SH20250819_1.sql  # Complete SQL test data
├── expected_results/
│   ├── expected_database_records.md    # Expected SOPL database records
│   └── expected_routing_behavior.md    # Expected routing and service calls
└── test_preferences.md                 # Implementation preferences and requirements
```

## What This Example Demonstrates

### Transaction Type: AR_INV (Accounts Receivable Invoice)
- **Transaction**: SH20250819_1
- **Total Amount**: 1,935.00 CNY  
- **Complexity**: 3 charge lines, VAT calculation, currency conversion
- **Routing**: External system via Kafka (typical AR behavior)

### Key Features Showcased

#### 1. **Multi-Currency Handling**
- CNY and USD charge lines
- Currency conversion (7.25 USD:CNY rate)
- Exchange rate precision handling

#### 2. **VAT/Tax Calculations**
- 6% VAT on Ocean Freight (60.00 CNY)
- 0% VAT on other charges
- Mixed tax rate handling

#### 3. **Complex Transaction Lines**
- Ocean Freight: 1000.00 CNY + VAT = 1060.00 CNY
- Documentation: 150.00 CNY (no VAT)  
- Terminal Handling: 100.00 USD = 725.00 CNY

#### 4. **External System Integration**
- Routing decision: Send to external system
- Kafka message expectations (3 messages)
- Service call patterns (4 total calls)

#### 5. **Complete Data Relationships**
- Proper Cargowise database structure
- All foreign key relationships maintained
- Realistic GUID usage

## How to Use This Template

### Step 1: Copy and Modify
1. **Copy the entire template directory** to your working area
2. **Rename files** to match your transaction:
   - `AR_INV_SH20250819_1.json` → `[YOUR_TYPE]_[YOUR_NUMBER].json`
   - `test-data-cargowise-SH20250819_1.sql` → `test-data-cargowise-[YOUR_NUMBER].sql`

### Step 2: Replace Transaction Data
1. **Update JSON payload** with your actual transaction data
2. **Modify SQL data** to match your transaction references
3. **Generate new GUIDs** for all primary keys to avoid conflicts
4. **Maintain relationships** between tables (foreign keys)

### Step 3: Update Expected Results
1. **Recalculate amounts** based on your transaction
2. **Update field expectations** to match your data
3. **Adjust routing behavior** based on transaction type
4. **Modify service call counts** based on charge line count

### Step 4: Customize Test Preferences  
1. **Choose test class approach** (new class or add to existing)
2. **Specify required test methods** based on your needs
3. **Define special assertions** for your business logic
4. **Set performance requirements**

## Template Validation Checklist

Before using this template, verify you understand:

### ✅ Data Structure
- [ ] How JSON payload maps to database records
- [ ] Foreign key relationships in Cargowise data
- [ ] GUID generation and consistency requirements
- [ ] Currency and amount calculation logic

### ✅ Business Logic
- [ ] Routing decision factors (AP vs AR, transaction type)
- [ ] Service call patterns (charge lines + controller)
- [ ] External system integration requirements
- [ ] VAT/tax calculation rules

### ✅ Test Requirements
- [ ] Database record expectations (counts and values)
- [ ] Service mock setup requirements
- [ ] Performance and timeout expectations
- [ ] Cleanup and isolation needs

## Common Customization Patterns

### For Different Transaction Types

#### AP Invoices (like existing APInvoiceAS20250818_2IntegrationTest)
- **Routing**: Typically database-only (LEGACY mode)
- **Kafka**: Usually disabled for AP transactions
- **Response**: "saved to DB only" message
- **Service Calls**: Routing service returns false

#### AR Credit Notes
- **Routing**: May go to external system (depends on configuration)
- **Amounts**: Typically negative values
- **Validation**: Credit note specific business rules
- **Special Handling**: Reversal logic may apply

#### Reversed Transactions
- **Transaction Number**: Contains "_Reversed" suffix
- **Business Logic**: Updates existing records vs creating new
- **Special Validation**: Outstanding amount clearing
- **Database Updates**: May modify existing records

### For Different Complexities

#### Simple Transactions (1-2 charge lines)
- **Reduce** charge line count in JSON and SQL
- **Adjust** service call expectations (N lines + 1 controller)
- **Simplify** amount calculations and validations
- **Remove** complex currency conversion if not needed

#### Complex Transactions (5+ charge lines)
- **Increase** charge line count and data
- **Expand** SQL INSERT statements accordingly
- **Update** service call expectations
- **Add** additional validation for large datasets

## File-by-File Usage Guide

### 1. TEST_DESCRIPTION.md
**Purpose**: Complete business context and requirements

**Customize**:
- Transaction type, number, amounts
- Business rules and edge cases
- Test scenarios to validate
- Calculation verification details

### 2. payload/[TRANSACTION].json
**Purpose**: Actual JSON request payload

**Customize**:
- Transaction identifiers and references
- Charge line details and amounts
- Currency codes and exchange rates
- Organization codes and job references

### 3. cargowise_data/test-data-cargowise-[NUMBER].sql
**Purpose**: Complete Cargowise database setup

**Customize**:
- Generate new GUIDs for all PKs
- Update transaction references consistently
- Modify amounts and descriptions
- Ensure foreign key relationships

### 4. expected_results/expected_database_records.md
**Purpose**: Detailed SOPL database expectations

**Customize**:
- Record counts based on your transaction
- Field values matching your data
- Amount calculations and currency handling
- Validation rules and assertions

### 5. expected_results/expected_routing_behavior.md  
**Purpose**: Service call and routing expectations

**Customize**:
- Routing decision (true/false)
- Service call counts (N charge lines + 1)
- Kafka message expectations
- Response format and content

### 6. test_preferences.md
**Purpose**: Implementation guidance and requirements

**Customize**:
- Test class naming and structure
- Required test methods for your scenario
- Special assertions and validations
- Performance and cleanup requirements

## Quality Assurance Tips

### Data Consistency
- **Verify GUIDs** are unique and properly formatted
- **Check relationships** between all tables
- **Validate amounts** match between JSON and SQL
- **Ensure references** are consistent across files

### Calculation Accuracy
- **Double-check** currency conversions
- **Verify VAT** calculations if applicable
- **Validate totals** match expected amounts
- **Test edge cases** like zero amounts or rates

### Completeness Verification
- **All charge lines** represented in test data
- **All expected records** documented
- **All service calls** accounted for
- **All business rules** covered in tests

## Getting Help

### If You Need Assistance
1. **Review the detailed guide**: `integration-test-data-preparation-guide.md`
2. **Study the working example**: APInvoiceAS20250818_2IntegrationTest
3. **Check existing reference data**: `reference/` directory
4. **Examine test resources**: `src/test/resources/` directory

### Common Issues and Solutions
- **GUID conflicts**: Generate new UUIDs for all primary keys
- **Missing relationships**: Verify foreign key references match
- **Amount mismatches**: Recalculate all totals and conversions  
- **Routing confusion**: Understand AP vs AR routing differences

---

**This template provides everything needed to create a comprehensive, high-quality integration test that validates complete transaction processing from JSON input to database persistence and external system integration.**