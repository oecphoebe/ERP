# AP Transaction Validation Analysis Report
## File: AP_INV_AS20250812_1_W.json

**Date:** 2025-08-14  
**Transaction:** AS20250812_1/W (AP Invoice)  
**Analysis Status:** ❌ VALIDATION FAILED  
**Processor:** CPAR Transaction Service v3.4+  

---

## Executive Summary

The AP invoice transaction `AS20250812_1/W` **FAILS** validation and will **NOT** be processed successfully by the CPAR system. The JSON structure is missing critical components required for AP transaction processing, particularly the Shipment/ChargeLine hierarchy and VAT information required by the 2025-08-13 AP TaxCode fix.

### Critical Issues Identified:
- ❌ Missing Shipment/JobCosting/ChargeLine structure
- ❌ Missing `CostGSTVATID` tax information for AP transactions
- ❌ Missing `SupplierReference` for buyer identification
- ❌ Missing cost-side financial data fields
- ❌ Incomplete transaction structure for database persistence

---

## Detailed Transaction Analysis

### 1. Transaction Header Validation ✅ PASS

| Field | Expected | Actual | Status |
|-------|----------|---------|---------|
| **Transaction Number** | Present | `AS20250812_1/W` | ✅ |
| **Ledger** | AR/AP | `AP` | ✅ |
| **Transaction Type** | INV/CRD/JNL | `INV` | ✅ |
| **Currency** | Valid ISO | `CNY` | ✅ |
| **Company Code** | Present | `SH1` | ✅ |
| **Branch Code** | Present | `SH1` | ✅ |
| **Department** | Present | `BRN` | ✅ |
| **Organization** | Present | `SHAEVESHA` | ✅ |
| **Is Cancelled** | Boolean | `false` | ✅ |
| **Transaction Date** | ISO Date | `2025-08-12T11:18:00` | ✅ |
| **Invoice Amount** | Numeric | `-100.0` | ✅ |

**Result:** Header data is complete and valid for database insertion into `at_account_transaction_header`.

### 2. JSON Structure Analysis ❌ FAIL

**Expected Structure (per mapping documentation):**
```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": { /* ✅ Present */ },
      "ShipmentCollection": {
        "Shipment": [
          {
            "JobCosting": {
              "ChargeLineCollection": {
                "ChargeLine": [
                  {
                    "ChargeCode": { /* Required */ },
                    "CostOSAmount": /* Required for AP */,
                    "CostOSCurrency": /* Required for AP */,
                    "CostGSTVATAmount": /* Required for AP */,
                    "CostGSTVATID": {
                      "TaxCode": /* CRITICAL - Required by 2025-08-13 fix */
                    },
                    "SupplierReference": /* Required for AP buyer identification */
                  }
                ]
              }
            }
          }
        ]
      }
    }
  }
}
```

**Actual Structure:**
```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": { /* ✅ Present */ }
      /* ❌ ShipmentCollection: MISSING */
    }
  }
}
```

**Analysis:** The JSON only contains `TransactionInfo` and `PostingJournalCollection`. The entire `ShipmentCollection` hierarchy is missing, which is required for ChargeLine processing.

### 3. ChargeLine Processing Analysis ❌ FAIL

#### 3.1 ChargeLine Location Paths
The system attempts to find ChargeLines at:
- **Primary Path:** `$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]`
- **Fallback Path:** `$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].SubShipmentCollection.SubShipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]`

#### 3.2 Processing Result
```
ChargeLines Found: 0
Reason: ShipmentCollection does not exist in JSON
```

#### 3.3 Expected ChargeLine Fields for AP Transactions
| Field | Purpose | Status in JSON |
|-------|---------|----------------|
| `ChargeCode.Code` | Charge identification | ❌ Missing |
| `CostOSAmount` | Cost amount | ❌ Missing |
| `CostOSCurrency.Code` | Cost currency | ❌ Missing |
| `CostGSTVATAmount` | VAT amount | ❌ Missing |
| `CostGSTVATID.TaxCode` | Tax code (CRITICAL) | ❌ Missing |
| `CostExchangeRate` | Exchange rate | ❌ Missing |
| `SupplierReference` | Buyer code | ❌ Missing |
| `Description` | Line description | ❌ Missing |

### 4. VAT Configuration Analysis ❌ FAIL

#### 4.1 Current VAT Data (PostingJournal)
```json
"VattaxID": {
  "TaxCode": "FREEVAT",
  "Description": "Zero Rated", 
  "TaxRate": 0,
  "TaxType": { "Code": "RAT" }
}
```

#### 4.2 Required VAT Data for AP (Missing)
```json
"CostGSTVATID": {
  "TaxCode": "FREEVAT",  // Required by hasValidCostGSTVATID()
  "TaxRate": 0
}
```

#### 4.3 Code Impact
**File:** `TransactionValidationService.java:63-75`
```java
public boolean hasValidCostGSTVATID(String jsonChargeLine) {
    try {
        Object costGSTVATID = JsonPath.using(configWithoutException)
            .parse(jsonChargeLine).read("$.CostGSTVATID");
        if (costGSTVATID == null) return false; // ❌ FAILS HERE
        
        String taxCode = JsonPath.using(configWithoutException)
            .parse(jsonChargeLine).read("$.CostGSTVATID.TaxCode");
        return StringUtils.isNotBlank(taxCode);
    } catch (Exception e) {
        return false;
    }
}
```

**Result:** Validation returns `false`, preventing external system submission.

### 5. Code Flow Analysis

#### 5.1 Processing Entry Point
```
external/v1/ARTransaction → TransactionBatchProcessor.handleUniversalTransactionBatch()
```

#### 5.2 Execution Path and Failure Points

1. **TransactionMappingService.analyzePayloadRaw()** ✅
   - Parses JSON successfully
   - Extracts TransactionInfo ✅

2. **queryService.getRefNo()** ❓ UNCERTAIN
   - Queries JobCharge table for SHIPMENT vs CONSOL determination
   - May return empty list if no matching records found

3. **processTransactionWithRefNo()** ❌ FAILS
   - If refNoList is empty: returns empty ArrayList
   - Error: "RefNoInfo not found"

4. **chargeLineProcessor.handleChargeLineInShipment()** ❌ NOT REACHED
   - Would fail due to missing Shipment structure

5. **Database Save** ❌ NOT REACHED
   - No line data to save

#### 5.3 Expected Error Messages
```
[DEBUG] RefNoInfo not found
[INFO] ChargeLine processing summary - Ledger: AP, Total: 0, Processed: 0, Saved to DB: 0, Sent to External: 0, Missing VAT: 0
```

### 6. Buyer Reference Extraction Analysis ❌ FAIL

#### 6.1 Code Logic (TransactionMappingService.java:361-378)
```java
public String extractBuyerCode(Object document, String ledger, String billNo) 
    throws BuyerReferenceNotFoundException {
    if (StringUtils.equals("AP", ledger)) {
        List<String> supplierReferenceList = JsonPath.read(document, "$..SupplierReference");
        if (supplierReferenceList.isEmpty()) { 
            throw new BuyerReferenceNotFoundException(
                "No SupplierReference found for AP transaction! TransactionInfo.Number = ["+ billNo +"]"); 
        }
        return supplierReferenceList.getFirst();
    }
}
```

#### 6.2 Expected Error
```
BuyerReferenceNotFoundException: No SupplierReference found for AP transaction! TransactionInfo.Number = [AS20250812_1/W]
```

### 7. Database Impact Assessment

#### 7.1 Table Impact
| Table | Expected Records | Actual Records | Status |
|-------|------------------|----------------|---------|
| `at_account_transaction_header` | 1 | 0 | ❌ Not saved |
| `at_account_transaction_lines` | 1+ | 0 | ❌ Not saved |

#### 7.2 Reason for No Database Save
The transaction fails early in processing due to missing ChargeLine data. The retry mechanism in `saveTransactionDataWithRetry()` is never reached because there are no valid lines to save.

### 8. External System Integration Analysis ❌ BLOCKED

#### 8.1 Compliance System Submission
**Status:** Will NOT be submitted to China Tax System

**Reasons:**
1. No ChargeLine data processed
2. Missing `CostGSTVATID.TaxCode` (required by 2025-08-13 fix)
3. Missing buyer information (`SupplierReference`)

#### 8.2 TransactionChargeLineRequestBean Creation
The system would attempt to create request beans but fail due to missing VAT validation:

```java
// ChargeLineProcessor.java:275
validForExternalSystem = validationService.hasValidCostGSTVATID(jsonChargeLine);
if (!validForExternalSystem) {
    log.info("AP ChargeLine will be saved to DB but not sent to external system - missing CostGSTVATID: ChargeCode={}", chargeCode);
}
```

---

## Compliance with 2025-08-13 AP TaxCode Fix

### Fix Summary
The 2025-08-13 update correctly implemented AP transaction processing to use `CostGSTVATID.TaxCode` instead of `SellGSTVATID.TaxCode`.

### Current JSON Compliance: ❌ FAIL
- **Required:** `$.ChargeLine[*].CostGSTVATID.TaxCode`
- **Available:** Only `$.PostingJournal[*].VattaxID.TaxCode`
- **Issue:** PostingJournal VAT data cannot substitute for ChargeLine VAT data

### Code Reference
**File:** `TransactionChargeLineRequestBean.java:84-88`
```java
if (StringUtils.equals("AR", ledger)) {
    // AR uses SellGSTVATID (sales side)
    taxCode = JsonPath.read(jsonChargeLine, "$.SellGSTVATID.TaxCode");
} else {
    // AP uses CostGSTVATID (cost/vendor side) ✅ CORRECTLY IMPLEMENTED
    taxCode = JsonPath.read(jsonChargeLine, "$.CostGSTVATID.TaxCode");
}
```

---

## Recommendations

### 1. JSON Structure Fix
Add the missing Shipment/ChargeLine hierarchy:

```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": { /* existing data */ },
      "ShipmentCollection": {
        "Shipment": [
          {
            "DataContext": {
              "DataSourceCollection": {
                "DataSource": [
                  {
                    "Type": "ForwardingShipment",
                    "Key": "WI00000073"
                  }
                ]
              }
            },
            "JobCosting": {
              "ChargeLineCollection": {
                "ChargeLine": [
                  {
                    "ChargeCode": {
                      "Code": "DOC",
                      "Description": "Destination Documentation Fee"
                    },
                    "CostOSAmount": -100.0,
                    "CostOSCurrency": {
                      "Code": "CNY",
                      "Description": "Chinese Yuan"
                    },
                    "CostGSTVATAmount": 0.0,
                    "CostGSTVATID": {
                      "TaxCode": "FREEVAT",
                      "TaxRate": 0
                    },
                    "CostExchangeRate": 1.0,
                    "SupplierReference": "SUPPLIER001",
                    "Description": "Destination Documentation Fee_test",
                    "DisplaySequence": 1,
                    "CostAPInvoiceNumber": "AS20250812_1/W"
                  }
                ]
              }
            }
          }
        ]
      }
    }
  }
}
```

### 2. Required Field Checklist
- ✅ Add `ShipmentCollection.Shipment[]`
- ✅ Add `JobCosting.ChargeLineCollection.ChargeLine[]`
- ✅ Add `CostGSTVATID.TaxCode` for each ChargeLine
- ✅ Add `SupplierReference` for buyer identification
- ✅ Add all cost-side amount fields (`CostOSAmount`, `CostGSTVATAmount`, etc.)
- ✅ Add `CostAPInvoiceNumber` matching transaction number
- ✅ Add `DisplaySequence` for proper line matching

### 3. Testing Validation
After implementing the fixes, the JSON should:
1. Pass `hasValidCostGSTVATID()` validation
2. Successfully extract buyer code via `SupplierReference`
3. Create database records in both header and lines tables
4. Generate `TransactionChargeLineRequestBean` for external system
5. Successfully submit to China Tax compliance system

---

## Conclusion

The current JSON structure `AP_INV_AS20250812_1_W.json` is **incompatible** with the CPAR transaction processing system. It represents a partial transaction containing only header and posting journal information, lacking the essential ChargeLine data structure required for AP transaction processing.

To successfully process this transaction, a complete restructuring of the JSON payload is required to include the Shipment/JobCosting/ChargeLine hierarchy with proper AP-specific fields, particularly the `CostGSTVATID` tax information mandated by the 2025-08-13 system update.

**Severity:** HIGH - Complete processing failure  
**Impact:** No database persistence, no external system integration  
**Action Required:** JSON structure redesign and data completion  

---

*Report generated by CPAR Analysis System - 2025-08-14*