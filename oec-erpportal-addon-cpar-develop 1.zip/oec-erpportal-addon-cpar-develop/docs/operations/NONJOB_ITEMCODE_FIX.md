# NonJob ItemCode Extraction Bug Fix

## 🐛 Bug Summary

**Issue**: JOB_INVOICE type NonJob transactions were incorrectly extracting GL account codes instead of charge codes for the `itemCode` field when sending data to external systems.

**Evidence**: Log file `logs/dev-20251120-06.log` line 177 showed:
```json
"itemCode": "4070.10.10"  // WRONG: GL account
```

**Expected**: Should show:
```json
"itemCode": "DOC"  // CORRECT: Charge code
```

---

## 🔍 Root Cause Analysis

### Buggy Code Location
**File**: `src/main/java/oec/lis/erpportal/addon/compliance/model/transaction/TransactionChargeLineRequestBean.java`
**Lines**: 69-82 (before fix)

### Original Flawed Logic

```java
// OLD BUGGY CODE
boolean isNonjobPostingJournal = JsonPath.using(configWithoutException)
    .parse(jsonChargeLine).read("$.Osamount") != null;

if (isNonjobPostingJournal) {
    // Always uses Glaccount - WRONG for JOB_INVOICE type!
    this.setItemCode(JsonPath.read(jsonChargeLine, "$.Glaccount.AccountCode"));
    this.setItemName(JsonPath.read(jsonChargeLine, "$.Glaccount.Description"));
} else {
    // Uses ChargeCode
    this.setItemCode(JsonPath.read(jsonChargeLine, "$.ChargeCode.Code"));
    this.setItemName(JsonPath.read(jsonChargeLine, "$.ChargeCode.Description"));
}
```

### Why It Failed

The detection logic only checked for `$.Osamount` field presence, which exists in **BOTH**:
1. **JOB_INVOICE type NonJob**: Has `ChargeCode` + `Glaccount` + `Osamount`
2. **GL_ACCOUNT type NonJob**: Has `Glaccount` + `Osamount` (no `ChargeCode`)

**Result**: JOB_INVOICE type was incorrectly treated as GL_ACCOUNT type.

### Data Structure Example

**JOB_INVOICE Type** (`reference/NonJob_AR_INV_2511001018-ADD.json`):
```json
{
  "ChargeCode": {
    "Code": "DOC",                    // ← SHOULD BE USED
    "Description": "Destination Documentation Fee"
  },
  "Glaccount": {
    "AccountCode": "4070.10.10",      // ← WAS INCORRECTLY USED
    "Description": "Handling Revenue Actual"
  },
  "Osamount": 50.0                    // ← Detection field (present in both types)
}
```

---

## ✅ Solution Implemented

### Fixed Logic

```java
// NEW CORRECT CODE
// Step 1: Check if ChargeCode.Code exists (priority for JOB_INVOICE type)
Object chargeCodeObj = JsonPath.using(configWithoutException)
    .parse(jsonChargeLine).read("$.ChargeCode.Code");
boolean hasChargeCode = chargeCodeObj != null && StringUtils.isNotBlank(chargeCodeObj.toString());

// Step 2: Detect NONJOB PostingJournal structure
boolean isNonjobPostingJournal = JsonPath.using(configWithoutException)
    .parse(jsonChargeLine).read("$.Osamount") != null;

// Step 3: Extract with proper prioritization
if (hasChargeCode) {
    // JOB_INVOICE type NonJob or standard ChargeLine - use ChargeCode
    this.setItemCode(JsonPath.read(jsonChargeLine, "$.ChargeCode.Code"));
    this.setItemName(JsonPath.read(jsonChargeLine, "$.ChargeCode.Description"));
} else if (isNonjobPostingJournal) {
    // GL_ACCOUNT type NonJob - use Glaccount (only when ChargeCode doesn't exist)
    this.setItemCode(JsonPath.read(jsonChargeLine, "$.Glaccount.AccountCode"));
    this.setItemName(JsonPath.read(jsonChargeLine, "$.Glaccount.Description"));
} else {
    // Fallback to ChargeCode (for safety)
    this.setItemCode(JsonPath.read(jsonChargeLine, "$.ChargeCode.Code"));
    this.setItemName(JsonPath.read(jsonChargeLine, "$.ChargeCode.Description"));
}
```

### Fix Strategy

**Priority-Based Extraction**:
1. **First Priority**: Check for `ChargeCode.Code` → Use it if present and non-blank
2. **Second Priority**: Check for `Osamount` + absence of `ChargeCode` → Use `Glaccount.AccountCode`
3. **Fallback**: Use `ChargeCode.Code` (safety net)

This ensures:
- ✅ JOB_INVOICE type NonJob → extracts `ChargeCode.Code` (e.g., "DOC")
- ✅ GL_ACCOUNT type NonJob → extracts `Glaccount.AccountCode` (e.g., "4070.10.10")
- ✅ Standard ChargeLines → extracts `ChargeCode.Code` (existing behavior preserved)

---

## 🧪 Test Coverage

### New Tests Added

**File**: `src/test/java/oec/lis/erpportal/addon/compliance/model/transaction/TransactionChargeLineRequestBeanTest.java`

**5 New Test Methods**:

1. **`testJobInvoiceNonJobExtractsChargeCode()`**
   - Verifies JOB_INVOICE type extracts `"DOC"` from `ChargeCode.Code`
   - Ensures `Glaccount.AccountCode` is ignored when `ChargeCode` exists

2. **`testGLAccountNonJobExtractsGlAccount()`**
   - Verifies GL_ACCOUNT type extracts `"1210.00.10"` from `Glaccount.AccountCode`
   - Confirms behavior when `ChargeCode` is absent

3. **`testStandardChargeLineExtractsChargeCode()`**
   - Verifies standard (non-NONJOB) transactions still work correctly
   - Extracts `"FRT"` from `ChargeCode.Code`

4. **`testJobInvoiceNonJobPrioritizesChargeCode()`**
   - Verifies prioritization: `ChargeCode.Code` over `Glaccount.AccountCode`
   - Extracts `"AMS"` instead of `"4080.20.00"`

5. **`testEmptyChargeCodeFallsBackToGlAccount()`**
   - Verifies fallback behavior when `ChargeCode.Code` is empty string
   - Correctly falls back to `Glaccount.AccountCode`

### Test Results

```bash
$ ./mvnw test -Dtest="TransactionChargeLineRequestBeanTest"

[INFO] Tests run: 15, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

**Total Test Coverage**:
- TransactionChargeLineRequestBeanTest: 15 tests (10 existing + 5 new)
- TransactionMappingServiceNonjobJobKeyTest: 16 tests
- NonJobTypeDetectionRealDataTest: 2 tests
- **Grand Total**: 33 tests passing ✅

---

## 📊 Impact Analysis

### Before Fix

| Transaction Type | Field Extracted | Value Extracted | Correct? |
|-----------------|----------------|-----------------|----------|
| JOB_INVOICE NonJob | `Glaccount.AccountCode` | `"4070.10.10"` | ❌ WRONG |
| GL_ACCOUNT NonJob | `Glaccount.AccountCode` | `"1210.00.10"` | ✅ Correct |
| Standard ChargeLine | `ChargeCode.Code` | `"FRT"` | ✅ Correct |

### After Fix

| Transaction Type | Field Extracted | Value Extracted | Correct? |
|-----------------|----------------|-----------------|----------|
| JOB_INVOICE NonJob | `ChargeCode.Code` | `"DOC"` | ✅ FIXED |
| GL_ACCOUNT NonJob | `Glaccount.AccountCode` | `"1210.00.10"` | ✅ Correct |
| Standard ChargeLine | `ChargeCode.Code` | `"FRT"` | ✅ Correct |

---

## 🎯 Expected Behavior After Fix

### For Reference File: `NonJob_AR_INV_2511001018-ADD.json`

**Before Fix** (from `logs/dev-20251120-06.log`):
```json
{
  "billNo": "2511001018",
  "itemCode": "4070.10.10",           // ← WRONG: GL account
  "itemName": "Handling Revenue Actual"
}
```

**After Fix** (expected):
```json
{
  "billNo": "2511001018",
  "itemCode": "DOC",                  // ← CORRECT: Charge code
  "itemName": "Destination Documentation Fee"
}
```

---

## 🔧 Files Modified

### Core Fix
1. **`TransactionChargeLineRequestBean.java`** (lines 66-92)
   - Added `hasChargeCode` detection
   - Implemented priority-based extraction logic
   - Added detailed logging for debugging

### Test Enhancements
2. **`TransactionChargeLineRequestBeanTest.java`** (lines 217-401)
   - Added 5 comprehensive test cases
   - Covers JOB_INVOICE, GL_ACCOUNT, and standard ChargeLines
   - Tests prioritization and fallback logic

---

## 🚀 Verification Steps

### 1. Unit Tests
```bash
# Run all NonJob-related unit tests
./mvnw test -Dtest="TransactionMappingServiceNonjobJobKeyTest,NonJobTypeDetectionRealDataTest,TransactionChargeLineRequestBeanTest"

# Expected: 33 tests passing
```

### 2. Real Data Test (Recommended)
```bash
# Process the reference file again and check logs
# POST reference/NonJob_AR_INV_2511001018-ADD.json to /universal/transaction

# Check logs for corrected itemCode:
grep -A2 '"itemCode"' logs/dev-20251120-*.log | tail -3

# Expected output:
# "itemCode": "DOC",
# "itemName": "Destination Documentation Fee",
```

### 3. Integration Test (Future)
- Create `JobInvoiceNonJobIntegrationTestV2.java` following V2 framework
- Test complete flow with Cargowise data and external system integration

---

## 📋 Architecture Insights

`★ Insight ─────────────────────────────────────────────────────────────`

**1. Field Priority Pattern**
The fix implements a "priority-based field extraction" pattern where the presence
of a more specific field (`ChargeCode.Code`) takes precedence over a generic field
(`Glaccount.AccountCode`). This is a common pattern when dealing with evolving
data structures where newer formats add specialized fields.

**2. Defensive Programming**
The solution uses three layers of checks:
- Primary: `hasChargeCode` → preferred field
- Secondary: `isNonjobPostingJournal && !hasChargeCode` → fallback field
- Tertiary: Final else → safety net

This defensive approach prevents null pointer exceptions and handles edge cases
gracefully without throwing errors.

**3. Separation of Concerns**
By separating detection (`hasChargeCode`, `isNonjobPostingJournal`) from
extraction (`setItemCode`, `setItemName`), the code becomes more maintainable
and testable. Each concern can be modified independently.

`─────────────────────────────────────────────────────────────────────────`

---

## ✅ Completion Checklist

- [x] Root cause identified (incorrect detection logic)
- [x] Fix implemented (priority-based extraction)
- [x] Unit tests added (5 new test cases)
- [x] All tests passing (33/33 unit tests)
- [x] Backward compatibility preserved (GL_ACCOUNT and standard ChargeLines unchanged)
- [x] Documentation updated (this file + NONJOB_PATH_VERIFICATION.md)
- [ ] Real data verification (run with actual reference file and check logs)
- [ ] Integration tests (recommended for V2 framework)
- [ ] Production deployment

---

## 📚 Related Documentation

- **Architecture**: `CLAUDE.md` (lines 131-242) - NonJob Type Differentiation
- **Path Verification**: `NONJOB_PATH_VERIFICATION.md` - Complete path comparison
- **Test Reference**: `reference/NonJob_AR_INV_2511001018-ADD.json` - JOB_INVOICE sample
- **Test Reference**: `reference/NonJob-AR_INV_2511001019-Add.json` - GL_ACCOUNT sample

---

**Fix Date**: 2025-11-20
**Status**: ✅ COMPLETE - Unit tests passing, ready for real data verification
**Next Action**: Process reference file and verify `itemCode="DOC"` in logs
