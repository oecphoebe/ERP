# vw_shipment_info Migration Guide for Operations Team

## Overview

This guide provides step-by-step instructions for deploying and managing the shipment view (vw_shipment_info) implementation in production environments. The implementation uses feature flags to enable zero-downtime migration from table-based to view-based shipment data access.

## Prerequisites

### Database Requirements
- **PostgreSQL Database**: Must contain `vw_shipment_info` view
- **View Availability**: Ensure the view exists and is properly indexed
- **Database Permissions**: Application user must have SELECT permissions on the view

### Application Requirements
- **Spring Boot 3.4.3**: Application version compatibility
- **Java 21**: Runtime environment
- **Configuration Management**: Access to application configuration files

## Deployment Phases

### Phase 1: Pre-Deployment Verification

#### 1.1 Database View Verification
```sql
-- Verify view exists and has correct structure
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'vw_shipment_info'
ORDER BY ordinal_position;

-- Expected columns:
-- shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl
-- carrier_book_no, shipment_type, cnsl_type
-- cnsl_first_leg_vssl, cnsl_first_leg_voy

-- Verify view has data
SELECT COUNT(*) FROM vw_shipment_info;
```

#### 1.2 Application Configuration Check
```yaml
# Verify current configuration (should be disabled initially)
shipment:
  use-view: false              # CRITICAL: Must be false for initial deployment
  fallback-enabled: true      # CRITICAL: Must be true for safety
  retry-attempts: 3
  retry-delay-ms: 1000
  query-timeout-ms: 30000
  health-check-enabled: true
```

### Phase 2: Application Deployment

#### 2.1 Deploy Application with View Code
```bash
# Deploy new application version with view implementation
# Ensure configuration keeps view disabled initially
kubectl apply -f cpar-api-deployment.yaml

# Verify deployment
kubectl get pods -l app=cpar-api
kubectl logs -f deployment/cpar-api
```

#### 2.2 Health Check Verification
```bash
# Check application health
curl -f http://cpar-api:8080/cpar-api/actuator/health

# Check shipment view health (should show available but disabled)
curl -f http://cpar-api:8080/cpar-api/actuator/health/shipmentView
```

### Phase 3: Feature Flag Activation

#### 3.1 Gradual Activation Strategy

**Step 1: Enable Health Monitoring (Optional)**
```yaml
shipment:
  use-view: false
  health-check-enabled: true    # Enable monitoring first
```

**Step 2: Enable View with Full Fallback**
```yaml
shipment:
  use-view: true                # Enable view implementation
  fallback-enabled: true       # Keep fallback enabled
  retry-attempts: 3             # Conservative retry count
```

**Step 3: Monitor and Optimize**
```yaml
shipment:
  use-view: true
  fallback-enabled: true       # Can remain enabled for safety
  retry-attempts: 2             # Reduce after confidence builds
  retry-delay-ms: 500          # Optimize for performance
```

#### 3.2 Configuration Update Methods

**Method 1: Kubernetes ConfigMap Update**
```bash
# Update ConfigMap
kubectl edit configmap cpar-api-config

# Restart pods to pick up new config
kubectl rollout restart deployment/cpar-api
```

**Method 2: Spring Cloud Config (if using external config server)**
```bash
# Update configuration in Git repository
# Trigger refresh endpoint
curl -X POST http://cpar-api:8080/cpar-api/actuator/refresh
```

### Phase 4: Monitoring and Validation

#### 4.1 Performance Monitoring
```bash
# Monitor application metrics
curl http://cpar-api:8080/cpar-api/actuator/prometheus | grep shipment

# Key metrics to watch:
# - shipment_view_query_duration_seconds
# - shipment_view_fallback_count_total
# - shipment_view_error_count_total
# - shipment_view_health_status
```

#### 4.2 Log Analysis
```bash
# Monitor application logs for view usage
kubectl logs -f deployment/cpar-api | grep -i "shipment.*view"

# Look for:
# - "Using view service implementation"
# - "Falling back to table implementation"
# - "View service health check"
# - Error patterns related to view access
```

#### 4.3 Database Performance Impact
```sql
-- Monitor query performance
SELECT schemaname, tablename, n_tup_ins, n_tup_upd, n_tup_del, n_tup_hot_upd
FROM pg_stat_user_tables
WHERE tablename = 'vw_shipment_info';

-- Check for slow queries
SELECT query, mean_time, calls, total_time
FROM pg_stat_statements
WHERE query LIKE '%vw_shipment_info%'
ORDER BY mean_time DESC;
```

## Configuration Reference

### Complete Configuration Options
```yaml
shipment:
  # Core feature control
  use-view: true                      # Enable/disable view implementation
  fallback-enabled: true             # Enable fallback to table implementation

  # Retry configuration
  retry-attempts: 3                   # Number of retry attempts for failed queries
  retry-delay-ms: 1000               # Delay between retry attempts (milliseconds)
  query-timeout-ms: 30000            # Query timeout threshold (milliseconds)

  # Performance tuning
  max-result-size: 1000              # Maximum records returned in bulk operations
  connection-pool-size: 0            # Dedicated connection pool (0 = use default)

  # Monitoring and observability
  health-check-enabled: true         # Enable health check monitoring
  health-check-interval-minutes: 5   # Health check frequency
  metrics-enabled: false             # Enable detailed metrics collection

  # Advanced features
  case-insensitive-search: false     # Enable case-insensitive matching
  cache-size: 100                    # Number of records to cache (0 = disabled)
  cache-ttl-minutes: 60              # Cache TTL in minutes
  log-level: INFO                    # Logging level for shipment operations
```

### Environment-Specific Configurations

#### Development Environment
```yaml
shipment:
  use-view: true
  fallback-enabled: true
  retry-attempts: 1
  retry-delay-ms: 100
  metrics-enabled: true
  log-level: DEBUG
```

#### QA Environment
```yaml
shipment:
  use-view: true
  fallback-enabled: true
  retry-attempts: 2
  retry-delay-ms: 500
  metrics-enabled: true
  log-level: INFO
```

#### Production Environment
```yaml
shipment:
  use-view: true
  fallback-enabled: true
  retry-attempts: 3
  retry-delay-ms: 1000
  query-timeout-ms: 30000
  health-check-enabled: true
  metrics-enabled: false
  log-level: INFO
```

## Troubleshooting Guide

### Common Issues and Solutions

#### Issue 1: View Not Found
**Symptoms**: `Table 'vw_shipment_info' doesn't exist` errors
**Solution**:
```sql
-- Verify view exists
\d vw_shipment_info;

-- If missing, contact DBA to create view
-- Temporarily set use-view: false
```

#### Issue 2: High Fallback Rate
**Symptoms**: Many "Falling back to table implementation" log entries
**Investigation**:
```bash
# Check view health
curl http://cpar-api:8080/cpar-api/actuator/health/shipmentView

# Check database connectivity
psql -h [db-host] -U [user] -d [database] -c "SELECT COUNT(*) FROM vw_shipment_info;"
```

#### Issue 3: Performance Degradation
**Symptoms**: Increased response times after enabling view
**Investigation**:
```sql
-- Check for missing indexes on view base tables
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM vw_shipment_info WHERE shipment_no = 'S240123001';

-- Monitor query execution plans
```

#### Issue 4: Configuration Not Taking Effect
**Symptoms**: Configuration changes not reflected in application behavior
**Solution**:
```bash
# Verify ConfigMap updated
kubectl get configmap cpar-api-config -o yaml

# Force pod restart
kubectl rollout restart deployment/cpar-api

# Check configuration endpoint
curl http://cpar-api:8080/cpar-api/actuator/configprops | grep shipment
```

## Emergency Procedures

### Immediate Disable (Emergency)
```bash
# Method 1: Quick ConfigMap update
kubectl patch configmap cpar-api-config -p '{"data":{"application.yml":"shipment:\n  use-view: false"}}'
kubectl rollout restart deployment/cpar-api

# Method 2: Environment variable override
kubectl set env deployment/cpar-api SHIPMENT_USE_VIEW=false
```

### Complete Rollback
```bash
# Revert to previous application version
kubectl rollout undo deployment/cpar-api

# Verify rollback
kubectl rollout status deployment/cpar-api
kubectl logs -f deployment/cpar-api | head -50
```

## Validation Checklist

### Pre-Deployment Validation
- [ ] Database view `vw_shipment_info` exists and accessible
- [ ] Application configuration has `use-view: false` initially
- [ ] Fallback is enabled (`fallback-enabled: true`)
- [ ] Health check endpoints are accessible
- [ ] Monitoring dashboards are configured

### Post-Deployment Validation
- [ ] Application starts successfully with view code deployed
- [ ] Health endpoints report healthy status
- [ ] Feature flag controls work correctly
- [ ] Fallback mechanism functions properly
- [ ] Performance metrics are being collected

### Production Readiness Validation
- [ ] View implementation performs within acceptable SLA
- [ ] Fallback rate is below 5% during normal operations
- [ ] Error rates remain stable after activation
- [ ] Database performance impact is minimal
- [ ] Monitoring alerts are properly configured

## Success Metrics

### Performance Metrics
- **Query Response Time**: <100ms for single record lookups
- **Fallback Rate**: <5% during normal operations
- **Error Rate**: <0.1% for view operations
- **CPU Usage**: No significant increase from baseline

### Operational Metrics
- **Deployment Success**: Zero downtime during feature activation
- **Recovery Time**: <5 minutes for emergency disable
- **Configuration Changes**: Applied within 1 minute
- **Monitoring Coverage**: 100% visibility into view operations

## Contact Information

### Support Escalation
- **L1 Support**: Operations team monitoring dashboards
- **L2 Support**: Application development team
- **L3 Support**: Database administrators for view-related issues
- **Emergency Contact**: On-call engineer for production issues

### Documentation References
- **Technical Architecture**: `docs/testing/vw_shipment_info-A/session_handover_05.md`
- **Configuration Reference**: `CLAUDE.md` - Shipment View Architecture section
- **API Documentation**: Swagger UI at `/cpar-api/swagger-ui/index.html`
- **Monitoring Dashboards**: Prometheus metrics at `/cpar-api/actuator/prometheus`