# vw_shipment_info Rollback Procedure

## Emergency Rollback Guide

This document provides comprehensive procedures for rolling back the shipment view (vw_shipment_info) implementation in case of production issues.

## Rollback Scenarios

### Scenario 1: Feature Flag Disable (Soft Rollback)
**When to Use**: Minor performance issues, unexpected behavior, high fallback rates
**Impact**: Zero downtime, immediate effect
**Recovery Time**: 1-2 minutes

### Scenario 2: Application Version Rollback (Hard Rollback)
**When to Use**: Critical bugs, application crashes, severe performance degradation
**Impact**: Brief downtime during deployment
**Recovery Time**: 5-10 minutes

### Scenario 3: Complete Environment Rollback
**When to Use**: Multiple component failures, data corruption concerns
**Impact**: Service downtime during full rollback
**Recovery Time**: 15-30 minutes

## Scenario 1: Feature Flag Disable (Immediate)

### Quick Disable via Configuration

#### Method 1A: Kubernetes ConfigMap Update (Fastest)
```bash
# Emergency disable - Single command approach
kubectl patch configmap cpar-api-config -p '{
  "data": {
    "application.yml": "shipment:\n  use-view: false\n  fallback-enabled: true"
  }
}'

# Restart deployment to pick up changes
kubectl rollout restart deployment/cpar-api

# Verify rollback successful
kubectl rollout status deployment/cpar-api
```

#### Method 1B: Environment Variable Override
```bash
# Override via environment variable (takes effect immediately)
kubectl set env deployment/cpar-api SHIPMENT_USE_VIEW=false

# Verify environment variable set
kubectl get deployment cpar-api -o yaml | grep -A5 env:
```

#### Method 1C: Spring Boot Admin (if available)
```bash
# Use management endpoint to disable feature
curl -X POST http://cpar-api:8080/cpar-api/actuator/env \
  -H "Content-Type: application/json" \
  -d '{"name": "shipment.use-view", "value": "false"}'

# Refresh configuration
curl -X POST http://cpar-api:8080/cpar-api/actuator/refresh
```

### Verification Steps for Scenario 1
```bash
# 1. Check configuration applied
curl http://cpar-api:8080/cpar-api/actuator/configprops | grep -A10 shipment

# 2. Verify logs show table implementation
kubectl logs -f deployment/cpar-api | grep -i "table.*implementation"

# 3. Monitor error rates return to baseline
curl http://cpar-api:8080/cpar-api/actuator/metrics/shipment.view.errors

# 4. Check health endpoints
curl http://cpar-api:8080/cpar-api/actuator/health
```

## Scenario 2: Application Version Rollback

### Preparation (Maintain at all times)
```bash
# Always tag current working version before deployment
kubectl get deployment cpar-api -o yaml > cpar-api-backup-$(date +%Y%m%d-%H%M).yaml

# Note current image version
kubectl get deployment cpar-api -o jsonpath='{.spec.template.spec.containers[0].image}'
```

### Rolling Back Application Version

#### Method 2A: Kubernetes Rollback Command
```bash
# Check rollout history
kubectl rollout history deployment/cpar-api

# Rollback to previous version
kubectl rollout undo deployment/cpar-api

# Verify rollback
kubectl rollout status deployment/cpar-api

# Confirm previous image is running
kubectl get pods -l app=cpar-api -o jsonpath='{.items[*].spec.containers[0].image}'
```

#### Method 2B: Specific Version Rollback
```bash
# Rollback to specific revision
kubectl rollout undo deployment/cpar-api --to-revision=2

# Or set specific image version
kubectl set image deployment/cpar-api cpar-api=cpar-api:v1.2.3
```

#### Method 2C: Complete Deployment Restore
```bash
# Restore from backup file
kubectl apply -f cpar-api-backup-YYYYMMDD-HHMM.yaml

# Wait for rollout completion
kubectl rollout status deployment/cpar-api
```

### Verification Steps for Scenario 2
```bash
# 1. Verify correct image version
kubectl describe deployment cpar-api | grep Image:

# 2. Check all pods are running
kubectl get pods -l app=cpar-api

# 3. Verify application health
curl -f http://cpar-api:8080/cpar-api/actuator/health

# 4. Confirm functionality restored
curl -f http://cpar-api:8080/cpar-api/swagger-ui/index.html

# 5. Monitor logs for errors
kubectl logs -f deployment/cpar-api --tail=50
```

## Scenario 3: Complete Environment Rollback

### Database Rollback (if needed)
```sql
-- If view implementation caused database issues
-- Drop problematic view (coordinate with DBA)
DROP VIEW IF EXISTS vw_shipment_info CASCADE;

-- Restore from backup if necessary
-- (Follow database-specific backup restoration procedures)
```

### Full Application Stack Rollback
```bash
# 1. Rollback application deployment
kubectl rollout undo deployment/cpar-api

# 2. Rollback associated ConfigMaps
kubectl apply -f configmap-backup-YYYYMMDD.yaml

# 3. Rollback any related services
kubectl apply -f service-backup-YYYYMMDD.yaml

# 4. Verify entire stack
kubectl get all -l app=cpar-api
```

## Post-Rollback Procedures

### Immediate Verification Checklist
- [ ] Application pods are running and healthy
- [ ] Health check endpoints return 200 OK
- [ ] Error rates have returned to baseline
- [ ] Core functionality is operational
- [ ] Database connections are stable
- [ ] Monitoring alerts have cleared

### Extended Monitoring (First 30 minutes)
```bash
# Monitor application logs continuously
kubectl logs -f deployment/cpar-api | tee rollback-$(date +%H%M).log

# Watch key metrics
watch -n 30 'curl -s http://cpar-api:8080/cpar-api/actuator/metrics/http.server.requests | jq ".measurements[0].value"'

# Monitor pod resource usage
kubectl top pods -l app=cpar-api
```

### Stakeholder Communication
```bash
# Generate status report
cat << EOF > rollback_status_$(date +%Y%m%d_%H%M).txt
Rollback Status Report
=====================
Date: $(date)
Scenario: [Specify which rollback scenario was used]
Duration: [Time from issue detection to resolution]
Impact: [Brief description of service impact]
Root Cause: [If known, brief description]
Current Status: [RESOLVED/MONITORING/INVESTIGATING]

Technical Details:
- Application Version: $(kubectl get deployment cpar-api -o jsonpath='{.spec.template.spec.containers[0].image}')
- Pod Count: $(kubectl get pods -l app=cpar-api --no-headers | wc -l)
- Health Status: $(curl -s -o /dev/null -w "%{http_code}" http://cpar-api:8080/cpar-api/actuator/health)

Next Steps:
- [List any follow-up actions needed]
EOF
```

## Rollback Decision Matrix

| Issue Severity | Recommended Action | Expected Downtime | Recovery Time |
|----------------|-------------------|-------------------|---------------|
| Minor performance issue | Feature flag disable | None | 1-2 minutes |
| High error rate (>5%) | Feature flag disable | None | 1-2 minutes |
| Application unresponsive | Application rollback | 2-5 minutes | 5-10 minutes |
| Critical functionality broken | Application rollback | 2-5 minutes | 5-10 minutes |
| Data integrity concerns | Complete environment rollback | 10-15 minutes | 15-30 minutes |
| Multiple system failures | Complete environment rollback | 15-30 minutes | 30-60 minutes |

## Testing Rollback Procedures

### Pre-Production Testing
```bash
# Test feature flag disable in QA environment
kubectl --context=qa patch configmap cpar-api-config -p '{"data":{"application.yml":"shipment:\n  use-view: false"}}'

# Test application rollback in staging
kubectl --context=staging rollout undo deployment/cpar-api

# Verify rollback procedures work as expected
# Document any issues or timing differences
```

### Rollback Drill Schedule
- **Monthly**: Feature flag disable test in QA environment
- **Quarterly**: Application version rollback test in staging environment
- **Annually**: Complete environment rollback drill in disaster recovery environment

## Prevention Measures

### Monitoring and Alerting
```yaml
# Recommended alerts for early detection
alerts:
  - name: ShipmentViewHighErrorRate
    condition: shipment_view_error_rate > 5%
    severity: warning
    action: Consider feature flag disable

  - name: ShipmentViewHighFallbackRate
    condition: shipment_view_fallback_rate > 20%
    severity: warning
    action: Investigate view performance

  - name: ApplicationUnresponsive
    condition: http_requests_per_second = 0 for 2 minutes
    severity: critical
    action: Immediate rollback consideration
```

### Configuration Safeguards
```yaml
# Recommended safeguards in production configuration
shipment:
  use-view: true
  fallback-enabled: true        # ALWAYS enabled in production
  retry-attempts: 3             # Reasonable retry count
  query-timeout-ms: 30000       # Prevent hanging queries
  health-check-enabled: true    # Monitor view availability
```

## Emergency Contacts

### Escalation Path
1. **Operations Team**: First responders, execute rollback procedures
2. **Development Team**: Technical guidance, root cause analysis
3. **Database Team**: Database-related issues and view management
4. **Management**: Major incident communication and decision making

### Contact Information
```
Operations Team:    [24/7 on-call rotation]
Development Lead:   [Contact details]
Database DBA:       [Contact details]
Incident Manager:   [Contact details]
```

### Communication Channels
- **Immediate**: Slack #incidents channel
- **Status Updates**: Email distribution list
- **Post-Incident**: JIRA incident ticket

## Documentation Updates

After any rollback:
1. Update this document with lessons learned
2. Document timing differences from estimates
3. Update monitoring thresholds based on observed behavior
4. Review and update escalation procedures if needed
5. Schedule team review meeting within 48 hours

## Related Documents
- **Migration Guide**: `vw_shipment_info_migration_guide.md`
- **Technical Architecture**: `session_handover_05.md`
- **Configuration Reference**: `CLAUDE.md`
- **Incident Response Plan**: `incident_response_procedures.md`