# NonJob Transaction Path Verification

## 🎯 Executive Summary

This document provides comprehensive verification that both NonJob transaction types are correctly implemented and differentiated:

- **JOB_INVOICE Type**: Has `JobInvoiceNumber`, matches by `ChargeCode.Code` → `acc.AC_Code`
- **GL_ACCOUNT Type**: No `JobInvoiceNumber`, matches by `Glaccount.AccountCode` → `ag.AG_AccountNum`

**Verification Status**: ✅ **PRODUCTION READY** (18/18 tests passing)

---

## 📊 Side-by-Side Path Comparison

### Detection Phase

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     NonJobType.detectFromPayload()                      │
│                                                                         │
│  Extract: $.Body.UniversalTransaction.TransactionInfo.JobInvoiceNumber │
│                              ↓                                          │
│                   StringUtils.isNotBlank()?                             │
│                              ↓                                          │
│              ┌───────────────┴────────────────┐                        │
│              ↓                                 ↓                        │
│        TRUE (has value)              FALSE (null/blank/empty)          │
│              ↓                                 ↓                        │
│       JOB_INVOICE                         GL_ACCOUNT                   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Processing Flow Comparison

| Step | JOB_INVOICE Path | GL_ACCOUNT Path |
|------|-----------------|----------------|
| **1. Entry Method** | `processJobInvoiceNonJob()` | `processGLAccountNonJob()` |
| **2. Query Method** | `getCWAccountTransactionInfo()` | `getCwTransactionInfoForGLAccount()` |
| **3. SQL Query** | `QUERY_CW_ACCOUNT_TRANSACTION_INFO_NONJOB` | `QUERY_CW_ACCOUNT_TRANSACTION_INFO_GL_ACCOUNT` |
| **4. Organization Filter** | ✅ WITH `org.OR_Code = ?` | ❌ WITHOUT (processes all rows) |
| **5. Match Field (DB)** | `acc.AC_Code` as `charge_Code` | `ag.AG_AccountNum` as `gl_Account` |
| **6. Match Field (Payload)** | `$.ChargeCode.Code` | `$.Glaccount.AccountCode` |
| **7. Processor Method** | `handleNonJobChargeLines()` | `handleGLAccountChargeLines()` |
| **8. Lines PK Strategy** | Always use `AL_PK` | Use `AL_PK` OR composite UUID |
| **9. Row Processing** | Single org match | ALL rows (multi-line) |

---

## 🔍 Reference File Analysis

### File 1: `reference/NonJob_AR_INV_2511001018-ADD.json`

**Detection Result**: `JOB_INVOICE` ✅

#### Key Payload Structures

```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": {
        "JobInvoiceNumber": "WI00000077/A",        ← DETECTION KEY (line 128)
        "Number": "2511001018",
        "Ledger": "AR",
        "TransactionType": "INV",
        "PostingJournalCollection": {
          "PostingJournal": [{
            "ChargeCode": {
              "Code": "DOC"                         ← MATCH KEY (line 207)
            },
            "Glaccount": {
              "AccountCode": "4070.10.10"           ← Also present but not used
            },
            "Osamount": 50.0,
            "Osgstvatamount": 0.0,
            "Sequence": 3
          }]
        }
      }
    }
  }
}
```

#### Processing Flow

```
1. Detection
   JobInvoiceNumber = "WI00000077/A" → JOB_INVOICE ✅

2. Database Query (WITH org filter)
   SELECT acc.AC_Code as charge_Code, al.AL_PK as lines_pk
   FROM AccTransactionHeader ah
   JOIN AccTransactionLines al ON al.AL_AH = ah.AH_PK
   JOIN AccChargeCode acc ON al.AL_AC = acc.AC_PK
   JOIN OrgHeader org ON ...
   WHERE ah.AH_TransactionNum = '2511001018'
     AND org.OR_Code = 'QINGARTAO'              ← Organization filter

   Result: charge_Code = 'DOC', lines_pk = <AL_PK_UUID>

3. Charge Line Matching (handleNonJobChargeLines)
   Extract from payload: $.ChargeCode.Code = "DOC"
   Compare with DB: charge_Code = "DOC"
   Match: ✅ StringUtils.equals("DOC", "DOC")

4. Lines PK Assignment
   cw_acct_trans_lines_pk = AL_PK (from database, always exists)
```

---

### File 2: `reference/NonJob-AR_INV_2511001019-Add.json`

**Detection Result**: `GL_ACCOUNT` ✅

#### Key Payload Structures

```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": {
        "JobInvoiceNumber": "",                     ← DETECTION KEY (line 127) - EMPTY!
        "Number": "2511001019",
        "Ledger": "AR",
        "TransactionType": "INV",
        "PostingJournalCollection": {
          "PostingJournal": [{
            "Glaccount": {
              "AccountCode": "1210.00.10"            ← MATCH KEY (line 313)
            },
            "Osamount": 38,
            "Osgstvatamount": 2.28,
            "Sequence": 1
            // NOTE: No ChargeCode object!
          }]
        }
      }
    }
  }
}
```

#### Processing Flow

```
1. Detection
   JobInvoiceNumber = "" → GL_ACCOUNT ✅

2. Database Query (WITHOUT org filter)
   SELECT acc.AC_Code as charge_Code,
          ag.AG_AccountNum as gl_Account,       ← Match field
          al.AL_PK as lines_pk                  ← May be NULL
   FROM AccTransactionHeader ah
   LEFT JOIN AccTransactionLines al ON al.AL_AH = ah.AH_PK
   LEFT JOIN AccGLHeader ag ON al.AL_AG = ag.AG_PK
   WHERE ah.AH_TransactionNum = '2511001019'
   -- NO org filter - returns ALL rows

   Result: gl_Account = '1210.00.10', lines_pk = <AL_PK_UUID or NULL>

3. Charge Line Matching (handleGLAccountChargeLines)
   Extract from payload: $.Glaccount.AccountCode = "1210.00.10"
   Compare with DB: gl_Account = "1210.00.10"
   Match: ✅ StringUtils.equals("1210.00.10", "1210.00.10")

4. Lines PK Assignment (with fallback)
   IF (AL_PK exists):
       cw_acct_trans_lines_pk = AL_PK
   ELSE:
       compositeKeySource = header_PK + "-" + postingJournalIndex
       cw_acct_trans_lines_pk = UUID.nameUUIDFromBytes(compositeKeySource)
```

---

## 🎯 Critical Implementation Details

### 1. Detection Logic (`NonJobType.java:63-87`)

```java
public static NonJobType detectFromPayload(String json) {
    Configuration config = Configuration.builder()
        .options(Option.SUPPRESS_EXCEPTIONS, Option.DEFAULT_PATH_LEAF_TO_NULL)
        .build();

    String jobInvoiceNumber = JsonPath.using(config)
        .parse(json)
        .read("$.Body.UniversalTransaction.TransactionInfo.JobInvoiceNumber", String.class);

    if (StringUtils.isNotBlank(jobInvoiceNumber)) {  // ← Handles null, "", " "
        return JOB_INVOICE;
    } else {
        return GL_ACCOUNT;
    }
}
```

**Test Results:**
- `"WI00000077/A"` → `isNotBlank()` = `true` → `JOB_INVOICE` ✅
- `""` (empty) → `isNotBlank()` = `false` → `GL_ACCOUNT` ✅
- `null` → `isNotBlank()` = `false` → `GL_ACCOUNT` ✅

### 2. Job-Invoice Matching (`ChargeLineProcessor.java:912-917`)

```java
// Job-Invoice NONJOB: Match by ChargeCode.Code
String currentChargeCode = JsonPath.using(configWithoutException)
    .parse(jsonChargeLine)
    .read("$.ChargeCode.Code");

if (StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode())) {
    // Match found: DOC == DOC
    // Use AL_PK from database
}
```

### 3. GL-Account Matching (`ChargeLineProcessor.java:675-681`)

```java
// GL-Account type: Match by GL account number
String currentGlAccount = JsonPath.using(configWithoutException)
    .parse(jsonChargeLine)
    .read("$.Glaccount.AccountCode");

if (StringUtils.equals(currentGlAccount, cwTransactionInfo.getGlAccount())) {
    // Match found: 1210.00.10 == 1210.00.10
    // Use AL_PK if exists, else generate composite UUID
}
```

### 4. Composite Key Generation (GL-Account Only)

```java
// When AL_PK is NULL (only for GL_ACCOUNT type)
if (linesPk == null) {
    String compositeKeySource = headerPk.toString() + "-" + postingJournalIndex;
    UUID compositeKey = UUID.nameUUIDFromBytes(
        compositeKeySource.getBytes(StandardCharsets.UTF_8)
    );
    linesBean.setCwAccountTransactionLinesPk(compositeKey);
}
```

**Benefits:**
- ✅ Deterministic: Same input always produces same UUID
- ✅ Idempotent: Webhook retries produce same UUID
- ✅ Unique: Different PostingJournal entries get different UUIDs

---

## 🧪 Test Results

### Unit Tests: 18/18 Passing ✅

```bash
$ ./mvnw test -Dtest="TransactionMappingServiceNonjobJobKeyTest,NonJobTypeDetectionRealDataTest"

[INFO] Tests run: 16, Failures: 0, Errors: 0, Skipped: 0
      -- in TransactionMappingServiceNonjobJobKeyTest
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
      -- in NonJobTypeDetectionRealDataTest

[INFO] BUILD SUCCESS
```

### Real Data Detection Tests

```
✅ Successfully detected JOB_INVOICE type from reference file
   File: NonJob_AR_INV_2511001018-ADD.json
   Expected: JOB_INVOICE
   Actual: JOB_INVOICE

✅ Successfully detected GL_ACCOUNT type (no JobInvoiceNumber)
   File: NonJob-AR_INV_2511001019-Add.json
   Expected: GL_ACCOUNT
   Actual: GL_ACCOUNT
```

---

## 📋 Production Readiness Checklist

| Category | Item | Status |
|----------|------|--------|
| **Detection** | JsonPath extraction for JobInvoiceNumber | ✅ |
| | Empty string handling (`isNotBlank`) | ✅ |
| | Null safety with `SUPPRESS_EXCEPTIONS` | ✅ |
| **Job-Invoice** | ChargeCode.Code extraction | ✅ |
| | acc.AC_Code matching logic | ✅ |
| | Organization filter in SQL query | ✅ |
| | AL_PK direct usage | ✅ |
| **GL-Account** | Glaccount.AccountCode extraction | ✅ |
| | ag.AG_AccountNum matching logic | ✅ |
| | No organization filter (multi-row) | ✅ |
| | Composite UUID generation when AL_PK NULL | ✅ |
| **Testing** | Unit tests (16 tests) | ✅ |
| | Real data detection tests (2 tests) | ✅ |
| | Reference file validation | ✅ |
| **Documentation** | CLAUDE.md updated with type differentiation | ✅ |
| | Code comments and JavaDoc | ✅ |
| **Integration** | V2 integration tests | ⏳ Recommended next step |
| **Deployment** | Production deployment | ⏳ Ready after integration tests |

---

## 🚀 Next Steps

### Priority 1: V2 Integration Testing

Create comprehensive end-to-end tests following the `BaseTransactionIntegrationTest` pattern:

1. **`JobInvoiceNonJobIntegrationTestV2.java`**
   - Test complete Job-Invoice NonJob flow
   - Verify charge code matching (DOC, FRT, AMS)
   - Validate database persistence
   - Confirm external system routing

2. **`GLAccountNonJobIntegrationTestV2.java`**
   - Test complete GL-Account NonJob flow
   - Verify GL account matching (1210.00.10, 4070.10.10)
   - Validate composite key generation when AL_PK is NULL
   - Test multi-row processing (no org filter)

### Priority 2: Test Data Setup

Create Cargowise test data files:

- `test-data-cargowise-nonjob-jobinvoice.sql`: Job-Invoice type with AccTransactionLines
- `test-data-cargowise-nonjob-glaccount.sql`: GL-Account type with/without AccTransactionLines

### Priority 3: Sample Payloads

Create test payloads in `src/test/resources/`:

- `nonjob-jobinvoice-ar-inv.json`: Job-Invoice type payload
- `nonjob-glaccount-ar-inv.json`: GL-Account type payload

---

## 📚 Architecture Insights

`★ Insight ─────────────────────────────────────────────────────────────`

**1. Type Detection Strategy**
The system uses a single discriminator field (`JobInvoiceNumber`) to determine
processing path, following the Strategy Pattern. This is more elegant than
checking multiple fields or using complex conditionals.

**2. Match Field Separation**
Job-Invoice and GL-Account types use completely different match fields:
- Job-Invoice: Business charge codes (DOC, FRT) from AccChargeCode table
- GL-Account: Accounting GL codes (1210.00.10) from AccGLHeader table
This prevents cross-contamination and ensures accurate data matching.

**3. Composite Key Innovation**
The deterministic UUID generation for GL-Account NULL scenarios enables:
- Idempotent webhook retry handling (same UUID for same data)
- No database schema changes required
- Future-proof for Cargowise data structure evolution

`─────────────────────────────────────────────────────────────────────────`

---

## 🔗 Related Documentation

- **Architecture**: `CLAUDE.md` (lines 131-242)
- **V2 Testing Framework**: `docs/testing/integration-test-architecture-insights.md`
- **Reference Data**: `docs/testing/reference-data-consolidation-guide.md`
- **Session Handover**: See message history for complete session details

---

**Report Date**: 2025-11-20
**Verification Status**: ✅ PRODUCTION READY (pending integration tests)
**Test Coverage**: 18/18 unit tests passing, real data validated
**Next Milestone**: V2 integration test implementation
