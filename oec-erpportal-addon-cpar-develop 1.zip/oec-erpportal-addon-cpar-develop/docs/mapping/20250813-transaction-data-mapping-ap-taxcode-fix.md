# Transaction Data Mapping Documentation - AP TaxCode Fix

## Overview
This document describes the data mapping from UniversalTransaction JSON to external systems and database tables in the CPAR (Compliance Accounts Receivable) service. The TransactionServiceImpl processes incoming transaction data and routes it to appropriate destinations.

**📝 UPDATE NOTES (2025-08-13):**
- **FIXED**: AP transactions now correctly use `$.CostGSTVATID.TaxCode` instead of `$.SellGSTVATID.TaxCode`
- **ADDED**: Validation logic for AP transactions using `hasValidCostGSTVATID()` method
- **REASONING**: AP (vendor invoices) should use cost-side VAT data, not sell-side VAT data

## Data Flow Architecture

```
UniversalTransaction (JSON) 
    ↓
TransactionServiceImpl
    ↓
┌─────────────────────────────────────┐
│  Database Tables (SOPL PostgreSQL)  │
│  - at_account_transaction_header    │
│  - at_account_transaction_lines     │
└─────────────────────────────────────┘
    ↓
External Compliance System (China Tax)
```

## 1. Transaction Header Mapping

### Target: `at_account_transaction_header` table

| Target Field | Source JsonPath | Database Query | Description |
|--------------|-----------------|----------------|-------------|
| **acct_trans_header_id** | Generated UUID | N/A | Auto-generated UUID |
| **ref_no** | See RefNo Query | SQL(A) or SQL(A+) | Shipment or Consol number |
| **cw_acc_trans_header_pk** | N/A | SQL(A/A+): `ath.AH_PK` | Cargowise AccTransaction Header PK |
| **ledger** | `$.Body.UniversalTransaction.TransactionInfo.Ledger` | N/A | AR or AP |
| **trans_type** | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | N/A | INV, CRD, JNL, REV, PAY |
| **inv_no** | AR: `$.Body.UniversalTransaction.TransactionInfo.JobInvoiceNumber`<br>AP: `$.Body.UniversalTransaction.TransactionInfo.Number` | N/A | Invoice number |
| **inv_date** | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | N/A | Invoice date |
| **due_date** | `$.Body.UniversalTransaction.TransactionInfo.DueDate` | N/A | Due date |
| **crncy_code** | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | N/A | Currency code |
| **inv_amt** | `$.Body.UniversalTransaction.TransactionInfo.Ostotal` | N/A | Invoice amount |
| **outstanding_amt** | `$.Body.UniversalTransaction.TransactionInfo.OutstandingAmount` | N/A | Outstanding amount |
| **cmpny_dept** | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | N/A | Department code |
| **exchg_rate** | `$.Body.UniversalTransaction.TransactionInfo.ExchangeRate` | N/A | Exchange rate |
| **inv_org_code** | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | N/A | Debitor organization code |
| **local_crncy_code** | `$.Body.UniversalTransaction.TransactionInfo.LocalCurrency.Code` | N/A | Local currency (CNY) |
| **cmpny_branch** | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | N/A | Branch code |
| **trans_desc** | `$.Body.UniversalTransaction.TransactionInfo.Description` | N/A | Transaction description |
| **total_vat_amt** | `$.Body.UniversalTransaction.TransactionInfo.Osgstvatamount` | N/A | Total VAT amount |
| **local_total_vat_amt** | `$.Body.UniversalTransaction.TransactionInfo.LocalVATAmount` | N/A | Local VAT amount |
| **cmpny_code** | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | N/A | Company code |
| **trans_no** | `$.Body.UniversalTransaction.TransactionInfo.Number` | N/A | Transaction number |
| **is_cancel** | `$.Body.UniversalTransaction.TransactionInfo.IsCancelled` | N/A | Cancellation flag |
| **update_time** | `$.Body.UniversalTransaction.TransactionInfo.DataContext.TriggerDate` | N/A | ISO8601 timestamp |

## 2. Transaction Lines Mapping

### Target: `at_account_transaction_lines` table

| Target Field | Source JsonPath | Database Query | Description |
|--------------|-----------------|----------------|-------------|
| **acc_trans_lines_id** | Generated UUID | N/A | Auto-generated UUID |
| **acct_trans_header_id** | From header | N/A | Links to header record |
| **cw_acct_trans_lines_pk** | N/A | SQL(A): `atl.AL_PK`<br>SQL(A+): `jcl.e6_pk` | Cargowise line PK |
| **chrg_code_id** | N/A | SQL(A/A+): `acc.AC_PK` | Charge code ID |
| **crncy_code** | AR: `$.SellOSCurrency.Code`<br>AP: `$.CostOSCurrency.Code` | N/A | Currency code |
| **chrg_amt** | AR: `($.SellOSAmount + $.SellOSGSTVATAmount) * -1`<br>AP: `($.CostOSAmount + $.CostOSGSTVATAmount) * -1` | N/A | Charge amount (including tax) |
| **vat_amt** | AR: `$.SellOSGSTVATAmount * -1`<br>AP: `$.CostOSGSTVATAmount * -1` | N/A | VAT amount |
| **total_amt** | AR: `$.SellLocalAmount * -1`<br>AP: `$.CostLocalAmount * -1` | N/A | Total local amount |
| **exchg_rate** | AR: `$.SellExchangeRate`<br>AP: `$.CostExchangeRate` | N/A | Exchange rate |
| **local_crncy_code** | From company config or `$.CostOSCurrency.Code` | SQL: `cw_global_company.crncy_code` | Local currency |
| **local_vat_amt** | Calculated: `vat_amt * exchg_rate` | N/A | Local VAT amount |
| **trans_line_desc** | `$.ChargeCode.Description` or `$.Description` | SQL: `cw_ref_account_charge_code` (AR only) | Line description |
| **display_sequence** | `$.DisplaySequence` | N/A | Display order |

### ChargeLine Location Paths (Context-Dependent)

**For SHIPMENT type:**
- Primary: `$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]`
- Fallback: `$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].SubShipmentCollection.SubShipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]`

**For CONSOL type:**
- `$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].ConsolCosts.ConsolCostLineCollection.ConsolCostLine[*]`

## 3. External System Request Mapping

### Target: `TransactionChargeLineRequestBean` (sent to China Tax System)

The TransactionChargeLineRequestBean extends TransactionInfoRequestBean, so it includes all header-level buyer information plus line-level details.

#### 3.1 Header-Level Fields (Inherited from TransactionInfoRequestBean)

| Target Field | Source | Condition | Description |
|--------------|--------|-----------|-------------|
| **billNo** | `$.Body.UniversalTransaction.TransactionInfo.Number` | Always | Transaction number |
| **transactionType** | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | Always | INV, CRD, etc. |
| **billDate** | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | Always | Transaction date |
| **companyCode** | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | Always | Company code |
| **branchCode** | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | Always | Branch code |
| **departmentCode** | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | Always | Department code |
| **currency** | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | Always | Currency code |
| **shipmentId** | `$.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key` | If exists | Shipment ID |
| **consolNo** | `$.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key` | If exists | Consol number |
| **debiterCode** | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | Always | Debitor organization |
| **debiterName** | Database query | Always | From cw_org_header |
| **buyerCode** | AR: `$..SellReference`<br>AP: Complex extraction (see section 5) | When sending to external | Buyer organization code |
| **buyerName** | Database query | When buyerCode exists | From cw_org_address |
| **buyerTaxNo** | Database query | When buyerCode exists | From cw_org_cus_code (VAT) |
| **buyerAddr** | Database query | When buyerCode exists | addr1 + addr2 from cw_org_address |
| **buyerTel** | Database query | When buyerCode exists | From cw_org_address.phone |
| **buyerBankName** | Database query (Cargowise) | When buyerCode exists | From AccAPAccountDetails |
| **buyerBankAccount** | Database query (Cargowise) | When buyerCode exists | From AccAPAccountDetails |
| **buyerEmail** | Database query | When buyerCode exists | From cw_org_address.email |
| **taxRate** | `$.PostingJournalCollection.PostingJournal[*].VattaxID.TaxRate` | AR only | Tax rate from posting journal |
| **oldBillNo** | `$.OriginalReference.OriginalTransactionNumber` | For reversed transactions | Original transaction number |
| **oldBillType** | Database query | For reversed transactions | Original transaction type |

#### 3.2 Line-Level Fields (TransactionChargeLineRequestBean specific)

| Target Field | Source | Condition | Description |
|--------------|--------|-----------|-------------|
| **itemGuid** | Generated UUID | Always | Line identifier |
| **itemCode** | `$.ChargeCode.Code` | Always | Charge code |
| **itemName** | `$.ChargeCode.Description` | Always | Item description |
| **itemUnit** | null | Always | Unit (empty) |
| **qty** | 1 | Always | Quantity (fixed) |
| **taxCode** | AR: `$.SellGSTVATID.TaxCode`<br>AP: `$.CostGSTVATID.TaxCode` ✅ **FIXED** | AR always, AP conditional | Tax code |
| **taxRate** | From PostingJournal matching | AR only | Tax rate percentage |
| **zeroFlag** | Calculated | Always | Zero tax flag |
| **discountAmt** | 0 | Always | Discount amount |
| **discountTaxAmt** | 0 | Always | Discount tax |
| **discountAmtIncludeTax** | 0 | Always | Discount including tax |
| **price** | AR: `$.SellOSAmount`<br>AP: `$.CostOSAmount * -1` | Always | Unit price |
| **taxIncludedAmount** | Same as price | Always | Amount with tax |
| **amount** | `price - GST/VAT amount` | Always | Amount without tax |

## 4. SQL Queries

### SQL(A): SHIPMENT Query
```sql
SELECT DISTINCT 
  ath.AH_PK as account_Transaction_Header_Pk,
  ath.AH_TransactionNum as invoice_no,
  oh.OH_Code as creditor,
  atl.AL_Sequence as display_Sequence,
  jh.JH_JobNum as job_Number,
  atl.AL_PK as account_Transaction_Lines_Pk,
  acc.AC_PK as account_Charge_Code_Pk,
  acc.AC_Code as charge_Code
FROM AccTransactionHeader ath
INNER JOIN AccTransactionLines atl on atl.AL_AH = ath.AH_PK
INNER JOIN AccChargeCode acc on acc.AC_PK = atl.AL_AC
INNER JOIN JobHeader jh on jh.JH_PK = atl.AL_JH
INNER JOIN OrgHeader oh on atl.AL_OH = oh.OH_PK
WHERE ath.AH_Ledger = :ledger
  AND ath.AH_TransactionType = :transactionType
  AND ath.AH_TransactionNum = :transactionNo
  AND oh.OH_Code = :organizationCode
```

### SQL(A+): CONSOL Query
```sql
SELECT DISTINCT 
  ath.AH_PK as account_Transaction_Header_Pk,
  ath.AH_TransactionNum as invoice_no,
  jcl.e6_pk as account_Transaction_Lines_Pk,
  acc.AC_PK as account_Charge_Code_Pk,
  acc.AC_Code as charge_Code
FROM AccTransactionHeader ath
INNER JOIN JobConsolCost jcl ON jcl.e6_ah_apinvoice = ath.ah_pk
INNER JOIN AccChargeCode acc on acc.AC_PK = jcl.E6_AC_ChargeCode
WHERE ath.AH_Ledger = :ledger
  AND ath.AH_TransactionType = :transactionType
  AND ath.AH_TransactionNum = :transactionNo
```

### Buyer Information Query
```sql
SELECT oh.org_code, cn_oa.ovr_cmpny_name as COMPANY_NAME, 
       cn_oa.addr1, cn_oa.addr2, cn_oa.phone, cn_oa.email
FROM cw_org_address cn_oa
INNER JOIN cw_org_header oh on oh.org_header_id = cn_oa.org_header_id
WHERE upper((cn_oa.addr_code)::text) = 'LOCAL'::text
  AND oh.org_code = :organizationCode
```

### Buyer Tax Number Query
```sql
SELECT a.cus_code_value 
FROM cw_org_cus_code a
INNER JOIN cw_org_header b on a.org_header_id = b.org_header_id
WHERE a.cus_code_type = 'VAT'
  AND b.org_code = :organizationCode
```

### Buyer Bank Information Query (Cargowise DB)
```sql
SELECT a.A1_AccountName as BANK_NAME, a.A1_BankAccount as BANK_ACCOUNT 
FROM AccAPAccountDetails a
INNER JOIN OrgCompanyData b on a.A1_OB = b.OB_PK
INNER JOIN OrgHeader c on c.OH_PK = b.OB_OH
WHERE c.OH_Code = :organizationCode
  AND a.A1_RX_NKAccountCurrency = :currencyCode
```

## 5. Special Processing Rules

### Buyer Code Extraction

**AR Transactions:**
- Source: `$..SellReference` (first value)
- Required for all AR transactions

**AP Transactions:**
- Complex extraction based on refNoType (SHIPMENT or CONSOL)
- SHIPMENT: Search in `ChargeLine[?(@.CostAPInvoiceNumber=='<transactionNo>')].SupplierReference`
- CONSOL: Search in `ConsolCostLine[?(@.CostAPInvoiceNumber=='<transactionNo>')].SupplierReference`
- Fallback: SubShipment structure, then global search

### RefNo Type Determination
- Query JobCharge table with transaction number
- If `JobCharge.jr_e6` is null → SHIPMENT
- If `JobCharge.jr_e6` has value → CONSOL

### Data Filtering Rules

**AR Transactions to External System:**
- Only send ChargeLines with valid `SellGSTVATID.TaxCode`
- Lines without VAT info are saved to DB but not sent externally

**AP Transactions to External System:** ✅ **UPDATED**
- Only send ChargeLines with valid `CostGSTVATID.TaxCode`
- Lines without VAT info are saved to DB but not sent externally
- INV/CRD with `is_cancelled=false`: Save to database
- INV/CRD with `is_cancelled=true`: Update existing records
- CONSOL type: Process as single consolidated line

### Reversed Transactions
- EventReference patterns: `AR|CRD|Reversed`, `AR|INV|Reversed`, `AP|CRD|Reversed`, `AP|INV|Reversed`
- Use `OriginalReference.OriginalTransactionNumber` for lookup
- Reverse transaction type (CRD↔INV) for query
- Set outstanding amounts to zero

### Retry Mechanism
- Maximum 5 retries for database save operations
- Exponential backoff: 2^attempt seconds + random jitter
- Handles `CannotAcquireLockException` for concurrent access

## 6. Validation Requirements

### Minimum Required Data
- ChargeCode must be present and non-empty
- All monetary amounts must be valid decimals
- Exchange rates must be positive numbers

### External System Requirements ✅ **UPDATED**
- AR: Must have valid `SellGSTVATID` with `TaxCode`
- AP: Must have valid `CostGSTVATID` with `TaxCode` (when configured to send to external system)

### Policy Compliance
- All valid transaction data MUST be saved to database
- External system filtering is separate from database persistence
- Detailed logging of filtered vs. saved records

## 7. Environment-Specific Configuration

### JsonPath Variables by Ledger Type

**AR (Accounts Receivable):**
- `JSON_PATH_CHARGELINE_OSAMOUNT` = `$.SellOSAmount`
- `JSON_PATH_CHARGELINE_OSGSTVATAMOUNT` = `$.SellOSGSTVATAmount`
- `JSON_PATH_CHARGELINE_LOCALAMOUNT` = `$.SellLocalAmount`
- `JSON_PATH_CHARGELINE_OSCURRENCY_CODE` = `$.SellOSCurrency.Code`
- `JSON_PATH_CHARGELINE_EXCHANGE_RATE` = `$.SellExchangeRate`

**AP (Accounts Payable):**
- `JSON_PATH_CHARGELINE_OSAMOUNT` = `$.CostOSAmount`
- `JSON_PATH_CHARGELINE_OSGSTVATAMOUNT` = `$.CostOSGSTVATAmount`
- `JSON_PATH_CHARGELINE_LOCALAMOUNT` = `$.CostLocalAmount`
- `JSON_PATH_CHARGELINE_OSCURRENCY_CODE` = `$.CostOSCurrency.Code`
- `JSON_PATH_CHARGELINE_EXCHANGE_RATE` = `$.CostExchangeRate`

## 8. Error Handling

### Missing Data Scenarios
- **BuyerReferenceNotFoundException**: No SellReference (AR) or SupplierReference (AP) found
- **CwAccountTransactionHeaderNotFoundException**: Cargowise header not found in database
- **DebiterNameNotFoundException**: Organization name not found in cw_org_header

### Graceful Degradation
- Missing VAT info: Save to DB, skip external system
- Missing buyer info: Use empty strings, log warning
- Missing local currency: Default to empty or CostOSCurrency.Code

## 9. Processing Flow Summary

1. **Parse UniversalTransaction JSON**
   - Extract TransactionInfo structure
   - Determine ledger type (AR/AP) and transaction type

2. **Determine Reference Type**
   - Query JobCharge to identify SHIPMENT vs CONSOL
   - Affects subsequent query selection

3. **Extract Buyer Information**
   - AR: From SellReference
   - AP: Complex extraction based on refNoType

4. **Query Cargowise Database**
   - Use appropriate SQL query (A or A+)
   - Match transaction header and lines

5. **Process ChargeLines**
   - Map JSON fields to database columns
   - Apply ledger-specific transformations
   - Filter for external system requirements

6. **Save to Database**
   - Always save valid data to at_account_transaction tables
   - Handle concurrent access with retry mechanism

7. **Send to External System** ✅ **UPDATED**
   - Only send lines meeting external requirements:
     - AR: Valid `SellGSTVATID.TaxCode`
     - AP: Valid `CostGSTVATID.TaxCode`
   - Track sent vs saved counts for monitoring

## 10. Implementation Changes (2025-08-13)

### Code Changes Made:

#### 1. TransactionChargeLineRequestBean.java
**Before:**
```java
String taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellGSTVATID.TaxCode");
```

**After:**
```java
String taxCode;
if (StringUtils.equals("AR", ledger)) {
    // AR uses SellGSTVATID (sales side)
    taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellGSTVATID.TaxCode");
} else {
    // AP uses CostGSTVATID (cost/vendor side)
    taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID.TaxCode");
}
```

#### 2. TransactionServiceImpl.java
**Added:**
```java
private boolean hasValidCostGSTVATID(String jsonChargeLine) {
    try {
        Object costGSTVATID = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID");
        if (costGSTVATID == null) return false;
        
        String taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID.TaxCode");
        return StringUtils.isNotBlank(taxCode);
    } catch (Exception e) {
        log.debug("Error checking CostGSTVATID for charge line: {}", e.getMessage());
        return false;
    }
}
```

**Updated validation logic:**
```java
} else if (StringUtils.equals("AP", ledger)) {
    validForExternalSystem = hasValidCostGSTVATID(jsonChargeLine);
    if (!validForExternalSystem) {
        filteredOutChargeLines++;
        String chargeCode = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"), "UNKNOWN");
        log.info("AP ChargeLine will be saved to DB but not sent to external system - missing CostGSTVATID: ChargeCode={}", chargeCode);
    }
}
```

### Benefits:
- **Logical Correctness**: AP transactions now use cost-side VAT data as expected
- **Data Consistency**: Proper alignment between ledger type and VAT data source
- **Better Validation**: AP transactions have dedicated validation for their VAT requirements
- **Enhanced Logging**: Clear differentiation in log messages between AR and AP validation failures

## Version History
- **2025-08-12**: Initial comprehensive mapping document (Based on TransactionServiceImpl.java analysis)
- **2025-08-13**: Fixed AP transactions to use `$.CostGSTVATID.TaxCode` instead of `$.SellGSTVATID.TaxCode`