# ChequeOrReference Implementation Documentation

**Date**: September 9, 2025  
**Version**: 1.0  
**Feature**: Unified chequeOrReference field mapping for AR and AP transactions  
**Related Files**: `TransactionMappingService.java`, database schema updates  
**Audience**: Future developers, system integrators, support engineers

---

## 1. Executive Summary

The chequeOrReference implementation provides unified payment reference tracking across both AR (Accounts Receivable) and AP (Accounts Payable) transactions. This feature extracts payment references from transaction JSON payloads and persists them to the `chequeorreference` database field with a 38-character constraint.

### Quick Reference Table

| Transaction Type | Extraction Method | Data Source | Success Strategy | Database Field |
|------------------|-------------------|-------------|------------------|----------------|
| **AR** | `extractSellReferenceForAR()` | SellReference (ChargeLine) | Enhanced JsonPath filtering | `chequeorreference` |
| **AP** | `extractSellReferenceForAP()` | CheckNumberOrPaymentRef | Single-phase extraction | `chequeorreference` |
| **Other** | N/A | N/A | Skipped | `chequeorreference` (null) |

---

## 2. Implementation Overview

### 2.1 Current Architecture (Version 2.0 - Simplified)

The implementation has been streamlined from the original multi-phase hierarchical approach to focus on primary data sources for optimal performance and reliability.

#### AR Transaction Processing
- **Primary Method**: Enhanced JsonPath filtering with transaction number matching
- **Data Source**: `SellReference` from ChargeLine where `SellPostedTransactionNumber` matches transaction number
- **Fallback Strategy**: ~~Removed~~ (Previously used `$..SellReference` general extraction)
- **Success Expectation**: High success rate for matching transactions

#### AP Transaction Processing  
- **Primary Method**: Direct field extraction
- **Data Source**: `CheckNumberOrPaymentRef` field
- **Fallback Strategy**: ~~Removed~~ (Previously included JobInvoiceNumber and Description)
- **Success Expectation**: Success rate dependent on CheckNumberOrPaymentRef field population

### 2.2 Database Integration

#### Field Specifications
```sql
-- Database field constraint
chequeorreference VARCHAR(38) -- Maximum 38 characters with truncation logging
```

#### Constraint Handling
- Automatic truncation for values exceeding 38 characters
- Warning logs generated for truncated values
- Graceful null handling when extraction fails

---

## 3. Technical Implementation Details

### 3.1 AR Extraction Logic (`extractSellReferenceForAR`)

**Location**: `TransactionMappingService.java:647-702`

```java
/**
 * Enhanced AR buyer code extraction using JsonPath filtering
 * Matches SellPostedTransactionNumber with transaction number to find correct SellReference
 */
private String extractSellReferenceForAR(Object document, String transactionNumber, String refNoType) {
    try {
        // Phase 1: Enhanced JsonPath filtering (PRIMARY APPROACH)
        String sanitizedTransactionNumber = sanitizeForJsonPath(transactionNumber);
        String jsonPathExpression = String.format(
            "$..ChargeLine[?(@.SellPostedTransactionNumber=='%s')].SellReference", 
            sanitizedTransactionNumber
        );
        
        List<String> filteredSellReferenceList = JsonPath.read(document, jsonPathExpression);
        if (!filteredSellReferenceList.isEmpty()) {
            String sellReference = filteredSellReferenceList.getFirst();
            log.info("Enhanced AR logic found matching SellReference [{}] for transaction [{}]", 
                    sellReference, transactionNumber);
            return sellReference;
        }
        
        // FALLBACK LOGIC REMOVED - Version 2.0 Simplification
        // Previously attempted: $..SellReference general extraction
        // Now returns null if no matching transaction found
        
        log.warn("No SellReference found for AR transaction! TransactionInfo.Number = [{}]", transactionNumber);
        return null;
        
    } catch (Exception e) {
        // FALLBACK EXCEPTION HANDLING REMOVED - Version 2.0 Simplification
        // Previously attempted: final fallback to $..SellReference
        // Now returns null immediately on exception
        
        log.warn("Error during enhanced AR SellReference extraction for transaction [{}]: {}.", 
                transactionNumber, e.getMessage());
        return null;
    }
}
```

#### Key Changes from Original Implementation:
- **Removed**: Fallback to `$..SellReference` general extraction
- **Removed**: Final exception fallback logic
- **Retained**: Enhanced JsonPath filtering with transaction matching
- **Impact**: More precise extraction but potentially lower success rate for edge cases

### 3.2 AP Extraction Logic (`extractSellReferenceForAP`)

**Location**: `TransactionMappingService.java:713-754`

```java
/**
 * Enhanced AP buyer code extraction using hierarchical field priority
 * Extracts payment reference from AP transaction JSON payload with graceful fallback
 */
private String extractSellReferenceForAP(Object document, String transactionNumber, String refNoType) {
    try {
        // Phase 1: CheckNumberOrPaymentRef (PRIMARY AND ONLY APPROACH)
        String checkNumberOrPaymentRef = JsonPath.using(configWithoutException)
            .parse(document).read("$.CheckNumberOrPaymentRef", String.class);
        if (StringUtils.isNotBlank(checkNumberOrPaymentRef)) {
            log.info("AP extraction Phase 1 success: Found CheckNumberOrPaymentRef [{}] for transaction [{}]", 
                    checkNumberOrPaymentRef, transactionNumber);
            return checkNumberOrPaymentRef;
        }
        log.debug("AP extraction Phase 1: CheckNumberOrPaymentRef is empty for transaction [{}]", transactionNumber);
        
        // HIERARCHICAL FALLBACK LOGIC REMOVED - Version 2.0 Simplification
        // Previously attempted:
        // Phase 2: JobInvoiceNumber (stable business identifier)
        // Phase 3: Description (descriptive fallback)
        // Now returns null if Phase 1 fails
        
        log.warn("No AP SellReference found - all phases failed for AP transaction! TransactionInfo.Number = [{}]", transactionNumber);
        return null;
        
    } catch (Exception e) {
        log.warn("Error during AP SellReference extraction for transaction [{}]: {}", 
                transactionNumber, e.getMessage());
        return null;
    }
}
```

#### Key Changes from Original Implementation:
- **Removed**: Phase 2 fallback to `JobInvoiceNumber`
- **Removed**: Phase 3 fallback to `Description` 
- **Retained**: Phase 1 primary extraction from `CheckNumberOrPaymentRef`
- **Impact**: Significantly reduced success rate from original 98%+ expectation

### 3.3 Header Bean Population

**Location**: `TransactionMappingService.java:219-261`

```java
// Extract and set SellReference for AR transactions using existing method
if (StringUtils.equals("AR", ledger)) {
    try {
        String sellReference = extractSellReferenceForAR(document, transactionNo, "UNKNOWN");
        if (StringUtils.isNotBlank(sellReference)) {
            // Enforce 38-character limit for database column constraint
            if (sellReference.length() > 38) {
                log.warn("SellReference [{}] exceeds 38 characters, truncating to fit database constraint for transaction [{}]", 
                        sellReference, transactionNo);
                sellReference = sellReference.substring(0, 38);
            }
            headerBean.setChequeOrReference(sellReference);
            log.debug("Set chequeOrReference to SellReference [{}] for AR transaction [{}]", sellReference, transactionNo);
        } else {
            log.debug("No SellReference found for AR transaction [{}], chequeOrReference remains null", transactionNo);
        }
    } catch (Exception e) {
        log.warn("Error extracting SellReference for AR transaction [{}]: {}", transactionNo, e.getMessage());
        // Continue processing - chequeOrReference will remain null
    }
} else if (StringUtils.equals("AP", ledger)) {
    // Extract and set AP SellReference using new AP-specific method
    try {
        String sellReference = extractSellReferenceForAP(document, transactionNo, "UNKNOWN");
        if (StringUtils.isNotBlank(sellReference)) {
            // Enforce 38-character limit for database column constraint
            if (sellReference.length() > 38) {
                log.warn("AP SellReference [{}] exceeds 38 characters, truncating to fit database constraint for transaction [{}]", 
                        sellReference, transactionNo);
                sellReference = sellReference.substring(0, 38);
            }
            headerBean.setChequeOrReference(sellReference);
            log.debug("Set chequeOrReference to AP SellReference [{}] for AP transaction [{}]", sellReference, transactionNo);
        } else {
            log.debug("No AP SellReference found for AP transaction [{}], chequeOrReference remains null", transactionNo);
        }
    } catch (Exception e) {
        log.warn("Error extracting AP SellReference for AP transaction [{}]: {}", transactionNo, e.getMessage());
        // Continue processing - chequeOrReference will remain null
    }
}
```

---

## 4. Impact Analysis

### 4.1 Success Rate Changes

| Version | AR Success Rate | AP Success Rate | Overall Impact |
|---------|----------------|-----------------|----------------|
| **Original (v1.0)** | ~100% (with fallbacks) | ~98% (3-phase hierarchical) | High field population |
| **Current (v2.0)** | High (precision matching) | Variable (depends on CheckNumberOrPaymentRef) | Improved precision, potentially lower coverage |

### 4.2 Performance Improvements

#### Benefits of Simplified Approach:
- **Reduced Processing Time**: Elimination of fallback logic reduces execution overhead
- **Lower Memory Usage**: Fewer JsonPath operations and temporary object creation
- **Simplified Error Handling**: Cleaner code paths with fewer exception scenarios
- **Enhanced Logging Clarity**: More focused logging without fallback noise

#### Potential Drawbacks:
- **Reduced Data Coverage**: Lower success rate for edge cases where primary sources are empty
- **Less Resilient**: No fallback options for data quality issues
- **Higher Null Rate**: More transactions may have null chequeOrReference values

### 4.3 Database Impact

#### Expected Changes:
```sql
-- Anticipated increase in null values
SELECT 
    ledger,
    COUNT(*) as total_transactions,
    COUNT(chequeorreference) as populated_references,
    ROUND(COUNT(chequeorreference) * 100.0 / COUNT(*), 2) as population_percentage
FROM at_account_transaction_header 
WHERE create_time >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY ledger;
```

---

## 5. Migration and Compatibility

### 5.1 Backward Compatibility

#### Database Schema
- **Field Addition**: `chequeorreference` field added to existing table structure
- **Null Handling**: Existing records continue to function with null values
- **Constraint Enforcement**: 38-character limit enforced for new records only

#### API Compatibility  
- **Response Structure**: No changes to external API response format
- **Processing Logic**: Core transaction processing remains unchanged
- **Status Codes**: No impact on existing status code behavior

### 5.2 Configuration Requirements

No additional configuration required for basic functionality:

```yaml
# Standard transaction processing - no special configuration needed
transaction:
  # chequeOrReference extraction is enabled by default for AR and AP transactions
  # No configuration toggles available - always attempts extraction
```

---

## 6. Monitoring and Validation

### 6.1 Key Metrics

#### Field Population Monitoring
```sql
-- Monitor chequeOrReference field population rates
SELECT 
    DATE(create_time) as date,
    ledger,
    transaction_type,
    COUNT(*) as total,
    COUNT(chequeorreference) as populated,
    ROUND(COUNT(chequeorreference) * 100.0 / COUNT(*), 2) as rate
FROM at_account_transaction_header 
WHERE create_time >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE(create_time), ledger, transaction_type
ORDER BY date DESC, ledger, transaction_type;
```

#### Truncation Monitoring
```bash
# Monitor truncation warnings in application logs
grep "exceeds 38 characters, truncating" application.log | wc -l
```

### 6.2 Data Quality Validation

#### AR Transaction Validation
```sql
-- Validate AR chequeOrReference extraction quality
SELECT 
    transaction_no,
    chequeorreference,
    CASE 
        WHEN chequeorreference IS NULL THEN 'Missing'
        WHEN LENGTH(chequeorreference) = 38 THEN 'Potentially Truncated'
        ELSE 'Normal'
    END as data_quality
FROM at_account_transaction_header 
WHERE ledger = 'AR' 
  AND create_time >= CURRENT_DATE - INTERVAL '1 day'
ORDER BY create_time DESC;
```

#### AP Transaction Validation
```sql
-- Validate AP chequeOrReference extraction quality  
SELECT 
    transaction_no,
    chequeorreference,
    CASE 
        WHEN chequeorreference IS NULL THEN 'Missing CheckNumberOrPaymentRef'
        WHEN LENGTH(chequeorreference) = 38 THEN 'Potentially Truncated'
        ELSE 'Normal'
    END as data_quality
FROM at_account_transaction_header 
WHERE ledger = 'AP' 
  AND create_time >= CURRENT_DATE - INTERVAL '1 day'
ORDER BY create_time DESC;
```

---

## 7. Troubleshooting Guide

### 7.1 Common Issues

#### High Null Rate for AP Transactions
**Symptoms**: Many AP transactions have null chequeOrReference values
**Cause**: CheckNumberOrPaymentRef field not populated in source data
**Resolution**: 
- Verify source system configuration for payment reference fields
- Consider re-enabling fallback logic if business requirements demand higher coverage
- Review transaction source data quality

#### AR Transactions Missing References
**Symptoms**: AR transactions with null chequeOrReference despite having SellReference data
**Cause**: SellPostedTransactionNumber doesn't match transaction number
**Resolution**:
- Verify transaction number consistency between header and charge line data
- Check for data synchronization issues in source system
- Consider re-enabling fallback logic for broader matching

#### Frequent Truncation Warnings
**Symptoms**: High volume of truncation logs
**Cause**: Source payment references exceed 38-character database constraint
**Resolution**:
- Review source data patterns to understand reference length distribution
- Consider database schema adjustment if business justification exists
- Implement intelligent truncation strategy (e.g., preserve suffix)

### 7.2 Diagnostic Commands

```bash
# Check recent chequeOrReference extraction patterns
grep -E "(Set chequeOrReference|No.*SellReference found)" application.log | tail -20

# Monitor extraction success rates by transaction type
grep -E "Phase 1 success|No.*found.*transaction" application.log | \
  grep -o -E "(AR|AP)" | sort | uniq -c

# Identify truncation frequency
grep "exceeds 38 characters" application.log | \
  awk '{print $1" "$2}' | sort | uniq -c | tail -10
```

---

## 8. Future Considerations

### 8.1 Potential Enhancements

#### Configurable Fallback Strategy
```yaml
# Future configuration option
transaction:
  chequeOrReference:
    ar:
      enableFallback: true  # Allow $..SellReference fallback
    ap:
      enableMultiPhase: true  # Re-enable JobInvoiceNumber and Description fallbacks
```

#### Advanced Matching Logic
- Fuzzy matching for transaction number variations
- Pattern-based extraction for specific reference formats  
- Machine learning-based reference identification

### 8.2 Performance Optimization Opportunities

#### Caching Strategy
- Cache JsonPath compiled expressions for reuse
- Implement extraction result caching for identical payloads

#### Parallel Processing
- Asynchronous chequeOrReference extraction for large batches
- Separate extraction pipeline for post-processing

---

## 9. Validation Results

### 9.1 Implementation Status

| Component | Status | Validation Date | Notes |
|-----------|--------|-----------------|-------|
| AR Extraction Logic | ✅ Implemented | Sept 8, 2025 | Enhanced JsonPath filtering active |
| AP Extraction Logic | ✅ Implemented | Sept 8, 2025 | Single-phase extraction active |
| Database Integration | ✅ Implemented | Sept 8, 2025 | 38-character constraint enforced |
| Error Handling | ✅ Implemented | Sept 8, 2025 | Graceful degradation active |
| Logging Integration | ✅ Implemented | Sept 8, 2025 | Comprehensive extraction logging |

### 9.2 Test Coverage

According to commit documentation:
- **Total Integration Tests**: 35 tests (AR: 10, AP: 25)
- **Success Rate**: 100% (0 failures, 0 errors)
- **Performance**: <52 seconds total execution time

---

**Document Version**: 1.0  
**Last Updated**: September 9, 2025  
**Next Review**: October 9, 2025  
**Contact**: Development Team

---

*This document serves as the authoritative reference for chequeOrReference field implementation. For questions or updates regarding the simplified extraction strategies, please consult the development team or update this documentation accordingly.*