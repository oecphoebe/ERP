# ARTransaction Endpoint Attribute Mapping Document

**Date**: August 16, 2025  
**Endpoint**: `POST /external/v1/ARTransaction`  
**Purpose**: Maps UniversalTransaction data to database and external compliance system

---

## 1. Executive Summary

The ARTransaction endpoint processes Cargowise Universal Transaction data and:
1. Saves data to PostgreSQL database tables
2. Routes AR transactions to China Compliance System via Kafka retry mechanism
3. Supports three refNoType categories: SHIPMENT, CONSOL, and NONJOB (enhanced)

## 2. Data Flow Architecture

```mermaid
graph TD
    A[UniversalTransaction JSON] --> B[UniversalController.receivePayload]
    B --> C[TransactionMappingService.analyzePayloadRaw]
    C --> D[TransactionQueryService.getRefNo]
    D --> E{RefNo Type?}
    E -->|SHIPMENT| F[Standard Shipment Processing]
    E -->|CONSOL| G[Consolidated Shipment Processing]  
    E -->|NONJOB| H[Enhanced Non-Job Processing]
    F --> I[Save to Database - ALWAYS]
    G --> I
    H --> I
    I --> J[TransactionRoutingService]
    J --> K{Ledger + TransactionType?}
    K -->|AR + Policy Match| L[Send to External System]
    K -->|AP or No Match| M[DB Only - No External]
    I --> N[at_account_transaction_header]
    I --> O[at_account_transaction_lines] 
    I --> P[at_shipment_info]
    L --> Q[China Compliance System via Kafka]
```

### Key Routing Logic:

1. **RefNoType (SHIPMENT/CONSOL/NONJOB)**: Determines processing logic only
   - Affects how data is extracted from JSON and CW database
   - All types save to database tables

2. **Ledger + TransactionType**: Determines external system routing
   - **Legacy Mode**: AR → External System, AP → DB Only
   - **Config Mode**: Based on routing rules configuration
   - **All transactions** always save to database regardless of routing

## 3. RefNoType Determination Logic

### 3.1 SQL Query for RefNo Determination

**Query**: `TransactionQueryService.getRefNo()`
```sql
SELECT DISTINCT 
 jc2.jr_e6 as JOB_HEADER,
 CASE 
  WHEN jc2.jr_e6 IS NULL THEN js.JS_UniqueConsignRef 
  ELSE jc.JK_UniqueConsignRef 
 END AS REF_NO 
 FROM AccTransactionHeader ath 
 LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK 
 LEFT JOIN JobHeader jh ON jh.JH_PK = atl.AL_JH 
 LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID 
 LEFT JOIN JobConShipLink jsl ON jsl.JN_JS = js.JS_PK 
 LEFT JOIN JobConsol jc ON jsl.JN_JK = jc.JK_PK 
 INNER JOIN AccChargeCode c ON c.ac_pk = atl.al_ac 
 LEFT JOIN JobCharge jc2 ON jc2.JR_JH = jh.jh_pk AND jc2.jr_ac = c.ac_pk AND jc2.JR_APInvoiceNum = ath.AH_TransactionNum 
WHERE ath.AH_Ledger = :ledger 
 AND ath.AH_TransactionType = :transactionType 
 AND ath.AH_TransactionNum = :transactionNo
```

### 3.2 RefNoType Logic (Including Enhanced NONJOB)

**Source**: `TransactionQueryService.getRefNo():198-235`

| Condition | RefNoType | Processing |
|-----------|-----------|------------|
| Empty result set | `NONJOB` | No shipment/consol references found |
| refNo = NULL, refNoType = NULL | `NONJOB` | Record exists but both fields null |
| refNo = NULL, refNoType exists | `SHIPMENT` | Standard shipment processing |
| refNo exists, refNoType exists | `CONSOL` | Consolidated shipment processing |

**JsonPath**: N/A (determined from database query, not JSON)

## 4. Database Table Mappings

### 4.1 at_account_transaction_header

| DB Column | Source JsonPath | Bean Field | Notes |
|-----------|----------------|------------|-------|
| `acct_trans_header_id` | Generated UUID | `acctTransHeaderId` | Primary key |
| `ref_no` | DB Query Result | N/A | From refNo determination logic |
| `cw_acc_trans_header_pk` | DB Query: `AccTransactionHeader.AH_PK` | `cwAccTransHeaderPk` | Cargowise transaction PK (requires UNIQUE constraint) |
| `ledger` | `$.Body.UniversalTransaction.TransactionInfo.Ledger` | `ledger` | AR/AP |
| `trans_type` | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | `transactionType` | INV/CRD |
| `inv_no` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `invoiceNo` | Transaction number |
| `inv_date` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `invoiceDate` | Transaction date |
| `due_date` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `dueDate` | Same as invoice date |
| `crncy_code` | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | `currencyCode` | Original currency |
| `inv_amt` | `$.Body.UniversalTransaction.TransactionInfo.Ostotal` | `invoiceAmount` | Total amount |
| `outstanding_amt` | `$.Body.UniversalTransaction.TransactionInfo.OutstandingAmount` | `outstandingAmount` | Outstanding amount |
| `cmpny_code` | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | `companyCode` | Company code |
| `cmpny_branch` | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | `companyBranch` | Branch code |
| `cmpny_dept` | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | `companyDepartment` | Department code |
| `exchg_rate` | `$.Body.UniversalTransaction.TransactionInfo.ExchangeRate` | `exchangeRate` | Exchange rate |
| `inv_org_code` | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | `invoiceOrgCode` | Organization code |
| `local_crncy_code` | `$.Body.UniversalTransaction.TransactionInfo.LocalCurrency.Code` | `localCurrencyCode` | Local currency |
| `trans_desc` | `$.Body.UniversalTransaction.TransactionInfo.Description` | `transactionDescription` | Description |
| `total_vat_amt` | `$.Body.UniversalTransaction.TransactionInfo.Osgstvatamount` | `totalVatAmount` | Total VAT amount |
| `local_total_vat_amt` | `$.Body.UniversalTransaction.TransactionInfo.LocalVATAmount` | `localTotalVatAmount` | Local VAT amount |
| `trans_no` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `transactionNo` | Same as inv_no |
| `is_cancel` | `$.Body.UniversalTransaction.TransactionInfo.IsCancelled` | `cancelled` | Cancellation flag |
| `update_time` | `$.Body.UniversalTransaction.DataContext.TriggerDate` | `updateTime` | Trigger timestamp |

### 4.2 at_account_transaction_lines (Enhanced for NONJOB)

| DB Column | Source JsonPath (Varies by Ledger) | Bean Field | Notes |
|-----------|-----------------------------------|------------|-------|
| `acc_trans_lines_id` | Generated UUID | `accountTransactionLinesId` | Primary key |
| `acct_trans_header_id` | From header bean | `accountTransactionHeaderId` | Foreign key |
| `cw_acct_trans_lines_pk` | DB Query Result or CW AccTransactionLines | `cwAccountTransactionLinesPk` | **Enhanced**: From CW query for NONJOB |
| `chrg_code_id` | DB Query Result or CW AccChargeCode | `chargeCodeId` | **Enhanced**: From CW query for NONJOB |
| `crncy_code` | AR: `$.SellOSCurrency.Code`<br/>AP: `$.CostOSCurrency.Code`<br/>**NONJOB**: `$.Oscurrency.Code` | `currencyCode` | **Enhanced**: Direct from PostingJournal |
| `chrg_amt` | AR: `$.SellOSAmount`<br/>AP: `$.CostOSAmount` (×-1)<br/>**NONJOB**: `$.Osamount` + `$.Osgstvatamount` | `chargeAmount` | **Enhanced**: CW data overrides JSON if available |
| `vat_amt` | AR: `$.SellOSGSTVATAmount`<br/>AP: `$.CostOSGSTVATAmount` (×-1)<br/>**NONJOB**: `$.Osgstvatamount` | `vatAmount` | **Enhanced**: CW data overrides JSON if available |
| `total_amt` | AR: `$.SellLocalAmount`<br/>AP: `$.CostLocalAmount` (×-1)<br/>**NONJOB**: `$.LocalAmount` | `totalAmount` | **Enhanced**: CW data overrides JSON if available |
| `exchg_rate` | AR: `$.SellExchangeRate`<br/>AP: `$.CostExchangeRate`<br/>**NONJOB**: `$.ChargeExchangeRate` | `exchangeRate` | **Enhanced**: CW data overrides JSON if available |
| `local_crncy_code` | `$.CostOSCurrency.Code` **NONJOB**: `$.LocalCurrency.Code` | `localCurrencyCode` | **Enhanced**: Different path for NONJOB |
| `local_vat_amt` | Calculated: vatAmount × exchangeRate | `localVatAmount` | Enhanced calculation |
| `cmpny_code` | From header | `companyCode` | Company code |
| `cmpny_branch` | From header | `companyBranch` | Branch code |
| `cmpny_dept` | From header | `companyDept` | Department code |
| `display_sequence` | From CW AccTransactionLines.AL_Sequence | `displaySequence` | **Enhanced**: Populated from CW for NONJOB |
| `trans_line_desc` | `$.ChargeCode.Description` | `transactionLineDescription` | Charge description |

### 4.3 at_shipment_info (Not populated for NONJOB)

| DB Column | Source | Notes |
|-----------|--------|-------|
| `ref_no` | DB Query from CW | Reference number |
| `shipment_no` | DB Query from CW | Shipment number |
| `cnsl_no` | DB Query from CW | Consol number |
| All other fields | DB Query from CW | Retrieved from Cargowise tables |

## 5. External System Mapping (China Compliance System)

### 5.1 TransactionChargeLineRequestBean Structure (Enhanced for NONJOB)

**Target System**: China Compliance System via Kafka  
**Processing**: Only AR transactions sent to external system

| External Field | Source JsonPath | Bean Field | Notes |
|----------------|----------------|------------|-------|
| `billNo` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `billNo` | Transaction number |
| `transactionType` | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | `transactionType` | **Enhanced**: Populated for NONJOB |
| `billDate` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `billDate` | **Enhanced**: Populated for NONJOB |
| `companyCode` | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | `companyCode` | **Enhanced**: From header bean for NONJOB |
| `branchCode` | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | `branchCode` | **Enhanced**: From header bean for NONJOB |
| `departmentCode` | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | `departmentCode` | **Enhanced**: From header bean for NONJOB |
| `currency` | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | `currency` | **Enhanced**: From document for NONJOB |
| `shipmentId` | From refNo determination or null for NONJOB | `shipmentId` | Null for NONJOB |
| `consolNo` | From refNo determination or null for NONJOB | `consolNo` | Null for NONJOB |
| `debiterCode` | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | `debiterCode` | **Enhanced**: Same as buyer for NONJOB |
| `debiterName` | DB Query: `cw_org_header.full_name` | `debiterName` | **Enhanced**: Same as buyer for NONJOB |
| `buyerCode` | AR: `$..SellReference[0]`<br/>AP: `$..SupplierReference[0]` | `buyerCode` | Buyer reference |
| `buyerName` | DB Query by buyerCode | `buyerName` | Buyer name |
| `buyerTaxNo` | DB Query: `cw_org_cus_code` where type='VAT' | `buyerTaxNo` | VAT tax ID |
| `buyerAddr` | DB Query: `cw_org_address.addr1` | `buyerAddr` | Buyer address |
| `buyerBankName` | DB Query: `AccAPAccountDetails.A1_AccountName` | `buyerBankName` | Bank name |
| `buyerBankAccount` | DB Query: `AccAPAccountDetails.A1_BankAccount` | `buyerBankAccount` | Bank account |
| `taxRate` | From PostingJournal matching by ChargeCode and Sequence | `taxRate` | Tax rate |
| `itemCode` | `$.ChargeCode.Code` | `itemCode` | Charge code |
| `itemName` | `$.ChargeCode.Description` | `itemName` | Charge description |
| `itemUnit` | Empty string | `itemUnit` | Fixed empty |
| `qty` | 1 | `qty` | Fixed to 1 |
| `taxCode` | AR: `$.SellGSTVATID.TaxCode`<br/>AP: `$.CostGSTVATID.TaxCode` | `taxCode` | VAT tax code |
| `price` | AR: `$.OutstandingAmount`<br/>AP: `$.OutstandingAmount` (×-1) | `price` | Price amount |
| `taxIncludedAmount` | Same as price | `taxIncludedAmount` | Tax inclusive amount |
| `amount` | price - VAT amount | `amount` | Net amount |
| `discountAmt` | BigDecimal.ZERO | `discountAmt` | Fixed to 0 |
| `discountTaxAmt` | BigDecimal.ZERO | `discountTaxAmt` | Fixed to 0 |
| `discountAmtIncludeTax` | BigDecimal.ZERO | `discountAmtIncludeTax` | Fixed to 0 |

## 6. SQL Queries Reference

### 6.1 Cargowise Account Transaction Header PK Query

**Purpose**: Retrieve `cw_acc_trans_header_pk` from Cargowise database  
**Source Table**: `AccTransactionHeader.AH_PK`  
**Implementation**: `TransactionQueryService.getCWAccountTransactionInfo()`

**SHIPMENT Query**: `QUERY_CW_ACCOUNT_TRANSACTION_INFO_SHIPMENT`
```sql
SELECT DISTINCT 
ath.AH_PK as account_Transaction_Header_Pk 
, ath.AH_TransactionNum as invoice_no 
, oh.OH_Code as creditor 
, atl.AL_Sequence as display_Sequence 
, jh.JH_JobNum as job_Number 
, atl.AL_PK as account_Transaction_Lines_Pk 
, acc.AC_PK as account_Charge_Code_Pk 
, acc.AC_Code as charge_Code 
FROM AccTransactionHeader ath 
INNER JOIN AccTransactionLines atl on atl.AL_AH = ath.AH_PK 
INNER JOIN AccChargeCode acc on acc.AC_PK = atl.AL_AC 
INNER JOIN JobHeader jh on jh.JH_PK = atl.AL_JH 
INNER JOIN OrgHeader oh on atl.AL_OH = oh.OH_PK 
WHERE ath.AH_Ledger = :ledger 
 AND ath.AH_TransactionType = :transactionType 
 AND ath.AH_TransactionNum = :transactionNo 
 AND oh.OH_Code = :organizationCode
```

**CONSOL Query**: `QUERY_CW_ACCOUNT_TRANSACTION_INFO_CONSOL`
```sql
SELECT DISTINCT 
ath.AH_PK as account_Transaction_Header_Pk 
, ath.AH_TransactionNum as invoice_no 
, jcl.e6_pk as account_Transaction_Lines_Pk 
, acc.AC_PK as account_Charge_Code_Pk 
, acc.AC_Code as charge_Code 
FROM AccTransactionHeader ath 
INNER JOIN JobConsolCost jcl ON jcl.e6_ah_apinvoice = ath.ah_pk 
INNER JOIN AccChargeCode acc on acc.AC_PK = jcl.E6_AC_ChargeCode 
WHERE ath.AH_Ledger = :ledger 
 AND ath.AH_TransactionType = :transactionType 
 AND ath.AH_TransactionNum = :transactionNo
```

**NONJOB Query (New)**: `QUERY_CW_ACCOUNT_TRANSACTION_INFO_NONJOB`
```sql
SELECT DISTINCT 
ath.AH_PK as account_Transaction_Header_Pk 
, ath.AH_TransactionNum as invoice_no 
, atl.AL_PK as account_Transaction_Lines_Pk 
, atl.AL_Sequence as display_Sequence 
, acc.AC_PK as account_Charge_Code_Pk 
, acc.AC_Code as charge_Code 
, oh.OH_Code as creditor 
, atl.AL_OSAmount as os_amount 
, atl.AL_GSTVAT as gst_vat_amount 
, atl.AL_LineAmount as line_amount 
, atl.AL_ExchangeRate as exchange_rate 
, atl.AL_RX_NKTransactionCurrency as currency_code 
FROM AccTransactionHeader ath 
INNER JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK 
INNER JOIN AccChargeCode acc ON acc.AC_PK = atl.AL_AC 
INNER JOIN OrgHeader oh ON atl.AL_OH = oh.OH_PK 
WHERE ath.AH_Ledger = :ledger 
 AND ath.AH_TransactionType = :transactionType 
 AND ath.AH_TransactionNum = :transactionNo 
 AND oh.OH_Code = :organizationCode
```

**Database Constraint Requirement**:
```sql
-- Required for ON CONFLICT upsert operations
ALTER TABLE at_account_transaction_header 
ADD CONSTRAINT uk_cw_acc_trans_header_pk 
UNIQUE (cw_acc_trans_header_pk);
```

### 6.2 RefNo Determination Query

**Usage**: Determine SHIPMENT/CONSOL/NONJOB type
```sql
SELECT DISTINCT 
 jc2.jr_e6 as JOB_HEADER,
 CASE 
  WHEN jc2.jr_e6 IS NULL THEN js.JS_UniqueConsignRef 
  ELSE jc.JK_UniqueConsignRef 
 END AS REF_NO 
 FROM AccTransactionHeader ath 
 LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK 
 LEFT JOIN JobHeader jh ON jh.JH_PK = atl.AL_JH 
 LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID 
 LEFT JOIN JobConShipLink jsl ON jsl.JN_JS = js.JS_PK 
 LEFT JOIN JobConsol jc ON jsl.JN_JK = jc.JK_PK 
 INNER JOIN AccChargeCode c ON c.ac_pk = atl.al_ac 
 LEFT JOIN JobCharge jc2 ON jc2.JR_JH = jh.jh_pk AND jc2.jr_ac = c.ac_pk AND jc2.JR_APInvoiceNum = ath.AH_TransactionNum 
WHERE ath.AH_Ledger = :ledger 
 AND ath.AH_TransactionType = :transactionType 
 AND ath.AH_TransactionNum = :transactionNo
```

### 6.3 Debiter Name Query

**Usage**: Get organization full name for debiter/creditor
```sql
select oh.full_name from cw_org_header oh where oh.org_code = :organizationCode
```

### 6.4 Buyer Tax Number Query (Updated)

**Usage**: Get VAT tax ID for buyer
```sql
select a.cus_code_value from cw_org_cus_code a 
inner join cw_org_header b on a.org_header_id = b.org_header_id 
where a.cus_code_type = 'VAT' 
and b.org_code = :organizationCode
```

### 6.5 Buyer Bank Info Query (Updated)

**Usage**: Get buyer bank account information from Cargowise
```sql
select a.A1_AccountName as BANK_NAME, a.A1_BankAccount as BANK_ACCOUNT from AccAPAccountDetails a 
inner join OrgCompanyData b on a.A1_OB = b.OB_PK 
inner join OrgHeader c on c.OH_PK = b.OB_OH 
where c.OH_Code = :organizationCode
 and a.A1_RX_NKAccountCurrency = :currencyCode
```

### 6.6 Local Currency Code Query (Updated)

**Usage**: Get local currency code by branch
```sql
select cgc.crncy_code from cw_global_branch cgb 
inner join cw_global_company cgc on cgc.global_cmpny_id = cgb.global_cmpny_id 
where branch_code = :branchCode
```

### 6.7 Old Bill Type Query (Updated)

**Usage**: Get existing transaction type from SOPL database
```sql
select aath.trans_type from at_account_transaction_header aath 
WHERE aath.ledger = :ledger 
 AND aath.trans_no = :transactionNo
```

## 7. Processing Flow by RefNoType

**Note**: All processing flows save to database. External system routing is determined separately by ledger + transaction type.

### 7.1 SHIPMENT Processing

**Source**: `TransactionMappingService.processStandardTransaction()`
1. Create TransactionInfoRequestBean with shipment reference
2. Query CW using SHIPMENT SQL (requires shipment/job context)
3. Process shipment collection from JSON
4. Extract charge lines from shipment charge collections
5. Validate VAT tax codes
6. Save to database (always)
7. If routing decision = external, send to China Compliance System

### 7.2 CONSOL Processing

**Source**: `ChargeLineProcessor.handleConsolChargeLines()`
1. Create TransactionInfoRequestBean with consol reference
2. Query CW using CONSOL SQL (JobConsolCost table)
3. Process single consol cost record
4. Extract charge information from JobConsolCost
5. Validate VAT tax codes
6. Save to database (always)
7. If routing decision = external, send to China Compliance System

### 7.3 NONJOB Processing (Enhanced)

**Source**: `TransactionMappingService.processNonJobTransaction()` and `ChargeLineProcessor.handleNonJobChargeLines()`
1. Create TransactionInfoRequestBean **without** shipment/consol reference
2. **Enhanced**: Populate additional fields from transaction document and header bean
3. Query CW using **dedicated NONJOB query** to fetch AccTransactionLines data directly
4. Process charge lines directly from **original PostingJournal JSON structure**
5. **Enhanced**: Populate missing fields from CW data (cwAccountTransactionLinesPk, chargeCodeId, displaySequence)
6. **Enhanced**: Use authoritative CW amounts when available (osAmount, gstVatAmount, lineAmount, exchangeRate)
7. Validate VAT tax codes (same rules apply)
8. Save to database (always) with complete line information
9. If routing decision = external, send to China Compliance System with populated request

### 7.4 Key Differences - NONJOB vs SHIPMENT/CONSOL (Updated)

| Aspect | SHIPMENT/CONSOL | NONJOB (Enhanced) |
|--------|-----------------|-------------------|
| RefNo Source | Database query result | N/A (null) |
| Shipment Processing | From JSON ShipmentCollection | Skip - no shipments |
| Charge Line Source | Shipment charge lines | **Enhanced**: Original PostingJournal JSON |
| CW Data Query | Required | **Enhanced**: Dedicated NONJOB query for line data |
| Data Population | Standard JSON mapping | **Enhanced**: CW data overrides JSON amounts |
| Foreign Keys | From shipment context | **Enhanced**: Direct from AccTransactionLines |
| Request Bean Population | Standard fields | **Enhanced**: Complete field population |
| Database Save | Always | Always (with enhanced data) |
| External System Routing | Based on ledger+type | Based on ledger+type (same logic) |
| External System Context | Full shipment context | **Enhanced**: Complete transaction context |

## 8. Validation Rules

### 8.1 Policy Compliance Validation

**Source**: `TransactionValidationService.validatePolicyCompliance()`
- Validates VAT tax codes for AR transactions
- Ensures required fields are present
- Checks amount consistency
- NONJOB transactions follow same validation rules

### 8.2 Buyer Reference Validation

**Source**: `TransactionMappingService.extractBuyerCode()`
- AR: Requires SellReference in JSON
- AP: Requires SupplierReference in JSON
- NONJOB: Same validation rules apply

## 9. Special Processing Notes

### 9.1 Amount Sign Conversion

- **AR transactions**: Amounts preserved as positive
- **AP transactions**: Amounts multiplied by -1 for correct accounting

### 9.2 Reversed Transactions

- Detected when `IsCancelled = true`
- Sets cancellation flag instead of creating new records
- Outstanding amounts cleared automatically

### 9.3 External System Routing Decision

**Source**: `TransactionRoutingService.shouldSendToExternalSystem()`
- **Legacy Mode (default)**: Only AR ledger → External System, AP ledger → DB Only
- **Config Mode**: Configurable rules by ledger + transaction type combination
- Decision made after database save, independent of refNoType
- Audit logging for all routing decisions

### 9.4 Kafka Retry Mechanism

- External system messages sent via retry mechanism
- Exponential backoff: 2^attempt seconds
- Dead letter queue for failed messages
- Topic naming: `{profile}-invoice-retry`

### 9.5 NONJOB JSON Structure Handling (New)

**PostingJournal Structure for NONJOB**:
```json
{
  "ChargeCode": {"Code": "AMS", "Description": "AMS Security Surcharge"},
  "Sequence": 3,
  "Osamount": "10.0",
  "Osgstvatamount": "0.0",
  "LocalAmount": "73.5",
  "Oscurrency": {"Code": "USD"},
  "LocalCurrency": {"Code": "CNY"},
  "ChargeExchangeRate": "7.35"
}
```

**Key Differences from SHIPMENT/CONSOL**:
- Uses `Oscurrency.Code` instead of `CostOSCurrency.Code`
- Uses `LocalCurrency.Code` for local currency reference
- Direct access to charge amounts without shipment context

## 10. Enhanced Error Handling and Lookup Failures (New)

### 10.1 Lookup Error Categories

**Source**: `UniversalController.extractLookupErrorDetails()`

| Error Type | Description | Common Causes | Resolution |
|------------|-------------|---------------|------------|
| Debiter/Organization Name Lookup | `getDebiterName()` fails | Organization not in cw_org_header | Configure organization in Cargowise |
| Buyer Organization Info Lookup | `getBuyerOrgInfo()` fails | Missing buyer organization data | Add organization to master data |
| Buyer Tax Number Lookup | `getBuyerTaxNo()` fails | No VAT registration configured | Configure tax number for organization |
| Buyer Bank Info Lookup | `getBuyerBankInfo()` fails | Missing bank account details | Add bank account for organization/currency |
| Company Configuration | Company UUID not found | Company not configured | Add company to system configuration |

### 10.2 Enhanced API Error Response Structure

**Instead of generic**: `"lookupErrors": "Some organization lookups failed - see debug messages"`

**Now provides detailed**:
```json
{
  "lookupErrors": {
    "summary": "Transaction saved to database but cannot be sent to external compliance system due to missing configuration data",
    "failedLookups": [
      {
        "type": "Debiter/Organization Name Lookup",
        "field": "Organization Code",
        "value": "ASHLEY",
        "issue": "Organization not found in cw_org_header table",
        "suggestion": "Verify organization code 'ASHLEY' exists in Cargowise system or update transaction with correct organization code"
      }
    ],
    "totalErrors": 1,
    "actionRequired": "Fix the configuration issues below and reprocess the transaction",
    "suggestions": [
      "Check if organization 'ASHLEY' is properly configured in Cargowise"
    ],
    "resolutionSteps": [
      "1. Review the failed lookups listed above",
      "2. Configure missing organization/company/bank data in the respective master data tables",
      "3. Verify data consistency between Cargowise and local system",
      "4. Resubmit the transaction or use the retry mechanism"
    ]
  }
}
```

### 10.3 Error Message Parsing Patterns

**Debug Message Patterns**:
- Organization Code: `getDebiterName() not found for organization code: [ASHLEY]`
- Buyer Info: `getBuyerOrgInfo [ASHLEY] Incorrect result size: expected 1, actual 0`
- Tax Number: `getBuyerTaxNo [ASHLEY] Incorrect result size: expected 1, actual 0`
- Bank Info: `getBuyerBankInfo [ASHLEY] [USD] Incorrect result size: expected 1, actual 0`
- Company: `Company UUID not found for AR transaction: SH1`

## 11. Implementation Changes Summary (August 16, 2025)

### 11.1 New Components Added

**Files Modified**:
- `TransactionQueryService.java`: Added NONJOB query constant
- `CwAccountTransactionInfo.java`: Enhanced with line-level fields
- `TransactionMappingService.java`: Enhanced NONJOB processing and transaction info population
- `ChargeLineProcessor.java`: Custom NONJOB bean creation and original JSON processing
- `UniversalController.java`: Enhanced error messaging with detailed lookup failures

### 11.2 New Database Query

**QUERY_CW_ACCOUNT_TRANSACTION_INFO_NONJOB**: Fetches complete AccTransactionLines data for NONJOB transactions

### 11.3 Enhanced Data Model

**CwAccountTransactionInfo**: Added fields for line-level amounts, exchange rates, and currency codes from AccTransactionLines

### 11.4 Improved User Experience

**Error Messaging**: Transformed generic error messages into specific, actionable information with resolution steps

---

**Document Version**: 3.0  
**Last Updated**: August 16, 2025  
**Author**: Claude Code Assistant  
**Review Status**: Updated with NONJOB enhancements and error handling improvements  
**Major Changes**: Enhanced NONJOB processing, dedicated CW queries, improved error messaging