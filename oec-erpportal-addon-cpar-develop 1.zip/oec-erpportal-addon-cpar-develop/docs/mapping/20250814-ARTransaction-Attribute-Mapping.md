# ARTransaction Endpoint Attribute Mapping Document

**Date**: August 14, 2025  
**Endpoint**: `POST /external/v1/ARTransaction`  
**Purpose**: Maps UniversalTransaction data to database and external compliance system

---

## 1. Executive Summary

The ARTransaction endpoint processes Cargowise Universal Transaction data and:
1. Saves data to PostgreSQL database tables
2. Routes AR transactions to China Compliance System via Kafka retry mechanism
3. Supports three refNoType categories: SHIPMENT, CONSOL, and NONJOB (new)

## 2. Data Flow Architecture

```mermaid
graph TD
    A[UniversalTransaction JSON] --> B[UniversalController.receivePayload]
    B --> C[TransactionMappingService.analyzePayloadRaw]
    C --> D[TransactionQueryService.getRefNo]
    D --> E{RefNo Type?}
    E -->|SHIPMENT| F[Standard Shipment Processing]
    E -->|CONSOL| G[Consolidated Shipment Processing]  
    E -->|NONJOB| H[Non-Job Processing]
    F --> I[Save to Database - ALWAYS]
    G --> I
    H --> I
    I --> J[TransactionRoutingService]
    J --> K{Ledger + TransactionType?}
    K -->|AR + Policy Match| L[Send to External System]
    K -->|AP or No Match| M[DB Only - No External]
    I --> N[at_account_transaction_header]
    I --> O[at_account_transaction_lines] 
    I --> P[at_shipment_info]
    L --> Q[China Compliance System via Kafka]
```

### Key Routing Logic:

1. **RefNoType (SHIPMENT/CONSOL/NONJOB)**: Determines processing logic only
   - Affects how data is extracted from JSON and CW database
   - All types save to database tables

2. **Ledger + TransactionType**: Determines external system routing
   - **Legacy Mode**: AR → External System, AP → DB Only
   - **Config Mode**: Based on routing rules configuration
   - **All transactions** always save to database regardless of routing

## 3. RefNoType Determination Logic

### 3.1 SQL Query for RefNo Determination

**Query**: `TransactionQueryService.getRefNo()`
```sql
SELECT rn.ref_no, rn.ref_no_type 
FROM cw_account_transaction_ref_no rn
INNER JOIN cw_account_transaction_header ath ON ath.acct_trans_header_id = rn.acct_trans_header_id
WHERE ath.ledger = :ledger
  AND ath.transaction_type = :transactionType  
  AND ath.transaction_no = :transactionNo
```

### 3.2 RefNoType Logic (Including NONJOB)

**Source**: `TransactionQueryService.getRefNo():198-235`

| Condition | RefNoType | Processing |
|-----------|-----------|------------|
| Empty result set | `NONJOB` | No shipment/consol references found |
| refNo = NULL, refNoType = NULL | `NONJOB` | Record exists but both fields null |
| refNo = NULL, refNoType exists | `SHIPMENT` | Standard shipment processing |
| refNo exists, refNoType exists | `CONSOL` | Consolidated shipment processing |

**JsonPath**: N/A (determined from database query, not JSON)

## 4. Database Table Mappings

### 4.1 at_account_transaction_header

| DB Column | Source JsonPath | Bean Field | Notes |
|-----------|----------------|------------|-------|
| `acct_trans_header_id` | Generated UUID | `acctTransHeaderId` | Primary key |
| `ref_no` | DB Query Result | N/A | From refNo determination logic |
| `cw_acc_trans_header_pk` | DB Query Result | `cwAccTransHeaderPk` | From CW query |
| `ledger` | `$.Body.UniversalTransaction.TransactionInfo.Ledger` | `ledger` | AR/AP |
| `trans_type` | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | `transactionType` | INV/CRD |
| `inv_no` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `invoiceNo` | Transaction number |
| `inv_date` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `invoiceDate` | Transaction date |
| `due_date` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `dueDate` | Same as invoice date |
| `crncy_code` | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | `currencyCode` | Original currency |
| `inv_amt` | `$.Body.UniversalTransaction.TransactionInfo.Ostotal` | `invoiceAmount` | Total amount |
| `outstanding_amt` | `$.Body.UniversalTransaction.TransactionInfo.OutstandingAmount` | `outstandingAmount` | Outstanding amount |
| `cmpny_code` | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | `companyCode` | Company code |
| `cmpny_branch` | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | `companyBranch` | Branch code |
| `cmpny_dept` | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | `companyDepartment` | Department code |
| `exchg_rate` | `$.Body.UniversalTransaction.TransactionInfo.ExchangeRate` | `exchangeRate` | Exchange rate |
| `inv_org_code` | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | `invoiceOrgCode` | Organization code |
| `local_crncy_code` | `$.Body.UniversalTransaction.TransactionInfo.LocalCurrency.Code` | `localCurrencyCode` | Local currency |
| `trans_desc` | `$.Body.UniversalTransaction.TransactionInfo.Description` | `transactionDescription` | Description |
| `total_vat_amt` | `$.Body.UniversalTransaction.TransactionInfo.Osgstvatamount` | `totalVatAmount` | Total VAT amount |
| `local_total_vat_amt` | `$.Body.UniversalTransaction.TransactionInfo.LocalVATAmount` | `localTotalVatAmount` | Local VAT amount |
| `trans_no` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `transactionNo` | Same as inv_no |
| `is_cancel` | `$.Body.UniversalTransaction.TransactionInfo.IsCancelled` | `cancelled` | Cancellation flag |
| `update_time` | `$.Body.UniversalTransaction.DataContext.TriggerDate` | `updateTime` | Trigger timestamp |

### 4.2 at_account_transaction_lines

| DB Column | Source JsonPath (Varies by Ledger) | Bean Field | Notes |
|-----------|-----------------------------------|------------|-------|
| `acc_trans_lines_id` | Generated UUID | `accountTransactionLinesId` | Primary key |
| `acct_trans_header_id` | From header bean | `accountTransactionHeaderId` | Foreign key |
| `cw_acct_trans_lines_pk` | DB Query Result | `cwAccountTransactionLinesPk` | From CW query |
| `chrg_code_id` | DB Query Result | `chargeCodeId` | Charge code PK |
| `crncy_code` | AR: `$.SellOSCurrency.Code`<br/>AP: `$.CostOSCurrency.Code` | `currencyCode` | Line currency |
| `chrg_amt` | AR: `$.SellOSAmount`<br/>AP: `$.CostOSAmount` (×-1) | `chargeAmount` | Original currency amount |
| `vat_amt` | AR: `$.SellOSGSTVATAmount`<br/>AP: `$.CostOSGSTVATAmount` (×-1) | `vatAmount` | VAT amount |
| `total_amt` | AR: `$.SellLocalAmount`<br/>AP: `$.CostLocalAmount` (×-1) | `totalAmount` | Local currency amount |
| `exchg_rate` | AR: `$.SellExchangeRate`<br/>AP: `$.CostExchangeRate` | `exchangeRate` | Line exchange rate |
| `local_crncy_code` | `$.CostOSCurrency.Code` | `localCurrencyCode` | Local currency code |
| `local_vat_amt` | Calculated: vatAmount × exchangeRate | `localVatAmount` | Local VAT amount |
| `cmpny_code` | From header | `companyCode` | Company code |
| `cmpny_branch` | From header | `companyBranch` | Branch code |
| `cmpny_dept` | From header | `companyDept` | Department code |
| `trans_line_desc` | `$.ChargeCode.Description` | `transactionLineDescription` | Charge description |

### 4.3 at_shipment_info (Not populated for NONJOB)

| DB Column | Source | Notes |
|-----------|--------|-------|
| `ref_no` | DB Query from CW | Reference number |
| `shipment_no` | DB Query from CW | Shipment number |
| `cnsl_no` | DB Query from CW | Consol number |
| All other fields | DB Query from CW | Retrieved from Cargowise tables |

## 5. External System Mapping (China Compliance System)

### 5.1 TransactionChargeLineRequestBean Structure

**Target System**: China Compliance System via Kafka  
**Processing**: Only AR transactions sent to external system

| External Field | Source JsonPath | Bean Field | Notes |
|----------------|----------------|------------|-------|
| `billNo` | `$.Body.UniversalTransaction.TransactionInfo.Number` | `billNo` | Transaction number |
| `transactionType` | `$.Body.UniversalTransaction.TransactionInfo.TransactionType` | `transactionType` | INV/CRD |
| `billDate` | `$.Body.UniversalTransaction.TransactionInfo.TransactionDate` | `billDate` | Transaction date |
| `companyCode` | `$.Body.UniversalTransaction.TransactionInfo.DataContext.Company.Code` | `companyCode` | Company code |
| `branchCode` | `$.Body.UniversalTransaction.TransactionInfo.Branch.Code` | `branchCode` | Branch code |
| `departmentCode` | `$.Body.UniversalTransaction.TransactionInfo.Department.Code` | `departmentCode` | Department code |
| `currency` | `$.Body.UniversalTransaction.TransactionInfo.Oscurrency.Code` | `currency` | Currency code |
| `shipmentId` | From refNo determination or null for NONJOB | `shipmentId` | Shipment reference |
| `consolNo` | From refNo determination or null for NONJOB | `consolNo` | Consol reference |
| `debiterCode` | `$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode` | `debiterCode` | Organization code |
| `debiterName` | DB Query: `cw_org_header.full_name` | `debiterName` | Organization name |
| `buyerCode` | AR: `$..SellReference[0]`<br/>AP: `$..SupplierReference[0]` | `buyerCode` | Buyer reference |
| `buyerName` | DB Query by buyerCode | `buyerName` | Buyer name |
| `buyerTaxNo` | DB Query: `cw_org_cus_code` where type='VatTaxID' | `buyerTaxNo` | VAT tax ID |
| `buyerAddr` | DB Query: `cw_org_address.addr1` | `buyerAddr` | Buyer address |
| `buyerBankName` | DB Query: `cw_org_bank_account.bank_name` | `buyerBankName` | Bank name |
| `buyerBankAccount` | DB Query: `cw_org_bank_account.bank_account` | `buyerBankAccount` | Bank account |
| `taxRate` | From PostingJournal matching by ChargeCode and Sequence | `taxRate` | Tax rate |
| `itemCode` | `$.ChargeCode.Code` | `itemCode` | Charge code |
| `itemName` | `$.ChargeCode.Description` | `itemName` | Charge description |
| `itemUnit` | Empty string | `itemUnit` | Fixed empty |
| `qty` | 1 | `qty` | Fixed to 1 |
| `taxCode` | AR: `$.SellGSTVATID.TaxCode`<br/>AP: `$.CostGSTVATID.TaxCode` | `taxCode` | VAT tax code |
| `price` | AR: `$.OutstandingAmount`<br/>AP: `$.OutstandingAmount` (×-1) | `price` | Price amount |
| `taxIncludedAmount` | Same as price | `taxIncludedAmount` | Tax inclusive amount |
| `amount` | price - VAT amount | `amount` | Net amount |
| `discountAmt` | BigDecimal.ZERO | `discountAmt` | Fixed to 0 |
| `discountTaxAmt` | BigDecimal.ZERO | `discountTaxAmt` | Fixed to 0 |
| `discountAmtIncludeTax` | BigDecimal.ZERO | `discountAmtIncludeTax` | Fixed to 0 |

## 6. SQL Queries Reference

### 6.1 RefNo Determination Query

**Usage**: Determine SHIPMENT/CONSOL/NONJOB type
```sql
SELECT rn.ref_no, rn.ref_no_type 
FROM cw_account_transaction_ref_no rn
INNER JOIN cw_account_transaction_header ath ON ath.acct_trans_header_id = rn.acct_trans_header_id
WHERE ath.ledger = :ledger
  AND ath.transaction_type = :transactionType 
  AND ath.transaction_no = :transactionNo
```

### 6.2 CW Account Transaction Info - SHIPMENT

**Usage**: Get CW transaction data for SHIPMENT processing
```sql
SELECT DISTINCT 
  ath.AH_PK as account_Transaction_Header_Pk,
  ath.AH_TransactionNum as invoice_no,
  oh.OH_Code as creditor,
  atl.AL_Sequence as display_Sequence,
  jh.JH_JobNum as job_Number,
  atl.AL_PK as account_Transaction_Lines_Pk,
  acc.AC_PK as account_Charge_Code_Pk,
  acc.AC_Code as charge_Code
FROM AccTransactionHeader ath 
INNER JOIN AccTransactionLines atl on atl.AL_AH = ath.AH_PK 
INNER JOIN AccChargeCode acc on acc.AC_PK = atl.AL_AC 
INNER JOIN JobHeader jh on jh.JH_PK = atl.AL_JH 
INNER JOIN OrgHeader oh on atl.AL_OH = oh.OH_PK 
WHERE ath.AH_Ledger = :ledger 
  AND ath.AH_TransactionType = :transactionType 
  AND ath.AH_TransactionNum = :transactionNo 
  AND oh.OH_Code = :organizationCode
```

### 6.3 CW Account Transaction Info - CONSOL

**Usage**: Get CW transaction data for CONSOL processing
```sql
SELECT DISTINCT 
  ath.AH_PK as account_Transaction_Header_Pk,
  ath.AH_TransactionNum as invoice_no,
  jcl.e6_pk as account_Transaction_Lines_Pk,
  acc.AC_PK as account_Charge_Code_Pk,
  acc.AC_Code as charge_Code
FROM AccTransactionHeader ath 
INNER JOIN JobConsolCost jcl ON jcl.e6_ah_apinvoice = ath.ah_pk 
INNER JOIN AccChargeCode acc on acc.AC_PK = jcl.E6_AC_ChargeCode 
WHERE ath.AH_Ledger = :ledger 
  AND ath.AH_TransactionType = :transactionType 
  AND ath.AH_TransactionNum = :transactionNo
```

### 6.4 Debiter Name Query

**Usage**: Get organization full name for debiter/creditor
```sql
SELECT oh.full_name 
FROM cw_org_header oh 
WHERE oh.org_code = :organizationCode
```

### 6.5 Buyer Tax Number Query

**Usage**: Get VAT tax ID for buyer
```sql
SELECT a.cus_code_value 
FROM cw_org_cus_code a 
INNER JOIN cw_org_header oh ON oh.org_header_id = a.org_header_id 
WHERE a.cus_code_type = 'VatTaxID' 
  AND oh.org_code = :organizationCode 
LIMIT 1
```

## 7. Processing Flow by RefNoType

**Note**: All processing flows save to database. External system routing is determined separately by ledger + transaction type.

### 7.1 SHIPMENT Processing

**Source**: `TransactionMappingService.processStandardTransaction()`
1. Create TransactionInfoRequestBean with shipment reference
2. Query CW using SHIPMENT SQL (requires shipment/job context)
3. Process shipment collection from JSON
4. Extract charge lines from shipment charge collections
5. Validate VAT tax codes
6. Save to database (always)
7. If routing decision = external, send to China Compliance System

### 7.2 CONSOL Processing

**Source**: `ChargeLineProcessor.handleConsolChargeLines()`
1. Create TransactionInfoRequestBean with consol reference
2. Query CW using CONSOL SQL (JobConsolCost table)
3. Process single consol cost record
4. Extract charge information from JobConsolCost
5. Validate VAT tax codes
6. Save to database (always)
7. If routing decision = external, send to China Compliance System

### 7.3 NONJOB Processing (New)

**Source**: `TransactionMappingService.processNonJobTransaction()` and `ChargeLineProcessor.handleNonJobChargeLines()`
1. Create TransactionInfoRequestBean **without** shipment/consol reference
2. Query CW using SHIPMENT SQL as base (may return empty - acceptable)
3. Process charge lines directly from PostingJournal (no shipment context needed)
4. **Bypass shipment-specific processing** - no shipment collections to iterate
5. Validate VAT tax codes (same rules apply)
6. Save to database (always)
7. If routing decision = external, send to China Compliance System

### 7.4 Key Differences - NONJOB vs SHIPMENT/CONSOL

| Aspect | SHIPMENT/CONSOL | NONJOB |
|--------|-----------------|--------|
| RefNo Source | Database query result | N/A (null) |
| Shipment Processing | From JSON ShipmentCollection | Skip - no shipments |
| Charge Line Source | Shipment charge lines | PostingJournal directly |
| CW Data Query | Required | Optional (may be empty) |
| Database Save | Always | Always |
| External System Routing | Based on ledger+type | Based on ledger+type (same logic) |
| External System Context | Full shipment context | No shipment context |

## 8. Validation Rules

### 8.1 Policy Compliance Validation

**Source**: `TransactionValidationService.validatePolicyCompliance()`
- Validates VAT tax codes for AR transactions
- Ensures required fields are present
- Checks amount consistency
- NONJOB transactions follow same validation rules

### 8.2 Buyer Reference Validation

**Source**: `TransactionMappingService.extractBuyerCode()`
- AR: Requires SellReference in JSON
- AP: Requires SupplierReference in JSON
- NONJOB: Same validation rules apply

## 9. Special Processing Notes

### 9.1 Amount Sign Conversion

- **AR transactions**: Amounts preserved as positive
- **AP transactions**: Amounts multiplied by -1 for correct accounting

### 9.2 Reversed Transactions

- Detected when `IsCancelled = true`
- Sets cancellation flag instead of creating new records
- Outstanding amounts cleared automatically

### 9.3 External System Routing Decision

**Source**: `TransactionRoutingService.shouldSendToExternalSystem()`
- **Legacy Mode (default)**: Only AR ledger → External System, AP ledger → DB Only
- **Config Mode**: Configurable rules by ledger + transaction type combination
- Decision made after database save, independent of refNoType
- Audit logging for all routing decisions

### 9.4 Kafka Retry Mechanism

- External system messages sent via retry mechanism
- Exponential backoff: 2^attempt seconds
- Dead letter queue for failed messages
- Topic naming: `{profile}-invoice-retry`

---

**Document Version**: 1.0  
**Last Updated**: August 14, 2025  
**Author**: Claude Code Assistant  
**Review Status**: Initial Draft