# AR/AP Transaction Amount Calculation Update

**Date**: October 7, 2025
**Version**: 6.0
**Previous Version**: 5.0 (October 2, 2025)
**Change Type**: Critical Bug Fix - AP Transaction Amount Calculation

---

## Executive Summary

This document details the **second phase** of amount calculation fixes for the Universal Transaction processing system. While the October 2, 2025 fix corrected AR transaction logic, this update extends the same semantic understanding to **AP transactions**, ensuring consistent treatment of net and gross amounts across both ledger types.

---

## Background: The October 2 AR Fix

### Original Problem (AR Transactions)
The October 2 fix addressed a critical bug where:
- AR transactions incorrectly treated `SellOSAmount` as gross amount (including VAT)
- `taxIncludedAmount` was set to net amount instead of gross amount
- `amount` was calculated as `net - VAT` instead of using net amount directly

### AR Fix Applied (October 2, 2025)
```java
// AR Transactions (Fixed):
if (StringUtils.equals("AR", ledger)) {
    this.setTaxIncludedAmount(outstandingAmount.add(outstandingGstVatAmount));  // net + VAT = gross
    this.setAmount(outstandingAmount);  // net amount directly
}
```

**Result**: AR transactions now correctly send gross amounts to China Compliance System.

---

## New Problem Identified: AP Transactions

### Root Cause Analysis

The October 2 fix **correctly identified** that Cargowise's `OSAmount` fields represent **net amounts** (excluding VAT) for both AR and AP transactions. However, the AP logic was left unchanged with a note "Keep existing behavior unchanged."

This was **inconsistent** because:
1. `CostOSAmount` (AP) has the **same semantic meaning** as `SellOSAmount` (AR) - both are **net amounts**
2. AP transactions were still using the old incorrect logic
3. Different calculation rules for AR vs AP violated the principle of consistent accounting

### AP Transaction Behavior (Before This Fix)

**Old AP Logic** (Incorrect):
```java
// AP: Keep existing behavior unchanged
if (StringUtils.equals("AP", ledger)) {
    this.setTaxIncludedAmount(outstandingAmount);  // Just net amount (WRONG)
    this.setAmount(outstandingAmount.subtract(outstandingGstVatAmount));  // net - VAT (WRONG)
}
```

**Example with CostOSAmount=1000, VAT=100:**
- price: -1000 ✓ (net amount, correct)
- taxIncludedAmount: -1000 ❌ (should be -1100)
- amount: -900 ❌ (should be -1000)

### Impact Assessment

**Why This Matters:**
- **Accounting Accuracy**: `taxIncludedAmount` should represent the total amount including tax (gross amount)
- **Compliance Systems**: External systems expect `taxIncludedAmount` to be the gross amount for proper tax reporting
- **Consistency**: AR and AP should follow the same semantic rules (net vs gross)
- **Data Integrity**: The `amount` field should represent net amount for both ledger types

---

## Solution: Unified Amount Calculation Logic

### New Unified Logic (October 7, 2025)

**Updated Code** (Lines 140-150 in `TransactionChargeLineRequestBean.java`):
```java
// Calculate taxIncludedAmount based on ledger type:
// Both AR and AP: OSAmount is net amount, so add VAT to get gross amount
// AR: positive values (net + VAT)
// AP: negative values (net + VAT, both already negated)
this.setTaxIncludedAmount(outstandingAmount.add(outstandingGstVatAmount));

// Calculate amount based on ledger type:
// Both AR and AP: OSAmount is already net amount, use directly
// AR: positive net amount
// AP: negative net amount (already negated)
this.setAmount(outstandingAmount);
```

### Key Changes

**Before (Conditional Logic)**:
- AR and AP had **different calculation formulas**
- Required `if/else` branching based on ledger type
- Inconsistent semantic treatment

**After (Unified Logic)**:
- **Same calculation formula** for both AR and AP
- No conditional branching needed
- Consistent semantic understanding: `OSAmount = net, taxIncludedAmount = gross`
- Sign differences handled automatically through earlier negation (line 130, 137)

---

## Corrected Behavior Comparison

### AR Transactions (Unchanged - Already Fixed Oct 2)

**Example: SellOSAmount=50, SellOSGSTVATAmount=3**

| Field | Before Oct 2 Fix | After Oct 2 Fix | After Oct 7 Fix |
|-------|-----------------|-----------------|-----------------|
| `price` | 50 | 50 ✓ | 50 ✓ |
| `taxIncludedAmount` | 50 ❌ | 53 ✓ | 53 ✓ |
| `amount` | 47 ❌ | 50 ✓ | 50 ✓ |

### AP Transactions (Fixed in This Update)

**Example: CostOSAmount=1000, CostOSGSTVATAmount=100**

| Field | Before Oct 2 Fix | After Oct 2 Fix | After Oct 7 Fix |
|-------|-----------------|-----------------|-----------------|
| `price` | -1000 ✓ | -1000 ✓ | -1000 ✓ |
| `taxIncludedAmount` | -1000 ❌ | -1000 ❌ | **-1100 ✓** |
| `amount` | -900 ❌ | -900 ❌ | **-1000 ✓** |

### Field Definitions (Consistent for Both AR and AP)

- **price**: The net amount (excluding VAT)
  - AR: Positive value from `SellOSAmount`
  - AP: Negative value from `CostOSAmount × -1`

- **taxIncludedAmount**: The gross amount (including VAT)
  - AR: Positive value = `SellOSAmount + SellOSGSTVATAmount`
  - AP: Negative value = `(CostOSAmount × -1) + (CostOSGSTVATAmount × -1)`

- **amount**: The net amount (same as price)
  - AR: Positive value = `SellOSAmount`
  - AP: Negative value = `CostOSAmount × -1`

---

## Code Changes

### File Modified
`src/main/java/oec/lis/erpportal/addon/compliance/model/transaction/TransactionChargeLineRequestBean.java`

### Before (Lines 140-159)
```java
// Calculate taxIncludedAmount based on ledger type:
// - AR: OSAmount is net amount, so add VAT to get gross amount
// - AP: Keep existing behavior (OSAmount is treated as-is)
if (StringUtils.equals("AR", ledger)) {
    // AR: Add VAT to get gross amount (net + VAT)
    this.setTaxIncludedAmount(outstandingAmount.add(outstandingGstVatAmount));
} else {
    // AP: Keep existing behavior unchanged
    this.setTaxIncludedAmount(outstandingAmount);
}
// Calculate amount based on ledger type:
// - AR: OSAmount is already net amount, use directly
// - AP: Keep existing subtraction logic
if (StringUtils.equals("AR", ledger)) {
    // AR: Use net amount directly (OSAmount is already net for AR)
    this.setAmount(outstandingAmount);
} else {
    // AP: Keep existing subtraction logic unchanged
    this.setAmount(outstandingAmount.subtract(outstandingGstVatAmount));
}
```

### After (Lines 140-150)
```java
// Calculate taxIncludedAmount based on ledger type:
// Both AR and AP: OSAmount is net amount, so add VAT to get gross amount
// AR: positive values (net + VAT)
// AP: negative values (net + VAT, both already negated)
this.setTaxIncludedAmount(outstandingAmount.add(outstandingGstVatAmount));

// Calculate amount based on ledger type:
// Both AR and AP: OSAmount is already net amount, use directly
// AR: positive net amount
// AP: negative net amount (already negated)
this.setAmount(outstandingAmount);
```

**Code Reduction**: 19 lines → 10 lines (47% reduction through unified logic)

---

## Test Updates

### Test Files Modified

1. **TransactionChargeLineRequestBeanTest.java** (Line 97)
   - Updated AP test assertion from `-900` to `-1000` for `amount` field
   - Updated AP test assertion from `-1000` to `-1100` for `taxIncludedAmount` field

2. **CurrencyExtractionEdgeCasesTest.java** (Line 290)
   - Updated mixed currency precision test from `-77.17` to `-85.75` for AP `amount` field

### Test Results

**All tests passing:**
- ✓ TransactionChargeLineRequestBeanTest: 10 tests passed
- ✓ CurrencyExtractionUnitTest: 8 tests passed
- ✓ CurrencyExtractionEdgeCasesTest: 11 tests passed
- ✓ Total: 29 unit tests passing with new logic

---

## Impact Assessment

### Positive Impacts

1. **Accounting Consistency**: Both AR and AP now follow standard accounting principles
   - Net amount = Price before tax
   - Gross amount = Net amount + VAT
   - VAT amount = Tax portion only

2. **Code Simplification**: Unified logic reduces complexity
   - Removed conditional branching
   - Easier to maintain and understand
   - Consistent semantic treatment

3. **External System Accuracy**: Compliance systems receive correct data
   - AR transactions: Already fixed (Oct 2)
   - AP transactions: Now fixed (Oct 7)

4. **Tax Reporting**: Improved accuracy for both revenue and cost reporting
   - AR: Revenue side tax reporting (already correct)
   - AP: Cost/vendor side tax reporting (now correct)

### Migration Considerations

**Database Storage**:
- No impact - database continues to store amounts correctly
- Only affects data sent to external systems

**Backward Compatibility**:
- External systems receiving AP transactions will see corrected amounts
- May require coordination with downstream systems expecting old format

**AP Transaction Processing**:
- All AP transactions now send correct gross amounts
- Improved compliance with tax regulations

---

## Documentation Updates

### Related Documentation

This update supersedes and extends:
- **20251002-ARTransaction-Attribute-Mapping.md** (v5.0) - AR fix documentation
- **20250825-ARTransaction-Status-Documentation.md** - Original mapping document

### Updated Field Mappings

**External System Mapping (China Compliance System)**:

| Field | AR Value | AP Value | Notes |
|-------|----------|----------|-------|
| `price` | `SellOSAmount` | `CostOSAmount × -1` | Net amount (both) |
| `taxIncludedAmount` | `SellOSAmount + SellOSGSTVATAmount` | `(CostOSAmount + CostOSGSTVATAmount) × -1` | **Updated**: Gross amount (both) |
| `amount` | `SellOSAmount` | `CostOSAmount × -1` | **Updated**: Net amount (both) |

---

## Validation and Testing

### Manual Verification Steps

1. **AP Invoice Processing**:
   ```bash
   # Test AP invoice with VAT
   CostOSAmount=1000, CostOSGSTVATAmount=100
   Expected: price=-1000, taxIncludedAmount=-1100, amount=-1000
   ```

2. **AR Invoice Processing**:
   ```bash
   # Verify AR still works correctly
   SellOSAmount=50, SellOSGSTVATAmount=3
   Expected: price=50, taxIncludedAmount=53, amount=50
   ```

3. **Unit Tests**:
   ```bash
   ./mvnw test -Dtest=TransactionChargeLineRequestBeanTest
   ./mvnw test -Dtest=CurrencyExtractionEdgeCasesTest
   ```

### Expected Test Results

All unit tests should pass with the updated logic:
- AR transaction tests (already passing from Oct 2 fix)
- AP transaction tests (now passing with corrected expectations)
- Currency extraction tests (updated for new AP logic)

---

## Future Considerations

### Potential Enhancements

1. **Documentation Consolidation**: Create master mapping document combining v5.0 and v6.0 changes
2. **Integration Testing**: Add integration tests for AP transaction external system routing
3. **Monitoring**: Add logging to track AP transaction amount calculations
4. **External System Coordination**: Notify downstream systems of AP amount format changes

### Questions for Review

1. Should we update older documentation files to reference this change?
2. Do external systems need migration period for old vs new AP format?
3. Should we add validation to ensure `taxIncludedAmount ≥ amount` for AR and `taxIncludedAmount ≤ amount` for AP?

---

## Summary

★ **Key Achievement**: Unified amount calculation logic across AR and AP transactions

**Changes Made**:
- ✓ Simplified calculation logic (removed conditional branching)
- ✓ Consistent semantic treatment of net vs gross amounts
- ✓ AP transactions now send correct gross amounts to external systems
- ✓ All 29 unit tests passing with updated expectations

**Business Value**:
- Improved tax reporting accuracy for both AR and AP
- Enhanced compliance with accounting standards
- Reduced code complexity and maintenance burden
- Consistent data format for external system integration

---

**Document Version**: 6.0
**Last Updated**: October 7, 2025
**Author**: Claude Code Assistant
**Review Status**: Updated with AP transaction logic fix
**Related Commits**:
- October 2, 2025: AR transaction fix (commit c89ef15)
- October 7, 2025: AP transaction fix (pending commit)
