# ARTransaction Endpoint Status Documentation

**Date**: August 25, 2025 (Updated October 7, 2025)
**Version**: 1.3 - Added amount calculation fix documentation
**Endpoint**: `POST /external/v1/ARTransaction`
**Purpose**: Comprehensive documentation of all status codes returned by the ARTransaction endpoint
**Audience**: Future developers, system integrators, support engineers

## Document Updates

**Version 1.3 - October 7, 2025**:
- **Critical Fix**: Unified AR/AP transaction amount calculation logic
- **Updated**: Both AR and AP now use consistent net/gross amount semantics
- **Impact**: External systems now receive correct `taxIncludedAmount` for both ledgers
- **Reference**: See `20251007-ARTransaction-Amount-Calculation-Update.md` for detailed changes

**Version 1.2 - September 9, 2025**:
- Added chequeOrReference field mapping documentation
- Updated response structures to include payment reference information
- Added chequeOrReference-specific troubleshooting scenarios
- Enhanced database schema section with new field specifications
- **Added currency code extraction enhancement documentation**
- **Documented charge-line level currency extraction for external systems**
- **Added multi-currency transaction support information**

**Version 1.1 - October 2, 2025**:
- **Critical Fix**: Corrected AR transaction amount calculation with proper VAT handling
- **Reference**: See `20251002-ARTransaction-Attribute-Mapping.md` for details

---

## 1. Executive Summary

The `/external/v1/ARTransaction` endpoint uses a sophisticated status system to track transaction processing through multiple stages. Unlike simple success/failure indicators, this system provides granular visibility into transaction lifecycle states, routing decisions, and system capabilities.

### Quick Reference Table

| Status | Definition | Database Saved | External System | Retry Possible |
|--------|------------|----------------|-----------------|----------------|
| `DONE` | Complete success | ✅ | ✅/❌ (routing dependent) | ❌ |
| `PARTIAL` | Saved but limited | ✅ | ❌ | ✅ (manual/config) |
| `ERROR` | Processing failed | ❌/✅ (context dependent) | ❌ | ✅ (automatic) |
| `REJECTED` | Explicitly denied | ❌ | ❌ | ✅ (config change) |
| `SKIP` | Intentionally ignored | ❌ | ❌ | ❌ |
| `RECEIVED` | Initial acceptance | ❓ | ❌ | ⏳ |
| `SENDING` | External transmission | ✅ | ⏳ | ⏳ |

---

## 2. ChequeOrReference Field Mapping

### 2.1 Overview

The ARTransaction endpoint now includes automatic extraction and persistence of payment reference information through the `chequeOrReference` field. This functionality operates transparently during transaction processing and does not affect status code behavior.

### 2.2 Implementation Details

| Transaction Type | Extraction Method | Data Source | Success Strategy |
|------------------|-------------------|-------------|------------------|
| **AR (Accounts Receivable)** | Enhanced JsonPath filtering | SellReference from ChargeLine | Precision matching with transaction number |
| **AP (Accounts Payable)** | Direct field extraction | CheckNumberOrPaymentRef | Single-phase extraction |
| **Other** | Skipped | N/A | Field remains null |

#### Extraction Logic

**AR Transactions**: 
- Uses JsonPath expression: `$..ChargeLine[?(@.SellPostedTransactionNumber=='TRANSACTION_NUM')].SellReference`
- Matches SellPostedTransactionNumber with transaction number for precise extraction
- Returns null if no matching reference found

**AP Transactions**:
- Extracts directly from `$.CheckNumberOrPaymentRef` field
- Returns null if field is empty or missing

#### Database Persistence

```sql
-- Database field specification
chequeorreference VARCHAR(38) -- 38-character limit with automatic truncation
```

**Key Features**:
- **Automatic Truncation**: Values exceeding 38 characters are truncated with warning logs
- **Null Handling**: Gracefully handles missing or empty payment references
- **Error Resilience**: Extraction failures do not affect transaction processing status

### 2.3 Impact on Transaction Processing

The chequeOrReference extraction operates as a supplementary feature:

- ✅ **No Status Impact**: Extraction failures do not change transaction status codes
- ✅ **Non-Blocking**: Processing continues regardless of reference extraction success
- ✅ **Transparent**: Clients receive same status codes as before
- ✅ **Additive**: Provides additional data without breaking existing functionality

---

## 3. Currency Code Enhancement Architecture

### 3.1 Overview

The ARTransaction endpoint now features enhanced currency extraction that provides charge-line level currency precision for external system integration while maintaining header-level currency for database persistence. This enhancement addresses multi-currency transaction scenarios where individual charge lines may have different currencies than the transaction header.

### 3.2 Implementation Details

| Transaction Type | External System Currency Source | Database Currency Source | Enhancement |
|------------------|----------------------------------|---------------------------|-------------|
| **AR (Accounts Receivable)** | `$.SellOSCurrency.Code` (charge-line) | `$.Oscurrency.Code` (header) | Charge-line precision |
| **AP (Accounts Payable)** | `$.CostOSCurrency.Code` (charge-line) | `$.Oscurrency.Code` (header) | Charge-line precision |
| **NONJOB** | `$.Oscurrency.Code` (PostingJournal) | `$.Oscurrency.Code` (header) | PostingJournal extraction |

#### Currency Extraction Logic

**AR Transactions**:
- **External System**: Extracts currency from individual charge lines via `$.SellOSCurrency.Code`
- **Database**: Maintains header currency from `$.Oscurrency.Code`
- **Fallback**: Uses header currency if charge-line currency is missing

**AP Transactions**:
- **External System**: Extracts currency from individual charge lines via `$.CostOSCurrency.Code`
- **Database**: Maintains header currency from `$.Oscurrency.Code`
- **Fallback**: Uses header currency if charge-line currency is missing

**NONJOB Transactions**:
- **External System**: Extracts currency from PostingJournal via `$.Oscurrency.Code`
- **Database**: Uses header currency from `$.Oscurrency.Code`
- **Enhanced Logic**: Detects PostingJournal structure automatically

### 3.3 Multi-Currency Transaction Support

The system now handles complex multi-currency scenarios:

**Example: AP_CRD_AS20250909_2**
- **Header Currency**: CNY (Chinese Yuan)
- **Charge Line 1**: CNY for FRT charges
- **Charge Line 2**: USD for AMS charges
- **Result**: External system receives precise CNY/USD per charge line

#### Business Benefits
- **Enhanced Data Accuracy**: External systems receive precise charge-line currencies
- **Multi-Currency Invoices**: Handles mixed currency transactions correctly
- **Complete Transaction Support**: AR, AP, and NONJOB fully supported
- **Zero Breaking Changes**: Database structure and existing functionality preserved

### 3.4 Error Handling and Fallback

**Graceful Degradation**:
- **Type-Safe Extraction**: Prevents ClassCastException with proper object validation
- **Missing Currency Handling**: Falls back to header currency when charge-line currency unavailable
- **Malformed JSON Recovery**: JsonPath with exception suppression ensures robustness
- **Enhanced Logging**: Debug logging for currency extraction decisions and troubleshooting

**Fallback Hierarchy**:
1. **Primary**: Charge-line currency (`$.SellOSCurrency.Code` / `$.CostOSCurrency.Code`)
2. **Secondary**: Header currency (`$.Oscurrency.Code`)
3. **Error State**: Detailed logging with error context

### 3.5 Impact on Transaction Processing

The currency extraction enhancement operates transparently:

- ✅ **No Status Impact**: Currency extraction failures do not affect transaction status codes
- ✅ **Non-Blocking**: Processing continues with fallback currency
- ✅ **Database Compatibility**: Header-level currency persistence unchanged
- ✅ **External System Enhancement**: Precise charge-line currency transmission
- ✅ **Backward Compatible**: Existing functionality fully preserved

---

## 4. Status Code Analysis

### 4.1 DONE Status

**Definition**: Transaction has been completely processed according to system configuration and routing rules.

#### Occurrence Scenarios

**Scenario 1: Database-Only Processing (No External System Required)**
- **Location**: `UniversalController.java:172-176`
- **Condition**: `!shouldSendToExternal` (routing decision)
- **Logic**: System determines transaction doesn't require external compliance system
- **Database**: Transaction saved to all relevant tables
- **External**: No external system call made (by design)
- **Response Code**: HTTP 202 (Accepted)

**Scenario 2: Full Processing (Database + External System)**
- **Location**: `UniversalController.java:185`
- **Condition**: `shouldSendToExternal && !hasLookupErrors`
- **Logic**: Transaction qualifies for external system and has no validation errors
- **Database**: Transaction saved to all relevant tables
- **External**: Successfully queued for China Compliance System via Kafka
- **Response Code**: HTTP 202 (Accepted)

**Scenario 3: Batch Transaction Success**
- **Location**: `UniversalController.java:338`
- **Condition**: UniversalTransactionBatch processed without exceptions
- **Logic**: Handles AP PAY/REV Reversed transactions
- **Database**: Varies based on transaction type
- **External**: Not applicable for batch transactions
- **Response Code**: HTTP 202 (Accepted)

#### Response Structure Example
```json
{
  "status": "DONE",
  "savedToDatabase": true,
  "readyForExternal": true,
  "transactionProcessing": {
    "messageCount": 2,
    "hasDebugMessages": true
  },
  "chequeOrReference": {
    "extracted": true,
    "value": "PAY2025090901",
    "source": "CheckNumberOrPaymentRef",
    "truncated": false
  },
  "executionTime": 1250
}
```

**Note**: The `chequeOrReference` object is included for informational purposes only and does not affect the DONE status determination.

### 4.2 PARTIAL Status

**Definition**: Transaction saved to database but cannot be sent to external compliance system due to data issues or system limitations.

#### Occurrence Scenarios

**Scenario 1: Lookup Errors Prevent External Transmission**
- **Location**: `UniversalController.java:179-183`
- **Condition**: `shouldSendToExternal && hasLookupErrors`
- **Logic**: Data validation failed (missing org info, bank details, tax numbers)
- **Database**: Transaction saved with warning flags
- **External**: Blocked due to incomplete data
- **Resolution**: Fix master data configuration
- **Response Code**: HTTP 202 (Accepted)

**Scenario 2: Kafka Integration Disabled**
- **Location**: `UniversalController.java:226-231`
- **Condition**: `!kafkaEnabled || kafkaTemplate == null`
- **Logic**: System configuration prevents external system integration
- **Database**: Transaction saved normally
- **External**: Not attempted due to disabled integration
- **Resolution**: Enable Kafka configuration
- **Response Code**: HTTP 202 (Accepted)

**Scenario 3: Empty Payload (VAT ID Filtering)**
- **Location**: `UniversalController.java:245-255`
- **Condition**: All charge lines filtered out due to missing VAT IDs
- **Logic**: Business rules require VAT IDs for external system transmission
- **Database**: Header saved, but no qualifying line items
- **External**: No data to send
- **Resolution**: Ensure proper VAT ID configuration in source system
- **Response Code**: HTTP 202 (Accepted)

#### Response Structure Example
```json
{
  "status": "PARTIAL",
  "savedToDatabase": true,
  "readyForExternal": false,
  "lookupErrors": {
    "summary": "Transaction saved but cannot be sent due to missing configuration data",
    "failedLookups": [
      {
        "type": "Buyer Tax Number Lookup",
        "field": "Tax Number",
        "value": "OECGRPORD",
        "issue": "Tax number not configured for this organization",
        "suggestion": "Configure tax registration number for organization 'OECGRPORD'"
      }
    ],
    "totalErrors": 1,
    "actionRequired": "Fix configuration issues and reprocess"
  },
  "executionTime": 950
}
```

### 4.3 ERROR Status

**Definition**: Processing failed due to system errors, data corruption, or external system failures.

#### Occurrence Scenarios

**Scenario 1: General Processing Exception**
- **Location**: `UniversalController.java:322`
- **Condition**: Uncaught exception during transaction processing
- **Logic**: Unexpected error in business logic or data access
- **Database**: May be partially saved depending on failure point
- **External**: Not attempted
- **Resolution**: Check logs, fix code/data issues, retry
- **Response Code**: HTTP 202 (Accepted) with error details

**Scenario 2: Batch Processing Exception**
- **Location**: `UniversalController.java:350`
- **Condition**: Error during UniversalTransactionBatch processing
- **Logic**: Exception in AP PAY/REV processing
- **Database**: Transaction rolled back
- **External**: Not attempted
- **Resolution**: Investigate batch processing logic
- **Response Code**: HTTP 202 (Accepted) with error details

**Scenario 3: External System Response Error**
- **Location**: `InvoiceProcessingService.java:74`
- **Condition**: `statusCode != 200 || !succeeded`
- **Logic**: China Compliance System rejected the transaction
- **Database**: Original transaction saved, external response logged
- **External**: Failed at destination
- **Resolution**: Check external system logs, fix data issues
- **Response Code**: Varies (logged in api_log table)

**Scenario 4: External System Communication Error**
- **Location**: `InvoiceProcessingService.java:87`
- **Condition**: Exception during external system call
- **Logic**: Network, authentication, or service unavailability
- **Database**: Original transaction saved, error logged
- **External**: Communication failed
- **Resolution**: Check connectivity, credentials, service status
- **Response Code**: Varies (logged in api_log table)

#### Response Structure Example
```json
{
  "status": "ERROR",
  "errorMessage": "Database connection timeout during transaction save",
  "errorType": "SQLException",
  "transactionProcessing": null,
  "executionTime": 30000
}
```

### 4.4 REJECTED Status

**Definition**: Transaction explicitly denied processing due to policy or configuration restrictions.

#### Occurrence Scenarios

**Scenario 1: NONJOB Support Disabled**
- **Location**: `UniversalController.java:282`
- **Condition**: NONJOB transaction when `transaction.nonjob.enabled=false`
- **Logic**: Policy prevents processing transactions without shipment references
- **Database**: Not saved (transaction rejected at validation stage)
- **External**: Not attempted
- **Resolution**: Enable NONJOB support or ensure transactions have proper references
- **Response Code**: HTTP 400 (Bad Request)

#### Response Structure Example
```json
{
  "status": "REJECTED",
  "savedToDatabase": false,
  "readyForExternal": false,
  "rejectionReason": {
    "errorType": "NONJOB_NOT_SUPPORTED",
    "message": "NONJOB transactions are not supported in current configuration",
    "transactionDetails": {
      "ledger": "AR",
      "transactionType": "INV",
      "transactionNo": "AR2508001031"
    },
    "configurationRequired": "transaction.nonjob.enabled=true",
    "suggestion": "Enable NONJOB support or ensure transaction has valid shipment/consol references"
  }
}
```

### 4.5 SKIP Status

**Definition**: Transaction intentionally ignored based on business rules or system limitations.

#### Occurrence Scenarios

**Scenario 1: PAY/REC Data (SOPL-2185)**
- **Location**: `UniversalController.java:342`
- **Condition**: UniversalTransactionBatch with PAY/REC transaction types
- **Logic**: Business decision to not process payment/receipt data in CPAR service
- **Database**: Not saved (handled by other systems)
- **External**: Not applicable
- **Resolution**: No action needed (working as designed)
- **Response Code**: HTTP 400 (Bad Request)

#### Response Structure Example
```json
{
  "Reason": "SOPL-2185 New PAY|REC data won't be handled by cpar service!"
}
```

### 4.6 RECEIVED Status

**Definition**: Initial status assigned when transaction payload is first accepted by the system.

#### Occurrence Scenarios

**Scenario 1: Transaction Initial Acceptance**
- **Location**: `UniversalController.java:98`
- **Condition**: Every incoming transaction (before processing)
- **Logic**: Logging entry point for audit trail
- **Database**: API log entry created
- **External**: Not yet determined
- **Resolution**: Temporary status, will change during processing
- **Response Code**: Processing continues

### 4.7 SENDING Status

**Definition**: Transaction is being transmitted to external compliance system.

#### Occurrence Scenarios

**Scenario 1: External System Transmission**
- **Location**: `InvoiceProcessingService.java:54`
- **Condition**: Before calling China Compliance System API
- **Logic**: Kafka consumer processing external system call
- **Database**: Transaction already saved, external call in progress
- **External**: API call initiated
- **Resolution**: Will transition to DONE or ERROR based on response
- **Response Code**: Not applicable (internal processing)

---

## 5. Decision Flow Diagrams

### Main Status Determination Flow

```mermaid
graph TD
    A[Incoming Transaction] --> B[Create APILog - RECEIVED]
    B --> C[Parse Universal Transaction]
    C --> D{Valid Structure?}
    D -->|No| E[Return HTTP 400 - Invalid Structure]
    D -->|Yes| F[Extract Transaction Info]
    F --> G[Process with TransactionService]
    G --> H{Processing Success?}
    H -->|Exception| I[Set Status: ERROR]
    H -->|Success| J[Check Routing Rules]
    J --> K{Should Send External?}
    K -->|No| L[Set Status: DONE - DB Only]
    K -->|Yes| M{Has Lookup Errors?}
    M -->|Yes| N[Set Status: PARTIAL - Lookup Errors]
    M -->|No| O{Kafka Enabled?}
    O -->|No| P[Set Status: PARTIAL - Kafka Disabled]
    O -->|Yes| Q{Payload Empty?}
    Q -->|Yes| R[Set Status: PARTIAL - No Data]
    Q -->|No| S[Send to Kafka - Status: DONE]
    
    I --> T[Return HTTP 202 with Error Details]
    L --> U[Return HTTP 202 - DB Only Success]
    N --> V[Return HTTP 202 - Partial Success]
    P --> W[Return HTTP 202 - Config Issue]
    R --> X[Return HTTP 202 - Data Issue]
    S --> Y[Return HTTP 202 - Full Success]
```

### External System Processing Flow

```mermaid
graph TD
    A[Kafka Message Received] --> B[Set Status: SENDING]
    B --> C[Call China Compliance API]
    C --> D{API Response OK?}
    D -->|statusCode=200 & succeeded=true| E[Set Status: DONE]
    D -->|statusCode≠200 or succeeded=false| F[Set Status: ERROR]
    C --> G{Network/Auth Error?}
    G -->|Yes| H[Set Status: ERROR - Exception]
    E --> I[Update Original APILog with Success]
    F --> J[Update Original APILog with Failure]
    H --> K[Update Original APILog with Exception]
```

### NONJOB Transaction Handling

```mermaid
graph TD
    A[NONJOB Transaction Detected] --> B{NONJOB Support Enabled?}
    B -->|transaction.nonjob.enabled=true| C[Process Normally]
    B -->|transaction.nonjob.enabled=false| D[Set Status: REJECTED]
    C --> E[Continue with Standard Processing]
    D --> F[Return HTTP 400 with Rejection Details]
```

---

## 6. Implementation Reference

### Key Files and Locations

| Status | Primary File | Line Numbers | Secondary References |
|--------|-------------|--------------|---------------------|
| DONE | UniversalController.java | 172-176, 185, 338 | InvoiceProcessingService.java:72 |
| PARTIAL | UniversalController.java | 179-183, 226-231, 245-255 | - |
| ERROR | UniversalController.java | 322, 350 | InvoiceProcessingService.java:74, 87 |
| REJECTED | UniversalController.java | 282 | - |
| SKIP | UniversalController.java | 342 | - |
| RECEIVED | UniversalController.java | 98 | Multiple other controllers |
| SENDING | InvoiceProcessingService.java | 54 | - |

### Database Schema Impact

#### API Log Table Structure
```sql
CREATE TABLE api_log (
    api_id UUID PRIMARY KEY,
    action_id UUID,
    api_name VARCHAR(100),  -- "CPAR-API-UniversalTransaction"
    api_status VARCHAR(20), -- Status codes documented here
    api_parameters TEXT,    -- Original request JSON
    api_response TEXT,      -- Response details including status
    cw_status VARCHAR(20),  -- External system response code
    create_time TIMESTAMP,
    update_time TIMESTAMP,
    update_by VARCHAR(50)
);
```

#### Transaction Header Table Structure (Updated)
```sql
CREATE TABLE at_account_transaction_header (
    acct_trans_header_id UUID PRIMARY KEY,
    -- ... other existing fields ...
    chequeorreference VARCHAR(38), -- NEW: Payment reference field (added Sept 2025)
    -- ... other existing fields ...
    create_time TIMESTAMP,
    update_time TIMESTAMP,
    create_by VARCHAR(50),
    update_by VARCHAR(50)
);
```

#### ChequeOrReference Field Queries
```sql
-- Monitor chequeOrReference field population
SELECT 
    ledger,
    COUNT(*) as total_transactions,
    COUNT(chequeorreference) as populated_references,
    ROUND(COUNT(chequeorreference) * 100.0 / COUNT(*), 2) as population_percentage
FROM at_account_transaction_header 
WHERE create_time >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY ledger;

-- Find transactions with truncated references
SELECT transaction_no, ledger, chequeorreference
FROM at_account_transaction_header 
WHERE LENGTH(chequeorreference) = 38
  AND create_time >= CURRENT_DATE - INTERVAL '1 day';
```

#### Status Tracking Query Examples
```sql
-- Count transactions by status
SELECT api_status, COUNT(*) as count
FROM api_log
WHERE api_name = 'CPAR-API-UniversalTransaction'
  AND create_time >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY api_status;

-- Find PARTIAL transactions with reasons
SELECT action_id, api_parameters, api_response
FROM api_log
WHERE api_status = 'PARTIAL'
  AND api_name = 'CPAR-API-UniversalTransaction'
ORDER BY create_time DESC;
```

---

## 7. Developer Guidelines

### 7.1 Client Application Handling

#### Recommended Response Processing
```java
// Example client-side status handling
public void handleTransactionResponse(String status, Map<String, Object> response) {
    switch (status) {
        case "DONE":
            // Transaction fully processed
            logSuccess("Transaction completed successfully");
            if (response.containsKey("readyForExternal")) {
                boolean sentExternal = (Boolean) response.get("readyForExternal");
                updateUI(sentExternal ? "Sent to compliance" : "Saved locally");
            }
            break;
            
        case "PARTIAL":
            // Action may be required
            logWarning("Transaction partially processed");
            if (response.containsKey("lookupErrors")) {
                displayConfigurationIssues((Map) response.get("lookupErrors"));
            }
            enableRetryOption();
            break;
            
        case "ERROR":
            // Retry or escalate
            logError("Processing failed: " + response.get("errorMessage"));
            scheduleRetry();
            break;
            
        case "REJECTED":
            // Configuration change needed
            Map rejection = (Map) response.get("rejectionReason");
            displayConfigurationRequired(rejection.get("configurationRequired"));
            break;
            
        default:
            logWarning("Unknown status: " + status);
    }
}
```

### 7.2 Configuration Requirements

#### NONJOB Support Configuration
```yaml
# Application configuration for NONJOB transactions
transaction:
  nonjob:
    enabled: true  # Required for processing transactions without shipment references
    error-message: "Custom rejection message"  # Optional
```

#### Kafka Configuration
```yaml
# Required for external system integration
kafka:
  enabled: true
  bootstrap-servers: ${KAFKA_SERVERS}
  # Additional Kafka configuration...
```

### 7.3 Monitoring and Alerting

#### Key Metrics to Monitor
1. **Status Distribution**: Track ratio of DONE vs PARTIAL vs ERROR
2. **PARTIAL Reasons**: Monitor frequency of specific lookup errors
3. **Processing Time**: Watch for performance degradation
4. **External System Success**: Monitor DONE vs ERROR for external calls

#### Alert Conditions
```yaml
# Example monitoring rules
alerts:
  - name: "High PARTIAL Rate"
    condition: "PARTIAL_rate > 20% over 1 hour"
    action: "Check master data configuration"
    
  - name: "REJECTED Transactions"
    condition: "REJECTED_count > 0"
    action: "Check NONJOB configuration"
    
  - name: "External System Errors"
    condition: "External_ERROR_rate > 10% over 15 minutes"
    action: "Check China Compliance System connectivity"
```

---

## 8. Troubleshooting Matrix

### Common Scenarios and Expected Status

| Scenario | Expected Status | Action Required | Configuration Check |
|----------|----------------|----------------|-------------------|
| Normal AR Invoice | DONE | None | Routing rules active |
| AR Invoice missing tax ID | PARTIAL | Configure tax ID | Master data tables |
| AP Invoice (legacy mode) | DONE | None | Routing set to legacy |
| NONJOB disabled | REJECTED | Enable support | `transaction.nonjob.enabled` |
| Kafka down | PARTIAL | Fix Kafka | `kafka.enabled` |
| External system down | ERROR (after retry) | Check service | Network/auth |
| Invalid JSON structure | HTTP 400 | Fix payload | Payload validation |
| Database timeout | ERROR | Check DB | Connection pooling |
| **AR with missing SellReference** | **DONE** | **Check source data** | **SellPostedTransactionNumber alignment** |
| **AP with missing CheckNumberOrPaymentRef** | **DONE** | **Verify payment workflow** | **Source system payment reference setup** |
| **High chequeOrReference truncation** | **DONE** | **Review reference formats** | **Consider schema adjustment** |
| **Multi-currency charge lines** | **DONE** | **Verify external system** | **Check charge-line currency extraction** |
| **Currency extraction fallback** | **DONE** | **Review JSON structure** | **Validate charge-line currency fields** |

### Diagnostic Questions

#### For PARTIAL Status
1. **Check routing decision**: Does the transaction type require external system?
2. **Verify lookup errors**: Are all required master data entries present?
3. **Confirm Kafka status**: Is the message queue operational?
4. **Validate payload content**: Do charge lines meet business rules?

#### For ERROR Status
1. **Review exception details**: What specific error occurred?
2. **Check system resources**: Is database/network available?
3. **Verify external system**: Is China Compliance System operational?
4. **Validate input data**: Is the JSON structure correct?

#### For REJECTED Status
1. **Check feature flags**: Is NONJOB support enabled if needed?
2. **Verify business rules**: Does transaction meet processing criteria?
3. **Review configuration**: Are all required settings present?

#### For ChequeOrReference Issues
1. **Check extraction logs**: Are there warnings about missing SellReference or CheckNumberOrPaymentRef?
2. **Verify source data**: Is SellPostedTransactionNumber matching transaction number in AR transactions?
3. **Review payment workflow**: Are CheckNumberOrPaymentRef fields populated in AP transactions?
4. **Monitor truncation**: Are references frequently exceeding 38 characters?
5. **Validate JsonPath**: Is the extraction JsonPath finding the correct data elements?

#### For Currency Code Issues
1. **Check charge-line currencies**: Are SellOSCurrency/CostOSCurrency fields populated in charge lines?
2. **Verify external system data**: Is the external system receiving charge-line specific currencies?
3. **Review fallback behavior**: Are transactions falling back to header currency appropriately?
4. **Monitor multi-currency transactions**: Are mixed currency invoices handled correctly?
5. **Validate NONJOB currencies**: Are PostingJournal currencies extracted properly for NONJOB transactions?
6. **Check type safety**: Are there any ClassCastException errors in currency extraction logs?

### Log Analysis Commands

```bash
# Find recent status distribution
grep "Track id.*Status=" application.log | tail -100 | sort | uniq -c

# Search for specific error patterns
grep "PARTIAL.*lookupErrors" application.log | jq '.lookupErrors'

# Monitor external system responses
grep "InvoiceProcessingService.*statusCode" application.log | grep -v "200.*true"

# ChequeOrReference-specific log analysis
# Monitor extraction success/failure patterns
grep -E "(Set chequeOrReference|No.*SellReference found)" application.log | tail -20

# Check truncation frequency
grep "exceeds 38 characters, truncating" application.log | wc -l

# Monitor AR extraction patterns
grep "Enhanced AR logic found matching SellReference" application.log | tail -10

# Monitor AP extraction patterns  
grep "AP extraction Phase 1 success" application.log | tail -10

# Currency extraction-specific log analysis
# Monitor charge-line currency extraction decisions
grep -E "(charge-line currency|Extracting currency|Currency fallback)" application.log | tail -20

# Check for multi-currency transaction processing
grep -E "(Multi-currency|Mixed currency|Currency mismatch)" application.log | tail -10

# Monitor currency extraction errors and fallbacks
grep -E "(Currency extraction.*failed|Using fallback currency|ClassCastException.*currency)" application.log | tail -15

# Verify NONJOB currency extraction
grep -E "(NONJOB.*currency|PostingJournal.*currency)" application.log | tail -10

# Track external system currency transmission
grep -E "(External system.*currency|TransactionChargeLineRequestBean.*currency)" application.log | tail -10
```

---

## 9. Future Considerations

### Potential Enhancements

1. **Status Hierarchies**: Consider sub-statuses for more granular tracking
2. **Retry Automation**: Implement automatic retry for certain PARTIAL scenarios
3. **Status Webhooks**: Notify external systems of status changes
4. **Performance Metrics**: Add timing breakdowns by processing stage

### Backward Compatibility

When modifying status behavior:
1. Maintain existing status values for API stability
2. Add new fields rather than changing existing response structure
3. Document migration path for deprecated patterns
4. Provide feature flags for gradual rollout

---

**Document Version**: 1.2  
**Last Updated**: September 9, 2025 (Added currency code extraction enhancement)  
**Previous Version**: 1.1 (September 9, 2025 - Added chequeOrReference mapping information)  
**Next Review**: October 9, 2025  
**Contact**: Development Team

---

*This document serves as the authoritative reference for ARTransaction endpoint status codes. For questions or updates, please consult the development team or update this documentation accordingly.*