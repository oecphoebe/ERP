# Mapping Relationship Document

## Overview

This document outlines the mapping relationship between source data from "Universal Transaction" and "Universal Transaction Batch" requests and the target database tables: `at_account_transaction_header`, `at_account_transaction_lines`, and `at_shipment_info`.

## Data Flow

```mermaid
graph TD
    A[Universal Transaction / Universal Transaction Batch] --> B[UniversalController]
    B --> C[TransactionService.analyzePayloadRaw]
    C --> D[generateRequestBeanRaw]
    D --> E[TransactionInfoRequestBean / TransactionChargeLineRequestBean]
    E --> F[AtAccountTransactionHeaderBean]
    E --> G[AtAccountTransactionLinesBean]
    F --> H[at_account_transaction_header]
    G --> I[at_account_transaction_lines]
    D --> J[fetchShipmentInfoFromCW]
    J --> K[AtShipmentInfoBean]
    K --> L[at_shipment_info]
```

## 1. Source to Target Mapping: Universal Transaction

### 1.1 at_account_transaction_header

| Target Field (at_account_transaction_header) | Source Field (Universal Transaction) | Notes |
|----------------------------------------------|-------------------------------------|-------|
| acct_trans_header_id | Generated UUID | Auto-generated |
| ref_no | ShipmentCollection.Shipment.DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key or ForwardingConsol.Key | Reference number (Shipment No or Consol No) |
| cw_acc_trans_header_pk | From CW database query | CargoWise AccTransactionHeader PK |
| ledger | TransactionInfo.Ledger | AR or AP |
| trans_type | TransactionInfo.TransactionType | INV, CRD, etc. |
| inv_no | TransactionInfo.Number | Invoice number |
| inv_date | TransactionInfo.TransactionDate | Invoice date |
| due_date | TransactionInfo.DueDate | Due date |
| crncy_code | TransactionInfo.Oscurrency.Code | Currency code |
| inv_amt | TransactionInfo.Ostotal | Invoice amount |
| outstanding_amt | TransactionInfo.OutstandingAmount | Outstanding amount |
| cmpny_dept | TransactionInfo.Department.Code | Company department |
| exchg_rate | TransactionInfo.ExchangeRate | Exchange rate |
| inv_org_code | TransactionInfo.OrganizationAddress.OrganizationCode | Invoice organization code (Debiter) |
| local_crncy_code | TransactionInfo.LocalCurrency.Code | Local currency code (CNY) |
| cmpny_branch | TransactionInfo.Branch.Code | Company branch |
| trans_desc | TransactionInfo.Description | Transaction description |
| total_vat_amt | TransactionInfo.Osgstvatamount | Total VAT amount |
| local_total_vat_amt | TransactionInfo.LocalVATAmount | Local total VAT amount |
| cmpny_code | TransactionInfo.DataContext.Company.Code | Company code |
| trans_no | TransactionInfo.Number | Transaction number |
| is_cancel | TransactionInfo.IsCancelled | Cancellation flag |
| update_time | TransactionInfo.DataContext.TriggerDate | ETL update timestamp |

### 1.2 at_account_transaction_lines

| Target Field (at_account_transaction_lines) | Source Field (Universal Transaction) | Notes |
|---------------------------------------------|-------------------------------------|-------|
| acc_trans_lines_id | Generated UUID | Auto-generated |
| acct_trans_header_id | Reference to header | Foreign key to at_account_transaction_header |
| cw_acct_trans_lines_pk | From CW database query | CargoWise AccTransactionLines PK |
| chrg_code_id | From CW database query | Charge code ID |
| crncy_code | ChargeLine.SellOSCurrency.Code (AR) or ChargeLine.CostOSCurrency.Code (AP) | Currency code |
| chrg_amt | ChargeLine.SellOSAmount (AR) or ChargeLine.CostOSAmount (AP) | Charge amount |
| vat_amt | Default to 0 | VAT amount |
| total_amt | ChargeLine amount calculation | Total amount |
| exchg_rate | ChargeLine.SellExchangeRate (AR) or ChargeLine.CostExchangeRate (AP) | Exchange rate |
| local_crncy_code | ChargeLine.CostOSCurrency.Code | Local currency code |
| local_vat_amt | Default to 0 | Local VAT amount |
| cmpny_code | From header | Company code |
| cmpny_branch | From header | Company branch |
| cmpny_dept | From header | Company department |
| trans_line_desc | ChargeLine.ChargeCode.Description | Transaction line description |

### 1.3 at_shipment_info

| Target Field (at_shipment_info) | Source Field (Universal Transaction) | Notes |
|---------------------------------|-------------------------------------|-------|
| ref_no | From CW database query | Reference number |
| shipment_no | From CW database query | Shipment number |
| cnsl_no | From CW database query | Consol number |
| hbl_no | From CW database query | House bill of lading number |
| mbl_no | From CW database query | Master bill of lading number |
| master_mbl | From CW database query | Master MBL |
| shipment_id | From CW database query | Shipment ID |
| master_shipment_id | From CW database query | Master shipment ID |
| carrier_book_no | From CW database query | Carrier booking number |
| etd | From CW database query | Estimated time of departure |
| atd | From CW database query | Actual time of departure |
| ata | From CW database query | Actual time of arrival |
| shipment_type | From CW database query | Shipment type |
| cnsl_type | From CW database query | Consol type |
| cntr_mode | From CW database query | Container mode |
| cntr_list | From CW database query | Container list |
| cnsl_first_leg_vssl | From CW database query | Consol first leg vessel |
| cnsl_first_leg_voy | From CW database query | Consol first leg voyage |
| create_cmpny | From CW database query | Create company |
| create_branch | From CW database query | Create branch |
| create_dept | From CW database query | Create department |

## 2. Source to Target Mapping: Universal Transaction Batch

The Universal Transaction Batch follows a similar mapping pattern to Universal Transaction but is used specifically for handling AP PAY and REV (Reversed) scenarios. The main difference is in how the data is processed in the controller:

```java
if (universalType.equals(UniversalType.UNIVERSAL_TRANSACTION)) {
    // Process Universal Transaction
    response = transactionService.analyzePayloadRaw(json);
} else if (universalType.equals(UniversalType.UNIVERSAL_TRANSACTION_BATCH)) {
    // Process Universal Transaction Batch
    response = transactionService.handleUniversalTransactionBatch(json);
}
```

## 3. Special Processing Logic

### 3.1 AR vs AP Processing

- For AR (Accounts Receivable):
  - Data is sent to the tax invoice system
  - BuyerCode is extracted from SellReference
  - Additional buyer information (name, address, tax number, etc.) is retrieved
  - PostingJournal information is used for tax rates

- For AP (Accounts Payable):
  - Data is only saved to the database, not sent to the tax invoice system
  - Different JSON paths are used for amount fields:
    ```java
    if (StringUtils.equals("AP", ledger)) {
        JSON_PATH_CHARGELINE_OSAMOUNT = "$.CostOSAmount";
        JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.CostOSGSTVATAmount";
        JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.CostOSCurrency.Code";
        JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.CostExchangeRate";
    } else {
        JSON_PATH_CHARGELINE_OSAMOUNT = "$.SellOSAmount";
        JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.SellOSGSTVATAmount";
        JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.SellOSCurrency.Code";
        JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.SellExchangeRate";
    }
    ```

### 3.2 Handling Cancellations and Reversals

- When `EventReference` contains patterns like "AR|CRD|Reversed", "AR|INV|Reversed", etc., and `IsCancelled` is true:
  - The system updates the `is_cancel` flag in the existing record rather than creating a new one
  - Original transaction information is retrieved using `OriginalReference.OriginalTransactionNumber`

### 3.3 Shipment vs Consol Processing

- Different SQL queries are used based on whether the reference is a Shipment or Consol:
  ```java
  String querySql = QUERY_CW_ACCOUNT_TRANSACTION_INFO_SHIPMENT;
  if (refNoType.equals("CONSOL")) {
      querySql = QUERY_CW_ACCOUNT_TRANSACTION_INFO_CONSOL;
  }
  ```

## 4. Data Transformation Notes

1. **UUID Generation**: Several UUIDs are generated during processing:
   - `acct_trans_header_id` for at_account_transaction_header
   - `acc_trans_lines_id` for at_account_transaction_lines
   - `itemGuid` for TransactionChargeLineRequestBean

2. **Date Handling**:
   - TriggerDate from the request is parsed as an ISO8601 string and converted to Instant for storage
   - Date fields like InvoiceDate and DueDate are stored as SQL Date objects

3. **Amount Calculations**:
   - For AP transactions, amounts are multiplied by -1 to maintain correct sign conventions
   - VAT amounts are calculated based on the transaction type and tax rates

4. **Upsert Logic**:
   - The system checks if records already exist before inserting
   - For existing records, it updates them instead of creating duplicates
   - The ETL update time is used to determine if newer data should overwrite existing data