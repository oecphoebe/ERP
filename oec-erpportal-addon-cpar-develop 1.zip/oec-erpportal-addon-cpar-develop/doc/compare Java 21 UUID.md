how to compare Java 21 UUID object's equality?

You can compare Java 21 `UUID` objects for equality using the `equals()` method. This method is inherited from the `Object` class and is overridden by the `UUID` class to provide meaningful comparison based on the UUID's value.

Here's how it works:

```java
import java.util.UUID;

public class UUIDComparison {
    public static void main(String[] args) {
        UUID uuid1 = UUID.randomUUID();
        UUID uuid2 = UUID.fromString(uuid1.toString()); // Create a UUID with the same value
        UUID uuid3 = UUID.randomUUID();

        // Using the equals() method
        boolean areEqual1and2 = uuid1.equals(uuid2);
        boolean areEqual1and3 = uuid1.equals(uuid3);

        System.out.println("UUID 1: " + uuid1);
        System.out.println("UUID 2: " + uuid2);
        System.out.println("UUID 3: " + uuid3);
        System.out.println("Are UUID 1 and UUID 2 equal? " + areEqual1and2);
        System.out.println("Are UUID 1 and UUID 3 equal? " + areEqual1and3);

        // You can also use the == operator to compare object references
        boolean sameObject1and2 = (uuid1 == uuid2);
        System.out.println("Do UUID 1 and UUID 2 refer to the same object? " + sameObject1and2);
    }
}
```

**Explanation:**

1.  **`equals(Object obj)` Method:** The `UUID` class overrides the `equals()` method. Two `UUID` objects are considered equal by this method if and only if they represent the same 128-bit value. This means that if two `UUID` objects are created in different ways but have the same underlying value, `equals()` will return `true`.

2.  **`==` Operator:** The `==` operator, on the other hand, compares object references. It checks if two variables refer to the *exact same object* in memory. In the example above, `uuid1` and `uuid2` have the same value but are distinct `UUID` objects in memory (unless `uuid2` was assigned directly as `uuid2 = uuid1`). Therefore, `uuid1 == uuid2` would likely return `false`.

**In summary, to compare the *values* of two `UUID` objects for equality, you should always use the `equals()` method.** The `==` operator should only be used if you want to check if two `UUID` variables refer to the same object instance.

How to retrieve HTTP request header from @RestController using Spring Boot 3.4 and Java 21?

You have several ways to retrieve HTTP request headers within your `@RestController` methods in Spring Boot 3.4 using Java 21. Here are the most common and effective approaches, along with explanations and examples:

**1. Using `@RequestHeader` Annotation (Recommended for Specific Headers):**

This is the most straightforward way to access individual headers. You annotate a method parameter with `@RequestHeader` and specify the name of the header you want to retrieve.

```java
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HeaderController {

    @GetMapping("/header-value")
    public ResponseEntity<String> getSpecificHeader(
            @RequestHeader("X-Custom-Header") String customHeader) {
        return ResponseEntity.ok("Value of X-Custom-Header: " + customHeader);
    }

    @GetMapping("/optional-header")
    public ResponseEntity<String> getOptionalHeader(
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        if (authorizationHeader != null) {
            return ResponseEntity.ok("Authorization Header: " + authorizationHeader);
        } else {
            return ResponseEntity.ok("Authorization Header not present.");
        }
    }

    @GetMapping("/header-with-default")
    public ResponseEntity<String> getHeaderWithDefault(
            @RequestHeader(value = "Accept-Language", defaultValue = "en-US") String acceptLanguage) {
        return ResponseEntity.ok("Accept-Language: " + acceptLanguage);
    }
}
```

* **`@RequestHeader("Header-Name") String headerValue`:** This will inject the value of the "Header-Name" into the `headerValue` parameter. If the header is missing, Spring will throw a `MissingRequestHeaderException` by default.
* **`@RequestHeader(value = "Header-Name", required = false) String headerValue`:** Setting `required = false` makes the header optional. If the header is not present, `headerValue` will be `null`.
* **`@RequestHeader(value = "Header-Name", defaultValue = "someValue") String headerValue`:** If the header is missing, the `headerValue` will be assigned the specified `defaultValue`.

**2. Using `HttpHeaders` Object (Accessing Multiple Headers):**

You can inject the `HttpHeaders` object into your controller method parameter. This object provides a map-like structure to access all the request headers.

```java
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AllHeadersController {

    @GetMapping("/all-headers")
    public ResponseEntity<String> getAllHeaders(HttpHeaders headers) {
        StringBuilder headerInfo = new StringBuilder("Request Headers:\n");
        for (java.util.Map.Entry<String, List<String>> entry : headers.entrySet()) {
            headerInfo.append(entry.getKey()).append(": ").append(String.join(", ", entry.getValue())).append("\n");
        }
        return ResponseEntity.ok(headerInfo.toString());
    }
}
```

* The `HttpHeaders` object provides methods like `get(String headerName)` (returns a single value or `null`), `getValuesAsList(String headerName)` (returns a `List` of values), and allows you to iterate through all the headers using `entrySet()`.

**3. Using `HttpServletRequest` Object (Lower-Level Access):**

You can inject the raw `HttpServletRequest` object, which is part of the Servlet API. This gives you the most direct access to the request details, including headers.

```java
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Enumeration;

@RestController
public class RawHeadersController {

    @GetMapping("/raw-headers")
    public ResponseEntity<String> getRawHeaders(HttpServletRequest request) {
        StringBuilder headerInfo = new StringBuilder("Request Headers (Raw):\n");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            headerInfo.append(headerName).append(": ").append(request.getHeader(headerName)).append("\n");
        }
        return ResponseEntity.ok(headerInfo.toString());
    }
}
```

* The `HttpServletRequest` object provides methods like `getHeader(String name)` (returns a single header value) and `getHeaders(String name)` (returns an `Enumeration` of header values).

**Choosing the Right Approach:**

* **`@RequestHeader`:** Use this when you need to access specific, well-known headers. It's clean and type-safe.
* **`HttpHeaders`:** Use this when you need to access multiple headers or iterate through all of them in a structured way. It provides a more convenient API than the raw `HttpServletRequest`.
* **`HttpServletRequest`:** Use this when you need lower-level access to the request details beyond just headers, or if you need to work directly with the Servlet API. For most header retrieval scenarios in a Spring Boot `@RestController`, the other two options are generally preferred for their conciseness and Spring integration.

All these methods are fully compatible with Spring Boot 3.4 and Java 21. Spring's dependency injection mechanism will automatically provide the required objects as method parameters in your `@RestController` methods.