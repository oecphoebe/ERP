# Large CSV File Processing System Architecture

<architecture_design>
The system architecture follows a microservices approach with a React.js frontend and Spring Boot backend, optimized for processing large CSV files within AWS EKS using Fargate with limited resources (0.5vCPU and 1GB memory).

High-level architecture:
1. **Frontend Layer**: React.js application that handles file selection, chunked uploads, and progress tracking
2. **API Gateway**: Manages API requests and authentication
3. **Backend Processing Layer**: Spring Boot 3.4 service that:
   - Receives file chunks
   - Stores raw files in S3
   - Processes CSV data via streaming without loading entire files into memory
   - Uses reactive programming for non-blocking operations
4. **Messaging Layer**: Lightweight message broker (Amazon SQS) for asynchronous processing
5. **Storage Layer**: 
   - S3 for raw file storage
   - RDS for processed data and metadata
6. **Notification Layer**: WebSocket connections for real-time progress updates

The architecture emphasizes memory efficiency through streaming processing, stateless design for horizontal scaling, and asynchronous operations to maximize throughput within the constrained resources.
</architecture_design>

<component_details>
## 1. Frontend (React.js)

### File Upload Mechanism
The frontend uses chunked file uploads to handle large CSV files efficiently.

```jsx
import React, { useState } from 'react';
import axios from 'axios';

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [progress, setProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState('');
  const [uploadId, setUploadId] = useState('');
  
  const CHUNK_SIZE = 1024 * 1024; // 1MB chunks
  
  const handleFileSelect = (e) => {
    setFile(e.target.files[0]);
    setProgress(0);
    setUploadStatus('');
  };
  
  const initiateUpload = async () => {
    try {
      const response = await axios.post('/api/uploads/initiate', {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type
      });
      
      setUploadId(response.data.uploadId);
      return response.data.uploadId;
    } catch (error) {
      setUploadStatus('Failed to initiate upload');
      console.error(error);
    }
  };
  
  const uploadChunk = async (chunk, chunkIndex, totalChunks, uploadId) => {
    const formData = new FormData();
    formData.append('file', chunk);
    formData.append('chunkIndex', chunkIndex);
    formData.append('totalChunks', totalChunks);
    
    try {
      await axios.post(`/api/uploads/${uploadId}/chunk`, formData, {
        onUploadProgress: (progressEvent) => {
          const percentChunk = (progressEvent.loaded / progressEvent.total) * 100;
          // Calculate overall progress based on chunk progress and total chunks
          const overallProgress = ((chunkIndex - 1) * 100 + percentChunk) / totalChunks;
          setProgress(Math.min(99, overallProgress)); // Cap at 99% until processing completes
        }
      });
      return true;
    } catch (error) {
      console.error(`Error uploading chunk ${chunkIndex}:`, error);
      return false;
    }
  };
  
  const completeUpload = async (uploadId) => {
    try {
      const response = await axios.post(`/api/uploads/${uploadId}/complete`);
      setProgress(100);
      setUploadStatus('Upload complete, processing started');
      
      // Connect to WebSocket for processing updates
      connectToWebSocket(uploadId);
      
      return response.data;
    } catch (error) {
      setUploadStatus('Failed to complete upload');
      console.error(error);
    }
  };
  
  const uploadFile = async () => {
    if (!file) return;
    
    setUploadStatus('Initiating upload...');
    const uploadId = await initiateUpload();
    if (!uploadId) return;
    
    setUploadStatus('Uploading...');
    
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
    let chunkIndex = 1;
    let start = 0;
    
    while (start < file.size) {
      const end = Math.min(start + CHUNK_SIZE, file.size);
      const chunk = file.slice(start, end);
      
      const success = await uploadChunk(chunk, chunkIndex, totalChunks, uploadId);
      if (!success) {
        setUploadStatus('Upload failed');
        return;
      }
      
      start = end;
      chunkIndex++;
    }
    
    await completeUpload(uploadId);
  };
  
  return (
    <div>
      <input type="file" accept=".csv" onChange={handleFileSelect} />
      <button onClick={uploadFile} disabled={!file}>Upload CSV</button>
      
      {progress > 0 && (
        <div className="progress-bar">
          <div className="progress" style={{ width: `${progress}%` }}></div>
        </div>
      )}
      
      <div className="status">{uploadStatus}</div>
    </div>
  );
};

export default FileUpload;
```

### Progress Tracking and Notifications
The frontend establishes a WebSocket connection to receive real-time processing updates:

```jsx
const connectToWebSocket = (uploadId) => {
  const socket = new WebSocket(`wss://api.example.com/ws/uploads/${uploadId}`);
  
  socket.onopen = () => {
    console.log('WebSocket connection established');
  };
  
  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'PROGRESS') {
      setUploadStatus(`Processing: ${data.progress}% (${data.processedRows}/${data.totalRows} rows)`);
    } else if (data.type === 'COMPLETE') {
      setUploadStatus('Processing complete');
      // Show summary of processing results
      displayResults(data.summary);
    } else if (data.type === 'ERROR') {
      setUploadStatus(`Error: ${data.message}`);
    }
  };
  
  socket.onclose = () => {
    console.log('WebSocket connection closed');
  };
  
  return socket;
};

const displayResults = (summary) => {
  // Display processing results, such as:
  // - Number of successfully processed records
  // - Number of records with errors
  // - Link to download error report
};
```

## 2. Backend (Spring Boot 3.4)

### File Reception and Multipart Upload Handling

```java
@RestController
@RequestMapping("/api/uploads")
public class FileUploadController {
    private final UploadService uploadService;
    private final WebSocketService webSocketService;
    
    public FileUploadController(UploadService uploadService, WebSocketService webSocketService) {
        this.uploadService = uploadService;
        this.webSocketService = webSocketService;
    }
    
    @PostMapping("/initiate")
    public ResponseEntity<InitiateUploadResponse> initiateUpload(@RequestBody InitiateUploadRequest request) {
        String uploadId = uploadService.initiateUpload(request.getFileName(), request.getFileSize(), request.getFileType());
        return ResponseEntity.ok(new InitiateUploadResponse(uploadId));
    }
    
    @PostMapping("/{uploadId}/chunk")
    public ResponseEntity<ChunkUploadResponse> uploadChunk(
            @PathVariable String uploadId,
            @RequestParam("file") MultipartFile file,
            @RequestParam("chunkIndex") int chunkIndex,
            @RequestParam("totalChunks") int totalChunks) {
        
        uploadService.saveChunk(uploadId, file, chunkIndex, totalChunks);
        return ResponseEntity.ok(new ChunkUploadResponse(true));
    }
    
    @PostMapping("/{uploadId}/complete")
    public ResponseEntity<CompleteUploadResponse> completeUpload(@PathVariable String uploadId) {
        // Start asynchronous processing after all chunks are received
        CompletableFuture.runAsync(() -> uploadService.processUpload(uploadId, progress -> {
            // Send progress updates via WebSocket
            webSocketService.sendProgressUpdate(uploadId, progress);
        }));
        
        return ResponseEntity.ok(new CompleteUploadResponse(true));
    }
}
```

### Upload Service Implementation

```java
@Service
@Slf4j
public class UploadServiceImpl implements UploadService {
    private final S3Client s3Client;
    private final SqsClient sqsClient;
    private final CsvProcessorService csvProcessorService;
    private final UploadMetadataRepository uploadMetadataRepository;
    
    // Queue and bucket names would be injected from configuration
    private final String csvProcessingQueue;
    private final String rawFilesBucket;
    
    @Override
    public String initiateUpload(String fileName, long fileSize, String fileType) {
        String uploadId = UUID.randomUUID().toString();
        
        // Create upload metadata entry
        UploadMetadata metadata = new UploadMetadata();
        metadata.setUploadId(uploadId);
        metadata.setFileName(fileName);
        metadata.setFileSize(fileSize);
        metadata.setStatus(UploadStatus.INITIATED);
        metadata.setCreatedAt(LocalDateTime.now());
        
        uploadMetadataRepository.save(metadata);
        
        // Create temporary directory for chunks
        Files.createDirectories(Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId));
        
        return uploadId;
    }
    
    @Override
    public void saveChunk(String uploadId, MultipartFile file, int chunkIndex, int totalChunks) {
        Path chunkPath = Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId, String.format("%05d", chunkIndex));
        
        try (OutputStream outputStream = Files.newOutputStream(chunkPath)) {
            file.getInputStream().transferTo(outputStream);
        } catch (IOException e) {
            log.error("Failed to save chunk {} for upload {}", chunkIndex, uploadId, e);
            throw new RuntimeException("Failed to save chunk", e);
        }
        
        // Update metadata
        UploadMetadata metadata = uploadMetadataRepository.findById(uploadId)
                .orElseThrow(() -> new RuntimeException("Upload not found"));
        
        metadata.setChunksReceived(metadata.getChunksReceived() + 1);
        metadata.setUpdatedAt(LocalDateTime.now());
        
        if (metadata.getChunksReceived() >= totalChunks) {
            metadata.setStatus(UploadStatus.UPLOADED);
        }
        
        uploadMetadataRepository.save(metadata);
    }
    
    @Override
    public void processUpload(String uploadId, Consumer<ProgressUpdate> progressConsumer) {
        try {
            // Combine chunks into a single file
            Path combinedFilePath = combineChunks(uploadId);
            
            // Upload combined file to S3
            String s3Key = String.format("raw/%s/%s", uploadId, combinedFilePath.getFileName().toString());
            uploadToS3(combinedFilePath, s3Key);
            
            // Update metadata
            UploadMetadata metadata = uploadMetadataRepository.findById(uploadId)
                    .orElseThrow(() -> new RuntimeException("Upload not found"));
            metadata.setStatus(UploadStatus.PROCESSING);
            metadata.setS3Key(s3Key);
            uploadMetadataRepository.save(metadata);
            
            // Send message to SQS for asynchronous processing
            SendMessageRequest sendMessageRequest = SendMessageRequest.builder()
                    .queueUrl(csvProcessingQueue)
                    .messageBody(JsonUtils.toJson(new CsvProcessingMessage(uploadId, s3Key)))
                    .build();
            
            sqsClient.sendMessage(sendMessageRequest);
            
            // Process the CSV file using streaming
            csvProcessorService.processFile(uploadId, s3Key, progressConsumer);
            
            // Clean up temporary files
            cleanupChunks(uploadId);
            
        } catch (Exception e) {
            log.error("Failed to process upload {}", uploadId, e);
            UploadMetadata metadata = uploadMetadataRepository.findById(uploadId)
                    .orElseThrow(() -> new RuntimeException("Upload not found"));
            metadata.setStatus(UploadStatus.FAILED);
            metadata.setErrorMessage(e.getMessage());
            uploadMetadataRepository.save(metadata);
            
            throw new RuntimeException("Failed to process upload", e);
        }
    }
    
    private Path combineChunks(String uploadId) throws IOException {
        Path uploadsDir = Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId);
        Path combinedFile = Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId + ".csv");
        
        try (OutputStream outputStream = Files.newOutputStream(combinedFile)) {
            Files.list(uploadsDir)
                    .sorted(Comparator.comparing(p -> p.getFileName().toString()))
                    .forEach(chunkPath -> {
                        try (InputStream inputStream = Files.newInputStream(chunkPath)) {
                            inputStream.transferTo(outputStream);
                        } catch (IOException e) {
                            throw new UncheckedIOException(e);
                        }
                    });
        }
        
        return combinedFile;
    }
    
    private void uploadToS3(Path filePath, String s3Key) throws IOException {
        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(rawFilesBucket)
                .key(s3Key)
                .build();
        
        s3Client.putObject(putObjectRequest, RequestBody.fromFile(filePath.toFile()));
    }
    
    private void cleanupChunks(String uploadId) throws IOException {
        Path uploadsDir = Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId);
        Files.walk(uploadsDir)
                .sorted(Comparator.reverseOrder())
                .forEach(path -> {
                    try {
                        Files.delete(path);
                    } catch (IOException e) {
                        log.warn("Failed to delete temporary file: {}", path, e);
                    }
                });
        
        Path combinedFile = Path.of(System.getProperty("java.io.tmpdir"), "uploads", uploadId + ".csv");
        Files.deleteIfExists(combinedFile);
    }
}
```

### CSV Processing Service (Memory-efficient streaming)

```java
@Service
@Slf4j
public class CsvProcessorService {
    private final S3Client s3Client;
    private final UploadMetadataRepository uploadMetadataRepository;
    private final ProcessedRecordRepository processedRecordRepository;
    private final WebSocketService webSocketService;
    
    private final String rawFilesBucket;
    
    public void processFile(String uploadId, String s3Key, Consumer<ProgressUpdate> progressConsumer) {
        try {
            // Update metadata
            UploadMetadata metadata = uploadMetadataRepository.findById(uploadId)
                    .orElseThrow(() -> new RuntimeException("Upload not found"));
            metadata.setStatus(UploadStatus.PROCESSING);
            uploadMetadataRepository.save(metadata);
            
            // Get file from S3
            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket(rawFilesBucket)
                    .key(s3Key)
                    .build();
            
            // Process with streaming to minimize memory usage
            try (ResponseInputStream<GetObjectResponse> s3InputStream = s3Client.getObject(getObjectRequest);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(s3InputStream))) {
                
                // Process first line as header
                String headerLine = reader.readLine();
                if (headerLine == null) {
                    throw new RuntimeException("Empty CSV file");
                }
                
                String[] headers = headerLine.split(",");
                List<String> headersList = Arrays.asList(headers);
                
                // Use streaming to process the CSV file with minimal memory usage
                final AtomicLong totalRows = new AtomicLong(0);
                final AtomicLong processedRows = new AtomicLong(0);
                
                // First pass to count total rows
                s3Client.getObject(getObjectRequest, ResponseTransformer.toOutputStream(
                        new CountingOutputStream(OutputStream.nullOutputStream()) {
                            private boolean firstLine = true;
                            private final byte[] newline = "\n".getBytes();
                            private int newlineCount = 0;
                            
                            @Override
                            protected void beforeWrite(int n) {
                                super.beforeWrite(n);
                                // Skip header row in count
                                if (firstLine) {
                                    firstLine = false;
                                } else {
                                    for (int i = 0; i < n; i++) {
                                        if (newlineCount < newline.length) {
                                            if (buf[off + i] == newline[newlineCount]) {
                                                newlineCount++;
                                                if (newlineCount == newline.length) {
                                                    totalRows.incrementAndGet();
                                                    newlineCount = 0;
                                                }
                                            } else {
                                                newlineCount = 0;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                ));
                
                // Batch processing with transaction batching to reduce memory usage
                final int batchSize = 500; // Process in small batches to limit memory usage
                List<CsvRecord> batch = new ArrayList<>(batchSize);
                
                String line;
                boolean firstLine = true;
                while ((line = reader.readLine()) != null) {
                    if (firstLine) {
                        firstLine = false;
                        continue; // Skip header
                    }
                    
                    String[] values = parseCSVLine(line); // Custom parser to handle CSV edge cases
                    
                    // Create record
                    CsvRecord record = new CsvRecord();
                    record.setUploadId(uploadId);
                    
                    Map<String, String> data = new HashMap<>();
                    for (int i = 0; i < Math.min(headers.length, values.length); i++) {
                        data.put(headers[i], values[i]);
                    }
                    
                    record.setData(data);
                    
                    // Validate record (simplified example)
                    List<String> validationErrors = validateRecord(record, headersList);
                    record.setValid(validationErrors.isEmpty());
                    record.setValidationErrors(validationErrors);
                    
                    batch.add(record);
                    
                    if (batch.size() >= batchSize) {
                        saveRecordBatch(batch);
                        
                        processedRows.addAndGet(batch.size());
                        batch.clear();
                        
                        // Report progress
                        long processed = processedRows.get();
                        long total = totalRows.get();
                        int progressPercent = (int) (processed * 100 / total);
                        
                        ProgressUpdate update = new ProgressUpdate(progressPercent, processed, total);
                        progressConsumer.accept(update);
                        
                        // Pause briefly to allow memory to be reclaimed
                        if (processed % 10000 == 0) {
                            System.gc(); // Hint to the garbage collector
                            Thread.sleep(100); // Small pause to reduce CPU usage
                        }
                    }
                }
                
                // Save any remaining records
                if (!batch.isEmpty()) {
                    saveRecordBatch(batch);
                    processedRows.addAndGet(batch.size());
                }
                
                // Update metadata
                metadata.setStatus(UploadStatus.COMPLETED);
                metadata.setProcessedRows(processedRows.get());
                metadata.setCompletedAt(LocalDateTime.now());
                uploadMetadataRepository.save(metadata);
                
                // Final progress update
                ProgressUpdate update = new ProgressUpdate(100, processedRows.get(), totalRows.get());
                progressConsumer.accept(update);
            }
        } catch (Exception e) {
            log.error("Failed to process CSV file for upload {}", uploadId, e);
            
            // Update metadata
            UploadMetadata metadata = uploadMetadataRepository.findById(uploadId)
                    .orElseThrow(() -> new RuntimeException("Upload not found"));
            metadata.setStatus(UploadStatus.FAILED);
            metadata.setErrorMessage(e.getMessage());
            uploadMetadataRepository.save(metadata);
            
            throw new RuntimeException("Failed to process CSV file", e);
        }
    }
    
    // Custom CSV line parser to handle quoted values, commas within quotes, etc.
    private String[] parseCSVLine(String line) {
        // Implementation of a robust CSV parser that handles quoted values,
        // escaped quotes, and other CSV edge cases
        // This is simplified for the example
        return line.split(",");
    }
    
    private List<String> validateRecord(CsvRecord record, List<String> headers) {
        List<String> errors = new ArrayList<>();
        
        // Implement validation logic based on headers and data
        // This is a simplified example
        
        Map<String, String> data = record.getData();
        
        // Example: Check required fields
        for (String requiredField : headers) {
            if (!data.containsKey(requiredField) || StringUtils.isBlank(data.get(requiredField))) {
                errors.add("Missing required field: " + requiredField);
            }
        }
        
        // Add other validation rules as needed
        
        return errors;
    }
    
    @Transactional
    private void saveRecordBatch(List<CsvRecord> batch) {
        processedRecordRepository.saveAll(batch);
    }
    
    static class ProgressUpdate {
        private final int progressPercent;
        private final long processedRows;
        private final long totalRows;
        
        public ProgressUpdate(int progressPercent, long processedRows, long totalRows) {
            this.progressPercent = progressPercent;
            this.processedRows = processedRows;
            this.totalRows = totalRows;
        }
        
        // Getters
    }
}
```

### WebSocket Implementation

```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
    
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic");
        registry.setApplicationDestinationPrefixes("/app");
    }
    
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOrigins("*")
                .withSockJS();
    }
}

@Service
public class WebSocketService {
    private final SimpMessagingTemplate messagingTemplate;
    
    public WebSocketService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }
    
    public void sendProgressUpdate(String uploadId, CsvProcessorService.ProgressUpdate progressUpdate) {
        WebSocketProgressMessage message = new WebSocketProgressMessage(
                "PROGRESS",
                progressUpdate.getProgressPercent(),
                progressUpdate.getProcessedRows(),
                progressUpdate.getTotalRows()
        );
        
        messagingTemplate.convertAndSend("/topic/uploads/" + uploadId, message);
    }
    
    public void sendCompletionMessage(String uploadId, ProcessingSummary summary) {
        WebSocketCompletionMessage message = new WebSocketCompletionMessage("COMPLETE", summary);
        messagingTemplate.convertAndSend("/topic/uploads/" + uploadId, message);
    }
    
    public void sendErrorMessage(String uploadId, String errorMessage) {
        WebSocketErrorMessage message = new WebSocketErrorMessage("ERROR", errorMessage);
        messagingTemplate.convertAndSend("/topic/uploads/" + uploadId, message);
    }
}
```

## 3. Database

### Schema Design

```java
@Entity
@Table(name = "upload_metadata")
public class UploadMetadata {
    @Id
    private String uploadId;
    
    private String fileName;
    private long fileSize;
    private String fileType;
    private String s3Key;
    
    @Enumerated(EnumType.STRING)
    private UploadStatus status;
    
    private int chunksReceived;
    private long processedRows;
    private String errorMessage;
    
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime completedAt;
    
    // Getters and setters
}

@Entity
@Table(name = "processed_records")
public class CsvRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String uploadId;
    
    @Convert(converter = JsonbConverter.class)
    private Map<String, String> data;
    
    private boolean isValid;
    
    @Convert(converter = StringListConverter.class)
    private List<String> validationErrors;
    
    private LocalDateTime createdAt;
    
    // Getters and setters
}

// Custom converter for storing JSON data
public class JsonbConverter implements AttributeConverter<Map<String, String>, String> {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    @Override
    public String convertToDatabaseColumn(Map<String, String> attribute) {
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting map to JSON", e);
        }
    }
    
    @Override
    public Map<String, String> convertToEntityAttribute(String dbData) {
        try {
            return objectMapper.readValue(dbData, new TypeReference<Map<String, String>>() {});
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting JSON to map", e);
        }
    }
}

// Custom converter for storing string lists
public class StringListConverter implements AttributeConverter<List<String>, String> {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    @Override
    public String convertToDatabaseColumn(List<String> attribute) {
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting list to JSON", e);
        }
    }
    
    @Override
    public List<String> convertToEntityAttribute(String dbData) {
        try {
            return objectMapper.readValue(dbData, new TypeReference<List<String>>() {});
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting JSON to list", e);
        }
    }
}
```

### Repository Interfaces

```java
@Repository
public interface UploadMetadataRepository extends JpaRepository<UploadMetadata, String> {
    List<UploadMetadata> findByStatus(UploadStatus status);
}

@Repository
public interface ProcessedRecordRepository extends JpaRepository<CsvRecord, Long> {
    List<CsvRecord> findByUploadId(String uploadId);
    List<CsvRecord> findByUploadIdAndIsValid(String uploadId, boolean isValid);
    
    @Query(value = "SELECT COUNT(*) FROM processed_records WHERE upload_id = :uploadId", nativeQuery = true)
    long countByUploadId(@Param("uploadId") String uploadId);
    
    @Query(value = "SELECT COUNT(*) FROM processed_records WHERE upload_id = :uploadId AND is_valid = :isValid", nativeQuery = true)
    long countByUploadIdAndIsValid(@Param("uploadId") String uploadId, @Param("isValid") boolean isValid);
}
```

## 4. Application Configuration

```java
@Configuration
public class AwsConfig {
    
    @Bean
    public S3Client s3Client() {
        return S3Client.builder()
                .region(Region.US_EAST_1) // Configure based on deployment region
                .build();
    }
    
    @Bean
    public SqsClient sqsClient() {
        return SqsClient.builder()
                .region(Region.US_EAST_1) // Configure based on deployment region
                .build();
    }
}

@Configuration
@EnableAsync
public class AsyncConfig implements AsyncConfigurer {
    
    @Override
    public Executor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2); // Keep minimal due to resource constraints
        executor.setMaxPoolSize(4);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("async-");
        executor.initialize();
        return executor;
    }
    
    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return new SimpleAsyncUncaughtExceptionHandler();
    }
}

@Configuration
@PropertySource("classpath:application.yml")
public class AppConfig {
    
    @Value("${aws.s3.rawFilesBucket}")
    private String rawFilesBucket;
    
    @Value("${aws.sqs.csvProcessingQueue}")
    private String csvProcessingQueue;
    
    @Bean
    public String rawFilesBucket() {
        return rawFilesBucket;
    }
    
    @Bean
    public String csvProcessingQueue() {
        return csvProcessingQueue;
    }
}
```

## 5. Containerization Configuration

**Dockerfile for Spring Boot application:**

```dockerfile
FROM amazoncorretto:17-alpine as builder
WORKDIR /app
COPY mvnw .
COPY .mvn .mvn
COPY pom.xml .
COPY src src
RUN ./mvnw package -DskipTests

FROM amazoncorretto:17-alpine
WORKDIR /app
COPY --from=builder /app/target/*.jar app.jar

# Optimize for low memory environment
ENV JAVA_OPTS="-Xms256m -Xmx768m -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:+UseStringDeduplication -XX:+UseCompressedOops -XX:+UseCompressedClassPointers"

ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]
```

**Kubernetes configuration for EKS Fargate:**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: csv-processor
spec:
  replicas: 1
  selector:
    matchLabels:
      app: csv-processor
  template:
    metadata:
      labels:
        app: csv-processor
    spec:
      containers:
      - name: csv-processor
        image: ${ECR_REPOSITORY_URI}:latest
        resources:
          requests:
            memory: "768Mi"
            cpu: "400m"
          limits:
            memory: "900Mi"
            cpu: "500m"
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "production"
        - name: AWS_REGION
          value: "us-east-1"
        livenessProbe:
          httpGet:
            path: /actuator/health/liveness
            port: 8080
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 15
---
apiVersion: v1
kind: Service
metadata:
  name: csv-processor
spec:
  selector:
    app: csv-processor
  ports:
  - port: 80
    targetPort: 8080
  type: ClusterIP
```
</component_details>

<scalability_and_performance>
# Scalability and Performance Optimization Strategies

## Memory Optimization for Limited Fargate Resources (1GB)

1. **Streaming-based CSV Processing**:
   - The implementation uses Java's streaming API to parse and process CSV files without loading the entire file into memory
   - Files are read line-by-line, with only a small batch of records kept in memory at any time

2. **Chunk-based Upload Strategy**:
   - Large files are uploaded in 1MB chunks to avoid overwhelming the server
   - Backend temporarily stores and then combines chunks to minimize memory pressure

3. **JVM Tuning for Low Memory Environments**:
   - Limited heap space (768MB max) leaving memory for container overhead
   - G1 garbage collector with tuned parameters for frequent, short collection pauses
   - String deduplication enabled to reduce memory consumption for repeated strings in CSV data

4. **Batch Processing with Controlled Memory Footprint**:
   - Records are processed in small batches (500 records) before being committed to the database
   - Periodic garbage collection hints and brief pauses during processing to allow memory reclamation

5. **Non-blocking I/O and Reactive Programming**:
   - Asynchronous processing for I/O operations to maintain responsiveness
   - Reactive streams used for data flow control

## Handling Concurrent Requests

1. **Asynchronous Processing Pipeline**:
   - Upload and processing phases decoupled using a lightweight message queue (SQS)
   - WebSocket for progress updates without blocking HTTP connections

2. **Minimalist Thread Pool Configuration**:
   - Thread pool optimized for limited CPU (0.5vCPU)
   - Core threads: 2, Maximum threads: 4
   - Larger queue capacity (50) to handle concurrent requests with minimal threads

3. **Database Connection Pooling**:
   - HikariCP connection pool configured with minimal idle connections (2)
   - Maximum pool size of 5 connections to prevent database connection overhead

4. **Stateless Application Design**:
   - All upload state stored in database and S3
   - Application can be horizontally scaled as needed
   - Session affinity not required

5. **Circuit Breaking and Backpressure**:
   - Detection of resource exhaustion with appropriate backpressure signals
   - Failing fast when operating conditions exceed capacity

## Performance Enhancement Techniques

1. **Indexed Database Queries**:
   - Optimized indices on uploadId and validity fields for quick querying
   - Strategic denormalization of data for read-intensive workloads

2. **Optimized API Gateway Configuration**:
   - Compression for HTTP responses
   - Minimal middleware for API request processing
   - Cache-control headers to leverage client-side caching

3. **S3 Transfer Acceleration**:
   - Direct browser-to-S3 uploads considered for extremely large files
   - S3 Transfer Acceleration enabled for faster cross-region file transfers

4. **Intelligent Load Shedding**:
   - Runtime detection of system load
   - Adaptive request throttling when system is under high load
   - Clear error communication to clients when throttling occurs

5. **Lazy Loading and Resource Management**:
   - Resources initialized only when needed
   - Connection pools warmed up gradually
   - Temporary files and resources explicitly released when no longer needed

These strategies collectively enable the system to efficiently process large CSV files while staying within the constrained Fargate resources of 0.5vCPU and 1GB memory, maintaining responsiveness for concurrent users and providing graceful degradation under heavy load.
</scalability_and_performance>

<summary>
# CSV File Processing System Summary

This architecture presents a complete solution for processing large CSV files in a resource-constrained AWS EKS Fargate environment (0.5vCPU, 1GB memory). The system successfully addresses all key requirements through a carefully designed approach that emphasizes memory efficiency, streaming data processing, and asynchronous operations.

## Key Design Decisions

1. **Chunked File Upload**: Large CSV files are split into manageable 1MB chunks on the client side, preventing server memory exhaustion during file reception.

2. **Memory-Efficient Processing**: The backend implements streaming-based CSV processing, reading and processing one line at a time without loading the entire file into memory.

3. **Asynchronous Workflow**: The system separates upload from processing using AWS SQS, enabling responsive user interaction while heavy processing occurs in the background.

4. **Real-time Progress Updates**: WebSocket connections provide users with live progress updates during both upload and processing phases.

5. **Resource-Conscious Implementation**: The entire architecture is optimized for the limited Fargate resources with strategic JVM tuning, minimal thread pools, and controlled batch processing.

## Implementation Highlights

- **React.js Frontend**: Implements chunked file uploads with progress tracking and WebSocket-based notifications
- **Spring Boot Backend**: Uses reactive programming patterns and non-blocking I/O for efficient resource utilization
- **S3 Integration**: Raw CSV files stored in S3 for durability and to offload storage from the application
- **Streaming CSV Processing**: Custom implementation for handling large files without memory constraints
- **Database Design**: Efficient schema with JSON storage for flexible record structures

## Deployment Approach

The system is containerized and deployed to AWS EKS using Fargate profiles. The deployment configuration includes:

- Resource limits matching the 0.5vCPU and 1GB memory constraints
- Health probes for container lifecycle management
- Performance-tuned JVM settings

## Scalability Considerations

While initially configured for the specified resource constraints, the architecture is designed to scale horizontally if needed. The stateless design of the application layer enables straightforward horizontal scaling by increasing the replica count.

## Final Assessment

This architecture provides a robust solution for processing large CSV files in a resource-constrained environment. By leveraging streaming data processing, asynchronous workflows, and memory-efficient implementation techniques, the system can handle files much larger than the available memory while maintaining responsiveness and providing real-time feedback to users.
</summary>