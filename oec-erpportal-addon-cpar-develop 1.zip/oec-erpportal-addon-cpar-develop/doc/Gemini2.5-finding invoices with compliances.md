```
help me tune following sql statement, the purpose of this sql is to list up aath.trans_no and cc.compliance_no with cc.compliance_no comes from the earliest record of cp_compliance.
---
select
distinct link.acct_trans_header_id,
aath.trans_no,
link.compliance_id,
cc.compliance_no,
cc.compliance_code,
cc.create_cmpny
from cp_compliance_acct_trans_header_line_link link
inner join at_account_transaction_header aath on aath.acct_trans_header_id = link.acct_trans_header_id
inner join cp_compliance cc on
cc.compliance_id = (
select cc3.compliance_id
from cp_compliance cc3
where create_time = (select min(cc2.create_time) from cp_compliance cc2 where cc2.compliance_id in(
select distinct compliance_id
from cp_compliance_acct_trans_header_line_link link
where acct_trans_header_id = link.acct_trans_header_id)
)
)
```

Okay, let's analyze the original query and tune it.

**Analysis of the Original Query:**

1.  **Goal:** For each `acct_trans_header_id` found in the `link` table, find the associated `trans_no` from `aath` and details from the `cp_compliance` (`cc`) record that has the *earliest* `create_time` among all `compliance_id`s linked to that *same* `acct_trans_header_id`.
2.  **Problem Area:** The main performance bottleneck and logical complexity lies in the subquery used to join `cp_compliance`:
    ```sql
    cc.compliance_id = (
        select cc3.compliance_id
        from cp_compliance cc3
        where create_time = ( -- Find the compliance_id matching the minimum create_time
            select min(cc2.create_time) -- Find the minimum create_time...
            from cp_compliance cc2
            where cc2.compliance_id in ( -- ...for compliance_ids linked to the header
                select distinct compliance_id
                from cp_compliance_acct_trans_header_line_link link -- <<<< PROBLEM: This 'link' is not correlated correctly
                where acct_trans_header_id = link.acct_trans_header_id -- <<<< This condition is always true within this subquery context
            )
        )
    )
    ```
    * **Correlation Issue:** The innermost subquery (`select distinct compliance_id from ... where acct_trans_header_id = link.acct_trans_header_id`) does *not* correctly correlate `link.acct_trans_header_id` from the *outer* query's `link` table. It essentially finds *all* distinct `compliance_id`s in the entire `link` table because `link.acct_trans_header_id = link.acct_trans_header_id` is always true for any row within *that* subquery's scope. This means it's likely finding the globally earliest `cp_compliance` record, not the earliest one specific to each transaction header.
    * **Inefficiency:** Using nested subqueries (`WHERE = (SELECT ... WHERE = (SELECT ... WHERE IN (SELECT ...)))`) is generally inefficient. Databases often struggle to optimize these deeply nested, correlated lookups.
    * **Tie Handling:** If multiple `cp_compliance` records share the same earliest `create_time` for a given `acct_trans_header_id`, the subquery `select cc3.compliance_id ... where create_time = ...` might return multiple rows, which would cause an error when used with `=`. The original query relies on the outer `DISTINCT` and the specific database behavior, which isn't robust.

**Tuned Query using Window Functions:**

The most efficient and standard SQL way to handle "get the top/earliest/latest N records per group" is using window functions like `ROW_NUMBER()`.

```sql
WITH RankedCompliance AS (
    -- Step 1: Join link and compliance tables, and rank compliance records for each header based on creation time
    SELECT
        link.acct_trans_header_id,
        cc.compliance_id,
        cc.compliance_no,
        cc.compliance_code,
        cc.create_cmpny,
        cc.create_time, -- Included for ordering, can be removed from final SELECT if not needed
        ROW_NUMBER() OVER(PARTITION BY link.acct_trans_header_id
                          ORDER BY cc.create_time ASC, cc.compliance_id ASC) as rn
        -- Partition by the header ID: Rank independently for each transaction.
        -- Order by create_time ascending: Earliest time gets rank 1.
        -- Order by compliance_id ascending (secondary sort): Acts as a tie-breaker if create_times are identical, ensuring deterministic results.
    FROM
        cp_compliance_acct_trans_header_line_link link
    INNER JOIN
        cp_compliance cc ON link.compliance_id = cc.compliance_id
)
-- Step 2: Join the ranked results with the transaction header table and filter for the earliest record (rank = 1)
SELECT
    rc.acct_trans_header_id,
    aath.trans_no,
    rc.compliance_id,
    rc.compliance_no,
    rc.compliance_code,
    rc.create_cmpny
FROM
    RankedCompliance rc
INNER JOIN
    at_account_transaction_header aath ON aath.acct_trans_header_id = rc.acct_trans_header_id
WHERE
    rc.rn = 1; -- Select only the earliest record for each acct_trans_header_id
```

**Explanation of the Tuned Query:**

1.  **`RankedCompliance` CTE (Common Table Expression):**
    * We first join `cp_compliance_acct_trans_header_line_link` (`link`) and `cp_compliance` (`cc`) to get all linked compliance records for all headers.
    * `ROW_NUMBER() OVER(...)` is the window function.
        * `PARTITION BY link.acct_trans_header_id`: This divides the data into partitions, one for each unique `acct_trans_header_id`. The row numbering restarts for each partition.
        * `ORDER BY cc.create_time ASC, cc.compliance_id ASC`: Within each partition (i.e., for each `acct_trans_header_id`), this orders the rows by `create_time` from earliest to latest. We add `compliance_id` as a secondary sort key to ensure that if two compliance records for the same header have the *exact same* `create_time`, the query consistently picks one (e.g., the one with the lower `compliance_id`), making the result deterministic.
        * `as rn`: This assigns the calculated rank (1 for the earliest, 2 for the second earliest, etc.) to a column named `rn`.
2.  **Final `SELECT`:**
    * We select from the `RankedCompliance` CTE.
    * We join it with `at_account_transaction_header` (`aath`) to get the `trans_no`.
    * `WHERE rc.rn = 1`: This is the crucial filter. It selects only the rows that received the rank of 1 within their partition, which corresponds to the earliest `cp_compliance` record for each `acct_trans_header_id`.
    * `DISTINCT` is no longer needed because the `ROW_NUMBER() = 1` filter guarantees only one row per `acct_trans_header_id` is selected from the `RankedCompliance` CTE.

**Benefits of the Tuned Query:**

* **Correctness:** Accurately finds the earliest record *per* `acct_trans_header_id`.
* **Efficiency:** Window functions are generally optimized by database engines for this type of task and usually perform significantly better than complex correlated subqueries.
* **Readability:** Using a CTE and `ROW_NUMBER()` makes the logic clearer and easier to understand.
* **Determinism:** Handles ties in `create_time` consistently.

**Indexing Recommendations:**

For optimal performance of the tuned query, ensure you have appropriate indexes:

* On `cp_compliance_acct_trans_header_line_link`: (`acct_trans_header_id`, `compliance_id`) - composite index might be beneficial.
* On `cp_compliance`: (`compliance_id`) and (`create_time`, `compliance_id`) - the latter helps the `ORDER BY` clause within the window function.
* On `at_account_transaction_header`: (`acct_trans_header_id`)




```
Is it possible to get the record count by each link.acct_trans_header_id in above tunned SQL?
```




Yes, absolutely. You can add another window function, `COUNT(*)`, within the same CTE to calculate the total count of linked compliance records for each `acct_trans_header_id` before filtering for the earliest one.

Here's the modified tuned query:

```sql
WITH RankedCompliance AS (
    -- Step 1: Join link and compliance tables, rank records, AND count total records per header
    SELECT
        link.acct_trans_header_id,
        cc.compliance_id,
        cc.compliance_no,
        cc.compliance_code,
        cc.create_cmpny,
        cc.create_time, -- Included for ordering, can be removed from final SELECT if not needed

        -- Rank compliance records for each header based on creation time
        ROW_NUMBER() OVER(PARTITION BY link.acct_trans_header_id
                          ORDER BY cc.create_time ASC, cc.compliance_id ASC) as rn,

        -- Count all compliance records associated with this header_id
        COUNT(*) OVER (PARTITION BY link.acct_trans_header_id) as total_compliance_records_count
    FROM
        cp_compliance_acct_trans_header_line_link link
    INNER JOIN
        cp_compliance cc ON link.compliance_id = cc.compliance_id
)
-- Step 2: Join the ranked results with the transaction header table and filter for the earliest record (rank = 1)
SELECT
    rc.acct_trans_header_id,
    aath.trans_no,
    rc.compliance_id,          -- ID of the earliest record
    rc.compliance_no,          -- Number of the earliest record
    rc.compliance_code,        -- Code of the earliest record
    rc.create_cmpny,           -- Company of the earliest record
    rc.total_compliance_records_count -- Total count of records for this header_id
FROM
    RankedCompliance rc
INNER JOIN
    at_account_transaction_header aath ON aath.acct_trans_header_id = rc.acct_trans_header_id
WHERE
    rc.rn = 1; -- Select only the row representing the earliest record
```

**Changes Made:**

1.  **Added `COUNT(*)` Window Function:** Inside the `RankedCompliance` CTE, we added:
    ```sql
    COUNT(*) OVER (PARTITION BY link.acct_trans_header_id) as total_compliance_records_count
    ```
    * `COUNT(*)`: Counts the rows.
    * `OVER (PARTITION BY link.acct_trans_header_id)`: This tells the database to perform the count separately for each group of rows that have the same `acct_trans_header_id`. Importantly, this count is performed *before* the `WHERE rc.rn = 1` filter is applied in the final query. Therefore, it gives the total count of linked records for that header.

2.  **Added to Final `SELECT`:** The new column `total_compliance_records_count` is included in the final `SELECT` list to display the calculated count.

This query remains efficient because both window functions (`ROW_NUMBER` and `COUNT`) can often be calculated in a single pass over the partitioned data within the CTE.



```
cp_compliance_acct_trans_header_link_link has following DDL, as you can see, it also contains an acct_trans_lines_id field which has many to one relationship with acct_trans_header_id. So I want to remove the redundency of count from above SQL. Help me with that!
---
CREATE TABLE sopl.cp_compliance_acct_trans_header_line_link (
compliance_acct_trans_header_line_link_id uuid NOT NULL,
compliance_id uuid NOT NULL,
acct_trans_header_id uuid NOT NULL,
acct_trans_lines_id uuid NOT NULL,
CONSTRAINT pk_cp_compliance_acct_trans_line_link PRIMARY KEY (compliance_acct_trans_header_line_link_id)
);
---
```


Okay, I understand. The `acct_trans_lines_id` in the `cp_compliance_acct_trans_header_line_link` table means that a single `compliance_id` might be linked multiple times to the same `acct_trans_header_id` (once for each distinct `acct_trans_lines_id` it's associated with under that header).

Therefore, the previous `COUNT(*) OVER (...)` was counting the number of *links*, not the number of *distinct compliance records* associated with the header.

To get the count of distinct `compliance_id`s associated with each `acct_trans_header_id`, you should use `COUNT(DISTINCT ...)` within the window function.

Here's the updated query:

```sql
WITH ComplianceData AS (
    -- Step 1: Join link and compliance tables.
    -- We select distinct combinations of header and compliance ID first
    -- if a compliance record links to multiple lines under the same header.
    -- This avoids issues if the *same* compliance record is the earliest but linked multiple times.
    SELECT DISTINCT
        link.acct_trans_header_id,
        cc.compliance_id,
        cc.compliance_no,
        cc.compliance_code,
        cc.create_cmpny,
        cc.create_time
    FROM
        cp_compliance_acct_trans_header_line_link link
    INNER JOIN
        cp_compliance cc ON link.compliance_id = cc.compliance_id

), RankedAndCountedCompliance AS (
    -- Step 2: Rank the distinct compliance records per header and count them
    SELECT
        cd.acct_trans_header_id,
        cd.compliance_id,
        cd.compliance_no,
        cd.compliance_code,
        cd.create_cmpny,
        cd.create_time,

        -- Rank distinct compliance records for each header based on creation time
        ROW_NUMBER() OVER(PARTITION BY cd.acct_trans_header_id
                          ORDER BY cd.create_time ASC, cd.compliance_id ASC) as rn,

        -- Count the total number of DISTINCT compliance records associated with this header_id
        COUNT(*) OVER (PARTITION BY cd.acct_trans_header_id) as distinct_compliance_records_count
        -- Since we selected distinct compliance_ids per header in the previous CTE,
        -- COUNT(*) here effectively counts distinct compliance records per header.

        -- Alternatively, if window functions support COUNT(DISTINCT ...) in your specific DB:
        -- COUNT(DISTINCT cd.compliance_id) OVER (PARTITION BY cd.acct_trans_header_id) as distinct_compliance_records_count

    FROM
        ComplianceData cd
)
-- Step 3: Join the ranked/counted results with the transaction header table and filter for the earliest record (rank = 1)
SELECT
    rcc.acct_trans_header_id,
    aath.trans_no,
    rcc.compliance_id,          -- ID of the earliest record
    rcc.compliance_no,          -- Number of the earliest record
    rcc.compliance_code,        -- Code of the earliest record
    rcc.create_cmpny,           -- Company of the earliest record
    rcc.distinct_compliance_records_count -- Total count of DISTINCT compliance records for this header_id
FROM
    RankedAndCountedCompliance rcc
INNER JOIN
    at_account_transaction_header aath ON aath.acct_trans_header_id = rcc.acct_trans_header_id
WHERE
    rcc.rn = 1; -- Select only the row representing the earliest distinct compliance record
```

**Explanation of Changes:**

1.  **`ComplianceData` CTE:**
    * We added a preliminary CTE `ComplianceData`.
    * `SELECT DISTINCT link.acct_trans_header_id, cc.compliance_id, ...`: This crucial step ensures that we only consider each unique pair of `(acct_trans_header_id, compliance_id)` once, even if a compliance record is linked via multiple lines in the `cp_compliance_acct_trans_header_line_link` table. This effectively de-duplicates based on the compliance record itself *before* ranking or counting.
2.  **`RankedAndCountedCompliance` CTE:**
    * This CTE now operates on the de-duplicated data from `ComplianceData`.
    * **`ROW_NUMBER()`:** This still correctly ranks the unique compliance records associated with the header to find the earliest one based on `create_time`.
    * **`COUNT(*) OVER (PARTITION BY cd.acct_trans_header_id)`:** Because the input data (`ComplianceData`) is already distinct per `(acct_trans_header_id, compliance_id)`, a simple `COUNT(*)` partitioned by `acct_trans_header_id` now correctly gives the count of *distinct* compliance records for that header.
    * **Alternative `COUNT(DISTINCT ...)`:** If your specific database version supports `COUNT(DISTINCT ...)` within window functions efficiently (most modern ones do), you could potentially skip the first CTE and directly use `COUNT(DISTINCT cc.compliance_id) OVER (PARTITION BY link.acct_trans_header_id)` in a single CTE structure similar to the previous answer. However, the two-CTE approach shown above is universally compatible and clearly separates the de-duplication step.
3.  **Final `SELECT`:** The final select remains similar but now correctly uses the `distinct_compliance_records_count`.

This revised query correctly identifies the earliest compliance record based on `create_time` while also providing an accurate count of the unique compliance records associated with each `acct_trans_header_id`.