# TransactionServiceImpl JSON Structure Mapping Analysis

## Overview
This document analyzes how the input JSON structure (UniversalTransaction) maps to the final `TransactionInfoRequestBean` data structure for external system integration in the TransactionServiceImpl.

## Input JSON Structure
The input JSON follows the UniversalTransaction format with the following key structure:

```json
{
  "Body": {
    "UniversalTransaction": {
      "TransactionInfo": {
        "Ledger": "AR|AP",
        "TransactionType": "INV|CRD",
        "Number": "transaction_number",
        "TransactionDate": "date",
        "IsCancelled": boolean,
        "DataContext": {
          "Company": {"Code": "company_code"},
          "EventType": {"Code": "ADD|EDT"},
          "EventReference": "event_reference",
          "TriggerDate": "iso_date_time"
        },
        "Branch": {"Code": "branch_code"},
        "Department": {"Code": "department_code"},
        "Oscurrency": {"Code": "currency_code"},
        "OrganizationAddress": {"OrganizationCode": "org_code"},
        "ShipmentCollection": {
          "Shipment": [{
            "DataContext": {
              "DataSourceCollection": {
                "DataSource": [
                  {"Type": "ForwardingShipment", "Key": "shipment_id"},
                  {"Type": "ForwardingConsol", "Key": "consol_no"}
                ]
              }
            },
            "JobCosting": {
              "ChargeLineCollection": {
                "ChargeLine": [
                  {
                    "ChargeCode": {"Code": "charge_code"},
                    "SellReference": "buyer_code",
                    "DisplaySequence": number,
                    "CostOSAmount": "amount",
                    "SellOSAmount": "amount",
                    "CostOSGSTVATAmount": "vat_amount",
                    "SellOSGSTVATAmount": "vat_amount"
                  }
                ]
              }
            }
          }]
        },
        "OriginalReference": {
          "OriginalTransactionNumber": "original_transaction_no"
        },
        "PostingJournalCollection": {
          "PostingJournal": [{
            "ChargeCode": {"Code": "charge_code"},
            "Sequence": number,
            "VattaxID": {
              "TaxCode": "tax_code",
              "TaxRate": number
            }
          }]
        }
      }
    }
  }
}
```

## Output Data Structure: TransactionInfoRequestBean
The target data structure contains the following fields:

```java
public class TransactionInfoRequestBean {
    private String billNo;           // Transaction number
    private String transactionType;  // INV, CRD, etc.
    private String billDate;         // Transaction date
    private String companyCode;      // Company code
    private String branchCode;       // Branch code
    private String departmentCode;   // Department code
    private String currency;         // Currency code
    private String shipmentId;       // Shipment ID
    private String consolNo;         // Consol number
    private String debiterCode;      // Organization code
    private String debiterName;      // Organization name (from DB)
    private String buyerCode;        // Buyer code (AR only)
    private String buyerName;        // Buyer name (AR only, from DB)
    private String buyerTaxNo;       // Buyer tax number (AR only, from DB)
    private String buyerAddr;        // Buyer address (AR only, from DB)
    private String buyerTel;         // Buyer telephone (AR only, from DB)
    private String buyerBankName;    // Buyer bank name (AR only, from DB)
    private String buyerBankAccount; // Buyer bank account (AR only, from DB)
    private String buyerEmail;       // Buyer email (AR only, from DB)
    private int taxRate;             // Tax rate
    private String oldBillNo;        // Original transaction number (for reversals)
    private String oldBillType;      // Original transaction type (for reversals)
}
```

## Field Mapping Details

### Direct JSON Path Mappings
The following fields are directly mapped from the JSON using JsonPath:

| TransactionInfoRequestBean Field | JSON Path | Code Line |
|----------------------------------|-----------|-----------|
| billNo | `$.Number` | 298 |
| transactionType | `$.TransactionType` | 299 |
| billDate | `$.TransactionDate` | 300 |
| companyCode | `$.DataContext.Company.Code` | 301 |
| branchCode | `$.Branch.Code` | 302 |
| departmentCode | `$.Department.Code` | 303 |
| currency | `$.Oscurrency.Code` | 304 |
| shipmentId | `$.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key` | 306-309 |
| consolNo | `$.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key` | 310-313 |
| debiterCode | `$.OrganizationAddress.OrganizationCode` | 314 |
| buyerCode | `$..SellReference` (AR only) | 328-331 |
| oldBillNo | `$.OriginalReference.OriginalTransactionNumber` (for reversals) | 386 |

### Database-Derived Fields
The following fields are populated by querying the database:

| Field | Method | Description |
|-------|--------|-------------|
| debiterName | `getDebiterName()` | Queries `cw_org_header` table for organization name |
| buyerName | `getBuyerOrgInfo()` | Queries `cw_org_address` table for buyer company name |
| buyerTaxNo | `getBuyerTaxNo()` | Queries `cw_org_cus_code` table for VAT number |
| buyerAddr | `getBuyerOrgInfo()` | Combines addr1 and addr2 from `cw_org_address` |
| buyerTel | `getBuyerOrgInfo()` | Queries `cw_org_address` table for phone |
| buyerEmail | `getBuyerOrgInfo()` | Queries `cw_org_address` table for email |
| buyerBankName | `getBuyerBankInfo()` | Queries Cargowise `AccAPAccountDetails` table |
| buyerBankAccount | `getBuyerBankInfo()` | Queries Cargowise `AccAPAccountDetails` table |
| oldBillType | `getOldBillType()` | Queries `at_account_transaction_header` table |

### Conditional Logic

#### AR vs AP Processing
- **AR (Accounts Receivable)**: Requires buyer information, tax codes, and posting journal data
- **AP (Accounts Payable)**: Simpler processing, no buyer information required

#### Event Type Handling
- **ADD Events**: Normal processing
- **EDT Events**: Update processing with trigger date validation
- **Reversed Transactions**: Special handling for `AR|CRD|Reversed`, `AR|INV|Reversed`, `AP|CRD|Reversed`, `AP|INV|Reversed`

#### Transaction Type Specific Logic
- **INV (Invoice)**: Standard invoice processing
- **CRD (Credit Note)**: Credit note processing with original reference lookup
- **Reversed**: Uses `OriginalTransactionNumber` and reverses transaction type

## Amount Field Processing
The implementation handles different amount fields based on ledger type:

### AP (Accounts Payable) Amount Fields
- `JSON_PATH_CHARGELINE_OSAMOUNT`: `$.CostOSAmount`
- `JSON_PATH_CHARGELINE_OSGSTVATAMOUNT`: `$.CostOSGSTVATAmount`
- `JSON_PATH_CHARGELINE_LOCALAMOUNT`: `$.CostLocalAmount`
- `JSON_PATH_CHARGELINE_OSCURRENCY_CODE`: `$.CostOSCurrency.Code`
- `JSON_PATH_CHARGELINE_EXCHANGE_RATE`: `$.CostExchangeRate`

### AR (Accounts Receivable) Amount Fields
- `JSON_PATH_CHARGELINE_OSAMOUNT`: `$.SellOSAmount`
- `JSON_PATH_CHARGELINE_OSGSTVATAMOUNT`: `$.SellOSGSTVATAmount`
- `JSON_PATH_CHARGELINE_LOCALAMOUNT`: `$.SellLocalAmount`
- `JSON_PATH_CHARGELINE_OSCURRENCY_CODE`: `$.SellOSCurrency.Code`
- `JSON_PATH_CHARGELINE_EXCHANGE_RATE`: `$.SellExchangeRate`

## Tax Rate Processing
For AR transactions, tax rates are extracted from the `PostingJournalCollection` structure and matched with charge lines based on `ChargeCode` and `DisplaySequence`.

## Error Handling
The implementation includes comprehensive error handling for:
- Missing SellReference for AR transactions (`SellReferenceNotFoundException`)
- Missing debiter name (`DebiterNameNotFoundException`)
- Missing Cargowise transaction header (`CwAccountTransactionHeaderNotFoundException`)
- Unsupported transaction types (`NotSupportedTransactionException`)

## Key Processing Methods

### `generateRequestBeanRaw()`
Main method that orchestrates the JSON to bean mapping process:
1. Parses the JSON structure
2. Extracts TransactionInfo
3. Maps basic fields
4. Handles AR-specific buyer information
5. Processes charge lines and amounts
6. Saves to database

### `handleChargeLineInShipment()`
Processes charge lines within shipment structures:
- Handles both shipment and consol scenarios
- Matches charge lines with Cargowise data
- Creates transaction line beans
- Supports recursive processing for sub-shipments

## Database Integration
The mapping process integrates with multiple database sources:
- **SOPL Database**: Application-specific data storage
- **Cargowise Database**: ERP system integration
- **Dual Database Support**: PostgreSQL (SOPL) and SQL Server (Cargowise)

## Conclusion
The TransactionServiceImpl provides a comprehensive mapping system that transforms complex UniversalTransaction JSON structures into standardized TransactionInfoRequestBean objects for external system integration. The implementation handles various transaction types, ledger differences, and complex business rules while maintaining data integrity and error handling.