```
How to use Java 21's record type like following example code? I mean, populate attribute or retrieve attribute and more.
---
public record DataRecord(String id, Map<String, Object> attributes) {}
---
```

Okay, let's break down how to use your `DataRecord` in Java 21.

Java records provide a concise syntax for declaring classes that are primarily simple, immutable data carriers. When you declare a record like yours:

```java
import java.util.Map;
import java.util.HashMap; // Needed for examples
import java.util.Objects; // Needed for compact constructor example

public record DataRecord(String id, Map<String, Object> attributes) {
    // Optional: You can add constructors, methods, etc. here
}
```

The Java compiler automatically generates several things for you:

1.  **Private `final` fields** for each component (`id` and `attributes`).
2.  A **canonical constructor** whose signature matches the record declaration (e.g., `public DataRecord(String id, Map<String, Object> attributes)`). This constructor initializes the fields.
3.  **Public accessor methods** for each component. These methods have the same name as the component (e.g., `public String id()` and `public Map<String, Object> attributes()`). Note: they don't follow the `get...` JavaBean convention.
4.  Implementations of **`equals()`**, **`hashCode()`**, and **`toString()`** based on the state of *all* components.

Here's how you typically interact with it:

**1. Creating Instances ("Populating")**

You use the automatically generated canonical constructor:

```java
import java.util.Map;
import java.util.HashMap;

public class RecordExample {
    public static void main(String[] args) {
        // Create a map for the attributes
        Map<String, Object> initialAttributes = new HashMap<>();
        initialAttributes.put("name", "Example Item");
        initialAttributes.put("value", 123);
        initialAttributes.put("active", true);

        // Create an instance of DataRecord using the constructor
        DataRecord record1 = new DataRecord("item-001", initialAttributes);

        // You can also create one with an empty map
        DataRecord record2 = new DataRecord("item-002", new HashMap<>());

        // Or using Map.of for an immutable map (often preferred)
        DataRecord record3 = new DataRecord("item-003", Map.of(
            "name", "Immutable Item",
            "status", "Pending"
        ));

        System.out.println(record1); // Uses the auto-generated toString()
        System.out.println(record2);
        System.out.println(record3);
    }
}
```

**Output:**

```
DataRecord[id=item-001, attributes={name=Example Item, active=true, value=123}]
DataRecord[id=item-002, attributes={}]
DataRecord[id=item-003, attributes={name=Immutable Item, status=Pending}]
```

**2. Retrieving Attributes**

You use the automatically generated accessor methods:

```java
import java.util.Map;
import java.util.HashMap;

public class RecordExample {
    public static void main(String[] args) {
        DataRecord record1 = new DataRecord("item-001", Map.of(
            "name", "Example Item",
            "value", 123
        ));

        // Retrieve the id
        String theId = record1.id();
        System.out.println("Retrieved ID: " + theId); // Output: Retrieved ID: item-001

        // Retrieve the attributes map
        Map<String, Object> theAttributes = record1.attributes();
        System.out.println("Retrieved Attributes: " + theAttributes); // Output: Retrieved Attributes: {name=Example Item, value=123}

        // Access values within the retrieved map
        String name = (String) theAttributes.get("name");
        Integer value = (Integer) theAttributes.get("value");
        System.out.println("Name from map: " + name);   // Output: Name from map: Example Item
        System.out.println("Value from map: " + value); // Output: Value from map: 123
    }
}
```

**3. Immutability Considerations (Important!)**

Records themselves are *shallowly immutable*. This means the references stored in the record's fields (`id` and the reference to the `attributes` map) cannot be changed after the record is created.

However, if the object referenced by a field is *mutable* (like a standard `HashMap`), its internal state *can* be changed.

```java
import java.util.Map;
import java.util.HashMap;

public class RecordMutabilityExample {
    public static void main(String[] args) {
        // Use a mutable HashMap
        Map<String, Object> mutableAttrs = new HashMap<>();
        mutableAttrs.put("status", "Initial");

        DataRecord recordWithMutableMap = new DataRecord("mutable-01", mutableAttrs);
        System.out.println("Before change: " + recordWithMutableMap);

        // Get the map reference
        Map<String, Object> retrievedMap = recordWithMutableMap.attributes();

        // !!! Modify the map *after* it was put into the record !!!
        retrievedMap.put("status", "Modified");
        retrievedMap.put("newKey", "newValue");

        // The record instance now reflects the changes in the map it points to
        System.out.println("After change:  " + recordWithMutableMap);
        System.out.println("Original map reference also changed: " + mutableAttrs);

        // You CANNOT do this (reassign the field):
        // recordWithMutableMap.attributes = new HashMap<>(); // Compile-time error
    }
}
```

**Output:**

```
Before change: DataRecord[id=mutable-01, attributes={status=Initial}]
After change:  DataRecord[id=mutable-01, attributes={newKey=newValue, status=Modified}]
Original map reference also changed: {newKey=newValue, status=Modified}
```

**To achieve deeper immutability**, ensure that the objects you pass into the record's constructor are themselves immutable. For the map, you can use `Map.copyOf()` (introduced in Java 10) either when creating the record or inside a custom constructor:

```java
import java.util.Map;
import java.util.HashMap;

public class ImmutableRecordExample {
    public static void main(String[] args) {
        Map<String, Object> sourceMap = new HashMap<>();
        sourceMap.put("color", "blue");

        // Create the record with an immutable copy of the map
        DataRecord trulyImmutableRecord = new DataRecord("immutable-01", Map.copyOf(sourceMap));

        System.out.println("Record: " + trulyImmutableRecord);

        // Try to modify the original map - this won't affect the record
        sourceMap.put("size", "large");
        System.out.println("Record after modifying original map: " + trulyImmutableRecord);
        System.out.println("Original map: " + sourceMap);

        // Try to modify the map retrieved from the record - this will fail
        try {
            Map<String, Object> attrsFromRecord = trulyImmutableRecord.attributes();
            attrsFromRecord.put("shape", "circle"); // Throws UnsupportedOperationException
        } catch (UnsupportedOperationException e) {
            System.out.println("Caught expected exception: " + e.getMessage());
        }
    }
}
```

**Output:**

```
Record: DataRecord[id=immutable-01, attributes={color=blue}]
Record after modifying original map: DataRecord[id=immutable-01, attributes={color=blue}]
Original map: {color=blue, size=large}
Caught expected exception: null // (Or a more specific message depending on JVM)
```

**4. Adding Custom Logic (Optional)**

You can add validation or normalization logic using a **compact constructor**. You can also add regular instance methods.

```java
import java.util.Map;
import java.util.Objects;

public record DataRecord(String id, Map<String, Object> attributes) {

    // Compact Constructor for validation/normalization
    // Runs *before* the canonical constructor assigns fields
    public DataRecord { // Note: No parameter list!
        Objects.requireNonNull(id, "id cannot be null");
        // Ensure attributes map is non-null and store an immutable copy
        attributes = (attributes == null) ? Map.of() : Map.copyOf(attributes);
    }

    // Example instance method
    public boolean hasAttribute(String key) {
        return this.attributes.containsKey(key);
    }

    // You can also add static methods or non-canonical constructors
    // (which must delegate to the canonical constructor using this(...))
    public static DataRecord createEmpty(String id) {
        return new DataRecord(id, Map.of()); // Delegates to canonical constructor
    }
}

// --- Usage ---
import java.util.Map;
import java.util.HashMap;

public class CustomRecordExample {
     public static void main(String[] args) {
        // Using the compact constructor's logic
        DataRecord r1 = new DataRecord("valid-id", Map.of("a", 1));
        System.out.println("R1 created: " + r1);

        DataRecord r2 = DataRecord.createEmpty("empty-attrs");
        System.out.println("R2 created via static factory: " + r2);

        System.out.println("R1 has attribute 'a'? " + r1.hasAttribute("a")); // true
        System.out.println("R1 has attribute 'b'? " + r1.hasAttribute("b")); // false

        try {
             DataRecord rNullId = new DataRecord(null, Map.of()); // Throws NullPointerException due to compact constructor
        } catch(NullPointerException e) {
             System.out.println("Caught expected validation error: " + e.getMessage());
        }

        // Example showing immutable copy feature of compact constructor
        Map<String, Object> originalMap = new HashMap<>();
        originalMap.put("key", "value");
        DataRecord r3 = new DataRecord("copy-test", originalMap);
        originalMap.put("anotherKey", "anotherValue"); // Modify original map

        System.out.println("R3 (should not have 'anotherKey'): " + r3);
        System.out.println("Original map (should have 'anotherKey'): " + originalMap);
     }
}
```

**Output:**

```
R1 created: DataRecord[id=valid-id, attributes={a=1}]
R2 created via static factory: DataRecord[id=empty-attrs, attributes={}]
R1 has attribute 'a'? true
R1 has attribute 'b'? false
Caught expected validation error: id cannot be null
R3 (should not have 'anotherKey'): DataRecord[id=copy-test, attributes={key=value}]
Original map (should have 'anotherKey'): {key=value, anotherKey=anotherValue}
```

In summary, you create `DataRecord` instances using `new DataRecord(...)`, retrieve values using `recordInstance.id()` and `recordInstance.attributes()`, and should be mindful of the mutability of the objects stored within the record, especially collections like `Map`. Using immutable collections like those from `Map.copyOf()` or `Map.of()` is generally recommended when creating records for true immutability.

```
Show me more examples like using record object to capture the result of database fetch query SQL.
```

Okay, using Java records to capture the results of database queries is a very common and practical use case. Records are excellent Data Transfer Objects (DTOs) because they are simple, immutable carriers for data, matching well with the row structure returned by SQL queries.

Let's imagine you have a database table like this:

**Table: `users`**

| Column Name | SQL Type        | Java Type Equivalent        |
| :---------- | :-------------- | :-------------------------- |
| `user_id`   | `VARCHAR(50)`   | `String`                    |
| `username`  | `VARCHAR(100)`  | `String`                    |
| `email`     | `VARCHAR(255)`  | `String`                    |
| `is_active` | `BOOLEAN` / `BIT` | `boolean`                   |
| `created_at`| `TIMESTAMP`     | `java.time.LocalDateTime` |

**Goal:** Fetch user data and map each row to a `UserRecord` object.

**1. Define the Record**

First, define a record whose components match the columns you want to retrieve. The names don't *have* to match exactly, but it often makes the mapping code clearer if they do (or follow a consistent convention like snake_case in SQL to camelCase in Java).

```java
import java.time.LocalDateTime;

public record UserRecord(
    String userId,      // Maps to user_id
    String username,    // Maps to username
    String email,       // Maps to email
    boolean isActive,   // Maps to is_active
    LocalDateTime createdAt // Maps to created_at
) {
    // No extra methods needed for simple data holding
}
```

**2. Fetch Data using JDBC and Populate Records**

Here's an example using standard JDBC. This demonstrates the manual mapping process.

```java
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    // Assume you get a connection from a connection pool or DriverManager
    private Connection getConnection() throws SQLException {
        // --- Placeholder: Replace with your actual connection logic ---
        // Example using H2 in-memory database (add H2 dependency for this)
        // String url = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1";
        // String user = "sa";
        // String password = "";
        // return DriverManager.getConnection(url, user, password);

        // For the example, we'll return null and handle it,
        // but in a real app, you'd connect properly.
        System.err.println("WARNING: Database connection logic is missing.");
        // You would typically get this from a DataSource
         throw new SQLException("Database connection not configured.");
        // return null; // Or throw exception
    }

    // --- Helper to set up dummy data (for runnable example without real DB) ---
    public void setupDummyData() {
         String createTableSQL = """
            CREATE TABLE IF NOT EXISTS users (
                user_id VARCHAR(50) PRIMARY KEY,
                username VARCHAR(100),
                email VARCHAR(255),
                is_active BOOLEAN,
                created_at TIMESTAMP
            );
            """;
         String insertSQL = """
            MERGE INTO users KEY(user_id) VALUES
            ('usr-101', 'alice', 'alice@example.com', true, '2025-04-20 10:00:00'),
            ('usr-102', 'bob', 'bob@example.com', false, '2025-04-21 11:30:00'),
            ('usr-103', 'charlie', 'charlie@example.com', true, '2025-04-22 15:45:00');
            """;
         try (Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "");
              Statement stmt = conn.createStatement()) {
             stmt.execute(createTableSQL);
             stmt.execute(insertSQL);
             System.out.println("Dummy data set up.");
         } catch (SQLException e) {
            System.err.println("Failed to set up dummy data: " + e.getMessage());
         }
    }


    public List<UserRecord> findActiveUsers() {
        List<UserRecord> activeUsers = new ArrayList<>();
        // Use aliases if column names differ significantly from record component names
        String sql = "SELECT user_id, username, email, is_active, created_at FROM users WHERE is_active = ?";

        // Use try-with-resources to ensure connection, statement, and resultset are closed
        // --- Replace with your actual connection source ---
        try (Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setBoolean(1, true); // Set the parameter for the WHERE clause

            try (ResultSet rs = pstmt.executeQuery()) {
                // Iterate through the results
                while (rs.next()) {
                    // Extract data from the current row
                    String userId = rs.getString("user_id");
                    String username = rs.getString("username");
                    String email = rs.getString("email");
                    boolean isActive = rs.getBoolean("is_active");
                    // For timestamps, use getObject for modern Java Time types
                    LocalDateTime createdAt = rs.getObject("created_at", LocalDateTime.class);

                    // *** Create the UserRecord instance ***
                    UserRecord user = new UserRecord(userId, username, email, isActive, createdAt);

                    // Add the record to the list
                    activeUsers.add(user);
                }
            } // ResultSet automatically closed here

        } catch (SQLException e) {
            // Handle exceptions appropriately (log, wrap, rethrow)
            System.err.println("Database error fetching active users: " + e.getMessage());
            // In a real app, you might throw a custom exception
        } // PreparedStatement and Connection automatically closed here

        return activeUsers;
    }

    public static void main(String[] args) {
        UserRepository repository = new UserRepository();

        // --- Setup H2 DB and Data (only needed for this runnable demo) ---
         try {
             // Make sure H2 driver is loaded (needed for DriverManager approach)
             Class.forName("org.h2.Driver");
         } catch (ClassNotFoundException e) {
            System.err.println("H2 Driver not found. Please add H2 dependency.");
            return;
         }
        repository.setupDummyData();
        // --- End Setup ---


        List<UserRecord> users = repository.findActiveUsers();

        if (users.isEmpty()) {
            System.out.println("No active users found or database error occurred.");
        } else {
            System.out.println("Found Active Users:");
            users.forEach(user -> {
                System.out.printf("  ID: %s, Username: %s, Email: %s, Active: %b, Created: %s%n",
                        user.userId(),
                        user.username(),
                        user.email(),
                        user.isActive(),
                        user.createdAt()
                );
            });
        }
    }
}
```

**Explanation:**

1.  **SQL Query:** Selects the specific columns needed for the `UserRecord`. Using `SELECT *` is generally discouraged in applications as it can fetch unnecessary data and break if the table schema changes.
2.  **JDBC Boilerplate:** Standard JDBC code to get a connection, prepare a statement, execute the query, and get a `ResultSet`. `try-with-resources` is crucial for proper resource management.
3.  **`ResultSet` Iteration:** The `while (rs.next())` loop moves through each row returned by the query.
4.  **Data Extraction:** Inside the loop, `rs.getString()`, `rs.getBoolean()`, `rs.getObject(..., LocalDateTime.class)` etc., are used to pull data from the current row, referencing columns by their names (or index, though names are usually preferred for readability).
5.  **Record Instantiation:** The core part: `new UserRecord(userId, username, email, isActive, createdAt)` creates an immutable `UserRecord` instance using the data extracted from the current row.
6.  **Collection:** The newly created record is added to the `activeUsers` list.
7.  **Type Mapping:** Be mindful of mapping SQL types to appropriate Java types (e.g., `VARCHAR` -> `String`, `BOOLEAN` -> `boolean`, `TIMESTAMP` -> `LocalDateTime`). JDBC drivers handle much of this, but using `getObject(..., Class)` is often the cleanest way for newer types like `java.time`.

**Benefits of using Records here:**

* **Conciseness:** The `UserRecord` definition is minimal compared to a traditional class with private fields, constructor, getters, `equals`, `hashCode`, and `toString`.
* **Immutability:** Records are inherently immutable, which is great for representing data snapshots like query results. You know the data won't change unexpectedly after being fetched.
* **Readability:** Clearly expresses the structure of the data being transferred.
* **Type Safety:** You get compile-time checking for the data types within your Java code.

**Alternative (Higher-Level Frameworks):**

Frameworks like Spring Data JDBC, jOOQ, or JPA often provide abstractions that automatically map `ResultSet` rows to records (or classes) with less manual code, sometimes using reflection or code generation. However, the underlying principle remains the same: map columns from a row to the components of a record. The JDBC example shows the fundamental process clearly.