
```mermaid
sequenceDiagram
    participant Client
    participant APIGateway
    participant MicrosoftEntraID
    participant APQueryAPI

    Client->>APIGateway: POST /cpar-api/compliance/v1/complianceAP
    alt Token expired or no token
        APIGateway-->>Client: return 401 Unauthorized
        Client->>APIGateway: GET /rest/login
        APIGateway->>MicrosoftEntraID: redirect to login
        MicrosoftEntraID->>MicrosoftEntraID: complete login
        MicrosoftEntraID-->>Client: 301 /acs
        Client->>APIGateway: GET /acs
        APIGateway-->>Client: 301 /auth
        Client->>APIGateway: GET /auth?secrect=...
        APIGateway-->>Client: return
        Client->>APIGateway: POST /rest/login
        APIGateway-->>Client: return token
        Client->>APIGateway: POST /cpar-api/compliance/v1/complianceAP
    else Token in cache and valid

    end
    APIGateway->>APQueryAPI: POST /cpar-api/compliance/v1/complianceAP
    APQueryAPI-->>Client: ComplianceAPResponse
```