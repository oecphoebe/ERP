-- Minimal SQL Server test schema for APInvoiceAS20250818_2IntegrationTest
-- Only includes tables needed for the specific test case

-- AccTransactionHeader table
CREATE TABLE AccTransactionHeader (
    AH_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    AH_Ledger NCHAR(2) NOT NULL,
    AH_TransactionType NCHAR(3) NOT NULL,
    AH_TransactionNum NVARCHAR(38) NOT NULL,
    AH_TransactionCount TINYINT DEFAULT 1 NOT NULL,
    AH_TransactionReference NVARCHAR(20) DEFAULT '' NOT NULL,
    AH_Desc NVARCHAR(128) DEFAULT '' NOT NULL,
    AH_InvoiceDate DATETIME2 NOT NULL,
    AH_TransactionCategory NVARCHAR(3) DEFAULT '' NOT NULL,
    AH_DueDate DATETIME2,
    AH_InvoiceAmount MONEY DEFAULT 0 NOT NULL,
    AH_GSTAmount MONEY DEFAULT 0 NOT NULL,
    AH_WithholdingTax MONEY DEFAULT 0 NOT NULL,
    AH_OSTotal MONEY DEFAULT 0 NOT NULL,
    AH_ExchangeRate DECIMAL(18,9) DEFAULT 1 NOT NULL,
    AH_AgePeriod INT DEFAULT 0 NOT NULL,
    AH_PostPeriod INT DEFAULT 0 NOT NULL,
    AH_PostDate DATETIME2,
    AH_ReceiptType NCHAR(3) DEFAULT '' NOT NULL,
    AH_OutstandingAmount MONEY DEFAULT 0 NOT NULL,
    AH_PostToGL NCHAR(1) DEFAULT 'N' NOT NULL,
    AH_InvoiceTerm NVARCHAR(3) DEFAULT '' NOT NULL,
    AH_InvoiceTermDays INT DEFAULT 0 NOT NULL,
    AH_ExportBatchNumber INT DEFAULT 0 NOT NULL,
    AH_OH UNIQUEIDENTIFIER,
    AH_JH UNIQUEIDENTIFIER,
    AH_GB UNIQUEIDENTIFIER,
    AH_GE UNIQUEIDENTIFIER,
    AH_GC UNIQUEIDENTIFIER NOT NULL,
    AH_RX_NKTransactionCurrency NCHAR(3),
    AH_SystemCreateTimeUtc DATETIME2 NOT NULL,
    AH_SystemCreateUser NVARCHAR(3) NOT NULL,
    AH_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    AH_SystemLastEditUser NVARCHAR(3) NOT NULL,
    AH_IsCancelled BIT DEFAULT 0 NOT NULL
);

-- AccTransactionLines table
CREATE TABLE AccTransactionLines (
    AL_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    AL_LineType NCHAR(3) NOT NULL,
    AL_Sequence INT NOT NULL,
    AL_Desc NVARCHAR(128) NOT NULL,
    AL_LineAmount MONEY NOT NULL,
    AL_GSTVAT MONEY DEFAULT 0 NOT NULL,
    AL_WithholdingTax MONEY DEFAULT 0 NOT NULL,
    AL_UnitQty INT DEFAULT 0 NOT NULL,
    AL_UnitPrice MONEY DEFAULT 0 NOT NULL,
    AL_OSUnitPrice MONEY DEFAULT 0 NOT NULL,
    AL_OSAmount MONEY NOT NULL,
    AL_ExchangeRate DECIMAL(18,9) NOT NULL,
    AL_PostPeriod INT DEFAULT 0 NOT NULL,
    AL_PostDate DATETIME2 NOT NULL,
    AL_PostToGL NCHAR(1) DEFAULT 'N' NOT NULL,
    AL_AH UNIQUEIDENTIFIER NOT NULL,
    AL_JH UNIQUEIDENTIFIER,
    AL_AC UNIQUEIDENTIFIER NOT NULL,
    AL_GE UNIQUEIDENTIFIER,
    AL_GB UNIQUEIDENTIFIER,
    AL_OH UNIQUEIDENTIFIER,
    AL_RX_NKTransactionCurrency NCHAR(3),
    AL_RevRecognitionType NVARCHAR(3) DEFAULT '' NOT NULL,
    AL_GC UNIQUEIDENTIFIER,
    AL_SystemCreateTimeUtc DATETIME2 NOT NULL,
    AL_SystemCreateUser NVARCHAR(3) NOT NULL,
    AL_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    AL_SystemLastEditUser NVARCHAR(3) NOT NULL,
    AL_InputGSTVATRecoverable DECIMAL(5,4) DEFAULT 1 NOT NULL
);

-- JobHeader table
CREATE TABLE JobHeader (
    JH_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    JH_JobNum NVARCHAR(15) NOT NULL,
    JH_Status NCHAR(3) NOT NULL,
    JH_ParentID UNIQUEIDENTIFIER,
    JH_HeaderType NVARCHAR(10) DEFAULT 'JOB' NOT NULL,
    JH_Name NVARCHAR(50) DEFAULT '' NOT NULL,
    JH_Description NVARCHAR(100) DEFAULT '' NOT NULL,
    JH_JobLocalReference NVARCHAR(50) DEFAULT '' NOT NULL,
    JH_ARInvoiceReference NVARCHAR(50) DEFAULT '' NOT NULL,
    JH_IsActive BIT DEFAULT 1 NOT NULL,
    JH_ParentTableCode NCHAR(2),
    JH_SystemCreateTimeUtc DATETIME2 NOT NULL,
    JH_SystemCreateUser NVARCHAR(3) NOT NULL,
    JH_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    JH_SystemLastEditUser NVARCHAR(3) NOT NULL,
    JH_GB UNIQUEIDENTIFIER,
    JH_GE UNIQUEIDENTIFIER,
    JH_GC UNIQUEIDENTIFIER
);

-- JobShipment table
CREATE TABLE JobShipment (
    JS_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    JS_ShipmentStatus NCHAR(3) NOT NULL,
    JS_UniqueConsignRef NVARCHAR(15) NOT NULL,
    JS_InterimReceipt NVARCHAR(50) DEFAULT '' NOT NULL,
    JS_HouseBill NVARCHAR(35) DEFAULT '' NOT NULL,
    JS_BookingReference NVARCHAR(35) DEFAULT '' NOT NULL,
    JS_GoodsDescription NVARCHAR(500) DEFAULT '' NOT NULL,
    JS_TransportMode NCHAR(3) NOT NULL,
    JS_PackingMode NCHAR(3) NOT NULL,
    JS_ActualVolume DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_DocumentedVolume DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_ManifestedVolume DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_UnitOfVolume NCHAR(3),
    JS_ActualWeight DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_DocumentedWeight DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_ManifestedWeight DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JS_UnitOfWeight NCHAR(3),
    JS_TotalPackageCount INT DEFAULT 0 NOT NULL,
    JS_OuterPacks INT DEFAULT 0 NOT NULL,
    JS_SystemCreateTimeUtc DATETIME2 NOT NULL,
    JS_SystemCreateUser NVARCHAR(3) NOT NULL,
    JS_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    JS_SystemLastEditUser NVARCHAR(3) NOT NULL,
    JS_IsValid BIT DEFAULT 1 NOT NULL,
    JS_JS_ColoadMasterShipment UNIQUEIDENTIFIER,
    JS_E_DEP DATETIME2
);

-- OrgHeader table
CREATE TABLE OrgHeader (
    OH_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    OH_Code NVARCHAR(10) NOT NULL,
    OH_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    OH_SystemLastEditUser NVARCHAR(3) NOT NULL,
    OH_SystemCreateTimeUtc DATETIME2 NOT NULL,
    OH_SystemCreateUser NVARCHAR(3) NOT NULL,
    OH_IsActive BIT DEFAULT 1 NOT NULL,
    OH_IsValid BIT DEFAULT 1 NOT NULL,
    OH_FullName NVARCHAR(150) NOT NULL
);

-- AccChargeCode table (uppercase table name but can be accessed as lowercase due to collation)
CREATE TABLE AccChargeCode (
    AC_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    AC_Code NVARCHAR(10) NOT NULL,
    AC_Desc NVARCHAR(100),
    AC_LocalLanguageDescription NVARCHAR(100) DEFAULT '',
    AC_ChargeType NVARCHAR(10),
    AC_MarginPercentage DECIMAL(5,2) DEFAULT 0,
    AC_AW_WithholdingTaxRate UNIQUEIDENTIFIER,
    AC_AT_GSTRate UNIQUEIDENTIFIER,
    AC_AG_RevenueAccount UNIQUEIDENTIFIER,
    AC_AG_WIPAccount UNIQUEIDENTIFIER,
    AC_AG_CostAccount UNIQUEIDENTIFIER,
    AC_AG_AccrualAccount UNIQUEIDENTIFIER,
    AC_PrintSequence INT DEFAULT 1,
    AC_AR_SalesGroup UNIQUEIDENTIFIER,
    AC_AR_ExpenseGroup UNIQUEIDENTIFIER,
    AC_ChargeGroup NVARCHAR(10),
    AC_ChargeSubGroup NVARCHAR(10),
    AC_RateCalculator NVARCHAR(10),
    AC_DepartmentFilterList NVARCHAR(10),
    AC_IATA_ChargeCodeMap NVARCHAR(10),
    AC_GC UNIQUEIDENTIFIER,
    AC_ENettChargeCodeMap NVARCHAR(10),
    AC_GoodsServiceType NVARCHAR(10),
    AC_ChargeOtherGroups NVARCHAR(10),
    AC_AX_TaxOverrideGroup UNIQUEIDENTIFIER,
    AC_IsActive BIT DEFAULT 1 NOT NULL,
    AC_IsGroupageCharge BIT DEFAULT 0,
    AC_ShowOnQuotation BIT DEFAULT 1,
    AC_SuppressOnQuoteIfZero BIT DEFAULT 1,
    AC_AllowDescriptionOvertype BIT DEFAULT 1,
    AC_IsCommissionable BIT DEFAULT 1,
    AC_InputGSTVATRecoverable DECIMAL(5,4) DEFAULT 1.0000,
    AC_EnergySourceGroup NVARCHAR(10),
    AC_DefaultCommissionProduct NVARCHAR(10),
    AC_DefaultCommissionService NVARCHAR(10),
    AC_DefaultCommissionSubModule NVARCHAR(10),
    AC_AC_RevenueChargeCode UNIQUEIDENTIFIER,
    AC_GovtChargeCode NVARCHAR(10),
    AC_IsAdhocServiceCharge BIT DEFAULT 0,
    AC_AG_CostClearingAccount UNIQUEIDENTIFIER,
    AC_AG_RevenueClearingAccount UNIQUEIDENTIFIER,
    AC_AutoVersion INT DEFAULT 1,
    AC_AG_DisbursementShortfallAccount UNIQUEIDENTIFIER,
    AC_AG_DisbursementSurplusAccount UNIQUEIDENTIFIER,
    AC_SystemCreateTimeUtc DATETIME2 NOT NULL,
    AC_SystemCreateUser NVARCHAR(3) NOT NULL,
    AC_SystemLastEditTimeUtc DATETIME2 NOT NULL,
    AC_SystemLastEditUser NVARCHAR(3) NOT NULL
);

-- JobCharge table (lowercase as expected by queries)
CREATE TABLE JobCharge (
    jr_pk UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    JR_JH UNIQUEIDENTIFIER NOT NULL,
    jr_ac UNIQUEIDENTIFIER NOT NULL,
    jr_e6 UNIQUEIDENTIFIER, -- NULL for SHIPMENT, NOT NULL for CONSOL
    JR_APInvoiceNum NVARCHAR(38),
    jr_desc NVARCHAR(128),
    jr_oscostamt MONEY DEFAULT 0,
    jr_ossellamt MONEY DEFAULT 0,
    jr_exchangerate DECIMAL(18,9) DEFAULT 1,
    jr_paymentdate DATETIME2,
    jr_systemcreatetime DATETIME2 NOT NULL,
    jr_systemcreateuser NVARCHAR(3) NOT NULL,
    jr_systemlastedittimeutc DATETIME2 NOT NULL,
    jr_systemlastedituser NVARCHAR(3) NOT NULL
);

-- JobConShipLink table (for linking JobConsol and JobShipment)
CREATE TABLE JobConShipLink (
    JN_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    JN_JK UNIQUEIDENTIFIER NOT NULL,  -- Reference to JobConsol
    JN_JS UNIQUEIDENTIFIER NOT NULL   -- Reference to JobShipment
);

-- jobconsoltransport table (lowercase as expected by queries)
CREATE TABLE jobconsoltransport (
    jw_pk UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    jw_parentguid UNIQUEIDENTIFIER NOT NULL,
    jw_legorder INT NOT NULL,
    jw_vessel NVARCHAR(35) DEFAULT '' NOT NULL,
    jw_voyageflight NVARCHAR(35) DEFAULT '' NOT NULL,
    JW_ETD DATETIME2,
    JW_ATD DATETIME2,
    JW_ATA DATETIME2
);

-- jobconsolcost table (lowercase as expected by queries)
CREATE TABLE jobconsolcost (
    e6_pk UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    e6_ah_apinvoice UNIQUEIDENTIFIER,
    e6_parentid UNIQUEIDENTIFIER,
    e6_ac_chargecode UNIQUEIDENTIFIER
);

-- jobconsol table (lowercase as expected by queries) 
CREATE TABLE jobconsol (
    jk_pk UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    jk_uniqueconsignref NVARCHAR(15) NOT NULL,
    jk_masterbillnum NVARCHAR(35) DEFAULT '' NOT NULL,
    jk_bookingreference NVARCHAR(35) DEFAULT '' NOT NULL,
    JK_CoLoadMasterBill NVARCHAR(35) DEFAULT '' NOT NULL,
    JK_AgentType NCHAR(3) DEFAULT 'AGT' NOT NULL
);

-- GlbCompany table
CREATE TABLE GlbCompany (
    GC_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    GC_Code NVARCHAR(5) NOT NULL,
    GC_Name NVARCHAR(100) NOT NULL,
    GC_IsActive BIT DEFAULT 1 NOT NULL
);

-- GlbBranch table
CREATE TABLE GlbBranch (
    GB_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    GB_Code NVARCHAR(5) NOT NULL,
    GB_BranchName NVARCHAR(100) NOT NULL,
    GB_GC UNIQUEIDENTIFIER NOT NULL,
    GB_IsActive BIT DEFAULT 1 NOT NULL
);

-- GlbDepartment table
CREATE TABLE GlbDepartment (
    GE_PK UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    GE_Code NVARCHAR(5) NOT NULL,
    GE_Desc NVARCHAR(100) NOT NULL,
    GE_IsActive BIT DEFAULT 1 NOT NULL
);

-- Insert common reference data used by all tests
INSERT INTO GlbCompany (GC_PK, GC_Code, GC_Name, GC_IsActive)
VALUES('15C1F416-01D2-4ED2-9B5B-D032C4796DC4', 'SH1', 'ORIENT EXPRESS CONTAINER CO.,LTD (SH1)', 1);

INSERT INTO GlbBranch (GB_PK, GB_Code, GB_BranchName, GB_GC, GB_IsActive)
VALUES('9652C78F-53ED-4DC2-B70D-D921C165A3B0', 'SH1', 'ORIENT EXPRESS CONTAINER CO.,LTD(SH1-CEP)', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', 1);

INSERT INTO GlbDepartment (GE_PK, GE_Code, GE_Desc, GE_IsActive)
VALUES('57F778C1-DAF6-46E0-B7DC-AF01C161C936', 'FES', 'Forwarding Export Sea', 1);

-- Common AccChargeCode data
INSERT INTO AccChargeCode (AC_PK, AC_Code, AC_Desc, AC_ChargeType, AC_IsActive, AC_SystemCreateTimeUtc, AC_SystemCreateUser, AC_SystemLastEditTimeUtc, AC_SystemLastEditUser)
VALUES
('C725B20C-1CE9-497E-84BD-2D79EB697067', 'DOC', 'Destination Documentation Fee', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-04-22 08:05:00.000', '~AD'),
('CE0AF0E4-E31D-40B0-8F9B-12E189F3348A', 'FRT', 'International Freight', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-07-03 03:48:00.000', '~AD'),
('E74937FD-FE45-401A-8728-795D85A69A0A', 'AMS', 'AMS Security Surcharge', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-05-23 04:44:00.000', '~AD'),
('6EFBC528-6B4E-41F8-A84F-67096D0CE8FA', 'OCHC', 'Origin Container Handling Charge', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-05-15 03:47:00.000', '~AD'),
('7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C', 'OCLR', 'Origin Customs Clearance Fee', 'MJA', 1, '2021-10-22 01:45:00.000', 'ACH', '2025-06-11 01:46:00.000', '~AD');

-- Common OrgHeader data
INSERT INTO OrgHeader (OH_PK, OH_Code, OH_SystemLastEditTimeUtc, OH_SystemLastEditUser, OH_SystemCreateTimeUtc, OH_SystemCreateUser, OH_IsActive, OH_IsValid, OH_FullName)
VALUES
('3C52A1A4-F0C6-406B-A70E-7342305013CE', 'OECGRPORD', '2025-07-31 08:47:00.000', 'MRL', '2017-01-31 17:16:00.000', 'E', 1, 1, 'OEC FREIGHT (NY), INC.'),
('C00543BE-015E-4D10-98B8-D9079CF2B314', 'CMACGMORF', '2025-05-12 07:11:00.000', '~AD', '2019-11-13 04:37:00.000', 'BL2', 1, 1, 'CMA CGM S.A.'),
('B7DF88AA-ED24-4163-B439-0D10D7623649', 'MEISINYTN', '2025-08-20 23:36:00.000', '~AD', '2021-12-09 16:49:00.000', 'CLL', 1, 1, 'MEIYUME (SINGAPORE) PTE.LIMITED'),
('D9E232B5-BBE5-4681-B747-040F24FA4AF6', 'YANTFUSHA', '2025-05-15 02:06:00.000', 'MRL', '2021-12-10 04:28:00.000', 'ACH', 1, 1, 'YANTAI T. FULL BIOTECH CO., LTD.');

-- StmNote table (for AR transaction getItemName() functionality)
CREATE TABLE StmNote (
    ST_PK uniqueidentifier NOT NULL  PRIMARY KEY,
    ST_ParentID uniqueidentifier NULL,
    ST_Table varchar(35) DEFAULT '' NOT NULL,
    ST_NoteText nvarchar(MAX) DEFAULT '' NOT NULL,
    ST_NoteType char(3) DEFAULT 'INT' NOT NULL,
    ST_NoteContext varchar(3) DEFAULT 'ALL' NOT NULL,
    ST_Description nvarchar(50) DEFAULT '' NOT NULL,
    ST_SystemCreateTimeUtc smalldatetime NULL,
    ST_SystemCreateUser varchar(3) DEFAULT '' NOT NULL,
    ST_SystemLastEditTimeUtc smalldatetime NULL,
    ST_SystemLastEditUser varchar(3) DEFAULT '' NOT NULL
);

-- Common StmNote data for AR transaction processing
INSERT INTO StmNote(ST_PK, ST_ParentID, ST_Table, ST_NoteText, ST_NoteType, ST_NoteContext, ST_Description, ST_SystemCreateTimeUtc, ST_SystemCreateUser, ST_SystemLastEditTimeUtc, ST_SystemLastEditUser)
VALUES
(N'CEBEBBBE-41C7-4E2D-98F8-0D12E5F52814', N'7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C', N'AccChargeCode', N'启运港空运清关费', N'INT', N'AAI', N'VAT Description', '2025-05-16 01:41:00.000', N'MRL', '2025-05-16 01:41:00.000', N'MRL'),
(N'F8D8E5D5-6D12-46FB-8893-AB279CB97530', N'7FA37EFE-9C26-4944-BB22-FFFAE0CB3C9C', N'AccChargeCode', N'启运港海运清关费', N'INT', N'AAS', N'VAT Description', '2025-05-16 01:41:00.000', N'MRL', '2025-05-16 01:41:00.000', N'MRL');

-- Create indexes for better performance
CREATE INDEX IX_AccTransactionLines_AH ON AccTransactionLines(AL_AH);
CREATE INDEX IX_AccTransactionLines_JH ON AccTransactionLines(AL_JH);
CREATE INDEX IX_AccTransactionLines_AC ON AccTransactionLines(AL_AC);
CREATE INDEX IX_JobHeader_ParentID ON JobHeader(JH_ParentID);
CREATE INDEX IX_AccChargeCode_Code ON AccChargeCode(AC_Code);
CREATE INDEX IX_JobCharge_jh ON JobCharge(JR_JH);
CREATE INDEX IX_JobCharge_ac ON JobCharge(jr_ac);
CREATE INDEX IX_JobCharge_apinvoicenum ON JobCharge(JR_APInvoiceNum);

-- OrgCompanyData table (minimal version with essential fields for integration tests)
CREATE TABLE OrgCompanyData (
    OB_PK uniqueidentifier NOT NULL,
    OB_GC uniqueidentifier NOT NULL,
    OB_OH uniqueidentifier NOT NULL,
    OB_IsDebtor bit DEFAULT 0 NOT NULL,
    OB_IsCreditor bit DEFAULT 0 NOT NULL,
    OB_IsValid bit DEFAULT 0 NOT NULL,
    OB_APCategory varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    OB_ARCategory varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    OB_SystemCreateTimeUtc smalldatetime NULL,
    OB_SystemCreateUser varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    OB_SystemLastEditTimeUtc smalldatetime NULL,
    OB_SystemLastEditUser varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    CONSTRAINT PK_UX__OB_PK PRIMARY KEY (OB_PK)
);

-- AccAPAccountDetails table (minimal version with essential fields for integration tests)
CREATE TABLE AccAPAccountDetails (
    A1_PK uniqueidentifier NOT NULL,
    A1_OB uniqueidentifier NOT NULL,
    A1_AccountName nvarchar(35) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    A1_BankName nvarchar(35) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    A1_BankAccount varchar(35) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    A1_PaymentMethod varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT 'DEF' NOT NULL,
    A1_IsDefaultAccount bit DEFAULT 0 NOT NULL,
    A1_RX_NKAccountCurrency varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    A1_SystemCreateTimeUtc smalldatetime NULL,
    A1_SystemCreateUser varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    A1_SystemLastEditTimeUtc smalldatetime NULL,
    A1_SystemLastEditUser varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '' NOT NULL,
    CONSTRAINT PK_UX__A1_PK PRIMARY KEY (A1_PK)
);