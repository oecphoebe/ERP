-- Test data for shipment view integration tests
-- This file provides additional shipment data beyond the schema defaults

-- Additional shipment test data for comprehensive testing
INSERT INTO vw_shipment_info
(shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl, carrier_book_no, shipment_type, cnsl_type, cnsl_first_leg_vssl, cnsl_first_leg_voy)
VALUES
-- Integration test specific data
('SINT001', 'CINT001', 'HBLINT001', 'MBLINT001', 'MASTERINT001', 'CBKINT001', 'SEA', 'FCL', 'INTEGRATION VESSEL', 'INT001'),
('SINT002', 'CINT002', 'HBLINT002', 'MBLINT002', 'MASTERINT002', 'CBKINT002', 'AIR', 'LCL', 'INTEGRATION PLANE', 'INT002'),

-- Edge case data for testing
('SEDGE001', 'CEDGE001', '', '', '', '', 'SEA', 'FCL', '', ''),
('SEDGE002', 'CEDGE002', 'HBLFULL', 'MBLFULL', 'MASTERFULL', 'CBKFULL', 'AIR', 'LCL', 'FULL VESSEL', 'FULL001'),

-- Data for retry mechanism testing
('SRETRY001', 'CRETRY001', 'HBLRETRY001', 'MBLRETRY001', 'MASTERRETRY001', 'CBKRETRY001', 'SEA', 'FCL', 'RETRY VESSEL', 'RET001'),

-- Data for case sensitivity testing
('slower001', 'clower001', 'hbllower001', 'mbllower001', 'masterlower001', 'cbklower001', 'SEA', 'FCL', 'LOWER VESSEL', 'LOW001'),
('SUPPER001', 'CUPPER001', 'HBLUPPER001', 'MBLUPPER001', 'MASTERUPPER001', 'CBKUPPER001', 'AIR', 'LCL', 'UPPER VESSEL', 'UPP001')
ON CONFLICT DO NOTHING;