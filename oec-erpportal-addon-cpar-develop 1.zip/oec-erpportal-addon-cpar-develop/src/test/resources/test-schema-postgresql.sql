-- PostgreSQL test schema for SOPL database
-- This script creates the necessary tables for integration testing

-- at_account_transaction_header table (using correct column names from sopl-schema.sql)
CREATE TABLE IF NOT EXISTS at_account_transaction_header (
    acct_trans_header_id UUID NOT NULL PRIMARY KEY,
    ref_no VARCHAR(20),
    cw_acc_trans_header_pk UUID,
    ledger VARCHAR(3),
    trans_type VARCHAR(3),
    inv_no VARCHAR(38),
    inv_date DATE,
    due_date DATE,
    crncy_code VARCHAR(3),
    inv_amt NUMERIC(19, 4),
    outstanding_amt NUMERIC(19, 4),
    cmpny_dept VARCHAR(3),
    exchg_rate NUMERIC(18, 9),
    inv_org_code VARCHAR(12),
    local_crncy_code VARCHAR(3),
    cmpny_branch VARCHAR(3),
    trans_desc VARCHAR(128),
    total_vat_amt NUMERIC(19, 4),
    local_total_vat_amt NUMERIC(19, 4),
    cmpny_code VARCHAR(3),
    trans_no VARCHAR(38),
    is_cancel BOOLEAN DEFAULT false NOT NULL,
    create_time TIMESTAMP NOT NULL,
    update_time TIMESTAMP NOT NULL,
    module VARCHAR(10),
    match_trans_header_id UUID,
    create_by VARCHAR(50) NOT NULL,
    update_by VARCHAR(50) NOT NULL,
    chequeorreference VARCHAR(38)
);

-- Add unique index to match production schema
CREATE UNIQUE INDEX IF NOT EXISTS unq_at_acct_trans_header_cw_acc_trans_header_pk ON at_account_transaction_header(cw_acc_trans_header_pk);

-- at_account_transaction_lines table (using correct column names from sopl-schema.sql)
CREATE TABLE IF NOT EXISTS at_account_transaction_lines (
    acc_trans_lines_id UUID NOT NULL PRIMARY KEY,
    acct_trans_header_id UUID NOT NULL REFERENCES at_account_transaction_header(acct_trans_header_id),
    cw_acct_trans_lines_pk UUID,
    chrg_code_id UUID,
    crncy_code VARCHAR(3),
    chrg_amt NUMERIC(19, 4),
    vat_amt NUMERIC(19, 4),
    total_amt NUMERIC(19, 4),
    exchg_rate NUMERIC(18, 9),
    local_crncy_code VARCHAR(3),
    local_vat_amt NUMERIC(19, 4),
    cmpny_code VARCHAR(3),
    cmpny_branch VARCHAR(3),
    cmpny_dept VARCHAR(3),
    trans_line_desc VARCHAR(1024)
);

-- at_shipment_info table (using correct column names from sopl-schema.sql)  
CREATE TABLE IF NOT EXISTS at_shipment_info (
    ref_no VARCHAR(20) NOT NULL PRIMARY KEY,
    cnsl_no VARCHAR(20),
    hbl_no VARCHAR(20),
    mbl_no VARCHAR(35),
    carrier_book_no VARCHAR(35),
    cntr_list VARCHAR(2500),
    cnsl_first_leg_vssl VARCHAR(35),
    cnsl_first_leg_voy VARCHAR(10),
    create_cmpny VARCHAR(3),
    create_branch VARCHAR(3),
    create_dept VARCHAR(3),
    create_by VARCHAR(50),
    create_time TIMESTAMP,
    shipment_no VARCHAR(20),
    etd TIMESTAMP,
    cntr_mode BPCHAR(3),
    master_mbl VARCHAR(35),
    shipment_id UUID,
    master_shipment_id UUID,
    atd TIMESTAMP,
    ata TIMESTAMP,
    shipment_type VARCHAR(3),
    cnsl_type VARCHAR(3)
);

-- sys_api_log table (matches production table name used by ApiLogServiceImpl)
CREATE TABLE IF NOT EXISTS sys_api_log (
    action_id UUID NOT NULL,
    api_id UUID NOT NULL,
    action_name VARCHAR(30) NOT NULL,
    api_name VARCHAR(20) NOT NULL,
    api_type VARCHAR(3) NOT NULL,
    api_status VARCHAR(20) NOT NULL,
    cw_status BPCHAR(3),
    cnsl_no VARCHAR(20),
    shipment_no VARCHAR(20),
    cmpny_code VARCHAR(3),
    agent_org_code VARCHAR(12),
    api_parameters JSON,
    api_response JSON,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    update_by VARCHAR(20) NOT NULL,
    CONSTRAINT pk_sys_api_log_action_id_api_id PRIMARY KEY (action_id, api_id)
);

-- cp_compliance table for compliance tracking
CREATE TABLE IF NOT EXISTS cp_compliance (
    compliance_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    compliance_no VARCHAR(100) NOT NULL UNIQUE,
    compliance_code VARCHAR(100),
    compliance_type VARCHAR(50),
    compliance_status VARCHAR(50),
    compliance_data TEXT,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    create_by VARCHAR(50),
    update_by VARCHAR(50)
);

-- cp_compliance_acct_trans_header_line_link table (links compliance to transaction records)
CREATE TABLE IF NOT EXISTS cp_compliance_acct_trans_header_line_link (
    compliance_acct_trans_header_line_link_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    compliance_id UUID REFERENCES cp_compliance(compliance_id),
    acct_trans_header_id UUID REFERENCES at_account_transaction_header(acct_trans_header_id),
    acct_trans_lines_id UUID REFERENCES at_account_transaction_lines(acc_trans_lines_id),
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    create_by VARCHAR(50),
    update_by VARCHAR(50)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_ath_trans_no ON at_account_transaction_header(trans_no);
CREATE INDEX IF NOT EXISTS idx_ath_ledger_type ON at_account_transaction_header(ledger, trans_type);
CREATE INDEX IF NOT EXISTS idx_ath_ref_no ON at_account_transaction_header(ref_no);
CREATE INDEX IF NOT EXISTS idx_atl_header_id ON at_account_transaction_lines(acct_trans_header_id);
CREATE INDEX IF NOT EXISTS idx_asi_ref_no ON at_shipment_info(ref_no);
CREATE INDEX IF NOT EXISTS idx_sys_api_log_action_id ON sys_api_log(action_id);
CREATE INDEX IF NOT EXISTS idx_cp_compliance_id ON cp_compliance(compliance_id);
CREATE INDEX IF NOT EXISTS idx_cp_link_compliance_id ON cp_compliance_acct_trans_header_line_link(compliance_id);
CREATE INDEX IF NOT EXISTS idx_cp_link_header_id ON cp_compliance_acct_trans_header_line_link(acct_trans_header_id);
CREATE INDEX IF NOT EXISTS idx_cp_link_lines_id ON cp_compliance_acct_trans_header_line_link(acct_trans_lines_id);

-- Add cw_global_company table (referenced by transaction processing)
CREATE TABLE IF NOT EXISTS cw_global_company (
    global_cmpny_id UUID PRIMARY KEY,
    country_code VARCHAR(2),
    cmpny_code VARCHAR(10),
    is_active BOOLEAN DEFAULT true,
    etl_create_time TIMESTAMP,
    etl_update_time TIMESTAMP,
    proxy_org_header_id UUID,
    crncy_code VARCHAR(3)
);

-- Insert test data for cw_global_company
INSERT INTO cw_global_company
(global_cmpny_id, country_code, cmpny_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id, crncy_code)
VALUES('15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'CN', 'SH1', true, '2023-02-01 17:18:30.329', '2025-06-16 03:51:57.881', 'baf95bea-bf76-4102-b4f8-192ed6ad88e5'::uuid, 'CNY')
ON CONFLICT (global_cmpny_id) DO NOTHING;

-- Add cw_global_branch table (referenced by transaction processing)
CREATE TABLE IF NOT EXISTS cw_global_branch (
    global_branch_id UUID PRIMARY KEY,
    global_cmpny_id UUID REFERENCES cw_global_company(global_cmpny_id),
    branch_code VARCHAR(10),
    is_active BOOLEAN DEFAULT true,
    etl_create_time TIMESTAMP,
    etl_update_time TIMESTAMP,
    proxy_org_header_id UUID
);

-- Insert test data for cw_global_branch
INSERT INTO cw_global_branch
(global_branch_id, global_cmpny_id, branch_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id)
VALUES('9652c78f-53ed-4dc2-b70d-d921c165a3b0'::uuid, '15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'SH1', true, '2023-02-01 17:25:09.404', '2025-06-16 03:52:00.284', '97cc1137-81fc-495c-9f59-a6974fa85f97'::uuid)
ON CONFLICT (global_branch_id) DO NOTHING;

-- CargoWise Global Company table (direct mapping to Cargowise schema)
CREATE TABLE IF NOT EXISTS GlbCompany (
    GC_PK UUID NOT NULL PRIMARY KEY,
    GC_Code CHAR(3) DEFAULT '' NOT NULL,
    GC_BusinessRegNo VARCHAR(35) DEFAULT '' NOT NULL,
    GC_BusinessRegNo2 VARCHAR(35) DEFAULT '' NOT NULL,
    GC_CustomsRegistrationNo VARCHAR(35) DEFAULT '' NOT NULL,
    GC_Address1 VARCHAR(50) DEFAULT '' NOT NULL,
    GC_Address2 VARCHAR(50) DEFAULT '' NOT NULL,
    GC_City VARCHAR(25) DEFAULT '' NOT NULL,
    GC_Phone VARCHAR(20) DEFAULT '' NOT NULL,
    GC_PostCode VARCHAR(10) DEFAULT '' NOT NULL,
    GC_State VARCHAR(25) DEFAULT '' NOT NULL,
    GC_Fax VARCHAR(20) DEFAULT '' NOT NULL,
    GC_NoOfAccountingPeriods INTEGER DEFAULT 12 NOT NULL,
    GC_PeriodFormat CHAR(3) DEFAULT 'CAL' NOT NULL,
    GC_StartDate TIMESTAMP NULL,
    GC_PeriodEndWeekDay CHAR(3) DEFAULT 'FRI' NOT NULL,
    GC_GLCurrentPeriod INTEGER DEFAULT 200001 NOT NULL,
    GC_ARAPCurrentPeriod INTEGER DEFAULT 200001 NOT NULL,
    GC_GLClosedPeriod INTEGER DEFAULT 200001 NOT NULL,
    GC_ARAPClosedPeriod INTEGER DEFAULT 200001 NOT NULL,
    GC_OH_OrgProxy UUID NULL,
    GC_ExRateDisplayMode VARCHAR(3) DEFAULT 'IUL' NOT NULL,
    GC_ExRateDecimals SMALLINT DEFAULT 4 NOT NULL,
    GC_RX_NKLocalCurrency VARCHAR(3) DEFAULT '' NOT NULL,
    GC_RN_NKCountryCode VARCHAR(2) DEFAULT '' NOT NULL,
    GC_LocalDocLanguage VARCHAR(3) DEFAULT 'DEF' NOT NULL,
    GC_IsActive BOOLEAN DEFAULT true NOT NULL,
    GC_IsReciprocal BOOLEAN DEFAULT false NOT NULL,
    GC_IsGSTRegistered BOOLEAN DEFAULT true NOT NULL,
    GC_IsGSTCashBasis BOOLEAN DEFAULT false NOT NULL,
    GC_IsWHTRegistered BOOLEAN DEFAULT false NOT NULL,
    GC_IsWHTCashBasis BOOLEAN DEFAULT true NOT NULL,
    GC_IsValid BOOLEAN DEFAULT false NOT NULL,
    GC_Name VARCHAR(100) DEFAULT '' NOT NULL,
    GC_Email VARCHAR(254) DEFAULT '' NOT NULL,
    GC_WebAddress VARCHAR(250) DEFAULT '' NOT NULL,
    GC_AddressMap VARCHAR(50) DEFAULT '' NOT NULL,
    GC_GeoLocation POINT NULL,
    GC_ValidationStatus CHAR(3) DEFAULT 'NYV' NOT NULL,
    GC_AutoVersion SMALLINT DEFAULT 0 NOT NULL,
    GC_SystemCreateTimeUtc TIMESTAMP NULL,
    GC_SystemCreateUser VARCHAR(3) DEFAULT '' NOT NULL,
    GC_SystemLastEditTimeUtc TIMESTAMP NULL,
    GC_SystemLastEditUser VARCHAR(3) DEFAULT '' NOT NULL
);

-- CargoWise Global Branch table (direct mapping to Cargowise schema)
CREATE TABLE IF NOT EXISTS GlbBranch (
    GB_PK UUID NOT NULL PRIMARY KEY,
    GB_Code CHAR(3) DEFAULT '' NOT NULL,
    GB_BranchName VARCHAR(50) DEFAULT '' NOT NULL,
    GB_Address1 VARCHAR(50) DEFAULT '' NOT NULL,
    GB_Address2 VARCHAR(50) DEFAULT '' NOT NULL,
    GB_City VARCHAR(25) DEFAULT '' NOT NULL,
    GB_State VARCHAR(25) DEFAULT '' NOT NULL,
    GB_PostCode VARCHAR(10) DEFAULT '' NOT NULL,
    GB_Phone VARCHAR(20) DEFAULT '' NOT NULL,
    GB_Fax VARCHAR(20) DEFAULT '' NOT NULL,
    GB_InternalExtension VARCHAR(20) DEFAULT '' NOT NULL,
    GB_WebAddress VARCHAR(60) DEFAULT '' NOT NULL,
    GB_GC UUID NOT NULL,
    GB_RL_NKHomePort VARCHAR(5) DEFAULT '' NOT NULL,
    GB_OH_OrgProxy UUID NULL,
    GB_LocalDocLanguage VARCHAR(3) DEFAULT 'DEF' NOT NULL,
    GB_IsActive BOOLEAN DEFAULT true NOT NULL,
    GB_IsValid BOOLEAN DEFAULT false NOT NULL,
    GB_Email VARCHAR(254) DEFAULT '' NOT NULL,
    GB_OA_AddressProxy UUID NULL,
    GB_AccountingGroupCode VARCHAR(3) DEFAULT '' NOT NULL,
    GB_RN_NKCountryCode VARCHAR(2) DEFAULT '' NOT NULL,
    GB_AddressMap VARCHAR(50) DEFAULT '' NOT NULL,
    GB_GeoLocation POINT NULL,
    GB_ValidationStatus CHAR(3) DEFAULT 'NYV' NOT NULL,
    GB_AutoVersion SMALLINT DEFAULT 0 NOT NULL,
    GB_SystemCreateTimeUtc TIMESTAMP NULL,
    GB_SystemCreateUser VARCHAR(3) DEFAULT '' NOT NULL,
    GB_SystemLastEditTimeUtc TIMESTAMP NULL,
    GB_SystemLastEditUser VARCHAR(3) DEFAULT '' NOT NULL
);

-- CargoWise Global Department table (direct mapping to Cargowise schema)
CREATE TABLE IF NOT EXISTS GlbDepartment (
    GE_PK UUID NOT NULL PRIMARY KEY,
    GE_Code CHAR(3) DEFAULT '' NOT NULL,
    GE_Desc VARCHAR(35) DEFAULT '' NOT NULL,
    GE_GE UUID NULL,
    GE_IsActive BOOLEAN DEFAULT true NOT NULL,
    GE_SystemCode BOOLEAN DEFAULT false NOT NULL,
    GE_Air BOOLEAN DEFAULT false NOT NULL,
    GE_Sea BOOLEAN DEFAULT false NOT NULL,
    GE_Road BOOLEAN DEFAULT false NOT NULL,
    GE_Rail BOOLEAN DEFAULT false NOT NULL,
    GE_Post BOOLEAN DEFAULT false NOT NULL,
    GE_NonTransport BOOLEAN DEFAULT false NOT NULL,
    GE_Export BOOLEAN DEFAULT false NOT NULL,
    GE_Import BOOLEAN DEFAULT false NOT NULL,
    GE_Domestic BOOLEAN DEFAULT false NOT NULL,
    GE_NonDirectional BOOLEAN DEFAULT false NOT NULL,
    GE_InternationalFreight BOOLEAN DEFAULT false NOT NULL,
    GE_CustomsBrokerage BOOLEAN DEFAULT false NOT NULL,
    GE_LocalTransport BOOLEAN DEFAULT false NOT NULL,
    GE_LineHaul BOOLEAN DEFAULT false NOT NULL,
    GE_DepotCFS BOOLEAN DEFAULT false NOT NULL,
    GE_Warehouse BOOLEAN DEFAULT false NOT NULL,
    GE_Misc BOOLEAN DEFAULT false NOT NULL,
    GE_IsValid BOOLEAN DEFAULT false NOT NULL,
    GE_AutoVersion SMALLINT DEFAULT 0 NOT NULL,
    GE_GDG_ManagementGroup UUID NULL,
    GE_IsCostCentre BOOLEAN DEFAULT false NOT NULL,
    GE_SystemCreateTimeUtc TIMESTAMP NULL,
    GE_SystemCreateUser VARCHAR(3) DEFAULT '' NOT NULL,
    GE_SystemLastEditTimeUtc TIMESTAMP NULL,
    GE_SystemLastEditUser VARCHAR(3) DEFAULT '' NOT NULL
);

-- CargoWise Job Consol Transport table (direct mapping to Cargowise schema)
CREATE TABLE IF NOT EXISTS JobConsolTransport (
    JW_PK UUID NOT NULL PRIMARY KEY,
    JW_TransportMode CHAR(3) DEFAULT '' NOT NULL,
    JW_LegOrder SMALLINT DEFAULT 0 NOT NULL,
    JW_TransportType CHAR(3) DEFAULT '' NOT NULL,
    JW_Vessel VARCHAR(35) DEFAULT '' NOT NULL,
    JW_VoyageFlight VARCHAR(10) DEFAULT '' NOT NULL,
    JW_RL_NKLoadPort VARCHAR(5) DEFAULT '' NOT NULL,
    JW_ETD TIMESTAMP NULL,
    JW_ATD TIMESTAMP NULL,
    JW_RL_NKDiscPort VARCHAR(5) DEFAULT '' NOT NULL,
    JW_ETA TIMESTAMP NULL,
    JW_ATA TIMESTAMP NULL,
    JW_CarrierBookingReference VARCHAR(35) DEFAULT '' NOT NULL,
    JW_JX UUID NULL,
    JW_ParentType VARCHAR(3) DEFAULT 'CON' NOT NULL,
    JW_ParentGUID UUID NULL,
    JW_Status VARCHAR(3) DEFAULT '' NOT NULL,
    JW_OA_DepartureLocation UUID NULL,
    JW_OA_ArrivalLocation UUID NULL,
    JW_LegNotes TEXT DEFAULT '' NOT NULL,
    JW_CustomDecimal1 DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JW_CustomLink1 UUID NULL,
    JW_RQ_TruckType UUID NULL,
    JW_Distance DECIMAL(9,3) DEFAULT 0 NOT NULL,
    JW_DistanceUnit VARCHAR(3) DEFAULT '' NOT NULL,
    JW_PL_NKCarrierServiceLevel VARCHAR(3) DEFAULT '' NOT NULL,
    JW_OA_CarrierAddress UUID NULL,
    JW_OA_CreditorAddress UUID NULL,
    JW_IsLinked BOOLEAN DEFAULT false NOT NULL,
    JW_IsCharter BOOLEAN DEFAULT false NOT NULL
);

-- CargoWise Job Consol Cost table (direct mapping to Cargowise schema)
CREATE TABLE IF NOT EXISTS JobConsolCost (
    E6_PK UUID NOT NULL PRIMARY KEY,
    E6_Sequence INTEGER DEFAULT 0 NOT NULL,
    E6_AC_ChargeCode UUID NOT NULL,
    E6_InvoiceNum VARCHAR(38) DEFAULT '' NOT NULL,
    E6_InvoiceDate TIMESTAMP NULL,
    E6_RX_NKCurrency VARCHAR(3) DEFAULT '' NOT NULL,
    E6_OSCostAmount DECIMAL(19,4) DEFAULT 0 NOT NULL,
    E6_OSGSTAmount DECIMAL(19,4) DEFAULT 0 NOT NULL,
    E6_ExchangeRate DECIMAL(18,9) DEFAULT 0 NOT NULL,
    E6_LocalCostAmount DECIMAL(19,4) DEFAULT 0 NOT NULL,
    E6_OH_Creditor UUID NULL,
    E6_PPDCLT VARCHAR(3) DEFAULT '' NOT NULL,
    E6_ApportionmentMethod VARCHAR(3) DEFAULT '' NOT NULL,
    E6_PaymentDate TIMESTAMP NULL,
    E6_PaymentType VARCHAR(3) DEFAULT '' NOT NULL,
    E6_AB_BankAccount UUID NULL,
    E6_AK_ChequeBook UUID NULL,
    E6_AT_TaxRate UUID NULL,
    E6_AH_ARInvoice UUID NULL,
    E6_AH_APInvoice UUID NULL,
    E6_GC UUID NOT NULL,
    E6_ParentID UUID NULL,
    E6_A9_VATClass UUID NULL,
    E6_IsValid BOOLEAN DEFAULT false NOT NULL,
    E6_IsForCollectInvoice BOOLEAN DEFAULT false NOT NULL,
    E6_CostReference VARCHAR(38) DEFAULT '' NOT NULL,
    E6_ChequeOrReference VARCHAR(38) DEFAULT '' NOT NULL,
    E6_ParentTableCode VARCHAR(3) DEFAULT '' NOT NULL,
    E6_Description TEXT DEFAULT '' NOT NULL,
    E6_IsTaxAmountOverridden BOOLEAN DEFAULT false NOT NULL,
    E6_TaxDate DATE NULL,
    E6_PlaceOfSupply VARCHAR(5) DEFAULT '' NOT NULL,
    E6_PlaceOfSupplyType VARCHAR(3) DEFAULT '' NOT NULL,
    E6_DocumentReceivedDate TIMESTAMP NULL,
    E6_GatewaySellChargeID UUID NULL,
    E6_GS_NKConsolCostOwner VARCHAR(3) DEFAULT '' NOT NULL,
    E6_AutoVersion SMALLINT DEFAULT 0 NOT NULL,
    E6_RatingBehaviour VARCHAR(3) DEFAULT '' NOT NULL,
    E6_SystemCreateTimeUtc TIMESTAMP NULL,
    E6_SystemCreateUser VARCHAR(3) DEFAULT '' NOT NULL,
    E6_SystemLastEditTimeUtc TIMESTAMP NULL,
    E6_SystemLastEditUser VARCHAR(3) DEFAULT '' NOT NULL,
    E6_SupplyType VARCHAR(3) DEFAULT '' NOT NULL,
    E6_GB_CostTaxBranch UUID NULL
);

-- cw_org_header table (organization header information for buyer lookups)
CREATE TABLE IF NOT EXISTS cw_org_header (
    org_header_id uuid NOT NULL,
    org_code varchar(12) NULL,
    full_name varchar(100) NULL,
    is_consignee bool NOT NULL,
    is_consignor bool NOT NULL,
    is_forwarder bool NOT NULL,
    is_shipping_provider bool NOT NULL,
    is_air_line bool NOT NULL,
    is_shipping_line bool NOT NULL,
    is_temp_acct bool NOT NULL,
    is_ctrling_cust bool NOT NULL,
    is_ctrling_agent bool NOT NULL,
    is_active bool NOT NULL,
    etl_create_time timestamp NULL,
    etl_update_time timestamp NULL,
    plk_org_code varchar(10) NULL,
    org_lang varchar(7) NULL,
    CONSTRAINT pk_cw_org_header_org_header_id PRIMARY KEY (org_header_id),
    CONSTRAINT unq_cw_org_header_org_code UNIQUE (org_code)
);

-- Insert test data for cw_org_header (CMACGMORF organization for AP-CRD test)
INSERT INTO cw_org_header(org_header_id, org_code, full_name, is_consignee, is_consignor, is_forwarder, is_shipping_provider, is_air_line, is_shipping_line, is_temp_acct, is_ctrling_cust, is_ctrling_agent, is_active, etl_create_time, etl_update_time, plk_org_code, org_lang)
VALUES('c00543be-015e-4d10-98b8-d9079cf2b314'::uuid, 'CMACGMORF', 'CMA CGM S.A.', false, true, false, true, false, true, true, false, false, true, '2023-02-02 16:23:27.445', '2025-06-16 03:52:09.009', 'CMA', NULL)
ON CONFLICT (org_code) DO NOTHING;
INSERT INTO cw_org_header(org_header_id, org_code, full_name, is_consignee, is_consignor, is_forwarder, is_shipping_provider, is_air_line, is_shipping_line, is_temp_acct, is_ctrling_cust, is_ctrling_agent, is_active, etl_create_time, etl_update_time, plk_org_code, org_lang)
VALUES('b7df88aa-ed24-4163-b439-0d10d7623649'::uuid, 'MEISINYTN', 'MEIYUME (SINGAPORE) PTE.LIMITED', true, true, false, false, false, false, true, false, false, true, '2023-02-02 16:23:27.445', '2025-06-16 03:52:09.009', NULL, NULL)
ON CONFLICT (org_code) DO NOTHING;
INSERT INTO cw_org_header(org_header_id, org_code, full_name, is_consignee, is_consignor, is_forwarder, is_shipping_provider, is_air_line, is_shipping_line, is_temp_acct, is_ctrling_cust, is_ctrling_agent, is_active, etl_create_time, etl_update_time, plk_org_code, org_lang)
VALUES('d9e232b5-bbe5-4681-b747-040f24fa4af6'::uuid, 'YANTFUSHA', 'YANTAI T. FULL BIOTECH CO., LTD.', false, true, false, false, false, false, false, false, false, true, '2023-02-02 16:23:27.445', '2025-06-16 03:52:09.009', NULL, NULL)
ON CONFLICT (org_code) DO NOTHING;

-- cw_org_address table (organization address information)
CREATE TABLE IF NOT EXISTS cw_org_address (
    org_addr_id uuid NOT NULL,
    org_header_id uuid NULL,
    country_code varchar(3) NULL,
    state_code varchar(25) NULL,
    postcode varchar(10) NULL,
    city_name varchar(50) NULL,
    addr1 varchar(50) NULL,
    addr2 varchar(50) NULL,
    is_active bool NOT NULL,
    etl_create_time timestamp NULL,
    etl_update_time timestamp NULL,
    phone varchar(20) NULL,
    fax varchar(20) NULL,
    addr_code varchar(25) NULL,
    ovr_cmpny_name varchar(100) NULL,
    email varchar(254) NULL,
    CONSTRAINT pk_cw_org_address_org_addr_id PRIMARY KEY (org_addr_id)
);

-- cw_org_cus_code table (organization customer code information)
CREATE TABLE IF NOT EXISTS cw_org_cus_code (
    org_cus_code_id uuid NOT NULL,
    org_header_id uuid NULL,
    cus_country_code varchar(2) NULL,
    cus_code_type varchar(3) NULL,
    cus_code_value varchar(254) NULL,
    etl_create_time timestamp NULL,
    etl_update_time timestamp NULL,
    CONSTRAINT pk_cw_org_cus_code_org_cus_code_id PRIMARY KEY (org_cus_code_id)
);
INSERT INTO cw_org_cus_code(org_cus_code_id, org_header_id, cus_country_code, cus_code_type, cus_code_value, etl_create_time, etl_update_time)
VALUES('df8e100b-b76f-451b-8ce6-9ce47fd7a624'::uuid, 'd9e232b5-bbe5-4681-b747-040f24fa4af6'::uuid, 'CN', 'VAT', '913706855690363661', '2025-05-12 02:33:12.219', '2025-06-16 03:52:13.324');

-- vw_shipment_info mock table for integration tests
-- In production this will be a view, but for testing we create it as a table
CREATE TABLE IF NOT EXISTS vw_shipment_info (
    shipment_no VARCHAR(20),
    cnsl_no VARCHAR(20),
    hbl_no VARCHAR(20),
    mbl_no VARCHAR(35),
    master_mbl VARCHAR(35),
    carrier_book_no VARCHAR(35),
    shipment_type VARCHAR(3),
    cnsl_type VARCHAR(3),
    cnsl_first_leg_vssl VARCHAR(35),
    cnsl_first_leg_voy VARCHAR(10)
);

CREATE TABLE IF NOT EXISTS vw_shipment_container_info (
    shipment_no VARCHAR(20),
    cnsl_no VARCHAR(20),
    cntr_no VARCHAR(20)
);

-- Insert sample test data for both 'C' and 'S' prefix testing
-- Test data for 'C' prefix (consolidation-based lookup)
INSERT INTO vw_shipment_info
(shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl, carrier_book_no, shipment_type, cnsl_type, cnsl_first_leg_vssl, cnsl_first_leg_voy)
VALUES
('S240123001', 'C240123001', 'HBL240123001', 'MBL240123001', 'MASTER240123001', 'CBK240123001', 'SEA', 'LCL', 'EVER GIVEN', 'V001'),
('S240123002', 'C240123002', 'HBL240123002', 'MBL240123002', 'MASTER240123002', 'CBK240123002', 'AIR', 'FCL', 'CARGO PLANE', 'F001'),
('S240123003', 'C240123003', 'HBL240123003', 'MBL240123003', 'MASTER240123003', 'CBK240123003', 'SEA', 'LCL', 'MSC OSCAR', 'V002')
ON CONFLICT DO NOTHING;

-- Test data for 'S' prefix (shipment-based lookup)
INSERT INTO vw_shipment_info
(shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl, carrier_book_no, shipment_type, cnsl_type, cnsl_first_leg_vssl, cnsl_first_leg_voy)
VALUES
('S240124001', 'C240124001', 'HBL240124001', 'MBL240124001', 'MASTER240124001', 'CBK240124001', 'SEA', 'FCL', 'MAERSK LINE', 'V003'),
('S240124002', 'C240124002', 'HBL240124002', 'MBL240124002', 'MASTER240124002', 'CBK240124002', 'AIR', 'LCL', 'AIR CARGO', 'F002'),
('S240124003', 'C240124003', 'HBL240124003', 'MBL240124003', 'MASTER240124003', 'CBK240124003', 'SEA', 'FCL', 'COSCO SHIPPING', 'V004')
ON CONFLICT DO NOTHING;

-- Grant permissions (if needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO test;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO test;