-- Basic test data for when view feature is disabled
-- Minimal Cargowise test data for fallback mechanism testing

-- Basic organization data (required for most tests)
INSERT INTO OrgHeader (OH_PK, OH_Code, OH_FullCompanyName)
VALUES
('TEST-ORG-001'::uuid, 'TESTORG', 'Test Organization Ltd.')
ON CONFLICT DO NOTHING;

-- Basic job header data
INSERT INTO JobHeader (JH_PK, JH_Job, JH_JobDate)
VALUES
('TEST-JOB-001'::uuid, 'TEST123', '2024-01-23'::date)
ON CONFLICT DO NOTHING;