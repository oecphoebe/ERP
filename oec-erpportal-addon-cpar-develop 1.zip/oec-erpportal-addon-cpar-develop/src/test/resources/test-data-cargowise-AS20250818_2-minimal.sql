-- Minimal test data for AP_INV_AS20250818_2 integration test
-- Only includes essential data needed for the getRefNo query to work

-- Note: AccChargeCode and OrgHeader data is now included in the consolidated schema file
-- to avoid duplicate key violations during test execution

-- JobHeader table - Job/Shipment information
INSERT INTO JobHeader (JH_PK, JH_JobNum, JH_Status, JH_ParentID, JH_HeaderType, JH_Name, JH_Description, JH_JobLocalReference, JH_ARInvoiceReference, JH_IsActive, JH_ParentTableCode, JH_SystemCreateTimeUtc, JH_SystemCreateUser, JH_SystemLastEditTimeUtc, JH_SystemLastEditUser, JH_GB, JH_GE, JH_GC)
VALUES('73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', 'SSSH1250818426', 'WRK', '5C7F2256-9A2D-4552-83CC-74BBF7811E7A', 'JOB', '', '', '00017356', '', 1, 'JS', '2025-08-18 08:32:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4');

-- JobShipment table - Shipment details
INSERT INTO JobShipment (JS_PK, JS_ShipmentStatus, JS_UniqueConsignRef, JS_InterimReceipt, JS_HouseBill, JS_BookingReference, JS_GoodsDescription, JS_TransportMode, JS_PackingMode, JS_ActualVolume, JS_DocumentedVolume, JS_ManifestedVolume, JS_UnitOfVolume, JS_ActualWeight, JS_DocumentedWeight, JS_ManifestedWeight, JS_UnitOfWeight, JS_TotalPackageCount, JS_OuterPacks, JS_SystemCreateTimeUtc, JS_SystemCreateUser, JS_SystemLastEditTimeUtc, JS_SystemLastEditUser, JS_IsValid)
VALUES('5C7F2256-9A2D-4552-83CC-74BBF7811E7A', 'CNF', 'SSSH1250818426', '', 'OERT201702Y00586', '', 'Visor hat', 'SEA', 'LCL', 4.300, 4.300, 4.300, 'M3', 878.000, 878.000, 878.000, 'KG', 0, 64, '2025-08-18 08:32:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', 1);

-- AccTransactionHeader table - Main transaction header
INSERT INTO AccTransactionHeader (AH_PK, AH_Ledger, AH_TransactionType, AH_TransactionNum, AH_TransactionCount, AH_TransactionReference, AH_Desc, AH_InvoiceDate, AH_TransactionCategory, AH_DueDate, AH_InvoiceAmount, AH_GSTAmount, AH_WithholdingTax, AH_OSTotal, AH_ExchangeRate, AH_AgePeriod, AH_PostPeriod, AH_PostDate, AH_ReceiptType, AH_OutstandingAmount, AH_PostToGL, AH_InvoiceTerm, AH_InvoiceTermDays, AH_ExportBatchNumber, AH_OH, AH_JH, AH_GB, AH_GE, AH_GC, AH_RX_NKTransactionCurrency, AH_SystemCreateTimeUtc, AH_SystemCreateUser, AH_SystemLastEditTimeUtc, AH_SystemLastEditUser, AH_IsCancelled)
VALUES('3DF9BEB8-11E2-42D4-BFED-1322B23D5411', 'AP', 'INV', 'AS20250818_2/', 1, '', 'OERT201702Y00586', '2025-08-18 17:19:00.000', 'STD', '2025-08-18 17:19:00.000', -47.7500, 0.0000, 0.0000, -47.7500, 1.000000000, 0, 0, '2025-08-18 17:19:00.000', '   ', -47.7500, 'N', 'COD', 0, 0, '3C52A1A4-F0C6-406B-A70E-7342305013CE', '73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', 'CNY', '2025-08-18 09:19:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', 0);

-- AccTransactionLines table - Transaction line items
INSERT INTO AccTransactionLines (AL_PK, AL_LineType, AL_Sequence, AL_Desc, AL_LineAmount, AL_GSTVAT, AL_WithholdingTax, AL_UnitQty, AL_UnitPrice, AL_OSUnitPrice, AL_OSAmount, AL_ExchangeRate, AL_PostPeriod, AL_PostDate, AL_PostToGL, AL_AH, AL_JH, AL_AC, AL_GE, AL_GB, AL_OH, AL_RX_NKTransactionCurrency, AL_RevRecognitionType, AL_GC, AL_SystemCreateTimeUtc, AL_SystemCreateUser, AL_SystemLastEditTimeUtc, AL_SystemLastEditUser, AL_InputGSTVATRecoverable)
VALUES
-- Line 1: Documentation Fee
('30752A97-EBFB-4F8B-8BA4-A94033B0102E', 'CST', 1, 'Destination Documentation Fee_0818D', -11.0000, 0.0000, 0.0000, 0, 0.0000, 0.0000, -11.0000, 1.000000000, 0, '2025-08-18 17:19:00.000', 'N', '3DF9BEB8-11E2-42D4-BFED-1322B23D5411', '73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', 'C725B20C-1CE9-497E-84BD-2D79EB697067', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', '3C52A1A4-F0C6-406B-A70E-7342305013CE', 'CNY', 'DEP', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '2025-08-18 09:19:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', 1.0000),

-- Line 2: International Freight
('6FE91D0A-3EED-4C20-9180-0E61BF90A8EE', 'CST', 2, 'International Freight_0818F', -36.7500, 0.0000, 0.0000, 0, 0.0000, 0.0000, -5.0000, 7.350000000, 0, '2025-08-18 17:19:00.000', 'N', '3DF9BEB8-11E2-42D4-BFED-1322B23D5411', '73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', 'CE0AF0E4-E31D-40B0-8F9B-12E189F3348A', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', '3C52A1A4-F0C6-406B-A70E-7342305013CE', 'USD', 'DEP', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '2025-08-18 09:19:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', 1.0000);

-- JobCharge table - Charge line details for the transaction
INSERT INTO JobCharge (JR_PK, JR_JH, JR_GE, JR_GB, JR_AC, JR_Desc, JR_OSCostAmt, JR_OSSellAmt, JR_OSCostExRate, JR_APInvoiceNum, JR_PaymentDate, JR_GC, JR_SystemCreateTimeUtc, JR_SystemCreateUser, JR_SystemLastEditTimeUtc, JR_SystemLastEditUser, JR_E6)
VALUES
-- JobCharge 1: Documentation Fee (JR_E6 is NULL = SHIPMENT)
('658ACA36-FE8C-491B-ABF6-0C2BFB429636', '73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', 'C725B20C-1CE9-497E-84BD-2D79EB697067', 'Destination Documentation Fee_0818D', 11.0000, 0.0000, 1.000000000, 'AS20250818_2/', '2025-08-18 17:19:00.000', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '2025-08-18 08:32:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', NULL),

-- JobCharge 2: International Freight (JR_E6 is NULL = SHIPMENT)
('5EDAC3B3-0133-40B0-B190-F693D302D949', '73030ED8-E7D5-4A35-9D8B-A5B8FDF6F8B5', '57F778C1-DAF6-46E0-B7DC-AF01C161C936', '9652C78F-53ED-4DC2-B70D-D921C165A3B0', 'CE0AF0E4-E31D-40B0-8F9B-12E189F3348A', 'International Freight_0818F', 5.0000, 0.0000, 7.350000000, 'AS20250818_2/', '2025-08-18 17:19:00.000', '15C1F416-01D2-4ED2-9B5B-D032C4796DC4', '2025-08-18 08:32:00.000', 'ASW', '2025-08-18 09:19:00.000', 'ASW', NULL);