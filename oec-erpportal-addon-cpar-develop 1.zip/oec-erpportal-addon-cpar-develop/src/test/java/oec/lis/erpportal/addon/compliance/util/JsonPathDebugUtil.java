package oec.lis.erpportal.addon.compliance.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

/**
 * Utility class for debugging JsonPath expressions against actual JSON documents.
 * Used to isolate JsonPath behavior from Spring test context and verify expressions work
 * with real Cargowise JSON payloads.
 */
@Slf4j
public class JsonPathDebugUtil {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Load JSON file from classpath and test JsonPath expressions against it.
     * 
     * @param jsonFileName The JSON file name in the classpath (e.g., "reference/AR_INV_2508001034.json")
     * @param transactionNumber The transaction number to search for
     */
    public static void testJsonPathWithRealFile(String jsonFileName, String transactionNumber) {
        try {
            // Load JSON file from classpath
            log.info("Loading JSON file: {}", jsonFileName);
            InputStream inputStream = JsonPathDebugUtil.class.getClassLoader().getResourceAsStream(jsonFileName);
            if (inputStream == null) {
                log.error("JSON file not found: {}", jsonFileName);
                return;
            }
            
            // Parse JSON into object
            Object document = objectMapper.readValue(inputStream, Object.class);
            log.info("JSON file loaded successfully");
            
            // Test basic SellReference extraction
            log.info("=== Testing Basic SellReference Extraction ===");
            testBasicSellReference(document);
            
            // Test enhanced SellReference extraction with filtering  
            log.info("=== Testing Enhanced SellReference Extraction ===");
            testEnhancedSellReference(document, transactionNumber);
            
            // Test structure inspection
            log.info("=== Testing JSON Structure Inspection ===");
            inspectJsonStructure(document);
            
        } catch (IOException e) {
            log.error("Error loading JSON file {}: {}", jsonFileName, e.getMessage(), e);
        }
    }
    
    /**
     * Test basic $..SellReference JsonPath expression
     */
    private static void testBasicSellReference(Object document) {
        try {
            String jsonPathExpression = "$..SellReference";
            log.info("Testing JsonPath: {}", jsonPathExpression);
            
            List<String> sellReferenceList = JsonPath.read(document, jsonPathExpression);
            log.info("Basic JsonPath returned: {} items", sellReferenceList.size());
            
            if (!sellReferenceList.isEmpty()) {
                for (int i = 0; i < sellReferenceList.size(); i++) {
                    log.info("  [{}]: {}", i, sellReferenceList.get(i));
                }
            } else {
                log.warn("No SellReference found with basic JsonPath!");
            }
            
        } catch (Exception e) {
            log.error("Error testing basic SellReference: {}", e.getMessage(), e);
        }
    }
    
    /**
     * Test enhanced SellReference extraction with filtering
     */
    private static void testEnhancedSellReference(Object document, String transactionNumber) {
        try {
            String jsonPathExpression = String.format(
                "$..ChargeLine[?(@.SellPostedTransactionNumber=='%s')].SellReference", 
                transactionNumber
            );
            log.info("Testing enhanced JsonPath: {}", jsonPathExpression);
            
            List<String> filteredSellReferenceList = JsonPath.read(document, jsonPathExpression);
            log.info("Enhanced JsonPath returned: {} items", filteredSellReferenceList.size());
            
            if (!filteredSellReferenceList.isEmpty()) {
                for (int i = 0; i < filteredSellReferenceList.size(); i++) {
                    log.info("  [{}]: {}", i, filteredSellReferenceList.get(i));
                }
            } else {
                log.warn("No SellReference found with enhanced JsonPath for transaction: {}", transactionNumber);
            }
            
        } catch (Exception e) {
            log.error("Error testing enhanced SellReference for transaction {}: {}", transactionNumber, e.getMessage(), e);
        }
    }
    
    /**
     * Inspect JSON structure to understand document format
     */
    private static void inspectJsonStructure(Object document) {
        try {
            // Test various paths to understand structure
            log.info("=== JSON Structure Inspection ===");
            
            // Check ShipmentCollection presence
            testJsonPath(document, "$.Body.UniversalTransaction.ShipmentCollection");
            
            // Check ChargeLineCollection presence  
            testJsonPath(document, "$..ChargeLineCollection");
            
            // Check ChargeLine presence
            testJsonPath(document, "$..ChargeLine");
            
            // Check SellPostedTransactionNumber presence
            testJsonPath(document, "$..SellPostedTransactionNumber");
            
            // Check all paths that contain "2508001034"
            log.info("Searching for transaction number 2508001034 in document...");
            testJsonPath(document, "$..*[?(@ == '2508001034')]");
            
        } catch (Exception e) {
            log.error("Error during JSON structure inspection: {}", e.getMessage(), e);
        }
    }
    
    /**
     * Test a single JsonPath expression and log results
     */
    private static void testJsonPath(Object document, String jsonPath) {
        try {
            log.info("Testing path: {}", jsonPath);
            Object result = JsonPath.read(document, jsonPath);
            
            if (result instanceof List<?>) {
                List<?> resultList = (List<?>) result;
                log.info("  Result: List with {} items", resultList.size());
                if (!resultList.isEmpty()) {
                    log.info("  First item type: {}", resultList.get(0).getClass().getSimpleName());
                    if (resultList.size() <= 5) {
                        for (int i = 0; i < resultList.size(); i++) {
                            log.info("  [{}]: {}", i, resultList.get(i));
                        }
                    }
                }
            } else if (result != null) {
                log.info("  Result: {} (type: {})", result, result.getClass().getSimpleName());
            } else {
                log.info("  Result: null");
            }
            
        } catch (Exception e) {
            log.warn("  Error testing path {}: {}", jsonPath, e.getMessage());
        }
    }
    
    /**
     * Main method for standalone testing
     */
    public static void main(String[] args) {
        testJsonPathWithRealFile("reference/AR_INV_2508001034.json", "2508001034");
    }
}