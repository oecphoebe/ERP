package oec.lis.erpportal.addon.compliance.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionInfoRequestBean;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Test data builder utility for VAT handling unit tests
 */
@Slf4j
public class TestDataBuilder {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Configuration jsonPathConfig = Configuration.defaultConfiguration()
            .addOptions(Option.SUPPRESS_EXCEPTIONS);
    
    /**
     * Load JSON test data from classpath resource
     */
    public static String loadJsonFromResource(String resourcePath) throws IOException {
        ClassPathResource resource = new ClassPathResource(resourcePath);
        return new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
    }
    
    /**
     * Create a sample TransactionInfoRequestBean for testing
     */
    public static TransactionInfoRequestBean createTransactionInfoRequestBean(String ledger, String transactionType) {
        TransactionInfoRequestBean bean = new TransactionInfoRequestBean();
        bean.setBillNo("TEST-" + System.currentTimeMillis());
        bean.setTransactionType(transactionType);
        bean.setCompanyCode("TEST_COMPANY");
        bean.setShipmentId("SHP-" + System.currentTimeMillis());
        bean.setConsolNo("CNSL-" + System.currentTimeMillis());
        return bean;
    }
    
    /**
     * Create a sample ChargeLine JSON with valid SellGSTVATID for AR
     */
    public static String createChargeLineWithVAT(String chargeCode, String taxCode, BigDecimal amount) {
        Map<String, Object> chargeLine = new HashMap<>();
        
        Map<String, Object> chargeCodeObj = new HashMap<>();
        chargeCodeObj.put("Code", chargeCode);
        chargeCodeObj.put("Description", "Test Charge - " + chargeCode);
        chargeLine.put("ChargeCode", chargeCodeObj);
        
        Map<String, Object> sellGSTVATID = new HashMap<>();
        sellGSTVATID.put("TaxCode", taxCode);
        sellGSTVATID.put("TaxRate", 10);
        chargeLine.put("SellGSTVATID", sellGSTVATID);
        
        chargeLine.put("OSAmount", amount.toString());
        chargeLine.put("OSGSTVATAmount", amount.multiply(new BigDecimal("0.1")).toString());
        
        try {
            return objectMapper.writeValueAsString(chargeLine);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create charge line JSON", e);
        }
    }
    
    /**
     * Create a sample ChargeLine JSON with both SellGSTVATID and CostGSTVATID for AP
     * This includes both cost-side and sell-side VAT data as found in real AP transactions
     */
    public static String createAPChargeLineWithVAT(String chargeCode, String taxCode, BigDecimal amount) {
        Map<String, Object> chargeLine = new HashMap<>();
        
        Map<String, Object> chargeCodeObj = new HashMap<>();
        chargeCodeObj.put("Code", chargeCode);
        chargeCodeObj.put("Description", "Test Charge - " + chargeCode);
        chargeLine.put("ChargeCode", chargeCodeObj);
        
        // AP transactions have CostGSTVATID (vendor/cost side)
        Map<String, Object> costGSTVATID = new HashMap<>();
        costGSTVATID.put("TaxCode", taxCode);
        costGSTVATID.put("TaxRate", 10);
        chargeLine.put("CostGSTVATID", costGSTVATID);
        
        // AP transactions may also have SellGSTVATID (for resale side)
        Map<String, Object> sellGSTVATID = new HashMap<>();
        sellGSTVATID.put("TaxCode", "NOTREPORT");  // Different from cost side
        sellGSTVATID.put("TaxRate", 0);
        chargeLine.put("SellGSTVATID", sellGSTVATID);
        
        chargeLine.put("OSAmount", amount.toString());
        chargeLine.put("OSGSTVATAmount", amount.multiply(new BigDecimal("0.1")).toString());
        
        try {
            return objectMapper.writeValueAsString(chargeLine);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create AP charge line JSON", e);
        }
    }
    
    /**
     * Create a sample ChargeLine JSON without SellGSTVATID for AR
     */
    public static String createChargeLineWithoutVAT(String chargeCode, BigDecimal amount) {
        Map<String, Object> chargeLine = new HashMap<>();
        
        Map<String, Object> chargeCodeObj = new HashMap<>();
        chargeCodeObj.put("Code", chargeCode);
        chargeCodeObj.put("Description", "Test Charge - " + chargeCode);
        chargeLine.put("ChargeCode", chargeCodeObj);
        
        // No SellGSTVATID section
        
        chargeLine.put("OSAmount", amount.toString());
        chargeLine.put("OSGSTVATAmount", "0");
        
        try {
            return objectMapper.writeValueAsString(chargeLine);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create charge line JSON", e);
        }
    }
    
    /**
     * Create a sample PostingJournal JSON with VattaxID
     */
    public static String createPostingJournalWithVAT(String chargeCode, int sequence, String taxCode, int taxRate) {
        Map<String, Object> journal = new HashMap<>();
        
        Map<String, Object> chargeCodeObj = new HashMap<>();
        chargeCodeObj.put("Code", chargeCode);
        journal.put("ChargeCode", chargeCodeObj);
        
        journal.put("Sequence", sequence);
        
        Map<String, Object> vattaxID = new HashMap<>();
        vattaxID.put("TaxCode", taxCode);
        vattaxID.put("TaxRate", taxRate);
        journal.put("VattaxID", vattaxID);
        
        try {
            return objectMapper.writeValueAsString(journal);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create posting journal JSON", e);
        }
    }
    
    /**
     * Create a sample PostingJournal JSON without VattaxID
     */
    public static String createPostingJournalWithoutVAT(String chargeCode, int sequence) {
        Map<String, Object> journal = new HashMap<>();
        
        Map<String, Object> chargeCodeObj = new HashMap<>();
        chargeCodeObj.put("Code", chargeCode);
        journal.put("ChargeCode", chargeCodeObj);
        
        journal.put("Sequence", sequence);
        
        // No VattaxID section
        
        try {
            return objectMapper.writeValueAsString(journal);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create posting journal JSON", e);
        }
    }
    
    /**
     * Create a minimal ChargeLine JSON without ChargeCode (invalid)
     */
    public static String createInvalidChargeLine() {
        Map<String, Object> chargeLine = new HashMap<>();
        // Missing required ChargeCode
        chargeLine.put("OSAmount", "100");
        chargeLine.put("OSGSTVATAmount", "10");
        
        try {
            return objectMapper.writeValueAsString(chargeLine);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create invalid charge line JSON", e);
        }
    }
    
    /**
     * Validate JSON structure using JsonPath
     */
    public static boolean hasPath(String json, String path) {
        try {
            Object result = JsonPath.using(jsonPathConfig).parse(json).read(path);
            return result != null;
        } catch (Exception e) {
            return false;
        }
    }
}