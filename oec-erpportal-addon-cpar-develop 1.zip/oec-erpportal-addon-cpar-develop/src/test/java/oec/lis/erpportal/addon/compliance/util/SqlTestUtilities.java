package oec.lis.erpportal.addon.compliance.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * SQL utilities for integration tests providing SQL parsing, loading, and execution functionality.
 * 
 * This class handles:
 * - Parsing multi-statement SQL files
 * - Loading and executing Cargowise test data
 * - Validating test data setup
 * - Extracting table names and metadata from SQL statements
 */
@Slf4j
public class SqlTestUtilities {

    /**
     * Parse SQL statements from a multi-statement SQL script file.
     * Handles INSERT statements separated by semicolons with proper boundary detection.
     */
    public List<String> parseSqlStatements(String sqlScript) {
        List<String> statements = new ArrayList<>();
        StringBuilder currentStatement = new StringBuilder();
        String[] lines = sqlScript.split("\n");
        
        boolean inStatement = false;
        
        for (String line : lines) {
            String trimmed = line.trim();
            
            // Skip comments and empty lines
            if (trimmed.isEmpty() || trimmed.startsWith("--")) {
                continue;
            }
            
            // Check if this is the start of an INSERT statement
            if (trimmed.startsWith("INSERT INTO")) {
                // If we were already in a statement, something went wrong
                if (inStatement) {
                    log.warn("Found nested INSERT statement, adding previous incomplete statement");
                    statements.add(currentStatement.toString().trim());
                }
                currentStatement = new StringBuilder();
                inStatement = true;
            }
            
            if (inStatement) {
                currentStatement.append(line).append("\n");
                
                // Check if this line ends the statement
                if (trimmed.endsWith(");")) {
                    statements.add(currentStatement.toString().trim());
                    currentStatement = new StringBuilder();
                    inStatement = false;
                }
            }
        }
        
        // Handle any remaining incomplete statement
        if (inStatement && currentStatement.length() > 0) {
            statements.add(currentStatement.toString().trim());
        }
        
        log.info("Parsed {} SQL statements from script", statements.size());
        return statements;
    }

    /**
     * Extract table name from INSERT INTO statement for logging and debugging
     */
    public String extractTableName(String sql) {
        if (sql.startsWith("INSERT INTO")) {
            String[] parts = sql.split("\\s+", 4);
            if (parts.length >= 3) {
                return parts[2].replaceAll("[^a-zA-Z0-9_]", "");
            }
        }
        return "unknown";
    }

    /**
     * Load and execute Cargowise test data from a SQL file.
     * Handles proper statement parsing and execution with error reporting.
     * Gracefully handles duplicate key violations for repeated test execution.
     */
    public void loadCargowiseTestData(Connection conn, String sqlFilePath) throws Exception {
        log.info("Loading Cargowise test data from: {}", sqlFilePath);
        
        // Read and execute the test data SQL script with proper parsing
        Path sqlFile = Paths.get(sqlFilePath);
        if (!Files.exists(sqlFile)) {
            throw new IllegalStateException("Test data SQL file not found: " + sqlFile.toAbsolutePath());
        }
        
        String sqlScript = Files.readString(sqlFile);
        List<String> statements = parseSqlStatements(sqlScript);
        
        Statement stmt = conn.createStatement();
        int executedCount = 0;
        int skippedCount = 0;
        
        for (String sql : statements) {
            try {
                log.debug("Executing statement {}: INSERT INTO {}", executedCount + 1, 
                         extractTableName(sql));
                stmt.execute(sql);
                executedCount++;
                log.debug("Successfully executed statement {} ", executedCount);
            } catch (Exception e) {
                String errorMessage = e.getMessage();
                
                // Check if this is a duplicate key violation (common in repeated test runs)
                if (errorMessage != null && (
                    errorMessage.contains("PRIMARY KEY constraint") || 
                    errorMessage.contains("duplicate key") ||
                    errorMessage.contains("UNIQUE KEY constraint"))) {
                    
                    skippedCount++;
                    log.debug("Skipping duplicate data for statement {} (table: {}): {}", 
                             executedCount + skippedCount, extractTableName(sql), e.getMessage());
                    continue;
                }
                
                // For non-duplicate key errors, still fail the test
                log.error("Failed to execute SQL statement {}: {}", executedCount + skippedCount + 1, e.getMessage());
                log.error("Failed SQL (first 200 chars): {}", sql.substring(0, Math.min(200, sql.length())));
                throw new RuntimeException("Failed to setup test data at statement " + (executedCount + skippedCount + 1) + 
                                         " (table: " + extractTableName(sql) + ")", e);
            }
        }
        
        if (skippedCount > 0) {
            log.info("Cargowise test data setup complete - executed {} SQL statements, skipped {} duplicates", 
                     executedCount, skippedCount);
        } else {
            log.info("Cargowise test data setup complete - executed {} SQL statements", executedCount);
        }
    }

    /**
     * Verify that critical test data was loaded correctly for a specific test case
     */
    public void verifyCargowiseTestData(Connection conn, Map<String, Object> expectedData) throws Exception {
        log.info("Verifying Cargowise test data setup...");
        
        // Verify JobHeader data if job number is provided
        if (expectedData.containsKey("jobNumber")) {
            String jobNumber = (String) expectedData.get("jobNumber");
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM JobHeader WHERE JH_JobNum = ?")) {
                ps.setString(1, jobNumber);
                ResultSet rs = ps.executeQuery();
                rs.next();
                int jobCount = rs.getInt(1);
                log.info("Verified JobHeader data: {} records found for {}", jobCount, jobNumber);
                
                if (jobCount == 0) {
                    throw new RuntimeException("Critical test data missing: JobHeader for " + jobNumber + " not found");
                }
            }
        }
        
        // Verify JobShipment data if reference is provided
        if (expectedData.containsKey("shipmentRef")) {
            String shipmentRef = (String) expectedData.get("shipmentRef");
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM JobShipment WHERE JS_UniqueConsignRef = ?")) {
                ps.setString(1, shipmentRef);
                ResultSet rs = ps.executeQuery();
                rs.next();
                int shipmentCount = rs.getInt(1);
                log.info("Verified JobShipment data: {} records found for {}", shipmentCount, shipmentRef);
            }
        }
        
        // Verify AccTransactionHeader data if transaction details are provided
        if (expectedData.containsKey("transactionNumber")) {
            String transactionNumber = (String) expectedData.get("transactionNumber");
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM AccTransactionHeader WHERE AH_TransactionNum = ?")) {
                ps.setString(1, transactionNumber);
                ResultSet rs = ps.executeQuery();
                rs.next();
                int transactionCount = rs.getInt(1);
                log.info("Verified AccTransactionHeader data: {} records found for {}", transactionCount, transactionNumber);
            }
        }
        
        // Verify charge codes if provided
        if (expectedData.containsKey("chargeCodes")) {
            @SuppressWarnings("unchecked")
            List<String> chargeCodes = (List<String>) expectedData.get("chargeCodes");
            for (String chargeCode : chargeCodes) {
                try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM AccChargeCode WHERE AC_Code = ?")) {
                    ps.setString(1, chargeCode);
                    ResultSet rs = ps.executeQuery();
                    rs.next();
                    int chargeCount = rs.getInt(1);
                    log.info("Verified AccChargeCode data: {} records found for {}", chargeCount, chargeCode);
                }
            }
        }
        
        log.info("Cargowise test data verification complete");
    }

    /**
     * Load SQL script content from a file path
     */
    public String loadSqlScript(String filePath) throws IOException {
        Path sqlFile = Paths.get(filePath);
        if (!Files.exists(sqlFile)) {
            throw new IllegalStateException("SQL file not found: " + sqlFile.toAbsolutePath());
        }
        return Files.readString(sqlFile);
    }

    /**
     * Execute a single SQL statement and return affected row count
     */
    public int executeSingleStatement(Connection conn, String sql) throws Exception {
        try (Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(sql);
        }
    }

    /**
     * Check if a specific record exists in a table
     */
    public boolean recordExists(Connection conn, String tableName, String whereClause, Object... params) throws Exception {
        String sql = "SELECT COUNT(*) FROM " + tableName + " WHERE " + whereClause;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    /**
     * Generate a simple INSERT statement for testing purposes
     */
    public String generateInsertStatement(String tableName, Map<String, Object> values) {
        StringBuilder sql = new StringBuilder("INSERT INTO ").append(tableName).append(" (");
        StringBuilder valuesPart = new StringBuilder(" VALUES (");
        
        boolean first = true;
        for (String column : values.keySet()) {
            if (!first) {
                sql.append(", ");
                valuesPart.append(", ");
            }
            sql.append(column);
            valuesPart.append("?");
            first = false;
        }
        
        sql.append(")").append(valuesPart).append(")");
        return sql.toString();
    }

    /**
     * Clean specific tables in the correct order to avoid foreign key violations
     */
    public void cleanTablesInOrder(Connection conn, String... tableNames) throws Exception {
        try (Statement stmt = conn.createStatement()) {
            for (String tableName : tableNames) {
                try {
                    stmt.execute("DELETE FROM " + tableName);
                    log.debug("Cleaned table: {}", tableName);
                } catch (Exception e) {
                    log.warn("Failed to clean table {}: {}", tableName, e.getMessage());
                }
            }
        }
    }

    /**
     * Get the primary key value for a record matching conditions
     */
    public Object getPrimaryKey(Connection conn, String tableName, String pkColumn, String whereClause, Object... params) throws Exception {
        String sql = "SELECT " + pkColumn + " FROM " + tableName + " WHERE " + whereClause;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getObject(1) : null;
        }
    }
}