package oec.lis.erpportal.addon.compliance.transaction.impl;

import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionInfoRequestBean;
import oec.lis.erpportal.addon.compliance.util.TestDataBuilder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for AP-CRD external routing data extraction
 * Verifies that tax codes are properly extracted when AP transactions
 * are configured for external system routing
 */
public class TransactionServiceImplAPCRDExternalTest {

    @Test
    @DisplayName("AP transaction with external routing should extract TaxCode")
    void testAPTransactionWithExternalRouting_ExtractsTaxCode() {
        // Given: AP transaction configured for external routing
        TransactionInfoRequestBean apTransaction = TestDataBuilder.createTransactionInfoRequestBean("AP", "CRD");
        String chargeLineJson = TestDataBuilder.createAPChargeLineWithVAT("FREIGHT", "VAT10", new BigDecimal("1000"));
        
        // When: Creating RequestBean with external routing enabled
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            apTransaction,
            chargeLineJson,
            "AP",
            "$.OSAmount",
            "$.OSGSTVATAmount",
            true // shouldSendToExternal = true
        );
        
        // Then: TaxCode should be extracted for AP external routing
        assertThat(bean.getTaxCode()).isEqualTo("VAT10");
        assertThat(bean.getItemCode()).isEqualTo("FREIGHT");
    }

    @Test
    @DisplayName("AP transaction with internal routing should NOT extract TaxCode")
    void testAPTransactionWithInternalRouting_SkipsTaxCode() {
        // Given: AP transaction configured for internal routing only
        TransactionInfoRequestBean apTransaction = TestDataBuilder.createTransactionInfoRequestBean("AP", "CRD");
        String chargeLineJson = TestDataBuilder.createAPChargeLineWithVAT("FREIGHT", "VAT10", new BigDecimal("1000"));
        
        // When: Creating RequestBean with external routing disabled
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            apTransaction,
            chargeLineJson,
            "AP",
            "$.OSAmount",
            "$.OSGSTVATAmount",
            false // shouldSendToExternal = false
        );
        
        // Then: TaxCode should NOT be extracted for AP internal routing
        assertThat(bean.getTaxCode()).isNull();
        assertThat(bean.getItemCode()).isEqualTo("FREIGHT");
    }

    @Test
    @DisplayName("AR transaction should always extract TaxCode regardless of routing flag")
    void testARTransactionAlwaysExtractsTaxCode() {
        // Given: AR transaction
        TransactionInfoRequestBean arTransaction = TestDataBuilder.createTransactionInfoRequestBean("AR", "INV");
        String chargeLineJson = TestDataBuilder.createChargeLineWithVAT("FREIGHT", "VAT10", new BigDecimal("1000"));
        
        // When: Creating RequestBean with external routing disabled
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            arTransaction,
            chargeLineJson,
            "AR",
            "$.OSAmount",
            "$.OSGSTVATAmount",
            false // shouldSendToExternal = false (should not matter for AR)
        );
        
        // Then: TaxCode should still be extracted for AR
        assertThat(bean.getTaxCode()).isEqualTo("VAT10");
        assertThat(bean.getItemCode()).isEqualTo("FREIGHT");
    }
}