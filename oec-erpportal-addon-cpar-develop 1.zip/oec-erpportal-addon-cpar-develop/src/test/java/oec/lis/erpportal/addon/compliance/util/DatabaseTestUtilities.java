package oec.lis.erpportal.addon.compliance.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import lombok.extern.slf4j.Slf4j;

/**
 * Database utilities for integration tests providing common database operations,
 * cleanup, debugging, and schema validation functionality.
 * 
 * This class centralizes database testing patterns to reduce code duplication
 * and provide consistent behavior across all integration tests.
 */
@Slf4j
public class DatabaseTestUtilities {

    /**
     * Count records in a specific table
     */
    public int countRecordsInTable(Connection conn, String tableName) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM " + tableName)) {
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /**
     * Clean all test database tables in proper dependency order to avoid foreign key constraint violations
     */
    public void cleanupTestDatabase(Connection conn) throws Exception {
        try (Statement stmt = conn.createStatement()) {
            // Clean tables in dependency order (foreign key constraints)
            try { 
                stmt.execute("DELETE FROM cp_compliance_acct_trans_header_line_link"); 
            } catch (Exception e) { 
                log.debug("Failed to clean cp_compliance_acct_trans_header_line_link: {}", e.getMessage()); 
            }
            stmt.execute("DELETE FROM at_account_transaction_lines");
            stmt.execute("DELETE FROM at_account_transaction_header");
            stmt.execute("DELETE FROM at_shipment_info");
            stmt.execute("DELETE FROM sys_api_log");
            stmt.execute("DELETE FROM cp_compliance");
            
            log.debug("Database cleanup completed successfully");
        }
    }

    /**
     * Reset reference tables to initial test data state
     */
    public void resetReferenceData(Connection conn) throws Exception {
        try (Statement stmt = conn.createStatement()) {
            // Reset reference tables to initial test data (in dependency order)
            stmt.execute("DELETE FROM cw_global_branch");
            stmt.execute("DELETE FROM cw_global_company");
            
            // Insert standard test reference data
            stmt.execute("INSERT INTO cw_global_company (global_cmpny_id, country_code, cmpny_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id, crncy_code) " +
                        "VALUES('15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'CN', 'SH1', true, '2023-02-01 17:18:30.329', '2025-06-16 03:51:57.881', 'baf95bea-bf76-4102-b4f8-192ed6ad88e5'::uuid, 'CNY')");
            
            stmt.execute("INSERT INTO cw_global_branch (global_branch_id, global_cmpny_id, branch_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id) " +
                        "VALUES('9652c78f-53ed-4dc2-b70d-d921c165a3b0'::uuid, '15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'SH1', true, '2023-02-01 17:25:09.404', '2025-06-16 03:52:00.284', '97cc1137-81fc-495c-9f59-a6974fa85f97'::uuid)");
            
            log.debug("Reference data reset completed successfully");
        }
    }

    /**
     * Debug helper to show all table contents for database persistence investigation.
     * This method helps identify if records are being saved but not found due to 
     * transaction boundary, timing, or schema issues.
     */
    public void debugAllTables(Connection conn) throws Exception {
        String[] tables = {"at_account_transaction_header", "at_account_transaction_lines", 
                          "at_shipment_info", "sys_api_log"};
        
        log.info("=== DATABASE DEBUG: Checking all tables for records ===");
        for (String table : tables) {
            try {
                int count = countRecordsInTable(conn, table);
                log.info("DEBUG: Table {} has {} records", table, count);
                
                if (count > 0) {
                    // Show sample records to verify data structure
                    try (PreparedStatement ps = conn.prepareStatement("SELECT * FROM " + table + " LIMIT 3")) {
                        ResultSet rs = ps.executeQuery();
                        int recordNum = 1;
                        while (rs.next()) {
                            log.info("DEBUG: Sample record {} from {}: Found data", recordNum, table);
                            recordNum++;
                        }
                    }
                } else {
                    log.warn("DEBUG: Table {} is EMPTY - no records found", table);
                }
            } catch (Exception e) {
                log.error("DEBUG: Failed to query table {}: {}", table, e.getMessage());
            }
        }
        log.info("=== DATABASE DEBUG: Completed table check ===");
    }

    /**
     * Verify database schema structure to ensure tables and columns exist as expected.
     * PostgreSQL is case-sensitive, so this helps identify column name mismatches.
     */
    public void verifyDatabaseSchema(Connection conn) throws Exception {
        // Check if tables exist
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")) {
            ResultSet rs = ps.executeQuery();
            
            log.info("=== SCHEMA DEBUG: Available tables in test database ===");
            while (rs.next()) {
                log.info("Schema: Table found - {}", rs.getString("table_name"));
            }
        }
        
        // Check column names for main table  
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT column_name FROM information_schema.columns WHERE table_name = 'at_account_transaction_header'")) {
            ResultSet rs = ps.executeQuery();
            
            log.info("=== SCHEMA DEBUG: Columns in at_account_transaction_header ===");
            while (rs.next()) {
                log.info("Schema: Column found - {}", rs.getString("column_name"));
            }
        }
        log.info("=== SCHEMA DEBUG: Completed schema verification ===");
    }

    /**
     * Wait for database records with retry logic to handle async processing timing.
     * Many database operations in Spring are async, so immediate verification may fail.
     */
    public void waitForDatabaseRecords(Connection conn, String tableName, int expectedCount, int maxWaitSeconds) throws Exception {
        int attempts = 0;
        int maxAttempts = maxWaitSeconds;
        
        log.info("WAIT: Starting wait for {} records in table {} (max {} seconds)", expectedCount, tableName, maxWaitSeconds);
        
        while (attempts < maxAttempts) {
            int actualCount = countRecordsInTable(conn, tableName);
            if (actualCount >= expectedCount) {
                log.info("WAIT: Found {} records in {} after {} seconds - SUCCESS", actualCount, tableName, attempts);
                return;
            }
            
            Thread.sleep(1000); // Wait 1 second
            attempts++;
            log.debug("WAIT: Waiting for records in {}: attempt {}/{}, found {}", tableName, attempts, maxAttempts, actualCount);
        }
        
        // Final attempt with debugging
        int finalCount = countRecordsInTable(conn, tableName);
        log.error("WAIT: TIMEOUT - Expected {} records in {} but found {} after {} seconds", 
                 expectedCount, tableName, finalCount, maxWaitSeconds);
        
        // Run debug helpers to understand why records are missing
        debugAllTables(conn);
        verifyDatabaseSchema(conn);
        
        throw new AssertionError(String.format("Expected %d records in %s but found %d after %d seconds", 
                               expectedCount, tableName, finalCount, maxWaitSeconds));
    }

    /**
     * Check if any specific conditions are met in a table
     */
    public boolean hasRecordsMatching(Connection conn, String tableName, String whereClause, Object... params) throws Exception {
        String sql = "SELECT COUNT(*) FROM " + tableName + " WHERE " + whereClause;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    /**
     * Get a specific field value from a table with conditions
     */
    public Object getFieldValue(Connection conn, String tableName, String fieldName, String whereClause, Object... params) throws Exception {
        String sql = "SELECT " + fieldName + " FROM " + tableName + " WHERE " + whereClause;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getObject(1) : null;
        }
    }

    /**
     * Debug specific table with conditions
     */
    public void debugTableWithConditions(Connection conn, String tableName, String whereClause, Object... params) throws Exception {
        String sql = "SELECT * FROM " + tableName + (whereClause != null ? " WHERE " + whereClause : "") + " LIMIT 5";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ResultSet rs = ps.executeQuery();
            
            log.info("=== DEBUG TABLE: {} ===", tableName);
            int recordNum = 1;
            while (rs.next()) {
                log.info("DEBUG: Record {} found in {}", recordNum, tableName);
                recordNum++;
            }
            if (recordNum == 1) {
                log.warn("DEBUG: No records found in {} with conditions: {}", tableName, whereClause);
            }
            log.info("=== DEBUG TABLE COMPLETE: {} ===", tableName);
        }
    }
}