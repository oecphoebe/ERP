package oec.lis.erpportal.addon.compliance.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;

/**
 * Test payload loading utilities for integration tests providing JSON test data loading,
 * validation, and extraction functionality.
 * 
 * This class handles:
 * - Loading JSON payload files from the filesystem
 * - Extracting metadata and key information from payloads
 * - Validating payload structure
 * - Dynamic payload generation from templates
 */
@Slf4j
public class TestPayloadLoader {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Configuration jsonPathConfig = Configuration.defaultConfiguration()
            .addOptions(Option.SUPPRESS_EXCEPTIONS);

    /**
     * Load JSON payload from file system
     */
    public String loadJsonPayload(String filePath) throws IOException {
        Path payloadPath = Paths.get(filePath);
        if (!Files.exists(payloadPath)) {
            throw new IllegalStateException("Test payload file not found: " + payloadPath.toAbsolutePath());
        }
        
        String payload = Files.readString(payloadPath);
        log.info("Loaded test payload from {}: {} characters", filePath, payload.length());
        
        // Log first few lines for verification
        String[] lines = payload.split("\n");
        log.debug("Payload preview: {} ... {}", 
                 lines.length > 0 ? lines[0] : "empty",
                 lines.length > 1 ? lines[1] : "");
        
        return payload;
    }

    /**
     * Load and validate JSON payload with basic structure checks
     */
    public String loadAndValidatePayload(String filePath) throws IOException {
        String payload = loadJsonPayload(filePath);
        
        // Basic JSON structure validation
        try {
            JsonNode rootNode = objectMapper.readTree(payload);
            
            // Check for required top-level fields
            if (!rootNode.has("AccTransactionHeader")) {
                log.warn("Payload missing AccTransactionHeader field");
            }
            if (!rootNode.has("AccTransactionLines")) {
                log.warn("Payload missing AccTransactionLines field");
            }
            
            log.info("Payload validation passed for {}", filePath);
            
        } catch (Exception e) {
            log.error("Payload validation failed for {}: {}", filePath, e.getMessage());
            throw new IOException("Invalid JSON structure in payload file: " + filePath, e);
        }
        
        return payload;
    }

    /**
     * Extract metadata from JSON payload for test setup and verification
     */
    public Map<String, Object> extractPayloadMetadata(String jsonPayload) {
        Map<String, Object> metadata = new HashMap<>();
        
        try {
            // Extract transaction header information
            String ledger = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_Ledger");
            String transactionType = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_TransactionType");
            String transactionNum = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_TransactionNum");
            String orgCode = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_OrgCode");
            
            metadata.put("ledger", ledger);
            metadata.put("transactionType", transactionType);
            metadata.put("transactionNumber", transactionNum);
            metadata.put("organizationCode", orgCode);
            
            // Extract transaction lines count
            Object linesArray = JsonPath.read(jsonPayload, "$.AccTransactionLines");
            if (linesArray instanceof java.util.List) {
                metadata.put("lineCount", ((java.util.List<?>) linesArray).size());
            }
            
            // Extract reference numbers if available
            try {
                String refNo = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_RefNo");
                metadata.put("referenceNumber", refNo);
            } catch (Exception e) {
                log.debug("No reference number found in payload");
            }
            
            // Extract job number if available
            try {
                String jobNum = JsonPath.read(jsonPayload, "$.AccTransactionLines[0].AL_JobNum");
                metadata.put("jobNumber", jobNum);
            } catch (Exception e) {
                log.debug("No job number found in payload");
            }
            
            log.info("Extracted payload metadata: {}", metadata);
            
        } catch (Exception e) {
            log.warn("Failed to extract some metadata from payload: {}", e.getMessage());
        }
        
        return metadata;
    }

    /**
     * Generate test payload from template with dynamic values
     */
    public String generateTestPayload(String templatePath, Map<String, Object> values) throws IOException {
        String template = loadJsonPayload(templatePath);
        
        // Simple template replacement using placeholders like ${transactionNumber}
        String generatedPayload = template;
        
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            String placeholder = "${" + entry.getKey() + "}";
            String value = String.valueOf(entry.getValue());
            generatedPayload = generatedPayload.replace(placeholder, value);
        }
        
        log.info("Generated payload from template {} with {} substitutions", templatePath, values.size());
        
        return generatedPayload;
    }

    /**
     * Extract specific field value from JSON payload using JsonPath
     */
    public Object extractField(String jsonPayload, String jsonPath) {
        try {
            return JsonPath.using(jsonPathConfig).parse(jsonPayload).read(jsonPath);
        } catch (Exception e) {
            log.warn("Failed to extract field using path '{}': {}", jsonPath, e.getMessage());
            return null;
        }
    }

    /**
     * Extract all transaction lines from payload
     */
    public java.util.List<Map<String, Object>> extractTransactionLines(String jsonPayload) {
        try {
            return JsonPath.read(jsonPayload, "$.AccTransactionLines[*]");
        } catch (Exception e) {
            log.warn("Failed to extract transaction lines: {}", e.getMessage());
            return new java.util.ArrayList<>();
        }
    }

    /**
     * Extract charge codes from transaction lines
     */
    public java.util.List<String> extractChargeCodes(String jsonPayload) {
        try {
            return JsonPath.read(jsonPayload, "$.AccTransactionLines[*].AL_ChargeCode");
        } catch (Exception e) {
            log.warn("Failed to extract charge codes: {}", e.getMessage());
            return new java.util.ArrayList<>();
        }
    }

    /**
     * Check if payload contains specific transaction type
     */
    public boolean isTransactionType(String jsonPayload, String expectedLedger, String expectedType) {
        try {
            String ledger = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_Ledger");
            String type = JsonPath.read(jsonPayload, "$.AccTransactionHeader.AH_TransactionType");
            
            return expectedLedger.equals(ledger) && expectedType.equals(type);
        } catch (Exception e) {
            log.warn("Failed to check transaction type: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Log payload summary for debugging
     */
    public void logPayloadSummary(String jsonPayload) {
        try {
            Map<String, Object> metadata = extractPayloadMetadata(jsonPayload);
            java.util.List<String> chargeCodes = extractChargeCodes(jsonPayload);
            
            log.info("=== PAYLOAD SUMMARY ===");
            log.info("Transaction: {} {}", metadata.get("ledger"), metadata.get("transactionType"));
            log.info("Transaction Number: {}", metadata.get("transactionNumber"));
            log.info("Organization Code: {}", metadata.get("organizationCode"));
            log.info("Reference Number: {}", metadata.get("referenceNumber"));
            log.info("Job Number: {}", metadata.get("jobNumber"));
            log.info("Line Count: {}", metadata.get("lineCount"));
            log.info("Charge Codes: {}", chargeCodes);
            log.info("=== PAYLOAD SUMMARY COMPLETE ===");
            
        } catch (Exception e) {
            log.warn("Failed to log payload summary: {}", e.getMessage());
        }
    }

    /**
     * Create a simple test payload for unit testing
     */
    public String createSimpleTestPayload(String ledger, String transactionType, String transactionNum, String orgCode) {
        String simplePayload = String.format("""
            {
              "AccTransactionHeader": {
                "AH_Ledger": "%s",
                "AH_TransactionType": "%s", 
                "AH_TransactionNum": "%s",
                "AH_OrgCode": "%s",
                "AH_Amount": 1000.0000,
                "AH_Outstanding": 1000.0000
              },
              "AccTransactionLines": [
                {
                  "AL_ChargeCode": "TEST",
                  "AL_Description": "Test Charge Line",
                  "AL_Amount": 1000.0000
                }
              ]
            }
            """, ledger, transactionType, transactionNum, orgCode);
        
        log.info("Created simple test payload: {} {} {}", ledger, transactionType, transactionNum);
        return simplePayload;
    }

    /**
     * Validate JSON structure without throwing exceptions
     */
    public boolean isValidJson(String jsonString) {
        try {
            objectMapper.readTree(jsonString);
            return true;
        } catch (Exception e) {
            log.warn("Invalid JSON structure: {}", e.getMessage());
            return false;
        }
    }
}