package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import oec.lis.erpportal.addon.compliance.common.config.NonJobTransactionConfig;
import oec.lis.erpportal.addon.compliance.model.transaction.*;
import oec.lis.erpportal.addon.compliance.service.*;
import oec.lis.sopl.common.model.RestListResponse;

@ExtendWith(MockitoExtension.class)
public class TransactionMappingServiceConsolNoTest {

    @Mock
    private TransactionQueryService queryService;
    
    @Mock
    private TransactionValidationService validationService;
    
    @Mock
    private AtAccountTransactionTableService atAccountTransactionTableService;
    
    @Mock
    private ChargeLineProcessor chargeLineProcessor;
    
    @Mock
    private NonJobTransactionConfig nonJobConfig;

    @InjectMocks
    private TransactionMappingService transactionMappingService;

    private String createTestJson(String refNoType, String shipmentKey, String consolKey) {
        Map<String, Object> payload = new HashMap<>();
        Map<String, Object> body = new HashMap<>();
        Map<String, Object> universalTransaction = new HashMap<>();
        Map<String, Object> transactionInfo = new HashMap<>();
        
        // Basic transaction info
        transactionInfo.put("Ledger", "AR");
        transactionInfo.put("TransactionType", "INV");
        transactionInfo.put("Number", "TEST123");
        transactionInfo.put("TransactionDate", "2025-01-01");
        transactionInfo.put("IsCancelled", false);
        
        Map<String, Object> currency = new HashMap<>();
        currency.put("Code", "USD");
        transactionInfo.put("Oscurrency", currency);
        
        Map<String, Object> company = new HashMap<>();
        company.put("Code", "TEST_COMPANY");
        Map<String, Object> dataContext = new HashMap<>();
        dataContext.put("Company", company);
        dataContext.put("TriggerDate", OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        transactionInfo.put("DataContext", dataContext);
        
        Map<String, Object> branch = new HashMap<>();
        branch.put("Code", "TEST_BRANCH");
        transactionInfo.put("Branch", branch);
        
        Map<String, Object> department = new HashMap<>();
        department.put("Code", "TEST_DEPT");
        transactionInfo.put("Department", department);
        
        Map<String, Object> orgAddress = new HashMap<>();
        orgAddress.put("OrganizationCode", "TEST_ORG");
        transactionInfo.put("OrganizationAddress", orgAddress);
        
        transactionInfo.put("Ostotal", "100.00");
        transactionInfo.put("OutstandingAmount", "100.00");
        transactionInfo.put("ExchangeRate", "1.0");
        transactionInfo.put("Osgstvatamount", "10.00");
        transactionInfo.put("LocalVATAmount", "10.00");
        transactionInfo.put("Description", "Test transaction");
        
        Map<String, Object> localCurrency = new HashMap<>();
        localCurrency.put("Code", "USD");
        transactionInfo.put("LocalCurrency", localCurrency);
        
        // Create shipment collection with DataSource based on refNoType
        if (!"NONJOB".equals(refNoType)) {
            Map<String, Object> shipmentCollection = new HashMap<>();
            List<Map<String, Object>> shipments = new ArrayList<>();
            Map<String, Object> shipment = new HashMap<>();
            Map<String, Object> shipmentDataContext = new HashMap<>();
            Map<String, Object> dataSourceCollection = new HashMap<>();
            List<Map<String, Object>> dataSources = new ArrayList<>();
            
            if ("SHIPMENT".equals(refNoType) && shipmentKey != null) {
                Map<String, Object> shipmentDataSource = new HashMap<>();
                shipmentDataSource.put("Type", "ForwardingShipment");
                shipmentDataSource.put("Key", shipmentKey);
                dataSources.add(shipmentDataSource);
            }
            
            if ("CONSOL".equals(refNoType) && consolKey != null) {
                Map<String, Object> consolDataSource = new HashMap<>();
                consolDataSource.put("Type", "ForwardingConsol");
                consolDataSource.put("Key", consolKey);
                dataSources.add(consolDataSource);
            }
            
            if ("CONSOL".equals(refNoType) && shipmentKey != null && consolKey != null) {
                // For CONSOL, add both ForwardingConsol and ForwardingShipment
                Map<String, Object> shipmentDataSource = new HashMap<>();
                shipmentDataSource.put("Type", "ForwardingShipment");
                shipmentDataSource.put("Key", shipmentKey);
                dataSources.add(shipmentDataSource);
            }
            
            dataSourceCollection.put("DataSource", dataSources);
            shipmentDataContext.put("DataSourceCollection", dataSourceCollection);
            shipment.put("DataContext", shipmentDataContext);
            shipments.add(shipment);
            shipmentCollection.put("Shipment", shipments);
            transactionInfo.put("ShipmentCollection", shipmentCollection);
        }
        
        universalTransaction.put("TransactionInfo", transactionInfo);
        body.put("UniversalTransaction", universalTransaction);
        payload.put("Body", body);
        
        try {
            return new ObjectMapper().writeValueAsString(payload);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create test JSON", e);
        }
    }

    @BeforeEach
    void setUp() {
        // Mock NonJobConfig to be enabled for testing
        lenient().when(nonJobConfig.isEnabled()).thenReturn(true);
        lenient().when(nonJobConfig.getErrorMessage()).thenReturn("NONJOB not supported");

        // Mock basic query service responses - use lenient() to avoid unnecessary stubbing errors
        try {
            lenient().when(queryService.getDebiterName(anyString())).thenReturn("Test Debiter");
        } catch (Exception e) {
            // This shouldn't happen in mocking but required for compilation
        }
        lenient().when(queryService.getBuyerOrgInfo(anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getBuyerTaxNo(anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getBuyerBankInfo(anyString(), anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getCompanyUUID(anyString())).thenReturn(Optional.of(UUID.randomUUID()));
    }

    @Test
    void testConsolScenario_ExtractsConsolNoOnly() throws Exception {
        // Arrange
        String consolKey = "CSSH1250610990";
        String shipmentKey = "SSSH1250617962";
        String json = createTestJson("CONSOL", shipmentKey, consolKey);
        
        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("CONSOL");
        refNoInfo.setRefNo(consolKey);
        refNoInfo.setJobHeader("someJobHeader"); // Not null for CONSOL
        refNoList.add(refNoInfo);
        
        when(queryService.getRefNo("AR", "INV", "TEST123")).thenReturn(refNoList);
        when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(Arrays.asList(createMockCwAccountTransactionInfo()));

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert
        verify(chargeLineProcessor, times(1)).handleChargeLineInShipment(
            any(), any(), any(), any(), argThat(request -> {
                // For CONSOL: shipmentId should be null, consolNo should be extracted
                assertNull(request.getShipmentId(), "CONSOL scenario should have null shipmentId");
                assertEquals(consolKey, request.getConsolNo(), "CONSOL scenario should extract consolNo from JSON");
                return true;
            }), any(), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testShipmentScenario_ExtractsShipmentIdOnly() throws Exception {
        // Arrange
        String shipmentKey = "SSSH1250617962";
        String json = createTestJson("SHIPMENT", shipmentKey, null);
        
        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("SHIPMENT");
        refNoInfo.setRefNo(shipmentKey);
        refNoInfo.setJobHeader(null); // Null for SHIPMENT
        refNoList.add(refNoInfo);
        
        when(queryService.getRefNo("AR", "INV", "TEST123")).thenReturn(refNoList);
        when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(Arrays.asList(createMockCwAccountTransactionInfo()));

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert
        verify(chargeLineProcessor, times(1)).handleChargeLineInShipment(
            any(), any(), any(), any(), argThat(request -> {
                // For SHIPMENT: shipmentId should be extracted, consolNo should be null
                assertEquals(shipmentKey, request.getShipmentId(), "SHIPMENT scenario should extract shipmentId from JSON");
                assertNull(request.getConsolNo(), "SHIPMENT scenario should have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobScenario_BothFieldsNull() throws Exception {
        // Arrange
        String json = createTestJson("NONJOB", null, null);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        when(queryService.getRefNo("AR", "INV", "TEST123")).thenReturn(refNoList);
        // For GL-Account type NONJOB (no JobInvoiceNumber in JSON)
        when(queryService.getCwTransactionInfoForGLAccount(anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Empty for NONJOB GL-Account

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert
        // Since there's no JobInvoiceNumber in the JSON, this is GL-ACCOUNT type NONJOB
        // which calls handleGLAccountChargeLines() instead of handleNonJobChargeLines()
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // For NONJOB GL-ACCOUNT: both shipmentId and consolNo should be null
                assertNull(request.getShipmentId(), "NONJOB GL-ACCOUNT scenario should have null shipmentId");
                assertNull(request.getConsolNo(), "NONJOB GL-ACCOUNT scenario should have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testMissingShipmentCollection_GracefulHandling() throws Exception {
        // Arrange - JSON without ShipmentCollection
        String json = createTestJson("NONJOB", null, null); // This creates JSON without ShipmentCollection
        
        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("SHIPMENT"); // Try SHIPMENT but no ShipmentCollection in JSON
        refNoInfo.setRefNo("SOME_REF");
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);
        
        when(queryService.getRefNo("AR", "INV", "TEST123")).thenReturn(refNoList);
        when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(Arrays.asList(createMockCwAccountTransactionInfo()));

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Should handle gracefully and set fields to null
        verify(chargeLineProcessor, times(1)).handleChargeLineInShipment(
            any(), any(), any(), any(), argThat(request -> {
                // Should handle missing ShipmentCollection gracefully
                assertNull(request.getShipmentId(), "Missing ShipmentCollection should result in null shipmentId");
                assertNull(request.getConsolNo(), "Missing ShipmentCollection should result in null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any(), any()
        );
    }

    private CwAccountTransactionInfo createMockCwAccountTransactionInfo() {
        CwAccountTransactionInfo info = new CwAccountTransactionInfo();
        info.setAccountTransactionHeaderPk(UUID.randomUUID());
        info.setAccountTransactionLinesPk(UUID.randomUUID());
        info.setAccountChargeCodePk(UUID.randomUUID());
        info.setChargeCode("TEST_CHARGE");
        info.setOsAmount(new BigDecimal("100.00"));
        info.setGstVatAmount(new BigDecimal("10.00"));
        info.setLineAmount(new BigDecimal("90.00"));
        info.setExchangeRate(new BigDecimal("1.0"));
        info.setCurrencyCode("USD");
        info.setDisplaySequence(1);
        info.setJobNumber("TEST_JOB");
        info.setUsed(false);
        info.setCreditor("TEST_CREDITOR");
        info.setInvoiceNo("TEST_INV");
        return info;
    }
}