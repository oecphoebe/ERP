package oec.lis.erpportal.addon.compliance.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

/**
 * Test for ReferenceDataLoader functionality.
 */
@SpringBootTest
@TestPropertySource(properties = {
    "spring.profiles.active=test",
    "spring.cloud.config.enabled=false",
    "spring.kafka.bootstrap-servers=localhost:9092",
    "external.cwis.url=http://localhost:9999",
    "external.compliance.url=http://localhost:9999",
    "external.erpportal.url=http://localhost:9999",
    "external.profile.url=http://localhost:9999",
    "KAFKA_USERNAME=testuser",
    "KAFKA_PASSWORD=testpass",
    "EMAIL_USERNAME=testuser",
    "EMAIL_PASSWORD=testpass",
    "JOB_EMAIL_RECEIPIENTS=test@example.com"
})
class ReferenceDataLoaderTest {

    @Autowired
    private ReferenceDataLoader referenceDataLoader;

    @Test
    void testReferenceDataLoaderExists() {
        assertNotNull(referenceDataLoader, "ReferenceDataLoader should be autowired");
    }

    @Test
    void testExtractTransactionInfo_ValidJson() {
        String validTransactionJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AP",
                            "TransactionType": "INV",
                            "Number": "TEST_001",
                            "IsCancelled": false,
                            "Job": {
                                "Type": "Job",
                                "Key": "TESTJOB001"
                            },
                            "DataContext": {
                                "EventType": {
                                    "Code": "ADD"
                                },
                                "TriggerDate": "2025-08-12T15:46:10.767+08:00"
                            },
                            "PostingJournalCollection": {
                                "PostingJournal": [
                                    {
                                        "ChargeCode": {
                                            "Code": "FRT",
                                            "Description": "Freight Charges"
                                        },
                                        "LocalAmount": 1000.00,
                                        "Sequence": 1
                                    }
                                ]
                            }
                        }
                    }
                }
            }
            """;
        
        // Test our implemented extractTransactionInfo method
        TransactionInfo txnInfo = referenceDataLoader.extractTransactionInfo(validTransactionJson);
        
        assertNotNull(txnInfo, "Should extract transaction info from valid JSON");
        assertEquals("AP", txnInfo.getLedger(), "Should extract correct ledger");
        assertEquals("INV", txnInfo.getTransactionType(), "Should extract correct transaction type");
        assertEquals("TEST_001", txnInfo.getTransactionNo(), "Should extract correct transaction number");
        assertEquals("TESTJOB001", txnInfo.getJobNumber(), "Should extract correct job number");
        assertEquals("ADD", txnInfo.getEventType(), "Should extract correct event type");
        assertFalse(txnInfo.isCancelled(), "Should extract correct cancelled status");
        assertEquals(1, txnInfo.getExpectedLineCount(), "Should extract correct line count");
    }

    @Test
    void testValidateJsonStructure_ValidJson() {
        String validTransactionJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AP",
                            "TransactionType": "INV",
                            "Number": "TEST_001"
                        }
                    }
                }
            }
            """;
        
        boolean isValid = referenceDataLoader.validateJsonStructure(validTransactionJson);
        assertTrue(isValid, "Should validate valid JSON structure");
    }

    @Test
    void testValidateJsonStructure_InvalidJson() {
        String invalidJson = """
            {
                "Body": {
                    "SomethingElse": {}
                }
            }
            """;
        
        boolean isValid = referenceDataLoader.validateJsonStructure(invalidJson);
        assertFalse(isValid, "Should reject invalid JSON structure");
    }

    @Test
    void testShouldSendToKafka_APTransaction() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AP", "INV");
        assertFalse(shouldSend, "AP transactions should not be sent to Kafka in legacy mode");
    }

    @Test
    void testShouldSendToKafka_ARTransaction() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AR", "INV");
        assertTrue(shouldSend, "AR transactions should be sent to Kafka in legacy mode");
    }

    @Test
    void testCreateCargowiseTestData() {
        TransactionInfo txnInfo = TransactionInfo.builder()
            .ledger("AP")
            .transactionType("INV")
            .transactionNo("TEST_001")
            .jobNumber("JOB001")
            .build();
        
        CargowiseTestData testData = referenceDataLoader.createCargowiseTestData(txnInfo);
        
        assertNotNull(testData, "Should create Cargowise test data");
        assertEquals("AP", testData.getLedger(), "Should set correct ledger");
        assertEquals("INV", testData.getTransactionType(), "Should set correct transaction type");
        assertEquals("TEST_001", testData.getTransactionNo(), "Should set correct transaction number");
        assertEquals("JOB001", testData.getJobNumber(), "Should set correct job number");
    }
}