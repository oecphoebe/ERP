package oec.lis.erpportal.addon.compliance.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import oec.lis.erpportal.addon.compliance.config.ShipmentProperties;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.model.transaction.VwShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.service.impl.AtAccountTransactionTableServiceImpl;

/**
 * Unit test for AtAccountTransactionTableServiceImpl to verify our implemented methods.
 * This test uses mocks to avoid Spring context issues.
 */
@ExtendWith(MockitoExtension.class)
class AtAccountTransactionTableServiceImplTest {

    @Mock
    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate;

    @Mock
    private ShipmentProperties shipmentProperties;

    @Mock
    private ShipmentViewService shipmentViewService;

    private AtAccountTransactionTableServiceImpl service;

    @BeforeEach
    void setUp() {
        // Setup default mock behavior for shipment properties (lenient to avoid unnecessary stubbing errors)
        lenient().when(shipmentProperties.isViewEnabled()).thenReturn(false);
        lenient().when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        // Create service with no ShipmentViewService (Optional.empty()) and mocked properties
        service = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.empty(), // No view service for unit tests
            shipmentProperties
        );
    }

    @Test
    void testFindHeadersByTransactionNo_ReturnsEmptyList() {
        // Arrange
        String transactionNo = "TEST_001";
        when(soplNamedJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(List.of());

        // Act
        List<AtAccountTransactionHeaderBean> result = service.findHeadersByTransactionNo(transactionNo);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertTrue(result.isEmpty(), "Result should be empty for non-existent transaction");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindLinesByHeaderPk_ReturnsEmptyList() {
        // Arrange
        Long headerPk = 999L;
        when(soplNamedJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(List.of());

        // Act
        List<AtAccountTransactionLinesBean> result = service.findLinesByHeaderPk(headerPk);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertTrue(result.isEmpty(), "Result should be empty for non-existent header");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_ReturnsNull() {
        // Arrange
        String jobNumber = "NON_EXISTENT_JOB";
        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenThrow(new EmptyResultDataAccessException(1));

        // Act
        AtShipmentInfoBean result = service.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNull(result, "Result should be null for non-existent job");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_ReturnsShipmentInfo() {
        // Arrange
        String jobNumber = "EXISTING_JOB";
        AtShipmentInfoBean mockShipment = new AtShipmentInfoBean();
        mockShipment.setRefNo(jobNumber);
        
        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(mockShipment);

        // Act
        AtShipmentInfoBean result = service.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNotNull(result, "Result should not be null for existing job");
        assertEquals(jobNumber, result.getRefNo(), "Should return correct job number");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindHeadersByTransactionNo_WithData() {
        // Arrange
        String transactionNo = "EXISTING_TXN_001";
        AtAccountTransactionHeaderBean mockHeader = new AtAccountTransactionHeaderBean();
        mockHeader.setTransactionNo(transactionNo);
        mockHeader.setLedger("AP");
        mockHeader.setTransactionType("INV");
        
        when(soplNamedJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(List.of(mockHeader));

        // Act
        List<AtAccountTransactionHeaderBean> result = service.findHeadersByTransactionNo(transactionNo);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertFalse(result.isEmpty(), "Result should not be empty for existing transaction");
        assertEquals(1, result.size(), "Should return one header");
        assertEquals(transactionNo, result.get(0).getTransactionNo(), "Should return correct transaction number");
        assertEquals("AP", result.get(0).getLedger(), "Should return correct ledger");
        assertEquals("INV", result.get(0).getTransactionType(), "Should return correct transaction type");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindLinesByHeaderPk_WithData() {
        // Arrange
        Long headerPk = 123L;
        AtAccountTransactionLinesBean mockLine = new AtAccountTransactionLinesBean();
        mockLine.setChargeCodeId(UUID.randomUUID());
        mockLine.setChargeAmount(new BigDecimal("1000.00"));
        
        when(soplNamedJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(List.of(mockLine));

        // Act
        List<AtAccountTransactionLinesBean> result = service.findLinesByHeaderPk(headerPk);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertFalse(result.isEmpty(), "Result should not be empty for existing header");
        assertEquals(1, result.size(), "Should return one line");
        assertNotNull(result.get(0).getChargeCodeId(), "Should return charge code");
        assertEquals(new BigDecimal("1000.00"), result.get(0).getChargeAmount(), "Should return correct charge amount");
        
        // Verify the correct SQL was called
        verify(soplNamedJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    // NEW TESTS FOR VIEW FUNCTIONALITY

    @Test
    void testFindShipmentByJobNumber_WithViewEnabled_UsesFallback() {
        // Arrange - Create service with view enabled but view service unavailable
        when(shipmentProperties.isViewEnabled()).thenReturn(true);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceWithView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.empty(), // No view service available
            shipmentProperties
        );

        String jobNumber = "TEST_JOB_123";
        AtShipmentInfoBean mockShipment = new AtShipmentInfoBean();
        mockShipment.setRefNo(jobNumber);

        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(mockShipment);

        // Act
        AtShipmentInfoBean result = serviceWithView.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNotNull(result, "Should fall back to table-based implementation");
        assertEquals(jobNumber, result.getRefNo(), "Should return correct job number from fallback");

        // Verify fallback was used (table-based query)
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_WithViewEnabled_UsesViewService() {
        // Arrange - Create service with view enabled and view service available
        when(shipmentProperties.isViewEnabled()).thenReturn(true);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceWithView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.of(shipmentViewService), // View service available
            shipmentProperties
        );

        String jobNumber = "TEST_JOB_123";
        VwShipmentInfoBean mockViewBean = createMockVwShipmentInfoBean(jobNumber);

        when(shipmentViewService.findShipmentByJobNumber(jobNumber))
            .thenReturn(Optional.of(mockViewBean));

        // Act
        AtShipmentInfoBean result = serviceWithView.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNotNull(result, "Should use view service implementation");
        assertEquals(jobNumber, result.getShipmentNo(), "Should return converted shipment data");
        assertEquals("C" + jobNumber.substring(1), result.getConsolNo(), "Should have converted consolidation number");

        // Verify view service was used
        verify(shipmentViewService).findShipmentByJobNumber(jobNumber);
        // Verify table-based query was NOT used
        verify(soplNamedJdbcTemplate, never()).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_WithViewEnabled_ViewNotFound_UsesFallback() {
        // Arrange - View enabled but doesn't find the shipment, should fall back
        when(shipmentProperties.isViewEnabled()).thenReturn(true);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceWithView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.of(shipmentViewService),
            shipmentProperties
        );

        String jobNumber = "NOT_FOUND_JOB";

        // View service returns empty
        when(shipmentViewService.findShipmentByJobNumber(jobNumber))
            .thenReturn(Optional.empty());

        // Table service throws exception (not found)
        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenThrow(new EmptyResultDataAccessException(1));

        // Act
        AtShipmentInfoBean result = serviceWithView.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNull(result, "Should return null when neither view nor table finds the shipment");

        // Verify both view service and fallback were attempted
        verify(shipmentViewService).findShipmentByJobNumber(jobNumber);
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_WithViewEnabled_ViewThrowsException_UsesFallback() {
        // Arrange - View service throws exception, should fall back gracefully
        when(shipmentProperties.isViewEnabled()).thenReturn(true);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceWithView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.of(shipmentViewService),
            shipmentProperties
        );

        String jobNumber = "ERROR_JOB";
        AtShipmentInfoBean mockShipment = new AtShipmentInfoBean();
        mockShipment.setRefNo(jobNumber);

        // View service throws exception
        when(shipmentViewService.findShipmentByJobNumber(jobNumber))
            .thenThrow(new RuntimeException("View service error"));

        // Table service returns data
        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(mockShipment);

        // Act
        AtShipmentInfoBean result = serviceWithView.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNotNull(result, "Should fall back to table service when view throws exception");
        assertEquals(jobNumber, result.getRefNo(), "Should return data from fallback");

        // Verify both attempts were made
        verify(shipmentViewService).findShipmentByJobNumber(jobNumber);
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
    }

    @Test
    void testFindShipmentByJobNumber_WithViewDisabled_UsesTableOnly() {
        // Arrange - View explicitly disabled
        when(shipmentProperties.isViewEnabled()).thenReturn(false);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceNoView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.of(shipmentViewService), // Service available but disabled by config
            shipmentProperties
        );

        String jobNumber = "TABLE_ONLY_JOB";
        AtShipmentInfoBean mockShipment = new AtShipmentInfoBean();
        mockShipment.setRefNo(jobNumber);

        when(soplNamedJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class)))
            .thenReturn(mockShipment);

        // Act
        AtShipmentInfoBean result = serviceNoView.findShipmentByJobNumber(jobNumber);

        // Assert
        assertNotNull(result, "Should use table-based implementation when view is disabled");
        assertEquals(jobNumber, result.getRefNo(), "Should return correct job number");

        // Verify only table service was used
        verify(soplNamedJdbcTemplate).queryForObject(anyString(), any(MapSqlParameterSource.class), any(BeanPropertyRowMapper.class));
        // Verify view service was NOT used
        verify(shipmentViewService, never()).findShipmentByJobNumber(anyString());
    }

    @Test
    void testConvertViewToAtShipmentInfo_ConvertsCorrectly() {
        // This test verifies the conversion logic from VwShipmentInfoBean to AtShipmentInfoBean
        // We can't test the private method directly, but we can test it through the public method

        // Arrange
        when(shipmentProperties.isViewEnabled()).thenReturn(true);
        when(shipmentProperties.isFallbackEnabled()).thenReturn(true);

        AtAccountTransactionTableServiceImpl serviceWithView = new AtAccountTransactionTableServiceImpl(
            soplNamedJdbcTemplate,
            cargowiseNamedJdbcTemplate,
            Optional.of(shipmentViewService),
            shipmentProperties
        );

        String jobNumber = "CONVERT_TEST";
        VwShipmentInfoBean mockViewBean = createMockVwShipmentInfoBean(jobNumber);

        when(shipmentViewService.findShipmentByJobNumber(jobNumber))
            .thenReturn(Optional.of(mockViewBean));

        // Act
        AtShipmentInfoBean result = serviceWithView.findShipmentByJobNumber(jobNumber);

        // Assert - Verify conversion was done correctly
        assertNotNull(result, "Conversion should produce a valid result");
        assertEquals(mockViewBean.getShipmentNo(), result.getShipmentNo(), "Shipment number should be converted");
        assertEquals(mockViewBean.getConsolNo(), result.getConsolNo(), "Consolidation number should be converted");
        assertEquals(mockViewBean.getHblNo(), result.getHblNo(), "HBL number should be converted");
        assertEquals(mockViewBean.getMblNo(), result.getMblNo(), "MBL number should be converted");
        assertEquals(mockViewBean.getCarrierBookNo(), result.getCarrierBookingNo(), "Carrier booking should be converted");
        assertEquals(mockViewBean.getShipmentType(), result.getShipmentType(), "Shipment type should be converted");
        assertEquals(mockViewBean.getConsolType(), result.getConsolType(), "Consolidation type should be converted");
    }

    /**
     * Helper method to create a mock VwShipmentInfoBean for testing
     */
    private VwShipmentInfoBean createMockVwShipmentInfoBean(String jobNumber) {
        VwShipmentInfoBean bean = new VwShipmentInfoBean();
        bean.setShipmentNo(jobNumber);
        bean.setConsolNo("C" + jobNumber.substring(1)); // Generate corresponding consol number
        bean.setHblNo("HBL" + jobNumber.substring(1));
        bean.setMblNo("MBL" + jobNumber.substring(1));
        bean.setMasterMbl("MASTER" + jobNumber.substring(1));
        bean.setCarrierBookNo("CBK" + jobNumber.substring(1));
        bean.setShipmentType("SEA");
        bean.setConsolType("FCL");
        bean.setConsolFirstLegVessel("TEST VESSEL");
        bean.setConsolFirstLegVoyage("V001");
        return bean;
    }
}