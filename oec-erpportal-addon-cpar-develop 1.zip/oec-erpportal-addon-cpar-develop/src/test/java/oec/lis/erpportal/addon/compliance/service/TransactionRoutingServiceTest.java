package oec.lis.erpportal.addon.compliance.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

import oec.lis.erpportal.addon.compliance.common.config.TransactionRoutingConfig;
import oec.lis.erpportal.addon.compliance.common.config.TransactionRoutingConfig.RoutingRule;

/**
 * Unit tests for TransactionRoutingService
 */
@ExtendWith({MockitoExtension.class, OutputCaptureExtension.class})
class TransactionRoutingServiceTest {

    @Mock
    private TransactionRoutingConfig config;

    private TransactionRoutingService routingService;

    @BeforeEach
    void setUp() {
        routingService = new TransactionRoutingService(config);
    }

    @Test
    void testLegacyMode_ARSendsToExternal() {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AR", "INV")).thenReturn(true);

        // When: AR INV transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AR", "INV", "TEST001");

        // Then: Should send to external system
        assertTrue(result);
    }

    @Test
    void testLegacyMode_ARCRDSendsToExternal() {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AR", "CRD")).thenReturn(true);

        // When: AR CRD transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AR", "CRD", "TEST002");

        // Then: Should send to external system
        assertTrue(result);
    }

    @Test
    void testLegacyMode_APDoesNotSendToExternal() {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AP", "CRD")).thenReturn(false);

        // When: AP CRD transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AP", "CRD", "TEST003");

        // Then: Should NOT send to external system
        assertFalse(result);
    }

    @Test
    void testLegacyMode_APINVDoesNotSendToExternal() {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AP", "INV")).thenReturn(false);

        // When: AP INV transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AP", "INV", "TEST004");

        // Then: Should NOT send to external system
        assertFalse(result);
    }

    @Test
    void testConfigMode_APCRDSendsToExternal() {
        // Given: Legacy mode is disabled and AP CRD is configured to send
        when(config.isEnableLegacyMode()).thenReturn(false);
        when(config.shouldSendToExternal("AP", "CRD")).thenReturn(true);
        when(config.findRuleDescription("AP", "CRD")).thenReturn("AP Credit Note to China Compliance System");

        // When: AP CRD transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AP", "CRD", "TEST005");

        // Then: Should send to external system
        assertTrue(result);
    }

    @Test
    void testConfigMode_APINVDoesNotSendToExternal() {
        // Given: Legacy mode is disabled and AP INV is configured NOT to send
        when(config.isEnableLegacyMode()).thenReturn(false);
        when(config.shouldSendToExternal("AP", "INV")).thenReturn(false);
        when(config.findRuleDescription("AP", "INV")).thenReturn("AP Invoice - Database only");

        // When: AP INV transaction is evaluated
        boolean result = routingService.shouldSendToExternalSystem("AP", "INV", "TEST006");

        // Then: Should NOT send to external system
        assertFalse(result);
    }

    @Test
    void testConfigMode_ARTransactionsStillSendToExternal() {
        // Given: Legacy mode is disabled and AR is configured to send
        when(config.isEnableLegacyMode()).thenReturn(false);
        when(config.shouldSendToExternal("AR", "INV")).thenReturn(true);
        when(config.shouldSendToExternal("AR", "CRD")).thenReturn(true);
        when(config.findRuleDescription("AR", "INV")).thenReturn("AR Invoice to China Compliance System");
        when(config.findRuleDescription("AR", "CRD")).thenReturn("AR Credit Note to China Compliance System");

        // When: AR transactions are evaluated
        boolean arInvResult = routingService.shouldSendToExternalSystem("AR", "INV", "TEST007");
        boolean arCrdResult = routingService.shouldSendToExternalSystem("AR", "CRD", "TEST008");

        // Then: Both should send to external system
        assertTrue(arInvResult);
        assertTrue(arCrdResult);
    }

    @Test
    void testAuditLoggingFormat_LegacyMode(CapturedOutput output) {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AR", "INV")).thenReturn(true);

        // When: Transaction is evaluated
        routingService.shouldSendToExternalSystem("AR", "INV", "TEST009");

        // Then: Audit log should contain expected format
        assertTrue(output.getOut().contains("ROUTING_AUDIT [LEGACY_MODE]"));
        assertTrue(output.getOut().contains("Transaction=TEST009"));
        assertTrue(output.getOut().contains("Ledger=AR"));
        assertTrue(output.getOut().contains("Type=INV"));
        assertTrue(output.getOut().contains("Decision=SEND_EXTERNAL"));
    }

    @Test
    void testAuditLoggingFormat_ConfigMode(CapturedOutput output) {
        // Given: Config mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(false);
        when(config.shouldSendToExternal("AP", "CRD")).thenReturn(true);
        when(config.findRuleDescription("AP", "CRD")).thenReturn("AP Credit Note to China Compliance System");

        // When: Transaction is evaluated
        routingService.shouldSendToExternalSystem("AP", "CRD", "TEST010");

        // Then: Audit log should contain expected format
        assertTrue(output.getOut().contains("ROUTING_AUDIT [CONFIG_MODE]"));
        assertTrue(output.getOut().contains("Transaction=TEST010"));
        assertTrue(output.getOut().contains("Ledger=AP"));
        assertTrue(output.getOut().contains("Type=CRD"));
        assertTrue(output.getOut().contains("Decision=SEND_EXTERNAL"));
        assertTrue(output.getOut().contains("Rule=AP Credit Note to China Compliance System"));
    }

    @Test
    void testGetRoutingMode() {
        // Test legacy mode
        when(config.isEnableLegacyMode()).thenReturn(true);
        assertEquals("LEGACY", routingService.getRoutingMode());

        // Test config mode
        when(config.isEnableLegacyMode()).thenReturn(false);
        assertEquals("CONFIG", routingService.getRoutingMode());
    }

    @Test
    void testIsLegacyModeEnabled() {
        // Test when legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        assertTrue(routingService.isLegacyModeEnabled());

        // Test when legacy mode is disabled
        when(config.isEnableLegacyMode()).thenReturn(false);
        assertFalse(routingService.isLegacyModeEnabled());
    }

    @Test
    void testUnknownTransactionType_ConfigMode() {
        // Given: Config mode with no matching rule
        when(config.isEnableLegacyMode()).thenReturn(false);
        when(config.shouldSendToExternal("XX", "YYY")).thenReturn(false);
        when(config.findRuleDescription("XX", "YYY")).thenReturn("No matching rule");

        // When: Unknown transaction type is evaluated
        boolean result = routingService.shouldSendToExternalSystem("XX", "YYY", "TEST011");

        // Then: Should NOT send to external system (default behavior)
        assertFalse(result);
    }

    @Test
    void testTransactionWithoutNumber() {
        // Given: Legacy mode is enabled
        when(config.isEnableLegacyMode()).thenReturn(true);
        when(config.shouldSendToExternal("AR", "INV")).thenReturn(true);

        // When: Transaction is evaluated without transaction number
        boolean result = routingService.shouldSendToExternalSystem("AR", "INV");

        // Then: Should still work and return correct result
        assertTrue(result);
    }
}