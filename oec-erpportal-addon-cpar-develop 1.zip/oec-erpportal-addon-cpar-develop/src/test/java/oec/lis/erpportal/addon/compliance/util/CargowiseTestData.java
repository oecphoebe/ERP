package oec.lis.erpportal.addon.compliance.util;

import lombok.Builder;
import lombok.Data;

/**
 * Test data for seeding Cargowise SQL Server database
 */
@Data
@Builder
public class CargowiseTestData {
    private String transactionNo;
    private String ledger;
    private String transactionType;
    private String jobNumber;
    private String organizationCode;
    private String chargeCode;
    private String creditorCode;
    private String debtorCode;

    /**
     * Generates SQL statements for inserting test data into Cargowise database
     */
    public String generateInsertSQL() {
        StringBuilder sql = new StringBuilder();
        
        // Insert AccTransactionHeader
        sql.append("INSERT INTO AccTransactionHeader (AH_TransactionNum, AH_Ledger, AH_TransactionType, AH_PK) ")
           .append("VALUES ('").append(transactionNo).append("', '")
           .append(ledger).append("', '")
           .append(transactionType).append("', ")
           .append(generatePK()).append(");\n");
        
        // Insert related organization if specified
        if (organizationCode != null) {
            sql.append("INSERT INTO OrgHeader (OH_Code, OH_PK) VALUES ('")
               .append(organizationCode).append("', ")
               .append(generateOrgPK()).append(");\n");
        }
        
        // Insert job header if specified
        if (jobNumber != null) {
            sql.append("INSERT INTO JobHeader (JH_JobNum, JH_PK) VALUES ('")
               .append(jobNumber).append("', ")
               .append(generateJobPK()).append(");\n");
        }
        
        return sql.toString();
    }

    private long generatePK() {
        return Math.abs(transactionNo.hashCode());
    }

    private long generateOrgPK() {
        return Math.abs((organizationCode != null ? organizationCode : "DEFAULT").hashCode());
    }

    private long generateJobPK() {
        return Math.abs((jobNumber != null ? jobNumber : "DEFAULT").hashCode());
    }
}