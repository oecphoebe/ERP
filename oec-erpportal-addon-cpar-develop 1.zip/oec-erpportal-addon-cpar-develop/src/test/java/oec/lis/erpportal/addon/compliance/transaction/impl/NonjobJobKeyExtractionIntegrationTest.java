package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

/**
 * Integration test for NONJOB Job.Key extraction using real sample JSON files.
 *
 * This test validates the JSON structure and JsonPath extraction logic for
 * extracting shipmentId from TransactionInfo.Job.Key when Job.Type equals "Job"
 * for NONJOB transactions.
 *
 * NOTE: These are JSON structure validation tests that don't require Spring context.
 */
@Slf4j
public class NonjobJobKeyExtractionIntegrationTest {

    private String loadJsonFile(String filename) throws IOException {
        // Try to load from test resources first
        Path resourcePath = Paths.get("src/test/resources/reference/" + filename);
        if (!Files.exists(resourcePath)) {
            // Fallback to reference directory
            resourcePath = Paths.get("reference/" + filename);
        }

        if (!Files.exists(resourcePath)) {
            throw new IOException("Test file not found: " + filename);
        }

        return Files.readString(resourcePath);
    }

    @Test
    void testNonjobWithJobKey_ExtractsShipmentId() throws Exception {
        // This file has Job.Type="Job" AND Job.Key="WI00000056"
        String jsonPayload = loadJsonFile("NonJob_AP_INV_WI00000056_A_ADD.json");

        // Verify the JSON has Job.Key using JsonPath
        String jobType = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        String jobKey = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");

        log.info("Test payload has Job.Type=[{}] and Job.Key=[{}]", jobType, jobKey);

        assertEquals("Job", jobType, "Test file should have Job.Type='Job'");
        assertEquals("WI00000056", jobKey, "Test file should have Job.Key='WI00000056'");

        // Note: This is a validation test to ensure the JSON structure is correct
        // The full end-to-end processing requires database mocking which is handled by V2 integration tests
        // This test focuses on verifying the JSON structure matches our expectations
        assertTrue(true, "JSON structure validated successfully for NONJOB with Job.Key");
    }

    @Test
    void testNonjobWithoutJobKey_HasOnlyJobType() throws Exception {
        // This file has Job.Type="Job" but NO Job.Key field
        String jsonPayload = loadJsonFile("NonJob_AR_INV_2510001001_ADD.json");

        // Verify the JSON has Job.Type but no Job.Key
        String jobType = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");

        log.info("Test payload has Job.Type=[{}]", jobType);

        assertEquals("Job", jobType, "Test file should have Job.Type='Job'");

        // Try to read Job.Key - should throw PathNotFoundException or return null
        try {
            String jobKey = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");
            assertNull(jobKey, "Job.Key should be null or not exist");
        } catch (com.jayway.jsonpath.PathNotFoundException e) {
            // Expected - Job.Key field doesn't exist
            log.info("Job.Key field not found as expected: {}", e.getMessage());
        }

        assertTrue(true, "JSON structure validated successfully for NONJOB without Job.Key");
    }

    @Test
    void testShipmentJsonStructure_NotAffected() throws Exception {
        // Verify that regular SHIPMENT files still have DataSourceCollection structure
        String jsonPayload = loadJsonFile("AR_INV_2508001034.json");

        // Verify this is a SHIPMENT type with DataSourceCollection
        java.util.List<String> shipmentKeys = JsonPath.read(jsonPayload,
            "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key");

        log.info("SHIPMENT test payload has shipmentKeys=[{}]", shipmentKeys);

        assertNotNull(shipmentKeys, "SHIPMENT file should have shipmentKey in DataSourceCollection");
        assertFalse(shipmentKeys.isEmpty(), "ShipmentKeys list should not be empty");

        String shipmentKey = shipmentKeys.get(0);
        assertNotNull(shipmentKey, "First shipmentKey should not be null");
        assertTrue(shipmentKey.startsWith("S"), "SHIPMENT key should start with 'S'");

        log.info("SHIPMENT JSON structure validated - not affected by NONJOB logic");
    }

    @Test
    void testJsonPathExtraction_NonjobWithJobKey() {
        // Direct JsonPath test to validate extraction logic
        String testJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Job": {
                                "Type": "Job",
                                "Key": "TEST_KEY_123"
                            }
                        }
                    }
                }
            }
            """;

        // Test the extraction logic used in TransactionMappingService
        String jobType = JsonPath.read(testJson, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        String jobKey = JsonPath.read(testJson, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");

        assertEquals("Job", jobType);
        assertEquals("TEST_KEY_123", jobKey);

        log.info("JsonPath extraction validated: Type=[{}], Key=[{}]", jobType, jobKey);
    }

    @Test
    void testJsonPathExtraction_NonjobWithoutJobKey() {
        // Direct JsonPath test for NONJOB without Job.Key
        String testJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Job": {
                                "Type": "Job"
                            }
                        }
                    }
                }
            }
            """;

        // Test the extraction logic
        String jobType = JsonPath.read(testJson, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        assertEquals("Job", jobType);

        // Try to read Job.Key - should fail
        assertThrows(com.jayway.jsonpath.PathNotFoundException.class, () -> {
            JsonPath.read(testJson, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");
        }, "Should throw PathNotFoundException when Job.Key doesn't exist");

        log.info("JsonPath extraction validated for missing Job.Key");
    }

    @Test
    void testJsonPathExtraction_NoJobObject() {
        // Direct JsonPath test for transaction without Job object
        String testJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Number": "TEST123"
                        }
                    }
                }
            }
            """;

        // Try to read Job.Type - should fail
        assertThrows(com.jayway.jsonpath.PathNotFoundException.class, () -> {
            JsonPath.read(testJson, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        }, "Should throw PathNotFoundException when Job object doesn't exist");

        log.info("JsonPath extraction validated for missing Job object");
    }

    // ========== NEW TESTS FOR FALLBACK LOGIC ==========

    @Test
    void testNonjobFallback_JobKeyMissing_UsesDataSourceCollection() throws Exception {
        // This file has Job.Type="Job" but NO Job.Key - should fall back to DataSourceCollection
        String jsonPayload = loadJsonFile("NonJob-AR_INV_2511001019-Add.json");

        // Verify the JSON has Job.Type but no Job.Key
        String jobType = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        assertEquals("Job", jobType, "Test file should have Job.Type='Job'");

        // Verify Job.Key doesn't exist
        try {
            String jobKey = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");
            assertNull(jobKey, "Job.Key should be null or not exist");
        } catch (com.jayway.jsonpath.PathNotFoundException e) {
            log.info("Job.Key field not found as expected (will trigger fallback): {}", e.getMessage());
        }

        // Verify DataSourceCollection has AccountingInvoice
        java.util.List<String> accountingInvoiceKeys = JsonPath.read(jsonPayload,
            "$.Body.UniversalTransaction.TransactionInfo.DataContext.DataSourceCollection.DataSource[?(@.Type=='AccountingInvoice')].Key");

        log.info("Fallback test: accountingInvoiceKeys=[{}]", accountingInvoiceKeys);

        assertNotNull(accountingInvoiceKeys, "DataSourceCollection should have AccountingInvoice entries");
        assertFalse(accountingInvoiceKeys.isEmpty(), "AccountingInvoice keys should not be empty");

        String accountingInvoiceKey = accountingInvoiceKeys.get(0);
        assertEquals("AR INV 2511001019", accountingInvoiceKey, "Raw key should contain spaces");

        // Verify whitespace trimming logic
        String trimmedKey = accountingInvoiceKey.replaceAll("\\s+", "");
        assertEquals("ARINV2511001019", trimmedKey, "Trimmed key should have all whitespace removed");

        log.info("Fallback extraction validated: raw=[{}], trimmed=[{}]", accountingInvoiceKey, trimmedKey);
    }

    @Test
    void testNonjobPrimary_JobKeyPresent_IgnoresDataSourceCollection() throws Exception {
        // This file has BOTH Job.Key AND DataSourceCollection - primary (Job.Key) should take precedence
        String jsonPayload = loadJsonFile("NonJob_AR_INV_2511001018-ADD.json");

        // Verify Job.Key exists (primary path)
        String jobType = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Type");
        String jobKey = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo.Job.Key");

        assertEquals("Job", jobType, "Test file should have Job.Type='Job'");
        assertEquals("WI00000077", jobKey, "Primary extraction should get Job.Key");

        // Verify DataSourceCollection also exists (but should be ignored)
        java.util.List<String> accountingInvoiceKeys = JsonPath.read(jsonPayload,
            "$.Body.UniversalTransaction.TransactionInfo.DataContext.DataSourceCollection.DataSource[?(@.Type=='AccountingInvoice')].Key");

        assertNotNull(accountingInvoiceKeys, "DataSourceCollection also exists");
        assertFalse(accountingInvoiceKeys.isEmpty(), "But should be ignored when Job.Key is present");

        String fallbackValue = accountingInvoiceKeys.get(0);
        log.info("Primary path test: Job.Key=[{}] should take precedence over DataSourceCollection=[{}]",
            jobKey, fallbackValue);

        // The logic should use Job.Key (WI00000077), not DataSourceCollection (AR INV 2511001018)
        assertNotEquals(jobKey, fallbackValue, "Primary and fallback values should differ (validates precedence)");
    }

    @Test
    void testWhitespaceTrimming_RemovesAllSpaces() {
        // Direct JsonPath test for whitespace trimming logic
        String testJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "DataContext": {
                                "DataSourceCollection": {
                                    "DataSource": [
                                        {
                                            "Type": "AccountingInvoice",
                                            "Key": "AR INV 2511001018"
                                        }
                                    ]
                                }
                            }
                        }
                    }
                }
            }
            """;

        // Extract the raw value with whitespace
        java.util.List<String> keys = JsonPath.read(testJson,
            "$.Body.UniversalTransaction.TransactionInfo.DataContext.DataSourceCollection.DataSource[?(@.Type=='AccountingInvoice')].Key");

        assertNotNull(keys);
        assertEquals(1, keys.size());

        String rawKey = keys.get(0);
        assertEquals("AR INV 2511001018", rawKey, "Raw value should contain spaces");

        // Test whitespace trimming logic
        String trimmedKey = rawKey.replaceAll("\\s+", "");
        assertEquals("ARINV2511001018", trimmedKey, "Trimmed value should have all whitespace removed");

        // Test with various whitespace patterns
        assertEquals("TEST", "  TEST  ".replaceAll("\\s+", ""), "Leading/trailing spaces removed");
        assertEquals("TEST123", "TEST 123".replaceAll("\\s+", ""), "Internal spaces removed");
        assertEquals("TEST", "  T E S T  ".replaceAll("\\s+", ""), "Multiple spaces removed");
        assertEquals("", "   ".replaceAll("\\s+", ""), "Whitespace-only becomes empty string");

        log.info("Whitespace trimming validated: [{}] -> [{}]", rawKey, trimmedKey);
    }

    @Test
    void testDataSourceCollection_MultipleEntries_UsesFirst() {
        // Test with multiple DataSource entries to ensure first match is used
        String testJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "DataContext": {
                                "DataSourceCollection": {
                                    "DataSource": [
                                        {
                                            "Type": "AccountingInvoice",
                                            "Key": "AR INV FIRST"
                                        },
                                        {
                                            "Type": "AccountingInvoice",
                                            "Key": "AR INV SECOND"
                                        },
                                        {
                                            "Type": "Other",
                                            "Key": "OTHER VALUE"
                                        }
                                    ]
                                }
                            }
                        }
                    }
                }
            }
            """;

        // Extract all AccountingInvoice entries
        java.util.List<String> keys = JsonPath.read(testJson,
            "$.Body.UniversalTransaction.TransactionInfo.DataContext.DataSourceCollection.DataSource[?(@.Type=='AccountingInvoice')].Key");

        assertNotNull(keys);
        assertEquals(2, keys.size(), "Should find 2 AccountingInvoice entries");

        // First match should be used
        String firstKey = keys.get(0);
        assertEquals("AR INV FIRST", firstKey, "First match should be 'AR INV FIRST'");

        String secondKey = keys.get(1);
        assertEquals("AR INV SECOND", secondKey, "Second match should be 'AR INV SECOND'");

        log.info("Multiple entries test: Found {} AccountingInvoice entries, first=[{}]", keys.size(), firstKey);
    }
}
