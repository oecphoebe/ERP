package oec.lis.erpportal.addon.compliance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.annotation.Commit;
import org.springframework.test.web.servlet.MvcResult;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.util.BaseTransactionIntegrationTest;

/**
 * V2 Integration test for AP_CRD_AS20250819_7_C.json payload demonstrating utility-based testing.
 * 
 * This test validates the complete AP Credit Note flow using the new utility classes:
 * - Extends BaseTransactionIntegrationTest for common setup  
 * - Uses utility classes for all common operations
 * - Focuses on test logic rather than infrastructure
 * - Significantly reduced code complexity (~300 lines vs 1400+ in original)
 * 
 * Test Scenario:
 * 1. AP Credit Note transaction (PARTIAL result expected)
 * 2. AMS Security Surcharge line gets filtered out
 * 3. SHIPMENT type transaction with buyer lookup  
 * 4. Should send to external but blocked by filtered charge lines
 */
@Slf4j
class APCreditNoteAS20250819_7_CIntegrationTestV2 extends BaseTransactionIntegrationTest {

    private String testPayloadJson;
    private Map<String, Integer> initialCounts;

    @Override
    protected void setupSpecificTestData() throws Exception {
        // Setup Cargowise test data specific to AP Credit Note
        setupCargowiseTestData(getTestDataSqlFile());
        
        // Verify critical test data was loaded
        Map<String, Object> expectedData = new HashMap<>();
        expectedData.put("jobNumber", "SSSH1250818463");
        expectedData.put("shipmentRef", "SSSH1250818463");
        expectedData.put("transactionNumber", "AS20250819_7/C");
        expectedData.put("chargeCodes", List.of("AMS"));
        
        try (Connection conn = getSqlServerConnection()) {
            sqlUtils.verifyCargowiseTestData(conn, expectedData);
        }
    }

    @Override
    protected String getTestDataSqlFile() {
        return "test-data-cargowise-AS20250819_7_C.sql";
    }

    @BeforeEach
    void setupTest() throws Exception {
        log.info("Setting up AP Credit Note test with utility-based configuration...");
        
        // Load and validate test payload
        testPayloadJson = payloadLoader.loadAndValidatePayload("reference/AP_CRD_AS20250819_7_C.json");
        
        // Log payload summary for debugging
        payloadLoader.logPayloadSummary(testPayloadJson);
        
        // Setup mocks using utility - for CMACGMORF organization (the creditor)
        mockUtils.setupBuyerInfoMock(globalTableService, "CMACGMORF", "CMA CGM S.A.");
        mockUtils.setupAPCreditNoteRouting(transactionRoutingService, "AS20250819_7/C");
        
        // Setup specific test data
        setupSpecificTestData();
        
        // Record initial database state
        try (Connection conn = getPostgresConnection()) {
            initialCounts = new HashMap<>();
            initialCounts.put("at_account_transaction_header", databaseUtils.countRecordsInTable(conn, "at_account_transaction_header"));
            initialCounts.put("at_account_transaction_lines", databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines"));
            initialCounts.put("at_shipment_info", databaseUtils.countRecordsInTable(conn, "at_shipment_info"));
            initialCounts.put("sys_api_log", databaseUtils.countRecordsInTable(conn, "sys_api_log"));
        }
        
        log.info("Initial DB state: {}", initialCounts);
    }

    /**
     * Test 1: Complete AP Credit Note processing flow expecting PARTIAL result
     */
    @Test
    @Commit
    void testAPCreditNoteCompleteProcessingFlow() throws Exception {
        log.info("=== Testing AP_CRD_AS20250819_7_C.json complete processing flow (V2) ===");
        
        // Execute endpoint using base class utility
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        log.info("Response: {}", responseBody);

        // Verify database changes using utilities
        try (Connection conn = getPostgresConnection()) {
            // Wait for async processing
            databaseUtils.waitForDatabaseRecords(conn, "at_account_transaction_header", 1, 10);
            
            Map<String, Integer> expectedIncrements = new HashMap<>();
            expectedIncrements.put("at_account_transaction_header", 1);
            expectedIncrements.put("at_account_transaction_lines", 1); // AMS charge
            expectedIncrements.put("at_shipment_info", 1);
            expectedIncrements.put("sys_api_log", 1);
            
            verificationUtils.verifyDatabaseChanges(conn, initialCounts, expectedIncrements);
            
            // Verify PARTIAL status (configured to send to external but blocked by filtered charge lines)
            verificationUtils.verifyTransactionStatus(conn, "PARTIAL", null);
        }
        
        // Verify mock interactions
        mockUtils.verifyServiceInteractions(globalTableService);
        
        log.info("=== Complete processing flow test PASSED (V2) ===");
    }

    /**
     * Test 2: Transaction header data verification using utilities  
     */
    @Test
    @Commit
    void testTransactionHeaderDataPersistence() throws Exception {
        log.info("=== Testing transaction header data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify transaction header using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "at_account_transaction_header", 1, 10);
            
            Map<String, Object> expectedHeader = new HashMap<>();
            expectedHeader.put("transactionNumber", "AS20250819_7/C");
            expectedHeader.put("ledger", "AP");
            expectedHeader.put("transactionType", "CRD");
            expectedHeader.put("organizationCode", "CMACGMORF");
            expectedHeader.put("invoiceAmount", 1000.0000);
            
            verificationUtils.verifyTransactionHeader(conn, expectedHeader);
        }
        
        log.info("=== Transaction header data test PASSED (V2) ===");
    }

    /**
     * Test 3: Transaction lines data verification using utilities
     */
    @Test
    @Commit
    void testTransactionLinesDataPersistence() throws Exception {
        log.info("=== Testing transaction lines data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify transaction lines using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "at_account_transaction_lines", 1, 10);
            
            // AMS Security Surcharge line
            Map<String, Object> amsLine = new HashMap<>();
            amsLine.put("description", "AMS Security Surcharge_CRD");
            amsLine.put("chargeAmount", 1000.0000);
            amsLine.put("totalAmount", 1000.0000);
            
            List<Map<String, Object>> expectedLines = List.of(amsLine);
            verificationUtils.verifyTransactionLines(conn, "AS20250819_7/C", expectedLines);
        }
        
        log.info("=== Transaction lines data test PASSED (V2) ===");
    }

    /**
     * Test 4: Shipment info data verification using utilities
     */
    @Test
    @Commit
    void testShipmentInfoDataPersistence() throws Exception {
        log.info("=== Testing shipment info data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify shipment info using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "at_shipment_info", 1, 10);
            
            Map<String, Object> expectedShipment = new HashMap<>();
            expectedShipment.put("hblNumber", "OERT201702Y00589");
            expectedShipment.put("containerMode", "LCL");
            expectedShipment.put("shipmentType", "LCL");
            
            verificationUtils.verifyShipmentInfo(conn, "SSSH1250818463", expectedShipment);
        }
        
        log.info("=== Shipment info data test PASSED (V2) ===");
    }

    /**
     * Test 5: API log verification for PARTIAL result
     */
    @Test
    @Commit
    void testApiLogCreationForPartialResult() throws Exception {
        log.info("=== Testing API log creation for PARTIAL result (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify API log using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "sys_api_log", 1, 10);
            
            // AP Credit Note should result in PARTIAL status
            // (configured to send to external but blocked by filtered charge lines)
            verificationUtils.verifyApiLog(conn, "PARTIAL", "API14");
        }
        
        log.info("=== API log creation test PASSED (V2) ===");
    }

    /**
     * Test 6: Complete flow verification using single utility call
     */
    @Test
    @Commit
    void testCompleteFlowWithSingleVerification() throws Exception {
        log.info("=== Testing complete flow with single verification call (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify everything with one utility call
        try (Connection conn = getPostgresConnection()) {
            verificationUtils.verifyCompleteTransactionFlow(conn, "AS20250819_7/C");
        }
        
        log.info("=== Complete flow single verification test PASSED (V2) ===");
    }

    /**
     * Test 7: Transaction routing investigation for AP Credit Note
     */
    @Test
    void testAPCreditNoteRoutingInvestigation() throws Exception {
        log.info("=== Investigating AP Credit Note routing configuration (V2) ===");
        
        // Use investigation utilities to analyze routing
        investigationUtils.analyzeTransactionFlow(applicationContext, "AP", "CRD");
        investigationUtils.findAPProcessingBeans(applicationContext);
        investigationUtils.detectAlternativeProcessingPaths(applicationContext, "AP", "CRD");
        
        // Check environment configuration
        investigationUtils.inspectEnvironmentConfiguration(applicationContext, 
            "transaction.routing.enable-legacy-mode",
            "transaction.nonjob.enabled",
            "transaction.routing.rules[3].ledger",
            "transaction.routing.rules[3].send-to-external-system");
        
        log.info("=== AP Credit Note routing investigation COMPLETE (V2) ===");
    }

    /**
     * Test 8: Database transaction boundary analysis using utilities
     */
    @Test
    @Commit
    void testDatabaseTransactionBoundaries() throws Exception {
        log.info("=== Testing database transaction boundaries (V2) ===");
        
        // Before API call - debug initial state
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.debugAllTables(conn);
        }
        
        // Execute API call
        executeTransaction(testPayloadJson);
        
        // Force any pending transactions to complete
        try (Connection conn = getPostgresConnection()) {
            if (!conn.getAutoCommit()) {
                conn.commit();
            }
            
            // Check immediate post-call state
            log.info("Database state immediately after API call:");
            databaseUtils.debugAllTables(conn);
            
            // Wait and recheck
            Thread.sleep(2000);
            log.info("Database state after 2-second wait:");
            databaseUtils.debugAllTables(conn);
        }
        
        log.info("=== Database transaction boundaries test COMPLETE (V2) ===");
    }

    /**
     * Test 9: NONJOB vs SHIPMENT type analysis
     */
    @Test
    void testTransactionTypeAnalysis() throws Exception {
        log.info("=== Analyzing NONJOB vs SHIPMENT transaction type (V2) ===");
        
        // Check transaction type using application services
        try {
            oec.lis.erpportal.addon.compliance.transaction.impl.TransactionQueryService transactionQueryService = 
                applicationContext.getBean(oec.lis.erpportal.addon.compliance.transaction.impl.TransactionQueryService.class);
            
            List<oec.lis.erpportal.addon.compliance.model.transaction.RefNoInfo> refNoList = 
                transactionQueryService.getRefNo("AP", "CRD", "AS20250819_7/C");
            
            log.info("RefNo analysis result count: {}", refNoList.size());
            
            if (!refNoList.isEmpty()) {
                oec.lis.erpportal.addon.compliance.model.transaction.RefNoInfo refInfo = refNoList.get(0);
                log.info("RefNo type: {}", refInfo.getRefNoType());
                log.info("RefNo value: {}", refInfo.getRefNo());
                
                // Verify this is SHIPMENT type (not NONJOB)
                assertThat(refInfo.getRefNoType()).isEqualTo("SHIPMENT");
                assertThat(refInfo.getRefNo()).isEqualTo("SSSH1250818463");
            } else {
                log.error("No RefNo information found - this indicates a configuration or data issue");
            }
            
        } catch (Exception e) {
            log.error("Transaction type analysis failed: {}", e.getMessage(), e);
        }
        
        log.info("=== Transaction type analysis COMPLETE (V2) ===");
    }
}