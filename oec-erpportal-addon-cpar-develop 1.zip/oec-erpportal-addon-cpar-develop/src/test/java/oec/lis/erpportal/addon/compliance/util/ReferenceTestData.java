package oec.lis.erpportal.addon.compliance.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * Test data wrapper for reference JSON files.
 * Encapsulates transaction information and test expectations.
 */
@Data
@Builder
@Slf4j
public class ReferenceTestData {
    
    private String filename;
    private String payloadJson;
    private String expectedLedger;
    private String expectedTransactionType;
    private String expectedTransactionNo;
    private String expectedJobNumber;
    private String expectedEventType;
    private boolean expectedIsCancelled;
    private int expectedLineCount;
    private boolean shouldSendToKafka;

    /**
     * Creates ReferenceTestData from filename and JSON content.
     * Parses filename to extract transaction details and analyzes JSON structure.
     * 
     * Filename pattern: {ledger}_{type}_{transaction_no}.json
     * Examples:
     * - AP_INV_AS20250812_1.json
     * - AP_CRD_AS20250812_3_C.json
     * - AP_INV_CSSH1250610990_0812_1.json
     */
    public static ReferenceTestData fromFilename(String filename, String jsonContent) {
        log.debug("Parsing reference test data from: {}", filename);
        
        ReferenceDataLoader loader = new ReferenceDataLoader();
        TransactionInfo txnInfo = loader.extractTransactionInfo(jsonContent);
        
        // Parse transaction details from filename if extraction failed
        if (txnInfo.getLedger() == null || txnInfo.getTransactionType() == null) {
            txnInfo = parseFromFilename(filename, txnInfo);
        }
        
        // Determine if this transaction should be sent to Kafka (legacy mode logic)
        boolean shouldSendToKafka = loader.shouldSendToKafka(txnInfo.getLedger(), txnInfo.getTransactionType());
        
        return ReferenceTestData.builder()
            .filename(filename)
            .payloadJson(jsonContent)
            .expectedLedger(txnInfo.getLedger())
            .expectedTransactionType(txnInfo.getTransactionType())
            .expectedTransactionNo(txnInfo.getTransactionNo())
            .expectedJobNumber(txnInfo.getJobNumber())
            .expectedEventType(txnInfo.getEventType())
            .expectedIsCancelled(txnInfo.isCancelled())
            .expectedLineCount(txnInfo.getExpectedLineCount())
            .shouldSendToKafka(shouldSendToKafka)
            .build();
    }

    /**
     * Fallback method to parse transaction info from filename when JSON parsing fails
     */
    private static TransactionInfo parseFromFilename(String filename, TransactionInfo existing) {
        // Pattern to match: LEDGER_TYPE_TRANSACTION_NO[_SUFFIX].json
        Pattern pattern = Pattern.compile("([A-Z]{2})_([A-Z]{3})_([^.]+)\\.json");
        Matcher matcher = pattern.matcher(filename);
        
        if (matcher.matches()) {
            String ledger = matcher.group(1);
            String type = matcher.group(2);
            String transactionNo = matcher.group(3);
            
            return existing.toBuilder()
                .ledger(ledger)
                .transactionType(type)
                .transactionNo(transactionNo)
                .build();
        }
        
        log.warn("Could not parse transaction info from filename: {}", filename);
        return existing;
    }

    /**
     * Gets the transaction number for database queries
     */
    public String getTransactionNo() {
        return expectedTransactionNo;
    }

    /**
     * Determines if this is an AP (Accounts Payable) transaction
     */
    public boolean isAPTransaction() {
        return "AP".equals(expectedLedger);
    }

    /**
     * Determines if this is an AR (Accounts Receivable) transaction
     */
    public boolean isARTransaction() {
        return "AR".equals(expectedLedger);
    }

    /**
     * Determines if this is an Invoice transaction
     */
    public boolean isInvoiceTransaction() {
        return "INV".equals(expectedTransactionType);
    }

    /**
     * Determines if this is a Credit Note transaction
     */
    public boolean isCreditTransaction() {
        return "CRD".equals(expectedTransactionType);
    }

    /**
     * Gets a descriptive name for test reporting
     */
    public String getTestDescription() {
        return String.format("%s %s Transaction: %s", 
            expectedLedger, expectedTransactionType, expectedTransactionNo);
    }

    /**
     * Validates that the test data has minimum required fields
     */
    public boolean isValid() {
        return filename != null && 
               payloadJson != null && 
               expectedLedger != null && 
               expectedTransactionType != null &&
               expectedTransactionNo != null;
    }

    @Override
    public String toString() {
        return String.format("ReferenceTestData{filename='%s', ledger='%s', type='%s', txnNo='%s', kafka=%s}", 
            filename, expectedLedger, expectedTransactionType, expectedTransactionNo, shouldSendToKafka);
    }
}