package oec.lis.erpportal.addon.compliance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;
import oec.lis.erpportal.addon.compliance.api18.client.ProfileClient;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Comprehensive integration test for AP_INV_AS20250818_2.json payload against /external/v1/ARTransaction endpoint.
 * 
 * This test validates the complete flow:
 * 1. Input: JSON payload from reference/AP_INV_AS20250818_2.json
 * 2. Processing: Transaction parsing, database persistence, routing decisions
 * 3. Output: Expected database records matching the reference data provided
 * 
 * Test Environment Configuration (following application-local.yml pattern):
 * - TestContainers for PostgreSQL (SOPL) and SQL Server (Cargowise)
 * - Environment variables matching env.sh structure
 * - Transaction routing in legacy mode (AP Invoice → database only)
 * - NONJOB support disabled for this test case
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Testcontainers
@TestPropertySource(properties = {
    // Basic Spring configuration following application-local.yml
    "spring.profiles.active=test",
    "spring.application.name=cpar-api",
    "spring.cloud.config.enabled=false",
    
    // Runtime environment configuration
    "runtime.environment=test",
    
    // Logging configuration
    "logging.level.oec.lis.erpportal.addon.compliance=DEBUG",
    "logging.level.oec.lis=TRACE",
    
    // Server configuration
    "server.servlet.context-path=/cpar-api",
    
    // Security configuration (matching application-local.yml)
    "spring.security.cors.allowed-origins=*",
    "spring.security.ignore-all-security-check=true",
    
    // Kafka configuration (disabled for database-only testing)
    "spring.kafka.bootstrap-servers=localhost:9092",
    "kafka.enabled=false",
    
    // Transaction routing configuration (legacy mode for AP Invoice testing)
    "transaction.routing.enable-legacy-mode=true",
    "transaction.nonjob.enabled=false",
    
    // External API configuration (disabled for testing)
    "external.cwis.url=http://localhost:9999",
    "external.compliance.url=http://localhost:9999",
    "external.erpportal.url=http://localhost:9999",
    "external.profile.url=http://localhost:9999",
    
    // Email configuration (using test values)
    "spring.mail.host=localhost",
    "spring.mail.port=587",
    "job.email.fromemail=test@example.com",
    "job.email.recipients=test@example.com",
    
    // Management endpoints
    "management.endpoints.web.exposure.include=health,info"
})
@Slf4j
class APInvoiceAS20250818_2IntegrationTest {

    // TestContainers for real database testing
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15.9-alpine")
            .withDatabaseName("sopl_test")
            .withUsername("test")
            .withPassword("test")
            .withInitScript("test-schema-postgresql.sql");

    @Container
    static MSSQLServerContainer<?> sqlserver = new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest")
            .withPassword("Test123!")
            .withSharedMemorySize(512 * 1024 * 1024L) // 512MB shared memory
            .withStartupTimeout(Duration.ofMinutes(5))
            .withInitScript("test-schema-sqlserver.sql")
            .acceptLicense();

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Configure PostgreSQL datasource (SOPL) - matching application-local.yml structure
        registry.add("spring.datasource.sopl.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.sopl.username", postgres::getUsername);
        registry.add("spring.datasource.sopl.password", postgres::getPassword);
        registry.add("spring.datasource.sopl.driver-class-name", () -> "org.postgresql.Driver");
        registry.add("spring.datasource.sopl.hikari.maximum-pool-size", () -> "5");
        registry.add("spring.datasource.sopl.hikari.pool-name", () -> "sopl-test-pool");

        // Configure SQL Server datasource (Cargowise) - matching application-local.yml structure  
        registry.add("spring.datasource.cargowise.url", sqlserver::getJdbcUrl);
        registry.add("spring.datasource.cargowise.username", sqlserver::getUsername);
        registry.add("spring.datasource.cargowise.password", sqlserver::getPassword);
        registry.add("spring.datasource.cargowise.driver-class-name", () -> "com.microsoft.sqlserver.jdbc.SQLServerDriver");
        registry.add("spring.datasource.cargowise.hikari.maximum-pool-size", () -> "3");
        registry.add("spring.datasource.cargowise.hikari.pool-name", () -> "cargowise-test-pool");
        registry.add("spring.datasource.cargowise.hikari.read-only", () -> "true");
        
        // Environment variables matching env.sh pattern (for application components that read them)
        registry.add("SOPL_DB_URL", postgres::getJdbcUrl);
        registry.add("SOPL_DB_USER", postgres::getUsername);
        registry.add("SOPL_DB_PASSWORD", postgres::getPassword);
        registry.add("CARGOWISE_DB_URL", sqlserver::getJdbcUrl);
        registry.add("CARGOWISE_DB_USER", sqlserver::getUsername);
        registry.add("CARGOWISE_DB_PASSWORD", sqlserver::getPassword);
        
        // Kafka configuration (disabled for database-only testing)
        registry.add("KAFKA_ENABLED", () -> "false");
        registry.add("KAFKA_URL", () -> "localhost:9092");
        registry.add("KAFKA_USERNAME", () -> "user1");
        registry.add("KAFKA_PASSWORD", () -> "44gmz7NVT7");
        
        // Email configuration (matching application-local.yml)
        registry.add("EMAIL_USERNAME", () -> "AKIARI2VVUAKJOCZJJZ7");
        registry.add("EMAIL_PASSWORD", () -> "BCHt/98aUNL1BpOPcJJOs0v9fMXUeBtXjkbrjgg/qj/L");
        registry.add("JOB_EMAIL_RECEIPIENTS", () -> "yinchao.tseng@oecgroup.com");
        
        // External API configuration (matching application-local.yml structure)
        registry.add("CWIS_API_URL", () -> "http://localhost:9999");
        registry.add("CWIS_CLIENT_ID", () -> "test_client");
        registry.add("CWIS_CLIENT_SECRET", () -> "test_secret");
        registry.add("COMPLIANCE_API_URL", () -> "http://localhost:9999");
        registry.add("COMPLIANCE_CLIENT_ID", () -> "test_client");
        registry.add("COMPLIANCE_CLIENT_SECRET", () -> "test_secret");
        registry.add("ERPPORTAL_CLIENT_ID", () -> "test_client");
        registry.add("ERPPORTAL_CLIENT_SECRET", () -> "test_secret");
        registry.add("ERPPORTAL_SERVICE_ACCOUNT", () -> "test@example.com");
    }

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AtAccountTransactionTableService transactionTableService;

    @Autowired
    private ApiLogService apiLogService;

    // Mock external dependencies for isolated testing
    @MockitoBean
    private CommonGlobalTableService globalTableService;

    @MockitoBean
    private TransactionRoutingService routingService;

    @MockitoBean
    private ProfileClient profileClient;

    // Kafka is disabled, so we don't need to inject the template
    // @MockitoBean
    // private KafkaTemplate<String, RetryRecord> kafkaTemplate;

    private String testPayloadJson;
    private Map<String, Object> expectedApiLogResponse;

    @BeforeAll
    static void setupContainers() throws Exception {
        log.info("Starting test containers...");
        log.info("PostgreSQL URL: {}", postgres.getJdbcUrl());
        log.info("SQL Server URL: {}", sqlserver.getJdbcUrl());

        // Setup test data in SQL Server using the prepared script
        setupCargowiseTestData();
    }

    @BeforeEach
    void setupTest() throws Exception {
        log.info("Setting up test with mock configurations...");
        
        // Load test payload JSON
        loadTestPayload();
        
        // Configure buyer reference resolution mock (for OECGRPORD organization)
        BuyerInfo mockBuyerInfo = new BuyerInfo();
        mockBuyerInfo.setBuyerReference("OECGRPORD");
        mockBuyerInfo.setBuyerName("OEC FREIGHT (NY), INC.");
        
        when(globalTableService.findBuyerReference("OECGRPORD"))
            .thenReturn(mockBuyerInfo);
        when(globalTableService.findBuyerReference(anyString()))
            .thenReturn(mockBuyerInfo);

        // Configure routing service for AP Invoice - should NOT send to external system in legacy mode
        when(routingService.shouldSendToExternalSystem("AP", "INV", "AS20250818_2/")).thenReturn(false);
        when(routingService.getRoutingMode()).thenReturn("LEGACY");
        
        // Note: Using real ApiLogService for complete integration testing

        // Initialize expected API response structure
        setupExpectedApiResponse();
    }

    @AfterEach
    void cleanupTest() throws Exception {
        log.info("Cleaning up test data...");
        
        // Clean PostgreSQL database tables to ensure fresh state for next test
        try (Connection conn = postgres.createConnection("")) {
            Statement stmt = conn.createStatement();
            
            // Clean tables in dependency order (foreign key constraints)
            try { stmt.execute("DELETE FROM cp_compliance_acct_trans_header_line_link"); } catch (Exception e) { log.debug("Failed to clean cp_compliance_acct_trans_header_line_link: {}", e.getMessage()); }
            stmt.execute("DELETE FROM at_account_transaction_lines");
            stmt.execute("DELETE FROM at_account_transaction_header");
            stmt.execute("DELETE FROM at_shipment_info");
            stmt.execute("DELETE FROM sys_api_log");
            stmt.execute("DELETE FROM cp_compliance");
            
            // Reset reference tables to initial test data (in dependency order)
            stmt.execute("DELETE FROM cw_global_branch");
            stmt.execute("DELETE FROM cw_global_company");
            stmt.execute("INSERT INTO cw_global_company (global_cmpny_id, country_code, cmpny_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id, crncy_code) VALUES('15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'CN', 'SH1', true, '2023-02-01 17:18:30.329', '2025-06-16 03:51:57.881', 'baf95bea-bf76-4102-b4f8-192ed6ad88e5'::uuid, 'CNY')");
            stmt.execute("INSERT INTO cw_global_branch (global_branch_id, global_cmpny_id, branch_code, is_active, etl_create_time, etl_update_time, proxy_org_header_id) VALUES('9652c78f-53ed-4dc2-b70d-d921c165a3b0'::uuid, '15c1f416-01d2-4ed2-9b5b-d032c4796dc4'::uuid, 'SH1', true, '2023-02-01 17:25:09.404', '2025-06-16 03:52:00.284', '97cc1137-81fc-495c-9f59-a6974fa85f97'::uuid)");
            
            log.info("PostgreSQL test database cleaned successfully");
        } catch (Exception e) {
            log.warn("Failed to clean PostgreSQL test database: {}", e.getMessage());
        }
        
        reset(globalTableService, routingService);
    }

    /**
     * Test 1: Complete AP Invoice processing flow - Main integration test
     */
    @Test
    void testAPInvoiceAS20250818_2_CompleteProcessingFlow() throws Exception {
        log.info("=== Testing AP_INV_AS20250818_2.json complete processing flow ===");
        
        // Record initial database state
        int initialHeaderCount = countRecordsInTable("at_account_transaction_header");
        int initialLinesCount = countRecordsInTable("at_account_transaction_lines"); 
        int initialShipmentCount = countRecordsInTable("at_shipment_info");
        int initialApiLogCount = countRecordsInTable("sys_api_log");

        log.info("Initial DB state - Headers: {}, Lines: {}, Shipments: {}, ApiLogs: {}", 
                initialHeaderCount, initialLinesCount, initialShipmentCount, initialApiLogCount);

        // Execute endpoint call
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("saved to DB only")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("LEGACY")))
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        String trackId = result.getResponse().getHeader("X-Track-ID");
        String apiId = result.getResponse().getHeader("X-API-ID");

        log.info("Response: {}", responseBody);
        log.info("Track ID: {}, API ID: {}", trackId, apiId);

        // Verify database changes - exactly what's expected
        verifyDatabaseChanges(initialHeaderCount, initialLinesCount, initialShipmentCount, initialApiLogCount);
        
        // With Kafka disabled, no messages should be sent (this is expected behavior)
        // verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
        
        // Verify routing service was called correctly (once per charge line + once at controller level = 3 times)
        verify(routingService, times(3)).shouldSendToExternalSystem("AP", "INV", "AS20250818_2/");
        verify(routingService, atLeastOnce()).getRoutingMode();

        log.info("=== Complete processing flow test PASSED ===");
    }

    /**
     * Test 2: Verify exact transaction header data matches expected records
     */
    @Test
    void testTransactionHeaderDataPersistence() throws Exception {
        log.info("=== Testing transaction header data persistence ===");
        
        // Execute endpoint call
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted());

        // Verify specific transaction header data matches expected structure
        verifyTransactionHeaderData();
        log.info("=== Transaction header data test PASSED ===");
    }

    /**
     * Test 3: Verify transaction lines data matches expected records
     */
    @Test
    void testTransactionLinesDataPersistence() throws Exception {
        log.info("=== Testing transaction lines data persistence ===");
        
        // Execute endpoint call
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted());

        // Verify transaction line items match expected data
        verifyTransactionLinesData();
        log.info("=== Transaction lines data test PASSED ===");
    }

    /**
     * Test 4: Verify shipment info data persistence
     */
    @Test
    void testShipmentInfoDataPersistence() throws Exception {
        log.info("=== Testing shipment info data persistence ===");
        
        // Execute endpoint call
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted());

        // Verify shipment info matches expected structure
        verifyShipmentInfoData();
        log.info("=== Shipment info data test PASSED ===");
    }

    /**
     * Test 5: Verify routing decision for AP Invoice (should be database only)
     */
    @Test
    void testAPInvoiceRoutingDecision() throws Exception {
        log.info("=== Testing AP Invoice routing decision ===");
        
        // Execute endpoint call
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        
        // Verify response indicates database-only processing for AP Invoice
        assertThat(responseBody).contains("saved to DB only");
        assertThat(responseBody).contains("LEGACY");
        assertThat(responseBody).contains("AP INV Payload");
        
        // With Kafka disabled, no external system integration is expected
        // verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
        
        // Verify routing service decision (once per charge line + once at controller level = 3 times)
        verify(routingService, times(3)).shouldSendToExternalSystem("AP", "INV", "AS20250818_2/");

        log.info("=== AP Invoice routing decision test PASSED ===");
    }

    /**
     * Test 6: Verify API log creation and content
     */
    @Test
    void testApiLogCreation() throws Exception {
        log.info("=== Testing API log creation ===");
        
        // Execute endpoint call
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted());

        // Verify API log was created with correct data
        verifyApiLogData();
        log.info("=== API log creation test PASSED ===");
    }

    // === Helper Methods ===

    private void loadTestPayload() throws Exception {
        Path payloadPath = Paths.get("reference/AP_INV_AS20250818_2.json");
        if (!Files.exists(payloadPath)) {
            throw new IllegalStateException("Test payload file not found: " + payloadPath.toAbsolutePath());
        }
        testPayloadJson = Files.readString(payloadPath);
        log.info("Loaded test payload: {} characters", testPayloadJson.length());
        
        // Log first few lines for verification
        String[] lines = testPayloadJson.split("\n");
        log.info("Payload preview: {} ... {}", 
                 lines.length > 0 ? lines[0] : "empty",
                 lines.length > 1 ? lines[1] : "");
    }

    private static void setupCargowiseTestData() throws Exception {
        log.info("Setting up Cargowise test data...");
        
        try (Connection conn = sqlserver.createConnection("")) {
            // Read and execute the test data SQL script with proper parsing
            String sqlScript = Files.readString(Paths.get("src/test/resources/test-data-cargowise-AS20250818_2-minimal.sql"));
            
            // Parse SQL statements properly - look for INSERT...); patterns
            List<String> statements = parseSqlStatements(sqlScript);
            Statement stmt = conn.createStatement();
            
            int executedCount = 0;
            for (String sql : statements) {
                try {
                    log.debug("Executing statement {}: INSERT INTO {}", executedCount + 1, 
                             extractTableName(sql));
                    stmt.execute(sql);
                    executedCount++;
                    log.debug("Successfully executed statement {} ", executedCount);
                } catch (Exception e) {
                    log.error("Failed to execute SQL statement {}: {}", executedCount + 1, e.getMessage());
                    log.error("Failed SQL (first 200 chars): {}", sql.substring(0, Math.min(200, sql.length())));
                    throw new RuntimeException("Failed to setup test data at statement " + (executedCount + 1) + 
                                             " (table: " + extractTableName(sql) + ")", e);
                }
            }
            
            // Verify key test data was loaded
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM JobHeader WHERE JH_JobNum = ?")) {
                ps.setString(1, "SSSH1250818426");
                ResultSet rs = ps.executeQuery();
                rs.next();
                int jobCount = rs.getInt(1);
                log.info("Verified JobHeader data: {} records found for SSSH1250818426", jobCount);
                
                if (jobCount == 0) {
                    throw new RuntimeException("Critical test data missing: JobHeader for SSSH1250818426 not found");
                }
            }
            
            // Also verify shipment data
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM JobShipment WHERE JS_UniqueConsignRef = ?")) {
                ps.setString(1, "SSSH1250818426");
                ResultSet rs = ps.executeQuery();
                rs.next();
                int shipmentCount = rs.getInt(1);
                log.info("Verified JobShipment data: {} records found for SSSH1250818426", shipmentCount);
            }
            
            // Verify charge code data
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM AccChargeCode WHERE AC_Code IN ('DOC', 'FRT')")) {
                ResultSet rs = ps.executeQuery();
                rs.next();
                int chargeCount = rs.getInt(1);
                log.info("Verified AccChargeCode data: {} records found for DOC/FRT", chargeCount);
            }
            
            log.info("Cargowise test data setup complete - executed {} SQL statements", executedCount);
        }
    }
    
    private static List<String> parseSqlStatements(String sqlScript) {
        List<String> statements = new ArrayList<>();
        StringBuilder currentStatement = new StringBuilder();
        String[] lines = sqlScript.split("\n");
        
        boolean inStatement = false;
        
        for (String line : lines) {
            String trimmed = line.trim();
            
            // Skip comments and empty lines
            if (trimmed.isEmpty() || trimmed.startsWith("--")) {
                continue;
            }
            
            // Check if this is the start of an INSERT statement
            if (trimmed.startsWith("INSERT INTO")) {
                // If we were already in a statement, something went wrong
                if (inStatement) {
                    log.warn("Found nested INSERT statement, adding previous incomplete statement");
                    statements.add(currentStatement.toString().trim());
                }
                currentStatement = new StringBuilder();
                inStatement = true;
            }
            
            if (inStatement) {
                currentStatement.append(line).append("\n");
                
                // Check if this line ends the statement
                if (trimmed.endsWith(");")) {
                    statements.add(currentStatement.toString().trim());
                    currentStatement = new StringBuilder();
                    inStatement = false;
                }
            }
        }
        
        // Handle any remaining incomplete statement
        if (inStatement && currentStatement.length() > 0) {
            statements.add(currentStatement.toString().trim());
        }
        
        log.info("Parsed {} SQL statements from script", statements.size());
        return statements;
    }
    
    private static String extractTableName(String sql) {
        // Extract table name from INSERT INTO statement
        if (sql.startsWith("INSERT INTO")) {
            String[] parts = sql.split("\\s+", 4);
            if (parts.length >= 3) {
                return parts[2].replaceAll("[^a-zA-Z0-9_]", "");
            }
        }
        return "unknown";
    }

    private void setupExpectedApiResponse() {
        expectedApiLogResponse = Map.of(
            "status", "DONE",
            "savedToDatabase", true,
            "readyForExternal", false, // AP Invoice in legacy mode
            "transactionProcessing", Map.of(
                "messageCount", 2, // Expected 2 charge lines
                "hasDebugMessages", true
            )
        );
    }

    private int countRecordsInTable(String tableName) throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM " + tableName);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private void verifyDatabaseChanges(int initialHeaderCount, int initialLinesCount, 
                                     int initialShipmentCount, int initialApiLogCount) throws Exception {
        // Verify exactly one new header record
        int newHeaderCount = countRecordsInTable("at_account_transaction_header");
        assertThat(newHeaderCount).isEqualTo(initialHeaderCount + 1);
        
        // Debug: Let's see what lines were actually created first
        debugTransactionLines();
        
        // Verify transaction lines - System correctly creates 2 lines (DOC + FRT)
        int newLinesCount = countRecordsInTable("at_account_transaction_lines");
        log.info("Expected lines count based on JSON: {}, Actual lines count: {}", initialLinesCount + 2, newLinesCount);
        log.info("Successfully created {} transaction line(s) from AP Invoice payload", newLinesCount - initialLinesCount);
        
        // Expected behavior: system processes 2 transaction lines (DOC + FRT)
        assertThat(newLinesCount).isEqualTo(initialLinesCount + 2);
        
        // Verify exactly one new shipment record
        int newShipmentCount = countRecordsInTable("at_shipment_info");
        assertThat(newShipmentCount).isEqualTo(initialShipmentCount + 1);
        
        // Verify exactly one new API log record
        int newApiLogCount = countRecordsInTable("sys_api_log");
        assertThat(newApiLogCount).isEqualTo(initialApiLogCount + 1);

        log.info("Database changes verified - Headers: +{}, Lines: +{}, Shipments: +{}, ApiLogs: +{}",
                 newHeaderCount - initialHeaderCount,
                 newLinesCount - initialLinesCount,
                 newShipmentCount - initialShipmentCount,
                 newApiLogCount - initialApiLogCount);
    }

    private void verifyTransactionHeaderData() throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT ledger, trans_type, trans_no, inv_org_code, " +
                "       local_crncy_code, inv_amt, outstanding_amt " +
                "FROM at_account_transaction_header " +
                "WHERE trans_no = 'AS20250818_2/' " +
                "ORDER BY create_time DESC LIMIT 1");
            ResultSet rs = ps.executeQuery();
            
            assertThat(rs.next()).isTrue();
            
            // Verify header data matches expected values from reference records
            assertThat(rs.getString("ledger")).isEqualTo("AP");
            assertThat(rs.getString("trans_type")).isEqualTo("INV");
            assertThat(rs.getString("trans_no")).isEqualTo("AS20250818_2/");
            assertThat(rs.getString("inv_org_code")).isEqualTo("OECGRPORD");
            assertThat(rs.getString("local_crncy_code")).isEqualTo("CNY");
            assertThat(rs.getBigDecimal("inv_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-47.75));
            assertThat(rs.getBigDecimal("outstanding_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-47.75));

            log.info("Transaction header data verification PASSED");
        }
    }

    private void verifyTransactionLinesData() throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT atl.trans_line_desc, atl.chrg_amt, " +
                "       atl.vat_amt, atl.total_amt " +
                "FROM at_account_transaction_lines atl " +
                "JOIN at_account_transaction_header ath ON atl.acct_trans_header_id = ath.acct_trans_header_id " +
                "WHERE ath.trans_no = 'AS20250818_2/' " +
                "ORDER BY atl.trans_line_desc");
            ResultSet rs = ps.executeQuery();
            
            // Verify first line (alphabetically) - Destination Documentation Fee
            assertThat(rs.next()).isTrue();
            assertThat(rs.getString("trans_line_desc")).contains("Destination Documentation Fee");
            assertThat(rs.getBigDecimal("chrg_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-11.00));
            assertThat(rs.getBigDecimal("total_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-11.00));
            
            // Verify second line (alphabetically) - International Freight
            assertThat(rs.next()).isTrue();
            assertThat(rs.getString("trans_line_desc")).contains("International Freight");
            assertThat(rs.getBigDecimal("chrg_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-5.00));
            assertThat(rs.getBigDecimal("total_amt")).isEqualByComparingTo(java.math.BigDecimal.valueOf(-36.75));

            // Verify no more lines
            assertThat(rs.next()).isFalse();

            log.info("Transaction lines data verification PASSED");
        }
    }

    private void verifyShipmentInfoData() throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT ref_no, hbl_no, cntr_mode, shipment_type " +
                "FROM at_shipment_info " +
                "WHERE ref_no = 'SSSH1250818426' " +
                "ORDER BY create_time DESC LIMIT 1");
            ResultSet rs = ps.executeQuery();
            
            assertThat(rs.next()).isTrue();
            assertThat(rs.getString("ref_no")).isEqualTo("SSSH1250818426");
            assertThat(rs.getString("hbl_no")).isEqualTo("OERT201702Y00586");
            assertThat(rs.getString("cntr_mode")).isEqualTo("LCL");
            assertThat(rs.getString("shipment_type")).isEqualTo("LCL");

            log.info("Shipment info data verification PASSED");
        }
    }

    private void verifyApiLogData() throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT api_name, api_status, api_response " +
                "FROM sys_api_log " +
                "ORDER BY create_time DESC LIMIT 1");
            ResultSet rs = ps.executeQuery();
            
            assertThat(rs.next()).isTrue();
            assertThat(rs.getString("api_name")).isEqualTo("API14");
            assertThat(rs.getString("api_status")).isEqualTo("DONE"); // AP Invoice saved to DB successfully
            
            String apiResponse = rs.getString("api_response");
            assertThat(apiResponse).isNotNull();
            assertThat(apiResponse).contains("savedToDatabase");
            assertThat(apiResponse).contains("true");

            log.info("API log data verification PASSED");
        }
    }

    private void debugTransactionLines() throws Exception {
        try (Connection conn = postgres.createConnection("")) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT atl.chrg_amt, atl.vat_amt, atl.total_amt, " +
                "       atl.local_vat_amt, atl.trans_line_desc " +
                "FROM at_account_transaction_lines atl " +
                "JOIN at_account_transaction_header ath ON atl.acct_trans_header_id = ath.acct_trans_header_id " +
                "WHERE ath.trans_no = 'AS20250818_2/' " +
                "ORDER BY atl.acc_trans_lines_id");
            ResultSet rs = ps.executeQuery();
            
            log.info("=== DEBUG: Transaction lines in database ===");
            int count = 0;
            while (rs.next()) {
                count++;
                log.info("Line {}: description='{}', chrg_amt={}, vat_amt={}, total_amt={}, local_vat_amt={}", 
                    count,
                    rs.getString("trans_line_desc"),
                    rs.getBigDecimal("chrg_amt"),
                    rs.getBigDecimal("vat_amt"),
                    rs.getBigDecimal("total_amt"),
                    rs.getBigDecimal("local_vat_amt"));
            }
            log.info("=== Total lines found: {} ===", count);
        }
    }
}