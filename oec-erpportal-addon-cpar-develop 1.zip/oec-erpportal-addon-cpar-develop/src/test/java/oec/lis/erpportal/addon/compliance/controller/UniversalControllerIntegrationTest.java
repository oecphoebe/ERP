package oec.lis.erpportal.addon.compliance.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import oec.lis.erpportal.addon.compliance.common.config.TransactionRoutingConfig;
import oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;
import oec.lis.erpportal.addon.compliance.transaction.TransactionService;
import oec.lis.sopl.common.model.RestListResponse;

/**
 * Integration tests for UniversalController with routing logic
 */
@WebMvcTest(UniversalController.class)
@TestPropertySource(properties = {
    "spring.profiles.active=test",
    "kafka.enabled=true"
})
class UniversalControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private TransactionService transactionService;

    @MockitoBean
    private ApiLogService apiLogService;

    @MockitoBean
    private KafkaTemplate<String, RetryRecord> kafkaTemplate;

    @MockitoBean
    private TransactionRoutingService routingService;

    private Map<String, Object> createTestPayload(String ledger, String transactionType) {
        Map<String, Object> payload = new HashMap<>();
        Map<String, Object> body = new HashMap<>();
        Map<String, Object> universalTransaction = new HashMap<>();
        Map<String, Object> transactionInfo = new HashMap<>();
        Map<String, Object> dataContext = new HashMap<>();
        Map<String, Object> eventType = new HashMap<>();
        
        transactionInfo.put("Ledger", ledger);
        transactionInfo.put("TransactionType", transactionType);
        transactionInfo.put("Number", "TEST-" + System.currentTimeMillis());
        transactionInfo.put("IsCancelled", false);
        
        eventType.put("Code", "EDT");
        dataContext.put("EventType", eventType);
        dataContext.put("TriggerDate", "2025-01-15T10:00:00Z");
        dataContext.put("EventReference", "Posted");
        
        transactionInfo.put("DataContext", dataContext);
        universalTransaction.put("TransactionInfo", transactionInfo);
        body.put("UniversalTransaction", universalTransaction);
        payload.put("Body", body);
        
        return payload;
    }

    @BeforeEach
    void setUp() {
        // Setup default mock behavior
        doAnswer(invocation -> {
            APILog log = invocation.getArgument(0);
            if (log.getActionId() == null) {
                log.setActionId(UUID.randomUUID());
            }
            if (log.getApiId() == null) {
                log.setApiId(UUID.randomUUID());
            }
            return null;
        }).when(apiLogService).saveLog(any(APILog.class));
    }

    @Test
    void testARInvoiceFlow_LegacyMode_SendsToExternal() throws Exception {
        // Given: AR INV payload with legacy mode
        Map<String, Object> payload = createTestPayload("AR", "INV");
        
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean();
        requestBean.setBillNo("AR-INV-001");
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList(requestBean));
        response.setMsg(Arrays.asList()); // Empty message list means no lookup errors
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem(eq("AR"), eq("INV"), anyString())).thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("LEGACY");

        // When & Then: Should process and send to Kafka
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Track ID")));

        // Verify Kafka was called
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testAPCRDFlow_LegacyMode_DoesNotSendToExternal() throws Exception {
        // Given: AP CRD payload with legacy mode (should NOT send to external)
        Map<String, Object> payload = createTestPayload("AP", "CRD");
        
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean();
        requestBean.setBillNo("AP-CRD-001");
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList(requestBean));
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem("AP", "CRD", "AP-CRD-001")).thenReturn(false);
        when(routingService.getRoutingMode()).thenReturn("LEGACY");

        // When & Then: Should process but NOT send to Kafka
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("saved to DB only")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("LEGACY mode")));

        // Verify Kafka was NOT called
        verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testAPCRDFlow_ConfigMode_SendsToExternal() throws Exception {
        // Given: AP CRD payload with config mode (NEW: should send to external)
        Map<String, Object> payload = createTestPayload("AP", "CRD");
        
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean();
        requestBean.setBillNo("AP-CRD-002");
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList(requestBean));
        response.setMsg(Arrays.asList()); // Empty message list means no lookup errors
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem(eq("AP"), eq("CRD"), anyString())).thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");

        // When & Then: Should process AND send to Kafka
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Track ID")));

        // Verify Kafka WAS called (new behavior)
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testAPINVFlow_ConfigMode_DoesNotSendToExternal() throws Exception {
        // Given: AP INV payload with config mode (should NOT send to external)
        Map<String, Object> payload = createTestPayload("AP", "INV");
        
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean();
        requestBean.setBillNo("AP-INV-001");
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList(requestBean));
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem("AP", "INV", "AP-INV-001")).thenReturn(false);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");

        // When & Then: Should process but NOT send to Kafka
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("saved to DB only")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("CONFIG mode")));

        // Verify Kafka was NOT called
        verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testMultipleTransactions_MixedRouting() throws Exception {
        // Given: Multiple transactions in response
        Map<String, Object> payload = createTestPayload("AR", "INV");
        
        TransactionChargeLineRequestBean requestBean1 = new TransactionChargeLineRequestBean();
        requestBean1.setBillNo("AR-INV-003");
        TransactionChargeLineRequestBean requestBean2 = new TransactionChargeLineRequestBean();
        requestBean2.setBillNo("AR-INV-004");
        
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList(requestBean1, requestBean2));
        response.setMsg(Arrays.asList()); // Empty message list means no lookup errors
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem(eq("AR"), eq("INV"), anyString())).thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");

        // When & Then: Should send all to Kafka
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted());

        // Verify Kafka was called for each transaction
        verify(kafkaTemplate, times(2)).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testErrorHandling_TransactionServiceException() throws Exception {
        // Given: Transaction service throws exception
        Map<String, Object> payload = createTestPayload("AR", "INV");
        
        when(transactionService.analyzePayloadRaw(anyString()))
            .thenThrow(new RuntimeException("Database connection error"));

        // When & Then: Should handle error gracefully
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"));

        // Verify error was logged
        verify(apiLogService, atLeast(2)).saveLog(argThat(log -> 
            "ERROR".equals(log.getApiStatus()) || "DONE".equals(log.getApiStatus())
        ));
    }

    @Test
    void testEmptyTransactionList() throws Exception {
        // Given: Empty transaction list
        Map<String, Object> payload = createTestPayload("AR", "INV");
        
        RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
        response.setBody(Arrays.asList()); // Empty list
        
        when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
        when(routingService.shouldSendToExternalSystem(eq("AR"), eq("INV"), anyString())).thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");

        // When & Then: Should handle empty list gracefully
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payload)))
                .andExpect(status().isAccepted());

        // Verify Kafka was not called (no transactions to send)
        verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
    }

    @Test
    void testInvalidPayloadStructure() throws Exception {
        // Given: Invalid payload structure
        Map<String, Object> invalidPayload = new HashMap<>();
        invalidPayload.put("Body", new HashMap<>()); // Missing UniversalTransaction

        // When & Then: Should return bad request
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidPayload)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Unsupported data strucutre")));
    }

    /**
     * Nested test class for Kafka disabled scenarios
     */
    @WebMvcTest(UniversalController.class)
    @TestPropertySource(properties = {
        "spring.profiles.active=test",
        "kafka.enabled=false"
    })
    static class KafkaDisabledTest {

        @Autowired
        private MockMvc mockMvc;

        @Autowired
        private ObjectMapper objectMapper;

        @MockitoBean
        private TransactionService transactionService;

        @MockitoBean
        private ApiLogService apiLogService;

        @MockitoBean
        private TransactionRoutingService routingService;

        private Map<String, Object> createTestPayload(String ledger, String transactionType) {
            Map<String, Object> payload = new HashMap<>();
            Map<String, Object> body = new HashMap<>();
            Map<String, Object> universalTransaction = new HashMap<>();
            Map<String, Object> transactionInfo = new HashMap<>();
            Map<String, Object> dataContext = new HashMap<>();
            Map<String, Object> eventType = new HashMap<>();
            
            transactionInfo.put("Ledger", ledger);
            transactionInfo.put("TransactionType", transactionType);
            transactionInfo.put("Number", "TEST-" + System.currentTimeMillis());
            transactionInfo.put("IsCancelled", false);
            
            eventType.put("Code", "EDT");
            dataContext.put("EventType", eventType);
            dataContext.put("TriggerDate", "2025-01-15T10:00:00Z");
            dataContext.put("EventReference", "Posted");
            
            transactionInfo.put("DataContext", dataContext);
            universalTransaction.put("TransactionInfo", transactionInfo);
            body.put("UniversalTransaction", universalTransaction);
            payload.put("Body", body);
            
            return payload;
        }

        @BeforeEach
        void setUp() {
            // Setup default mock behavior
            doAnswer(invocation -> {
                APILog log = invocation.getArgument(0);
                if (log.getActionId() == null) {
                    log.setActionId(UUID.randomUUID());
                }
                if (log.getApiId() == null) {
                    log.setApiId(UUID.randomUUID());
                }
                return null;
            }).when(apiLogService).saveLog(any(APILog.class));
        }

        @Test
        void testKafkaDisabled_ShouldReturnPartialStatus() throws Exception {
            // Given: Kafka is disabled
            Map<String, Object> payload = createTestPayload("AR", "INV");
            
            TransactionChargeLineRequestBean transaction = new TransactionChargeLineRequestBean();
            transaction.setBillNo("TEST-001");
            
            RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
            response.setBody(Arrays.asList(transaction));
            
            when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
            when(routingService.shouldSendToExternalSystem(eq("AR"), eq("INV"), anyString())).thenReturn(true);

            // When & Then: Should return PARTIAL status with Kafka disabled message
            mockMvc.perform(post("/external/v1/ARTransaction")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(payload)))
                    .andExpect(status().isAccepted())
                    .andExpect(header().exists("X-Track-ID"))
                    .andExpect(header().exists("X-API-ID"))
                    .andExpect(content().string(org.hamcrest.Matchers.containsString("Kafka is disabled")));

            // Verify that transaction was processed and saved to DB
            verify(transactionService, times(1)).analyzePayloadRaw(anyString());
            
            // Verify API log was saved with PARTIAL status
            verify(apiLogService, atLeast(1)).saveLog(argThat(log -> 
                "PARTIAL".equals(log.getApiStatus())
            ));
        }
    }

    /**
     * Nested test class for NONJOB feature flag scenarios
     */
    @WebMvcTest(UniversalController.class)
    @TestPropertySource(properties = {
        "spring.profiles.active=test",
        "kafka.enabled=true",
        "transaction.nonjob.enabled=false"  // NONJOB disabled
    })
    static class NonJobDisabledTest {

        @Autowired
        private MockMvc mockMvc;

        @Autowired
        private ObjectMapper objectMapper;

        @MockitoBean
        private TransactionService transactionService;

        @MockitoBean
        private ApiLogService apiLogService;

        @MockitoBean
        private KafkaTemplate<String, RetryRecord> kafkaTemplate;

        @MockitoBean
        private TransactionRoutingService routingService;

        private Map<String, Object> createTestPayload(String ledger, String transactionType) {
            Map<String, Object> payload = new HashMap<>();
            Map<String, Object> body = new HashMap<>();
            Map<String, Object> universalTransaction = new HashMap<>();
            Map<String, Object> transactionInfo = new HashMap<>();
            Map<String, Object> dataContext = new HashMap<>();
            Map<String, Object> eventType = new HashMap<>();
            
            transactionInfo.put("Ledger", ledger);
            transactionInfo.put("TransactionType", transactionType);
            transactionInfo.put("Number", "NONJOB-TEST-" + System.currentTimeMillis());
            transactionInfo.put("IsCancelled", false);
            
            eventType.put("Code", "EDT");
            dataContext.put("EventType", eventType);
            dataContext.put("TriggerDate", "2025-01-15T10:00:00Z");
            dataContext.put("EventReference", "Posted");
            
            transactionInfo.put("DataContext", dataContext);
            universalTransaction.put("TransactionInfo", transactionInfo);
            body.put("UniversalTransaction", universalTransaction);
            payload.put("Body", body);
            
            return payload;
        }

        @BeforeEach
        void setUp() {
            // Setup default mock behavior
            doAnswer(invocation -> {
                APILog log = invocation.getArgument(0);
                if (log.getActionId() == null) {
                    log.setActionId(UUID.randomUUID());
                }
                if (log.getApiId() == null) {
                    log.setApiId(UUID.randomUUID());
                }
                return null;
            }).when(apiLogService).saveLog(any(APILog.class));
        }

        @Test
        void testNonJobTransactionDisabled_ShouldReturnBadRequest() throws Exception {
            // Given: NONJOB transaction is disabled and service throws NonJobNotSupportedException
            Map<String, Object> payload = createTestPayload("AR", "INV");
            
            when(transactionService.analyzePayloadRaw(anyString()))
                .thenThrow(new oec.lis.erpportal.addon.compliance.exception.NonJobNotSupportedException(
                    "NONJOB transactions are not supported. Please ensure transaction has valid shipment or consol references.",
                    "AR", "INV", "NONJOB-TEST-001"
                ));

            // When & Then: Should return HTTP 400 with detailed error response
            mockMvc.perform(post("/external/v1/ARTransaction")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(payload)))
                    .andExpect(status().isBadRequest())
                    .andExpect(header().exists("X-Track-ID"))
                    .andExpect(header().exists("X-API-ID"))
                    .andExpect(jsonPath("$.status").value("REJECTED"))
                    .andExpect(jsonPath("$.savedToDatabase").value(false))
                    .andExpect(jsonPath("$.readyForExternal").value(false))
                    .andExpect(jsonPath("$.rejectionReason.errorType").value("NONJOB_NOT_SUPPORTED"))
                    .andExpect(jsonPath("$.rejectionReason.message").value("NONJOB transactions are not supported. Please ensure featue flag for NONJOB transaction is enabled."))
                    .andExpect(jsonPath("$.rejectionReason.transactionDetails.ledger").value("AR"))
                    .andExpect(jsonPath("$.rejectionReason.transactionDetails.transactionType").value("INV"))
                    .andExpect(jsonPath("$.rejectionReason.transactionDetails.transactionNo").value("NONJOB-TEST-001"))
                    .andExpect(jsonPath("$.rejectionReason.configurationRequired").value("transaction.nonjob.enabled=true"))
                    .andExpect(jsonPath("$.rejectionReason.suggestion").exists())
                    .andExpect(jsonPath("$.transactionProcessing.note").value("Transaction rejected due to NONJOB feature disabled"))
                    .andExpect(jsonPath("$.messageCount").value(0))
                    .andExpect(jsonPath("$.executionTime").exists());

            // Verify Kafka was NOT called
            verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
            
            // Verify API log was saved with REJECTED status
            verify(apiLogService, atLeast(1)).saveLog(argThat(log -> 
                "REJECTED".equals(log.getApiStatus())
            ));
        }
    }

    /**
     * Nested test class for NONJOB enabled scenarios
     */
    @WebMvcTest(UniversalController.class)
    @TestPropertySource(properties = {
        "spring.profiles.active=test",
        "kafka.enabled=true",
        "transaction.nonjob.enabled=true"  // NONJOB enabled
    })
    static class NonJobEnabledTest {

        @Autowired
        private MockMvc mockMvc;

        @Autowired
        private ObjectMapper objectMapper;

        @MockitoBean
        private TransactionService transactionService;

        @MockitoBean
        private ApiLogService apiLogService;

        @MockitoBean
        private KafkaTemplate<String, RetryRecord> kafkaTemplate;

        @MockitoBean
        private TransactionRoutingService routingService;

        private Map<String, Object> createTestPayload(String ledger, String transactionType) {
            Map<String, Object> payload = new HashMap<>();
            Map<String, Object> body = new HashMap<>();
            Map<String, Object> universalTransaction = new HashMap<>();
            Map<String, Object> transactionInfo = new HashMap<>();
            Map<String, Object> dataContext = new HashMap<>();
            Map<String, Object> eventType = new HashMap<>();
            
            transactionInfo.put("Ledger", ledger);
            transactionInfo.put("TransactionType", transactionType);
            transactionInfo.put("Number", "NONJOB-ENABLED-" + System.currentTimeMillis());
            transactionInfo.put("IsCancelled", false);
            
            eventType.put("Code", "EDT");
            dataContext.put("EventType", eventType);
            dataContext.put("TriggerDate", "2025-01-15T10:00:00Z");
            dataContext.put("EventReference", "Posted");
            
            transactionInfo.put("DataContext", dataContext);
            universalTransaction.put("TransactionInfo", transactionInfo);
            body.put("UniversalTransaction", universalTransaction);
            payload.put("Body", body);
            
            return payload;
        }

        @BeforeEach
        void setUp() {
            // Setup default mock behavior
            doAnswer(invocation -> {
                APILog log = invocation.getArgument(0);
                if (log.getActionId() == null) {
                    log.setActionId(UUID.randomUUID());
                }
                if (log.getApiId() == null) {
                    log.setApiId(UUID.randomUUID());
                }
                return null;
            }).when(apiLogService).saveLog(any(APILog.class));
        }

        @Test
        void testNonJobTransactionEnabled_ShouldProcessNormally() throws Exception {
            // Given: NONJOB transaction is enabled and processes normally
            Map<String, Object> payload = createTestPayload("AR", "INV");
            
            TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean();
            requestBean.setBillNo("NONJOB-ENABLED-001");
            RestListResponse<TransactionChargeLineRequestBean> response = new RestListResponse<>();
            response.setBody(Arrays.asList(requestBean));
            
            when(transactionService.analyzePayloadRaw(anyString())).thenReturn(response);
            when(routingService.shouldSendToExternalSystem("AR", "INV", "NONJOB-ENABLED-001")).thenReturn(true);
            when(routingService.getRoutingMode()).thenReturn("CONFIG");

            // When & Then: Should process normally and send to Kafka
            mockMvc.perform(post("/external/v1/ARTransaction")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(payload)))
                    .andExpect(status().isAccepted())
                    .andExpect(header().exists("X-Track-ID"))
                    .andExpect(header().exists("X-API-ID"))
                    .andExpect(content().string(org.hamcrest.Matchers.containsString("Track ID")));

            // Verify Kafka was called for normal processing
            verify(kafkaTemplate, times(1)).send(anyString(), anyString(), any(RetryRecord.class));
            
            // Verify API log was saved with DONE status
            verify(apiLogService, atLeast(1)).saveLog(argThat(log -> 
                "DONE".equals(log.getApiStatus())
            ));
        }
    }
}