package oec.lis.erpportal.addon.compliance.util;

import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

import lombok.extern.slf4j.Slf4j;

/**
 * Service investigation utilities for integration tests providing debugging and analysis tools
 * for Spring service configuration, registration, and behavior investigation.
 * 
 * This class helps diagnose issues in integration tests by:
 * - Verifying service registration in Spring context
 * - Finding strategy beans and processors
 * - Inspecting service configuration and dependencies
 * - Analyzing transaction flow and routing
 * - Detecting AOP proxy wrapping
 */
@Slf4j
public class ServiceInvestigationUtilities {

    /**
     * Verify all transaction processing services are registered in Spring context
     */
    public void verifyServiceRegistration(ApplicationContext applicationContext) {
        log.info("=== SERVICE REGISTRATION VERIFICATION ===");
        
        Map<String, Object> allBeans = applicationContext.getBeansOfType(Object.class);
        int transactionServiceCount = 0;
        int strategyCount = 0;
        
        for (Map.Entry<String, Object> entry : allBeans.entrySet()) {
            String beanName = entry.getKey();
            String className = entry.getValue().getClass().getName();
            
            if (beanName.contains("Transaction") || className.contains("Transaction")) {
                log.info("✅ Transaction bean: {} -> {}", beanName, className);
                transactionServiceCount++;
            }
            
            if (beanName.contains("Strategy") || className.contains("Strategy")) {
                log.info("✅ Strategy bean: {} -> {}", beanName, className);
                strategyCount++;
            }
            
            // Look for specific services we need
            if (beanName.contains("AtAccountTransactionTableService")) {
                log.info("🎯 KEY SERVICE: AtAccountTransactionTableService found -> {}", className);
            }
            
            if (beanName.contains("TransactionService")) {
                log.info("🎯 KEY SERVICE: TransactionService found -> {}", className);
            }
        }
        
        log.info("=== SERVICE SUMMARY: {} transaction services, {} strategies ===", 
                transactionServiceCount, strategyCount);
    }

    /**
     * Find strategy beans matching a specific pattern
     */
    public List<String> findStrategyBeans(ApplicationContext applicationContext, String pattern) {
        log.info("=== STRATEGY BEAN SEARCH: Pattern '{}' ===", pattern);
        
        String[] beanNames = applicationContext.getBeanNamesForType(Object.class);
        List<String> matchingBeans = Arrays.stream(beanNames)
            .filter(name -> name.toLowerCase().contains(pattern.toLowerCase()))
            .collect(Collectors.toList());
        
        if (matchingBeans.isEmpty()) {
            log.warn("⚠️ NO STRATEGY BEANS FOUND matching pattern '{}'", pattern);
        } else {
            log.info("Found {} strategy beans matching pattern '{}':", matchingBeans.size(), pattern);
            matchingBeans.forEach(name -> {
                Object bean = applicationContext.getBean(name);
                log.info("  🎯 {}: {}", name, bean.getClass().getName());
            });
        }
        
        return matchingBeans;
    }

    /**
     * Inspect service configuration and dependencies
     */
    public void inspectServiceConfiguration(ApplicationContext applicationContext, Class<?> serviceClass) {
        log.info("=== SERVICE CONFIGURATION INSPECTION: {} ===", serviceClass.getSimpleName());
        
        try {
            Object service = applicationContext.getBean(serviceClass);
            
            if (service != null) {
                log.info("✅ {} is registered: {}", serviceClass.getSimpleName(), service.getClass().getName());
                
                // Check if it's a proxy (might indicate AOP/Transaction issues)
                if (detectProxyWrapping(service)) {
                    log.info("📋 {} is a proxy - AOP/Transaction wrapping active", serviceClass.getSimpleName());
                } else {
                    log.info("📋 {} is a direct instance - no proxy wrapping", serviceClass.getSimpleName());
                }
            } else {
                log.error("❌ {} is NULL - injection failed", serviceClass.getSimpleName());
            }
            
        } catch (Exception e) {
            log.error("❌ {} not found or failed to retrieve: {}", serviceClass.getSimpleName(), e.getMessage());
        }
    }

    /**
     * Analyze transaction flow and routing configuration
     */
    public void analyzeTransactionFlow(ApplicationContext applicationContext, String ledger, String transactionType) {
        log.info("=== TRANSACTION FLOW ANALYSIS: {} {} ===", ledger, transactionType);
        
        // Check routing service configuration
        try {
            String[] routingBeans = applicationContext.getBeanNamesForType(Object.class);
            List<String> routingServices = Arrays.stream(routingBeans)
                .filter(name -> name.toLowerCase().contains("routing"))
                .collect(Collectors.toList());
                
            if (routingServices.isEmpty()) {
                log.warn("⚠️ NO ROUTING SERVICES FOUND");
            } else {
                log.info("Found routing services: {}", routingServices);
            }
            
        } catch (Exception e) {
            log.error("Failed to analyze routing configuration: {}", e.getMessage());
        }
        
        // Check transaction processing services
        findTransactionProcessors(applicationContext, ledger, transactionType);
    }

    /**
     * Detect if a service is wrapped with AOP proxies
     */
    public boolean detectProxyWrapping(Object service) {
        String className = service.getClass().getName();
        boolean isProxy = className.contains("Proxy") || 
                         className.contains("$$EnhancerBySpringCGLIB") ||
                         className.contains("$$SpringCGLIB");
        
        if (isProxy) {
            log.debug("Proxy detected for {}: {}", service.getClass().getSimpleName(), className);
        }
        
        return isProxy;
    }

    /**
     * Find transaction processors for specific transaction types
     */
    public void findTransactionProcessors(ApplicationContext applicationContext, String ledger, String transactionType) {
        log.info("=== TRANSACTION PROCESSOR SEARCH: {} {} ===", ledger, transactionType);
        
        String[] beanNames = applicationContext.getBeanNamesForType(Object.class);
        
        // Look for specific transaction type processors
        List<String> processors = Arrays.stream(beanNames)
            .filter(name -> name.toLowerCase().contains(ledger.toLowerCase()) ||
                           name.toLowerCase().contains(transactionType.toLowerCase()) ||
                           name.toLowerCase().contains("processor") ||
                           name.toLowerCase().contains("handler"))
            .collect(Collectors.toList());
            
        if (processors.isEmpty()) {
            log.warn("⚠️ NO SPECIFIC PROCESSORS FOUND for {} {}", ledger, transactionType);
        } else {
            log.info("Found {} processors for {} {}:", processors.size(), ledger, transactionType);
            processors.forEach(name -> {
                Object bean = applicationContext.getBean(name);
                log.info("  🎯 {}: {}", name, bean.getClass().getName());
            });
        }
    }

    /**
     * Inspect environment configuration for specific properties
     */
    public void inspectEnvironmentConfiguration(ApplicationContext applicationContext, String... propertyNames) {
        log.info("=== ENVIRONMENT CONFIGURATION INSPECTION ===");
        
        Environment env = applicationContext.getEnvironment();
        
        for (String propertyName : propertyNames) {
            String value = env.getProperty(propertyName, "not-set");
            log.info("Property {}: {}", propertyName, value);
        }
    }

    /**
     * Analyze DataSource configuration
     */
    public void analyzeDataSourceConfiguration(ApplicationContext applicationContext) {
        log.info("=== DATASOURCE CONFIGURATION ANALYSIS ===");
        
        try {
            String[] dataSourceNames = applicationContext.getBeanNamesForType(javax.sql.DataSource.class);
            
            if (dataSourceNames.length == 0) {
                log.error("❌ NO DATASOURCES FOUND");
            } else {
                log.info("Found {} datasources:", dataSourceNames.length);
                for (String dsName : dataSourceNames) {
                    Object ds = applicationContext.getBean(dsName);
                    log.info("  DataSource: {} -> {}", dsName, ds.getClass().getName());
                }
            }
            
        } catch (Exception e) {
            log.error("Failed to analyze datasource configuration: {}", e.getMessage());
        }
    }

    /**
     * Log comprehensive service context summary
     */
    public void logServiceContextSummary(ApplicationContext applicationContext) {
        log.info("=== SERVICE CONTEXT SUMMARY ===");
        
        String[] allBeanNames = applicationContext.getBeanDefinitionNames();
        log.info("Total beans registered: {}", allBeanNames.length);
        
        // Count beans by category
        long transactionBeans = Arrays.stream(allBeanNames)
            .filter(name -> name.toLowerCase().contains("transaction"))
            .count();
            
        long serviceBeans = Arrays.stream(allBeanNames)
            .filter(name -> name.toLowerCase().contains("service"))
            .count();
            
        long controllerBeans = Arrays.stream(allBeanNames)
            .filter(name -> name.toLowerCase().contains("controller"))
            .count();
            
        long configBeans = Arrays.stream(allBeanNames)
            .filter(name -> name.toLowerCase().contains("config"))
            .count();
            
        log.info("Bean categories: {} transaction, {} service, {} controller, {} config", 
                transactionBeans, serviceBeans, controllerBeans, configBeans);
                
        log.info("=== SERVICE CONTEXT SUMMARY COMPLETE ===");
    }

    /**
     * Check mock service configurations and interactions
     */
    public void investigateMockServices(Object... mocks) {
        log.info("=== MOCK SERVICE INVESTIGATION ===");
        
        for (Object mock : mocks) {
            String className = mock.getClass().getSimpleName();
            boolean isMock = mockingDetails(mock).isMock();
            int invocations = mockingDetails(mock).getInvocations().size();
            
            log.info("Service {}: Mock={}, Invocations={}", className, isMock, invocations);
            
            if (isMock && invocations == 0) {
                log.warn("⚠️ {} is mocked but never called - may indicate processing bypass", className);
            }
        }
        
        log.info("=== MOCK INVESTIGATION COMPLETE ===");
    }

    /**
     * Find beans related to AP processing specifically
     */
    public List<String> findAPProcessingBeans(ApplicationContext applicationContext) {
        log.info("=== AP PROCESSING BEAN SEARCH ===");
        
        String[] beanNames = applicationContext.getBeanNamesForType(Object.class);
        
        List<String> apBeans = Arrays.stream(beanNames)
            .filter(name -> name.toLowerCase().contains("ap") || 
                           name.toLowerCase().contains("credit") ||
                           name.toLowerCase().contains("crd") ||
                           name.toLowerCase().contains("payable"))
            .collect(Collectors.toList());
        
        log.info("Found {} AP processing related beans:", apBeans.size());
        apBeans.forEach(name -> {
            Object bean = applicationContext.getBean(name);
            log.info("  🎯 {}: {}", name, bean.getClass().getName());
        });
        
        return apBeans;
    }

    /**
     * Detect alternative processing paths for specific transaction types
     */
    public void detectAlternativeProcessingPaths(ApplicationContext applicationContext, String ledger, String transactionType) {
        log.info("=== ALTERNATIVE PROCESSING PATH DETECTION: {} {} ===", ledger, transactionType);
        
        // Look for specific handlers or strategies
        String[] beanNames = applicationContext.getBeanNamesForType(Object.class);
        
        List<String> alternativePaths = Arrays.stream(beanNames)
            .filter(name -> name.toLowerCase().contains("alternative") ||
                           name.toLowerCase().contains("bypass") ||
                           name.toLowerCase().contains("special") ||
                           name.toLowerCase().contains("custom"))
            .collect(Collectors.toList());
            
        if (alternativePaths.isEmpty()) {
            log.info("No alternative processing paths detected");
        } else {
            log.warn("⚠️ Alternative processing paths found: {}", alternativePaths);
        }
        
        // Check for transaction type specific processors
        List<String> typeSpecific = Arrays.stream(beanNames)
            .filter(name -> name.toLowerCase().contains(ledger.toLowerCase() + transactionType.toLowerCase()) ||
                           name.toLowerCase().contains(transactionType.toLowerCase() + "Processor"))
            .collect(Collectors.toList());
            
        if (!typeSpecific.isEmpty()) {
            log.info("Transaction type specific processors found: {}", typeSpecific);
        }
    }
}