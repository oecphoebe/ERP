package oec.lis.erpportal.addon.compliance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;
import oec.lis.erpportal.addon.compliance.util.ReferenceDataLoader;
import oec.lis.erpportal.addon.compliance.util.ReferenceTestData;
import oec.lis.erpportal.addon.compliance.util.TestValidationHelper;

import javax.sql.DataSource;

/**
 * Comprehensive integration test for /external/v1/ARTransaction endpoint using real-world data.
 * 
 * This test validates:
 * - Complete transaction processing from JSON payload to database persistence
 * - Correct routing decisions (save-only vs save-and-send-external)
 * - Database integrity across PostgreSQL (SOPL) and SQL Server (Cargowise)
 * - Kafka message sending validation
 * - API logging and audit trail
 * - Collision handling and edge cases
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Testcontainers
@TestPropertySource(properties = {
    "spring.profiles.active=test",
    "logging.level.oec.lis.erpportal.addon.compliance=DEBUG",
    "transaction.routing.enable-legacy-mode=true",
    "spring.cloud.config.enabled=false",
    "spring.kafka.bootstrap-servers=localhost:9092"
})
@Transactional
@Slf4j
class ARTransactionEndpointRealDataIntegrationTest {

    // TestContainers for real database testing
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15.9-alpine")
            .withDatabaseName("sopl_test")
            .withUsername("test")
            .withPassword("test")
            .withInitScript("test-schema-postgresql.sql");

    @Container
    static MSSQLServerContainer<?> sqlserver = new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest")
            .withPassword("Test123!")
            .withInitScript("test-schema-sqlserver.sql")
            .acceptLicense();

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Configure PostgreSQL datasource (SOPL) - using actual property names from application.yaml
        registry.add("spring.datasource.sopl.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.sopl.username", postgres::getUsername);
        registry.add("spring.datasource.sopl.password", postgres::getPassword);
        registry.add("spring.datasource.sopl.driver-class-name", () -> "org.postgresql.Driver");

        // Configure SQL Server datasource (Cargowise)
        registry.add("spring.datasource.cargowise.url", sqlserver::getJdbcUrl);
        registry.add("spring.datasource.cargowise.username", sqlserver::getUsername);
        registry.add("spring.datasource.cargowise.password", sqlserver::getPassword);
        registry.add("spring.datasource.cargowise.driver-class-name", () -> "com.microsoft.sqlserver.jdbc.SQLServerDriver");
        
        // Disable external API calls during testing
        registry.add("external.cwis.url", () -> "http://localhost:9999");
        registry.add("external.compliance.url", () -> "http://localhost:9999");
        registry.add("external.erpportal.url", () -> "http://localhost:9999");
        registry.add("external.profile.url", () -> "http://localhost:9999");
        
        // Override environment variables for testing
        registry.add("KAFKA_URL", () -> "localhost:9092");
        registry.add("KAFKA_USERNAME", () -> "testuser");
        registry.add("KAFKA_PASSWORD", () -> "testpass");
        registry.add("EMAIL_USERNAME", () -> "testuser");
        registry.add("EMAIL_PASSWORD", () -> "testpass");
        registry.add("JOB_EMAIL_RECEIPIENTS", () -> "test@example.com");
    }

    @TestConfiguration
    static class TestConfig {
        
        @Bean
        public ReferenceDataLoader referenceDataLoader() {
            return new ReferenceDataLoader();
        }
    }

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ReferenceDataLoader referenceDataLoader;

    @Autowired
    private AtAccountTransactionTableService transactionTableService;

    @Autowired
    private ApiLogService apiLogService;

    @Autowired
    private TestValidationHelper validationHelper;

    // Mock external dependencies
    @MockitoBean
    private KafkaTemplate<String, RetryRecord> kafkaTemplate;

    @MockitoBean
    private CommonGlobalTableService globalTableService;

    @MockitoBean
    private TransactionRoutingService routingService;

    @BeforeAll
    static void setupContainers() {
        log.info("Starting test containers...");
        log.info("PostgreSQL URL: {}", postgres.getJdbcUrl());
        log.info("SQL Server URL: {}", sqlserver.getJdbcUrl());
    }

    @BeforeEach
    void setupTest() {
        log.info("Setting up test with mock configurations...");
        
        // Configure buyer reference resolution mock
        BuyerInfo mockBuyerInfo = new BuyerInfo();
        mockBuyerInfo.setBuyerReference("TEST_BUYER");
        mockBuyerInfo.setBuyerName("Test Buyer Company");
        
        when(globalTableService.findBuyerReference(anyString()))
            .thenReturn(mockBuyerInfo);

        // Configure legacy mode routing by default
        configureLegacyModeRouting();
        
        // Setup API log mocks
        doAnswer(invocation -> {
            APILog log = invocation.getArgument(0);
            if (log.getActionId() == null) {
                log.setActionId(UUID.randomUUID());
            }
            if (log.getApiId() == null) {
                log.setApiId(UUID.randomUUID());
            }
            return null;
        }).when(apiLogService).saveLog(any(APILog.class));
    }

    @AfterEach
    void cleanupTest() {
        log.info("Cleaning up test data...");
        // Note: @Transactional with @Rollback will handle PostgreSQL cleanup
        // SQL Server test data is read-only, so no cleanup needed
        reset(kafkaTemplate, globalTableService, routingService, apiLogService);
    }

    /**
     * Provides all reference JSON files for parameterized testing
     */
    static Stream<ReferenceTestData> referenceDataFiles() throws Exception {
        Path referencePath = Paths.get("reference");
        
        if (!Files.exists(referencePath)) {
            throw new IllegalStateException("Reference directory not found: " + referencePath.toAbsolutePath());
        }

        return Files.walk(referencePath)
                .filter(path -> path.toString().endsWith(".json"))
                .map(path -> {
                    try {
                        String filename = path.getFileName().toString();
                        String content = Files.readString(path);
                        
                        // Parse transaction details from filename
                        ReferenceTestData testData = ReferenceTestData.fromFilename(filename, content);
                        log.info("Loaded reference data: {}", filename);
                        return testData;
                    } catch (Exception e) {
                        throw new RuntimeException("Failed to load reference file: " + path, e);
                    }
                });
    }

    /**
     * Main parameterized test that processes all reference JSON files
     */
    @ParameterizedTest
    @MethodSource("referenceDataFiles")
    void testTransactionProcessingWithRealData(ReferenceTestData testData) throws Exception {
        log.info("Testing transaction processing for: {}", testData.getFilename());
        
        // Setup test data in Cargowise container if needed
        setupCargowiseTestData(testData);
        
        // Execute endpoint call
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Track ID")))
                .andReturn();

        // Extract tracking information from response
        String trackId = result.getResponse().getHeader("X-Track-ID");
        String apiId = result.getResponse().getHeader("X-API-ID");
        
        log.info("Transaction processed with Track ID: {}, API ID: {}", trackId, apiId);

        // Validate response content
        validateResponseContent(result, testData);
        
        // Validate database persistence
        validateDatabasePersistence(testData);
        
        // Validate routing decision and Kafka message
        validateRoutingDecision(testData);
        
        // Validate API logging
        validateAPILogging(UUID.fromString(trackId), testData);
        
        log.info("Successfully validated transaction: {}", testData.getFilename());
    }

    /**
     * Test AP Invoice transactions that should save to DB only (no Kafka)
     */
    @Test
    void testAPInvoiceTransaction_SaveOnly() throws Exception {
        ReferenceTestData testData = referenceDataLoader.loadByFilename("AP_INV_AS20250812_1.json");
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("saved to DB only")));

        // Verify no Kafka message sent for AP transaction
        verify(kafkaTemplate, never()).send(anyString(), anyString(), any(RetryRecord.class));
        
        // Verify database persistence
        validateDatabasePersistence(testData);
    }

    /**
     * Test collision handling when same job is processed multiple times
     */
    @Test
    void testShipmentCollisionHandling() throws Exception {
        ReferenceTestData testData = referenceDataLoader.loadByFilename("AP_INV_AS20250812_1.json");
        
        // First transaction - should succeed
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted());
        
        // Verify first transaction was persisted
        validateDatabasePersistence(testData);
        Long firstHeaderPk = validationHelper.getHeaderPK(testData.getTransactionNo());
        
        // Second identical transaction - should handle gracefully (collision detection)
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted());
        
        // Verify no duplicate records created
        validationHelper.validateNoDuplicates(testData.getTransactionNo());
        
        log.info("✓ Collision handling test passed");
    }

    /**
     * Test processing of different transaction types (AR vs AP)
     */
    @Test
    void testARTransactionProcessing_SendsToKafka() throws Exception {
        // Create mock AR transaction data
        String arPayload = createARTransactionPayload("AR_INV_TEST_001");
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(arPayload))
                .andExpect(status().isAccepted());
        
        // Verify AR transaction triggers Kafka message
        verify(kafkaTemplate, atLeastOnce())
            .send(eq("test-invoice-retry"), anyString(), any(RetryRecord.class));
            
        log.info("✓ AR transaction Kafka routing test passed");
    }

    /**
     * Test configuration mode vs legacy mode routing
     */
    @Test
    void testConfigModeRouting() throws Exception {
        // Configure config mode (non-legacy)
        when(routingService.isLegacyModeEnabled()).thenReturn(false);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");
        when(routingService.shouldSendToExternalSystem(eq("AP"), eq("CRD"), anyString()))
            .thenReturn(true); // In config mode, AP CRD could be sent to external
        
        ReferenceTestData testData = referenceDataLoader.loadByFilename("AP_CRD_AS20250812_3_C.json");
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted());
        
        // Verify Kafka message was sent (different from legacy mode)
        verify(kafkaTemplate, atLeastOnce())
            .send(anyString(), anyString(), any(RetryRecord.class));
            
        log.info("✓ Config mode routing test passed");
    }

    /**
     * Test transaction with missing optional fields
     */
    @Test 
    void testTransactionWithMissingFields() throws Exception {
        String payloadWithMissingFields = createMinimalTransactionPayload();
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(payloadWithMissingFields))
                .andExpect(status().isAccepted());
        
        // Should still process successfully with minimal data
        log.info("✓ Missing fields handling test passed");
    }

    /**
     * Test large transaction with multiple line items
     */
    @Test
    void testLargeTransactionProcessing() throws Exception {
        // Use one of the more complex reference files
        ReferenceTestData testData = referenceDataLoader.loadByFilename("AP_INV_AS20250812_1.json");
        
        long startTime = System.currentTimeMillis();
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)  
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted());
        
        long processingTime = System.currentTimeMillis() - startTime;
        
        // Validate performance and data integrity
        validateDatabasePersistence(testData);
        validationHelper.validateProcessingMetrics(testData, processingTime);
        
        log.info("✓ Large transaction processing test passed in {}ms", processingTime);
    }

    /**
     * Test error recovery and retry mechanism
     */
    @Test
    void testErrorRecoveryMechanism() throws Exception {
        // Simulate a transaction that might cause issues initially
        ReferenceTestData testData = referenceDataLoader.loadByFilename("AP_INV_AS20250812_2.json");
        
        // First attempt might encounter some issues (simulated by service mock)
        when(globalTableService.findBuyerReference(anyString()))
            .thenThrow(new RuntimeException("Temporary database connection issue"))
            .thenReturn(createMockBuyerInfo()); // Second call succeeds
        
        // The endpoint should handle the error gracefully
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testData.getPayloadJson()))
                .andExpect(status().isAccepted()); // Should still return accepted
        
        // Verify error was logged appropriately  
        verify(apiLogService, atLeastOnce()).saveLog(argThat(log -> 
            "ERROR".equals(log.getApiStatus()) || "DONE".equals(log.getApiStatus())
        ));
        
        log.info("✓ Error recovery mechanism test passed");
    }

    /**
     * Test error handling for invalid payload structure
     */
    @Test
    void testInvalidPayloadHandling() throws Exception {
        String invalidPayload = "{\"Body\": {}}"; // Missing UniversalTransaction
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(invalidPayload))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Unsupported data strucutre")));
    }

    // Helper methods for test validation

    private void configureLegacyModeRouting() {
        when(routingService.shouldSendToExternalSystem(eq("AP"), anyString(), anyString()))
            .thenReturn(false);
        when(routingService.shouldSendToExternalSystem(eq("AR"), anyString(), anyString()))
            .thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("LEGACY");
        when(routingService.isLegacyModeEnabled()).thenReturn(true);
    }

    private void setupCargowiseTestData(ReferenceTestData testData) {
        // Setup any required test data in SQL Server container
        // This would populate AccTransactionHeader, AccTransactionLines, etc.
        log.debug("Setting up Cargowise test data for: {}", testData.getTransactionNo());
    }

    private void validateResponseContent(MvcResult result, ReferenceTestData testData) {
        try {
            String responseBody = result.getResponse().getContentAsString();
            validationHelper.validateResponseContent(responseBody, testData);
        } catch (Exception e) {
            log.error("Error validating response content", e);
        }
    }

    private void validateDatabasePersistence(ReferenceTestData testData) {
        validationHelper.validateCompleteDatabasePersistence(testData);
        validationHelper.validateNoDuplicates(testData.getTransactionNo());
    }

    private void validateRoutingDecision(ReferenceTestData testData) {
        validationHelper.validateKafkaMessage(kafkaTemplate, testData, "test");
    }

    private void validateAPILogging(UUID trackId, ReferenceTestData testData) {
        validationHelper.validateAPILogging(apiLogService, trackId, testData);
    }

    // Helper methods for test data generation

    private String createARTransactionPayload(String transactionNo) {
        return String.format("""
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AR",
                            "TransactionType": "INV",
                            "Number": "%s",
                            "IsCancelled": false,
                            "Job": {
                                "Type": "Job",
                                "Key": "TESTJOB001"
                            },
                            "DataContext": {
                                "EventType": {
                                    "Code": "ADD"
                                },
                                "TriggerDate": "2025-08-12T15:46:10.767+08:00"
                            },
                            "PostingJournalCollection": {
                                "PostingJournal": [
                                    {
                                        "ChargeCode": {
                                            "Code": "FRT",
                                            "Description": "Freight Charges"
                                        },
                                        "LocalAmount": 1000.00,
                                        "Sequence": 1
                                    }
                                ]
                            }
                        }
                    }
                }
            }
            """, transactionNo);
    }

    private String createMinimalTransactionPayload() {
        return """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AP",
                            "TransactionType": "INV", 
                            "Number": "MINIMAL_TEST_001",
                            "IsCancelled": false,
                            "DataContext": {
                                "EventType": {
                                    "Code": "ADD"
                                }
                            }
                        }
                    }
                }
            }
            """;
    }

    private BuyerInfo createMockBuyerInfo() {
        BuyerInfo buyerInfo = new BuyerInfo();
        buyerInfo.setBuyerReference("MOCK_BUYER");
        buyerInfo.setBuyerName("Mock Buyer Company");
        return buyerInfo;
    }
}