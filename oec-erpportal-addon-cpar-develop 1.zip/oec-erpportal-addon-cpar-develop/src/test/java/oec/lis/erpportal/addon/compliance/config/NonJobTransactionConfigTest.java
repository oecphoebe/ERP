package oec.lis.erpportal.addon.compliance.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import oec.lis.erpportal.addon.compliance.common.config.NonJobTransactionConfig;

/**
 * Unit test for NonJobTransactionConfig (without Spring Boot context)
 */
class NonJobTransactionConfigTest {

    @Test
    void testDefaultConfiguration() {
        // Test default values when creating a new instance
        NonJobTransactionConfig config = new NonJobTransactionConfig();
        
        assertFalse(config.isEnabled(), "NONJOB support should be disabled by default");
        assertEquals("NONJOB transactions are not supported in this environment", 
                    config.getErrorMessage(), "Default error message should match");
    }

    @Test
    void testCustomConfiguration() {
        // Test setting custom values
        NonJobTransactionConfig config = new NonJobTransactionConfig();
        config.setEnabled(true);
        config.setErrorMessage("Custom test error message");
        
        assertTrue(config.isEnabled(), "NONJOB support should be enabled when set to true");
        assertEquals("Custom test error message", 
                    config.getErrorMessage(), "Custom error message should be set");
    }

    @Test
    void testDisabledConfiguration() {
        // Test explicitly setting disabled
        NonJobTransactionConfig config = new NonJobTransactionConfig();
        config.setEnabled(false);
        
        assertFalse(config.isEnabled(), "NONJOB support should be disabled when explicitly set to false");
        assertEquals("NONJOB transactions are not supported in this environment", 
                    config.getErrorMessage(), "Default error message should be used when not overridden");
    }

    @Test
    void testSetErrorMessage() {
        // Test setting error message independently
        NonJobTransactionConfig config = new NonJobTransactionConfig();
        String customMessage = "Please contact administrator to enable NONJOB support";
        config.setErrorMessage(customMessage);
        
        assertEquals(customMessage, config.getErrorMessage(), "Error message should be settable");
        assertFalse(config.isEnabled(), "Enabled flag should remain unchanged");
    }
}