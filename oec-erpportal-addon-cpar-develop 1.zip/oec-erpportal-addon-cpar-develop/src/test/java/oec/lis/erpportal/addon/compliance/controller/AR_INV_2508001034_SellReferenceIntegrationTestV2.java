package oec.lis.erpportal.addon.compliance.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MvcResult;

import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.util.BaseTransactionIntegrationTest;

/**
 * Integration test for AR Invoice 2508001034 SellReference extraction using enhanced buyerCode logic.
 * 
 * This test validates:
 * 1. JsonPath expressions work correctly with actual Cargowise JSON payloads
 * 2. Enhanced SellReference extraction returns "YANTFUSHA" for transaction "2508001034"
 * 3. Complete transaction processing flow with real JSON structure
 * 4. Database integration and data persistence
 * 
 * Uses V2 testing framework with BaseTransactionIntegrationTest for comprehensive validation.
 */
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@TestPropertySource(properties = {
    "transaction.nonjob.enabled=true"
})
class AR_INV_2508001034_SellReferenceIntegrationTestV2 extends BaseTransactionIntegrationTest {

    private String testPayloadJson;
    private Map<String, Integer> initialCounts;
    
    @Override
    protected void setupSpecificTestData() throws Exception {
        // Setup Cargowise test data for AR Invoice 2508001034
        setupCargowiseTestData(getTestDataSqlFile());
        
        // Verify critical test data was loaded
        Map<String, Object> expectedData = new HashMap<>();
        expectedData.put("transactionNumber", "2508001034");
        expectedData.put("jobNumber", "SSSH1250718349");
        expectedData.put("organizationCode", "YANTFUSHA");
        
        try (Connection conn = getSqlServerConnection()) {
            sqlUtils.verifyCargowiseTestData(conn, expectedData);
        }
    }
    
    @Override
    protected String getTestDataSqlFile() {
        return "test-data-cargowise-ar-2508001034.sql";
    }
    
    @BeforeEach
    void setupTest() throws Exception {
        log.info("=== AR_INV_2508001034 SellReference Integration Test Setup ===");
        
        // Load and validate the actual reference JSON payload
        testPayloadJson = payloadLoader.loadAndValidatePayload("reference/AR_INV_2508001034.json");
        log.info("Loaded actual AR_INV_2508001034.json payload with {} characters", testPayloadJson.length());
        
        // Test JsonPath expressions directly against the loaded JSON to verify structure compatibility
        testJsonPathCompatibility();
        
        // Setup mocks for buyer info lookup
        mockUtils.setupBuyerInfoMock(globalTableService, "YANTFUSHA", "YANTAI T. FULL BIOTECH CO., LTD.");
        
        // Setup transaction routing for AR Invoice
        mockUtils.setupARInvoiceRouting(transactionRoutingService, "2508001034");
        
        // Record initial database state
        try (Connection conn = getPostgresConnection()) {
            initialCounts = new HashMap<>();
            initialCounts.put("at_account_transaction_header", databaseUtils.countRecordsInTable(conn, "at_account_transaction_header"));
            initialCounts.put("at_account_transaction_lines", databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines"));
            initialCounts.put("at_shipment_info", databaseUtils.countRecordsInTable(conn, "at_shipment_info"));
            initialCounts.put("sys_api_log", databaseUtils.countRecordsInTable(conn, "sys_api_log"));
        }
        log.info("Recorded initial database state: {}", initialCounts);
    }
    
    /**
     * Test JsonPath expressions directly against the loaded JSON payload to ensure compatibility
     */
    private void testJsonPathCompatibility() throws Exception {
        log.info("=== Testing JsonPath Compatibility with Actual JSON ===");
        
        Object document = objectMapper.readValue(testPayloadJson, Object.class);
        
        // Test basic SellReference extraction
        @SuppressWarnings("unchecked")
        List<String> basicSellReferenceList = JsonPath.read(document, "$..SellReference");
        log.info("Basic $..SellReference returned: {} items", basicSellReferenceList.size());
        if (!basicSellReferenceList.isEmpty()) {
            log.info("First SellReference: {}", basicSellReferenceList.get(0));
        }
        
        // Test enhanced SellReference extraction with filtering  
        String enhancedJsonPath = "$..ChargeLine[?(@.SellPostedTransactionNumber=='2508001034')].SellReference";
        @SuppressWarnings("unchecked")
        List<String> enhancedSellReferenceList = JsonPath.read(document, enhancedJsonPath);
        log.info("Enhanced JsonPath {} returned: {} items", enhancedJsonPath, enhancedSellReferenceList.size());
        if (!enhancedSellReferenceList.isEmpty()) {
            log.info("First enhanced SellReference: {}", enhancedSellReferenceList.get(0));
        }
        
        // Validate expected results
        if (basicSellReferenceList.size() != 4) {
            throw new AssertionError("Expected 4 SellReference items, got: " + basicSellReferenceList.size());
        }
        
        if (enhancedSellReferenceList.size() != 2) {
            throw new AssertionError("Expected 2 enhanced SellReference items, got: " + enhancedSellReferenceList.size());
        }
        
        String expectedBuyerCode = "YANTFUSHA";
        if (!expectedBuyerCode.equals(enhancedSellReferenceList.get(0))) {
            throw new AssertionError("Expected enhanced SellReference 'YANTFUSHA', got: " + enhancedSellReferenceList.get(0));
        }
        
        log.info("✅ JsonPath compatibility validation passed - Enhanced logic correctly returns 'YANTFUSHA'");
    }
    
    @Test
    @Order(1)
    void testJsonPathStructureDirectly() throws Exception {
        log.info("=== Test 1: JsonPath Structure Direct Validation ===");
        
        // This test validates JsonPath expressions work outside Spring test context
        // to isolate any framework-specific issues discovered in Session A_03
        
        Object document = objectMapper.readValue(testPayloadJson, Object.class);
        
        // Test the exact expressions used in TransactionMappingService
        String sanitizedTransactionNumber = "2508001034";
        String jsonPathExpression = String.format(
            "$..ChargeLine[?(@.SellPostedTransactionNumber=='%s')].SellReference", 
            sanitizedTransactionNumber
        );
        
        log.info("Testing JsonPath expression: {}", jsonPathExpression);
        @SuppressWarnings("unchecked")
        List<String> filteredSellReferenceList = JsonPath.read(document, jsonPathExpression);
        log.info("JsonPath returned: {} items", filteredSellReferenceList.size());
        
        // Validate results match expected enhanced logic behavior
        assert filteredSellReferenceList.size() == 2 : "Expected 2 matching ChargeLines";
        assert "YANTFUSHA".equals(filteredSellReferenceList.get(0)) : "Expected first result to be 'YANTFUSHA'";
        assert "YANTFUSHA".equals(filteredSellReferenceList.get(1)) : "Expected second result to be 'YANTFUSHA'";
        
        log.info("✅ JsonPath structure validation passed - Enhanced logic works correctly");
    }
    
    @Test
    @Order(2)
    void testCompleteTransactionProcessingFlow() throws Exception {
        log.info("=== Test 2: Complete Transaction Processing Flow ===");
        
        // Execute the transaction request using the actual reference JSON
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        // Verify successful response (202 = Accepted, saved to DB only since Kafka is disabled in test)
        int actualStatus = result.getResponse().getStatus();
        String responseContent = result.getResponse().getContentAsString();
        log.info("Response status: {}, content: {}", actualStatus, responseContent);
        assert actualStatus == 202 : String.format("Expected status 202 but got %d. Response: %s", actualStatus, responseContent);
        assert responseContent.contains("AR INV Payload received and saved to DB") : "Expected successful save to DB in response";
        log.info("✅ Transaction processing completed successfully");
        
        // Verify database changes occurred (NONJOB transactions don't create shipment records)
        try (Connection conn = getPostgresConnection()) {
            int newHeaders = databaseUtils.countRecordsInTable(conn, "at_account_transaction_header");
            int newLines = databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines");
            int newShipments = databaseUtils.countRecordsInTable(conn, "at_shipment_info");
            int newLogs = databaseUtils.countRecordsInTable(conn, "sys_api_log");
            
            log.info("Database counts - Headers: {} (initial: {}), Lines: {} (initial: {}), Shipments: {} (initial: {}), Logs: {} (initial: {})", 
                newHeaders, initialCounts.get("at_account_transaction_header"),
                newLines, initialCounts.get("at_account_transaction_lines"), 
                newShipments, initialCounts.get("at_shipment_info"),
                newLogs, initialCounts.get("sys_api_log"));
            
            assert newHeaders == initialCounts.get("at_account_transaction_header") + 1 : "Expected 1 new transaction header";
            assert newLines == initialCounts.get("at_account_transaction_lines") + 2 : "Expected 2 new transaction lines";
            // NONJOB transactions don't create shipment records, so shipment count should remain the same
            assert newShipments == initialCounts.get("at_shipment_info") : "Expected no change in shipment info for NONJOB transaction";
            assert newLogs == initialCounts.get("sys_api_log") + 1 : "Expected 1 new API log entry";
        }
        log.info("✅ Database changes validated successfully");
    }
    
    @Test  
    @Order(3)
    void testChequeOrReferenceExtraction() throws Exception {
        log.info("=== Test 3: ChequeOrReference Field Extraction Validation ===");
        
        // First process the transaction to have data in database
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        // Verify the correct chequeOrReference was extracted and stored
        try (Connection conn = getPostgresConnection()) {
            String sql = "SELECT chequeorreference FROM at_account_transaction_header WHERE trans_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2508001034");
            ResultSet rs = stmt.executeQuery();
            
            assert rs.next() : "Transaction header not found for 2508001034";
            String actualChequeOrReference = rs.getString("chequeorreference");
            assert "YANTFUSHA".equals(actualChequeOrReference) : 
                String.format("Expected chequeOrReference 'YANTFUSHA', got: '%s'", actualChequeOrReference);
                
            log.info("✅ ChequeOrReference field extraction validated: {}", actualChequeOrReference);
            rs.close();
            stmt.close();
        }
    }
    
    @Test
    @Order(4) 
    void testTransactionLineDetails() throws Exception {
        log.info("=== Test 4: Transaction Line Details Validation ===");
        
        // Process the transaction
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        // Verify transaction line details exist (lines don't store chequeOrReference, only header does)
        try (Connection conn = getPostgresConnection()) {
            String sql = "SELECT count(*) as line_count FROM at_account_transaction_lines WHERE acct_trans_header_id IN (SELECT acct_trans_header_id FROM at_account_transaction_header WHERE trans_no = ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2508001034");
            ResultSet rs = stmt.executeQuery();
            
            assert rs.next() : "Unable to count transaction lines";
            int lineCount = rs.getInt("line_count");
            assert lineCount == 2 : String.format("Expected 2 transaction lines, got: %d", lineCount);
            
            rs.close();
            stmt.close();
            
            log.info("✅ Transaction line details validated - Found {} transaction lines", lineCount);
        }
    }
    
    @Test
    @Order(5)
    void testFallbackLogicNotUsed() throws Exception {
        log.info("=== Test 5: Enhanced Logic Used (Not Fallback) ===");
        
        // This test confirms that for transaction 2508001034, the enhanced logic
        // finds matches and does NOT fall back to the original $..SellReference logic
        
        Object document = objectMapper.readValue(testPayloadJson, Object.class);
        
        // Test enhanced logic finds matches
        String enhancedJsonPath = "$..ChargeLine[?(@.SellPostedTransactionNumber=='2508001034')].SellReference";
        @SuppressWarnings("unchecked")
        List<String> enhancedResults = JsonPath.read(document, enhancedJsonPath);
        @SuppressWarnings("unchecked")
        List<String> fallbackResults = JsonPath.read(document, "$..SellReference");
        
        // Validate enhanced logic results differ from fallback 
        assert !enhancedResults.isEmpty() : "Enhanced logic should find matches";
        assert enhancedResults.size() == 2 : "Enhanced logic should find exactly 2 matches";
        assert fallbackResults.size() == 4 : "Fallback logic should find 4 total SellReference items";
        
        // Enhanced logic returns filtered results, fallback would return first unfiltered result
        String enhancedResult = enhancedResults.get(0);  // "YANTFUSHA"
        String fallbackResult = fallbackResults.get(0);  // "OECGRPORD" (first in document order)
        
        assert "YANTFUSHA".equals(enhancedResult) : "Enhanced logic should return YANTFUSHA";
        assert "OECGRPORD".equals(fallbackResult) : "Fallback logic would return OECGRPORD";
        assert !enhancedResult.equals(fallbackResult) : "Enhanced and fallback results should differ";
        
        log.info("✅ Enhanced logic validation passed - Returns YANTFUSHA (not fallback OECGRPORD)");
    }
    
    @Test
    @Order(6)
    void testDifferentTransactionNumberFallback() throws Exception {
        log.info("=== Test 6: Different Transaction Number Fallback Logic ===");
        
        // Test that enhanced logic falls back to original logic when no matches found
        Object document = objectMapper.readValue(testPayloadJson, Object.class);
        
        String nonExistentTransaction = "9999999999";
        String enhancedJsonPath = String.format(
            "$..ChargeLine[?(@.SellPostedTransactionNumber=='%s')].SellReference", 
            nonExistentTransaction
        );
        
        @SuppressWarnings("unchecked")
        List<String> enhancedResults = JsonPath.read(document, enhancedJsonPath);
        @SuppressWarnings("unchecked")
        List<String> fallbackResults = JsonPath.read(document, "$..SellReference");
        
        // Enhanced logic should find no matches for non-existent transaction
        assert enhancedResults.isEmpty() : "Enhanced logic should find no matches for non-existent transaction";
        
        // Fallback logic should still work
        assert !fallbackResults.isEmpty() : "Fallback logic should find SellReference items";
        assert "OECGRPORD".equals(fallbackResults.get(0)) : "Fallback should return first SellReference";
        
        log.info("✅ Fallback logic validation passed - Enhanced logic falls back correctly");
    }
    
    @Test
    @Order(7)
    void testChequeOrReferenceFieldValidation() throws Exception {
        log.info("=== Test 7: Comprehensive ChequeOrReference Field Validation ===");
        
        // Process the transaction
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        // Verify chequeOrReference field is correctly populated in database
        try (Connection conn = getPostgresConnection()) {
            String sql = "SELECT trans_no, chequeorreference, create_time FROM at_account_transaction_header WHERE trans_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2508001034");
            ResultSet rs = stmt.executeQuery();
            
            assert rs.next() : "Transaction header not found for 2508001034";
            
            String transactionNumber = rs.getString("trans_no");
            String actualChequeOrReference = rs.getString("chequeorreference");
            String createTime = rs.getString("create_time");
            
            // Validate transaction details
            assert "2508001034".equals(transactionNumber) : "Transaction number mismatch";
            assert "YANTFUSHA".equals(actualChequeOrReference) : 
                String.format("Expected chequeOrReference 'YANTFUSHA', got: '%s'", actualChequeOrReference);
            assert createTime != null : "Create time should not be null";
            
            // Verify field is not null and within length constraints
            assert actualChequeOrReference != null : "ChequeOrReference should not be null for successful extraction";
            assert actualChequeOrReference.length() <= 38 : 
                String.format("ChequeOrReference length %d exceeds maximum 38 characters", actualChequeOrReference.length());
            assert actualChequeOrReference.length() > 0 : "ChequeOrReference should not be empty string";
            
            log.info("✅ ChequeOrReference field validation passed - Value: '{}', Length: {}", 
                actualChequeOrReference, actualChequeOrReference.length());
            
            rs.close();
            stmt.close();
        }
    }
    
    @Test
    @Order(8)
    void testChequeOrReferenceNullScenario() throws Exception {
        log.info("=== Test 8: ChequeOrReference Null Value Scenario ===");
        
        // Create a payload with no matching SellReference for enhanced logic
        String modifiedPayload = testPayloadJson.replace("2508001034", "9999999999");
        
        // Process the transaction with modified payload (should fall back to original logic)
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(modifiedPayload))
                .andReturn();
        
        // Verify response is still successful
        int actualStatus = result.getResponse().getStatus();
        assert actualStatus == 202 : String.format("Expected status 202 but got %d", actualStatus);
        
        // Wait a moment for database write
        Thread.sleep(100);
        
        // Verify database record exists and check chequeOrReference field
        try (Connection conn = getPostgresConnection()) {
            String sql = "SELECT trans_no, chequeorreference FROM at_account_transaction_header WHERE trans_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "9999999999");
            ResultSet rs = stmt.executeQuery();
            
            assert rs.next() : "Transaction header not found for 9999999999";
            
            String transactionNumber = rs.getString("trans_no");
            String actualChequeOrReference = rs.getString("chequeorreference");
            
            // Validate transaction was created
            assert "9999999999".equals(transactionNumber) : "Transaction number mismatch";
            
            // For this scenario, chequeOrReference should be populated with fallback logic result
            // The fallback logic returns the first SellReference found in the JSON, regardless of transaction number
            assert actualChequeOrReference != null : "ChequeOrReference should not be null (fallback should work)";
            // The fallback logic still finds SellReference values, so it will be populated (could be any SellReference from the JSON)
            assert actualChequeOrReference.length() > 0 : "ChequeOrReference should not be empty when fallback works";
            
            // Log what we actually got - the important thing is that fallback logic works, not the specific value
            log.info("Fallback logic returned: '{}'", actualChequeOrReference);
            
            log.info("✅ Null scenario validation passed - Fallback value: '{}'", actualChequeOrReference);
            
            rs.close();
            stmt.close();
        }
    }
    
    @Test
    @Order(9)
    void testChequeOrReferenceLengthConstraint() throws Exception {
        log.info("=== Test 9: ChequeOrReference Length Constraint Validation ===");
        
        // This test validates that the 38-character constraint is properly enforced
        // We'll use the existing payload which should have values within the constraint
        
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        try (Connection conn = getPostgresConnection()) {
            String sql = "SELECT chequeorreference FROM at_account_transaction_header WHERE trans_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2508001034");
            ResultSet rs = stmt.executeQuery();
            
            assert rs.next() : "Transaction header not found";
            String chequeOrReference = rs.getString("chequeorreference");
            
            // Validate length constraint
            int actualLength = chequeOrReference.length();
            assert actualLength <= 38 : 
                String.format("ChequeOrReference length %d exceeds 38-character limit", actualLength);
            assert actualLength > 0 : "ChequeOrReference should not be empty";
            
            // Validate content is expected value
            assert "YANTFUSHA".equals(chequeOrReference) : 
                String.format("Expected 'YANTFUSHA', got: '%s'", chequeOrReference);
            assert chequeOrReference.length() == 9 : 
                String.format("Expected length 9 for 'YANTFUSHA', got: %d", chequeOrReference.length());
            
            log.info("✅ Length constraint validation passed - Value: '{}', Length: {}", 
                chequeOrReference, actualLength);
            
            rs.close();
            stmt.close();
        }
    }
    
    @Test
    @Order(10)
    void testChequeOrReferenceDataIntegrity() throws Exception {
        log.info("=== Test 10: ChequeOrReference Data Integrity Validation ===");
        
        // Process transaction and verify complete data integrity
        mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andReturn();
        
        try (Connection conn = getPostgresConnection()) {
            // Check that chequeOrReference is consistent across potential multiple inserts
            String sql = "SELECT trans_no, chequeorreference, ledger, trans_type, create_time, update_time FROM at_account_transaction_header WHERE trans_no = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "2508001034");
            ResultSet rs = stmt.executeQuery();
            
            int recordCount = 0;
            String chequeOrReference = null;
            
            while (rs.next()) {
                recordCount++;
                String currentChequeOrReference = rs.getString("chequeorreference");
                String ledger = rs.getString("ledger");
                String transType = rs.getString("trans_type");
                String createTime = rs.getString("create_time");
                String updateTime = rs.getString("update_time");
                
                // Validate transaction metadata
                assert "AR".equals(ledger) : String.format("Expected ledger 'AR', got: '%s'", ledger);
                assert "INV".equals(transType) : String.format("Expected trans_type 'INV', got: '%s'", transType);
                assert createTime != null : "Create time should not be null";
                
                // Check consistency of chequeOrReference
                if (chequeOrReference == null) {
                    chequeOrReference = currentChequeOrReference;
                } else {
                    assert chequeOrReference.equals(currentChequeOrReference) : 
                        "ChequeOrReference values should be consistent across records";
                }
                
                assert "YANTFUSHA".equals(currentChequeOrReference) : 
                    String.format("Expected chequeOrReference 'YANTFUSHA', got: '%s'", currentChequeOrReference);
            }
            
            assert recordCount == 1 : String.format("Expected 1 record, found: %d", recordCount);
            
            log.info("✅ Data integrity validation passed - Records: {}, ChequeOrReference: '{}'", 
                recordCount, chequeOrReference);
            
            rs.close();
            stmt.close();
        }
    }
}