package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

/**
 * Integration test for NONJOB buyerCode extraction using real sample JSON files.
 *
 * <p>This test validates the two-phase buyerCode extraction logic:
 * <ol>
 *   <li>Phase 1 (Primary): Extract from $.CheckNumberOrPaymentRef</li>
 *   <li>Phase 2 (Fallback): Extract from $.OrganizationAddress.OrganizationCode</li>
 *   <li>Return null if both phases fail (graceful degradation)</li>
 * </ol>
 *
 * <p>NOTE: These are JSON structure validation tests that don't require Spring context.
 */
@Slf4j
public class NonjobBuyerCodeExtractionIntegrationTest {

    private String loadJsonFile(String filename) throws IOException {
        // Try to load from test resources first
        Path resourcePath = Paths.get("src/test/resources/reference/" + filename);
        if (!Files.exists(resourcePath)) {
            // Fallback to reference directory
            resourcePath = Paths.get("reference/" + filename);
        }

        if (!Files.exists(resourcePath)) {
            throw new IOException("Test file not found: " + filename);
        }

        return Files.readString(resourcePath);
    }

    @Test
    void testNonjobBuyerCode_Fallback_RealSampleFile() throws Exception {
        // This file has CheckNumberOrPaymentRef="" (empty) but OrganizationCode="QINGARTAO"
        // Should fall back to OrganizationCode
        String jsonPayload = loadJsonFile("NonJob-AR_INV_2511001019-Add.json");

        // Verify the JSON structure
        String checkNumberOrPaymentRef = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.CheckNumberOrPaymentRef");
        String organizationCode = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode");

        log.info("Test payload CheckNumberOrPaymentRef=[{}], OrganizationCode=[{}]",
                checkNumberOrPaymentRef, organizationCode);

        // Validate JSON structure
        assertTrue(checkNumberOrPaymentRef == null || checkNumberOrPaymentRef.isEmpty(),
                "Test file should have empty/null CheckNumberOrPaymentRef to trigger fallback");
        assertEquals("QINGARTAO", organizationCode,
                "Test file should have OrganizationCode='QINGARTAO'");

        // Simulate extraction logic
        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        String buyerCode = service.extractBuyerCode(transactionInfo, "AR",
                "2511001019", "NONJOB");

        // Assert fallback extraction worked
        assertEquals("QINGARTAO", buyerCode,
                "NONJOB with empty CheckNumberOrPaymentRef should fall back to OrganizationCode");

        log.info("✓ Fallback extraction validated: buyerCode=[{}]", buyerCode);
    }

    @Test
    void testNonjobBuyerCode_Primary_RealSampleFile() throws Exception {
        // This file has CheckNumberOrPaymentRef="QINGARTAO" (populated)
        // Should use primary path, NOT fallback
        String jsonPayload = loadJsonFile("NonJob_AR_INV_2511001018-ADD.json");

        // Verify the JSON structure
        String checkNumberOrPaymentRef = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.CheckNumberOrPaymentRef");
        String organizationCode = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode");

        log.info("Test payload CheckNumberOrPaymentRef=[{}], OrganizationCode=[{}]",
                checkNumberOrPaymentRef, organizationCode);

        // Validate JSON structure
        assertNotNull(checkNumberOrPaymentRef, "Test file should have populated CheckNumberOrPaymentRef");
        assertFalse(checkNumberOrPaymentRef.trim().isEmpty(),
                "CheckNumberOrPaymentRef should not be empty/blank");
        assertEquals("QINGARTAO", organizationCode,
                "Test file should have OrganizationCode='QINGARTAO'");

        // Simulate extraction logic
        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        String buyerCode = service.extractBuyerCode(transactionInfo, "AR",
                "2511001018", "NONJOB");

        // Assert primary extraction worked (should use CheckNumberOrPaymentRef, not fallback)
        assertEquals(checkNumberOrPaymentRef.trim(), buyerCode,
                "NONJOB with populated CheckNumberOrPaymentRef should use primary path (not fallback)");

        log.info("✓ Primary extraction validated: buyerCode=[{}] from CheckNumberOrPaymentRef (not fallback)", buyerCode);
    }

    @Test
    void testNonjobBuyerCode_DebiterCodePropagation() throws Exception {
        // Validates that buyerCode automatically propagates to debiterCode for NONJOB
        // This is a documentation test - the actual propagation happens in createTransactionInfoRequestSafe()
        String jsonPayload = loadJsonFile("NonJob-AR_INV_2511001019-Add.json");

        // Verify the fallback extraction
        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        String buyerCode = service.extractBuyerCode(transactionInfo, "AR",
                "2511001019", "NONJOB");

        assertEquals("QINGARTAO", buyerCode,
                "BuyerCode should be extracted from fallback");

        log.info("✓ BuyerCode extraction validated: [{}]", buyerCode);
        log.info("  Note: For NONJOB transactions, debiterCode is set equal to buyerCode in TransactionMappingService.createTransactionInfoRequestSafe()");
        log.info("  Expected behavior: debiterCode = buyerCode = '{}'", buyerCode);

        // Note: Full end-to-end debiterCode validation requires V2 integration test framework
        // This test documents the expected behavior
    }

    @Test
    void testNonjobBuyerCode_PrecedenceValidation() throws Exception {
        // Validates that when BOTH CheckNumberOrPaymentRef and OrganizationCode are present,
        // primary (CheckNumberOrPaymentRef) takes precedence over fallback
        String jsonPayload = loadJsonFile("NonJob_AR_INV_2511001018-ADD.json");

        // Extract both values
        String checkNumberOrPaymentRef = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.CheckNumberOrPaymentRef");
        String organizationCode = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode");

        log.info("Precedence test: CheckNumberOrPaymentRef=[{}], OrganizationCode=[{}]",
                checkNumberOrPaymentRef, organizationCode);

        // Simulate extraction
        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        String buyerCode = service.extractBuyerCode(transactionInfo, "AR",
                "2511001018", "NONJOB");

        // Assert primary takes precedence
        assertEquals(checkNumberOrPaymentRef.trim(), buyerCode,
                "When both are present, primary (CheckNumberOrPaymentRef) should take precedence");

        log.info("✓ Precedence validated: Primary path used buyerCode=[{}] (not fallback OrganizationCode=[{}])",
                buyerCode, organizationCode);
    }

    @Test
    void testNonjobBuyerCode_WhitespaceTrimming_RealFile() throws Exception {
        // Validates whitespace trimming on real data
        String jsonPayload = loadJsonFile("NonJob-AR_INV_2511001019-Add.json");

        // Extract OrganizationCode
        String organizationCode = JsonPath.read(jsonPayload,
                "$.Body.UniversalTransaction.TransactionInfo.OrganizationAddress.OrganizationCode");

        log.info("OrganizationCode from file: [{}]", organizationCode);

        // Check if it has whitespace (it should not in real files, but test the logic)
        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        String buyerCode = service.extractBuyerCode(transactionInfo, "AR",
                "2511001019", "NONJOB");

        // Should equal trimmed version
        assertEquals(organizationCode.trim(), buyerCode,
                "BuyerCode should have whitespace trimmed (if any exists)");

        log.info("✓ Whitespace handling validated: OrganizationCode=[{}], buyerCode=[{}]",
                organizationCode, buyerCode);
    }

    @Test
    void testNonjobBuyerCode_APLedger_RealFile() throws Exception {
        // Test with AP ledger instead of AR (should work the same)
        String jsonPayload = loadJsonFile("NonJob-AR_INV_2511001019-Add.json");

        TransactionMappingService service = createTestService();
        Object transactionInfo = JsonPath.read(jsonPayload, "$.Body.UniversalTransaction.TransactionInfo");

        // Use AP ledger instead of AR
        String buyerCode = service.extractBuyerCode(transactionInfo, "AP",
                "2511001019", "NONJOB");

        assertEquals("QINGARTAO", buyerCode,
                "NONJOB fallback should work for AP ledger same as AR ledger");

        log.info("✓ AP ledger fallback works: buyerCode=[{}]", buyerCode);
    }

    /**
     * Creates a test instance of TransactionMappingService with mocked dependencies.
     * The extractBuyerCode() method doesn't use these dependencies, so mocks are minimal.
     */
    private TransactionMappingService createTestService() {
        // For this test, we only need the service instance to call extractBuyerCode()
        // The method doesn't use injected dependencies for NONJOB extraction
        // In a full integration test, use proper dependency injection or V2 framework
        try {
            return new TransactionMappingService(null, null, null, null, null);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create test service", e);
        }
    }
}
