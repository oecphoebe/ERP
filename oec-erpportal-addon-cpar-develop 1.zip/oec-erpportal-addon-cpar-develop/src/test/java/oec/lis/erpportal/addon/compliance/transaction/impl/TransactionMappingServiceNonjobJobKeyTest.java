package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

import oec.lis.erpportal.addon.compliance.common.config.NonJobTransactionConfig;
import oec.lis.erpportal.addon.compliance.model.transaction.*;
import oec.lis.erpportal.addon.compliance.service.*;
import oec.lis.sopl.common.model.RestListResponse;

/**
 * Unit tests for NONJOB Job.Key extraction logic in TransactionMappingService.
 * Tests the new functionality where shipmentId is extracted from TransactionInfo.Job.Key
 * when TransactionInfo.Job.Type equals "Job" for NONJOB transactions.
 */
@ExtendWith(MockitoExtension.class)
public class TransactionMappingServiceNonjobJobKeyTest {

    @Mock
    private TransactionQueryService queryService;

    @Mock
    private TransactionValidationService validationService;

    @Mock
    private AtAccountTransactionTableService atAccountTransactionTableService;

    @Mock
    private ChargeLineProcessor chargeLineProcessor;

    @Mock
    private NonJobTransactionConfig nonJobConfig;

    @InjectMocks
    private TransactionMappingService transactionMappingService;

    /**
     * Creates test JSON payload with Job object at TransactionInfo level
     * @param jobType The Job.Type value (e.g., "Job", "NotJob", null)
     * @param jobKey The Job.Key value (e.g., "WI00000056", "", null)
     * @param includeJobObject Whether to include the Job object at all
     */
    private String createNonjobTestJson(String jobType, String jobKey, boolean includeJobObject) {
        return createNonjobTestJsonWithDataSource(jobType, jobKey, includeJobObject, null);
    }

    /**
     * Creates test JSON payload with Job object and optional DataSourceCollection at TransactionInfo level
     * @param jobType The Job.Type value (e.g., "Job", "NotJob", null)
     * @param jobKey The Job.Key value (e.g., "WI00000056", "", null)
     * @param includeJobObject Whether to include the Job object at all
     * @param dataSourceKeys List of AccountingInvoice Key values to add to DataSourceCollection (null = no DataSourceCollection)
     */
    private String createNonjobTestJsonWithDataSource(String jobType, String jobKey, boolean includeJobObject, List<String> dataSourceKeys) {
        Map<String, Object> payload = new HashMap<>();
        Map<String, Object> body = new HashMap<>();
        Map<String, Object> universalTransaction = new HashMap<>();
        Map<String, Object> transactionInfo = new HashMap<>();

        // Basic transaction info
        transactionInfo.put("Ledger", "AR");
        transactionInfo.put("TransactionType", "INV");
        transactionInfo.put("Number", "NONJOB_TEST_123");
        transactionInfo.put("TransactionDate", "2025-11-18");
        transactionInfo.put("IsCancelled", false);

        Map<String, Object> currency = new HashMap<>();
        currency.put("Code", "CNY");
        transactionInfo.put("Oscurrency", currency);

        Map<String, Object> company = new HashMap<>();
        company.put("Code", "SH1");
        Map<String, Object> dataContext = new HashMap<>();
        dataContext.put("Company", company);
        dataContext.put("TriggerDate", OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));

        // Add DataSourceCollection if requested (for fallback testing)
        if (dataSourceKeys != null && !dataSourceKeys.isEmpty()) {
            Map<String, Object> dataSourceCollection = new HashMap<>();
            List<Map<String, Object>> dataSources = new ArrayList<>();

            for (String key : dataSourceKeys) {
                Map<String, Object> dataSource = new HashMap<>();
                dataSource.put("Type", "AccountingInvoice");
                dataSource.put("Key", key);
                dataSources.add(dataSource);
            }

            dataSourceCollection.put("DataSource", dataSources);
            dataContext.put("DataSourceCollection", dataSourceCollection);
        }

        transactionInfo.put("DataContext", dataContext);

        Map<String, Object> branch = new HashMap<>();
        branch.put("Code", "SH1");
        transactionInfo.put("Branch", branch);

        Map<String, Object> department = new HashMap<>();
        department.put("Code", "FES");
        transactionInfo.put("Department", department);

        Map<String, Object> orgAddress = new HashMap<>();
        orgAddress.put("OrganizationCode", "REVERESEA");
        transactionInfo.put("OrganizationAddress", orgAddress);

        transactionInfo.put("Ostotal", "100.00");
        transactionInfo.put("OutstandingAmount", "100.00");
        transactionInfo.put("ExchangeRate", "1.0");
        transactionInfo.put("Osgstvatamount", "10.00");
        transactionInfo.put("LocalVATAmount", "10.00");
        transactionInfo.put("Description", "NONJOB Test Transaction");

        Map<String, Object> localCurrency = new HashMap<>();
        localCurrency.put("Code", "CNY");
        transactionInfo.put("LocalCurrency", localCurrency);

        // Add Job object at TransactionInfo level if requested
        if (includeJobObject) {
            Map<String, Object> job = new HashMap<>();
            if (jobType != null) {
                job.put("Type", jobType);
            }
            if (jobKey != null) {
                job.put("Key", jobKey);
            }
            transactionInfo.put("Job", job);
        }

        // Add PostingJournalCollection for NONJOB processing
        Map<String, Object> postingJournalCollection = new HashMap<>();
        List<Map<String, Object>> postingJournals = new ArrayList<>();
        Map<String, Object> postingJournal = new HashMap<>();

        postingJournal.put("LocalAmount", "100.00");
        postingJournal.put("LocalGSTVATAmount", "10.00");
        postingJournal.put("Description", "Test Charge");

        Map<String, Object> chargeCode = new HashMap<>();
        chargeCode.put("Code", "DOC");
        postingJournal.put("ChargeCode", chargeCode);

        Map<String, Object> organization = new HashMap<>();
        organization.put("Type", "Organization");
        organization.put("Key", "REVERESEA");
        postingJournal.put("Organization", organization);

        Map<String, Object> sellGstVatId = new HashMap<>();
        sellGstVatId.put("TaxCode", "VAT");
        postingJournal.put("SellGSTVATID", sellGstVatId);

        postingJournals.add(postingJournal);
        postingJournalCollection.put("PostingJournal", postingJournals);
        transactionInfo.put("PostingJournalCollection", postingJournalCollection);

        universalTransaction.put("TransactionInfo", transactionInfo);
        body.put("UniversalTransaction", universalTransaction);
        payload.put("Body", body);

        try {
            return new ObjectMapper().writeValueAsString(payload);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create test JSON", e);
        }
    }

    @BeforeEach
    void setUp() {
        // Mock NonJobConfig to be enabled for testing
        lenient().when(nonJobConfig.isEnabled()).thenReturn(true);
        lenient().when(nonJobConfig.getErrorMessage()).thenReturn("NONJOB not supported");

        // Mock basic query service responses (lenient to allow unused mocks)
        try {
            lenient().when(queryService.getDebiterName(anyString())).thenReturn("Test Debiter");
        } catch (Exception e) {
            // This shouldn't happen in mocking but required for compilation
        }
        lenient().when(queryService.getBuyerOrgInfo(anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getBuyerTaxNo(anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getBuyerBankInfo(anyString(), anyString())).thenReturn(Optional.empty());
        lenient().when(queryService.getCompanyUUID(anyString())).thenReturn(Optional.of(UUID.randomUUID()));

        // Mock GL-Account specific query method for NONJOB transactions
        lenient().when(queryService.getCwTransactionInfoForGLAccount(anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>());
    }

    @Test
    void testNonjob_WithJobTypeJob_AndJobKey_ExtractsShipmentId() throws Exception {
        // Arrange
        String expectedJobKey = "WI00000056";
        String json = createNonjobTestJson("Job", expectedJobKey, true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Empty for NONJOB (lenient - not used by GL-Account type)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // NONJOB with Job.Type="Job" and Job.Key should extract shipmentId from Job.Key
                assertEquals(expectedJobKey, request.getShipmentId(),
                    "NONJOB with Job.Type='Job' and Job.Key should extract shipmentId from Job.Key");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_WithJobTypeJob_ButNoJobKey_ShipmentIdNull() throws Exception {
        // Arrange - Job.Type="Job" but Job.Key field doesn't exist
        String json = createNonjobTestJson("Job", null, true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Job.Type="Job" but no Job.Key field → shipmentId should be null
                assertNull(request.getShipmentId(),
                    "NONJOB with Job.Type='Job' but missing Job.Key field should have null shipmentId");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_WithJobTypeJob_ButEmptyJobKey_ShipmentIdNull() throws Exception {
        // Arrange - Job.Type="Job" but Job.Key is empty string
        String json = createNonjobTestJson("Job", "", true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Job.Type="Job" but Job.Key is empty → shipmentId should be null
                assertNull(request.getShipmentId(),
                    "NONJOB with Job.Type='Job' but empty Job.Key should have null shipmentId");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_WithJobTypeNotJob_ShipmentIdNull() throws Exception {
        // Arrange - Job.Type != "Job"
        String json = createNonjobTestJson("NotJob", "SOME_KEY", true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Job.Type != "Job" → shipmentId should be null even if Job.Key exists
                assertNull(request.getShipmentId(),
                    "NONJOB with Job.Type != 'Job' should have null shipmentId even if Job.Key exists");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_WithoutJobObject_ShipmentIdNull() throws Exception {
        // Arrange - No Job object at all
        String json = createNonjobTestJson(null, null, false);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // No Job object → shipmentId should be null (original behavior)
                assertNull(request.getShipmentId(),
                    "NONJOB without Job object should have null shipmentId (original behavior)");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_WithJobKeyWhitespace_ShipmentIdNull() throws Exception {
        // Arrange - Job.Key is whitespace only
        String json = createNonjobTestJson("Job", "   ", true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Job.Key with only whitespace should be treated as blank → null shipmentId
                assertNull(request.getShipmentId(),
                    "NONJOB with whitespace-only Job.Key should have null shipmentId");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjob_MultipleJobKeys_ExtractsFirst() throws Exception {
        // Arrange - Valid Job.Type and Job.Key with various special characters
        String expectedJobKey = "WI-2025-11-18_001";
        String json = createNonjobTestJson("Job", expectedJobKey, true);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Should handle Job.Key with special characters correctly
                assertEquals(expectedJobKey, request.getShipmentId(),
                    "NONJOB should extract Job.Key with special characters correctly");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testShipment_NotAffectedByNonjobLogic() throws Exception {
        // Arrange - SHIPMENT transaction should not be affected by NONJOB logic
        Map<String, Object> payload = new HashMap<>();
        Map<String, Object> body = new HashMap<>();
        Map<String, Object> universalTransaction = new HashMap<>();
        Map<String, Object> transactionInfo = new HashMap<>();

        transactionInfo.put("Ledger", "AR");
        transactionInfo.put("TransactionType", "INV");
        transactionInfo.put("Number", "SHIPMENT_TEST");
        transactionInfo.put("TransactionDate", "2025-11-18");
        transactionInfo.put("IsCancelled", false);

        // Add minimal required fields
        Map<String, Object> currency = new HashMap<>();
        currency.put("Code", "CNY");
        transactionInfo.put("Oscurrency", currency);
        transactionInfo.put("LocalCurrency", currency);

        Map<String, Object> company = new HashMap<>();
        company.put("Code", "SH1");
        Map<String, Object> dataContext = new HashMap<>();
        dataContext.put("Company", company);
        dataContext.put("TriggerDate", OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        transactionInfo.put("DataContext", dataContext);

        Map<String, Object> branch = new HashMap<>();
        branch.put("Code", "SH1");
        transactionInfo.put("Branch", branch);

        Map<String, Object> department = new HashMap<>();
        department.put("Code", "FES");
        transactionInfo.put("Department", department);

        Map<String, Object> orgAddress = new HashMap<>();
        orgAddress.put("OrganizationCode", "TESTORG");
        transactionInfo.put("OrganizationAddress", orgAddress);

        transactionInfo.put("Ostotal", "100.00");
        transactionInfo.put("OutstandingAmount", "100.00");
        transactionInfo.put("ExchangeRate", "1.0");
        transactionInfo.put("Osgstvatamount", "10.00");
        transactionInfo.put("LocalVATAmount", "10.00");
        transactionInfo.put("Description", "Shipment Test Transaction");

        // Add ShipmentCollection for SHIPMENT
        Map<String, Object> shipmentCollection = new HashMap<>();
        List<Map<String, Object>> shipments = new ArrayList<>();
        Map<String, Object> shipment = new HashMap<>();
        Map<String, Object> shipmentDataContext = new HashMap<>();
        Map<String, Object> dataSourceCollection = new HashMap<>();
        List<Map<String, Object>> dataSources = new ArrayList<>();

        Map<String, Object> shipmentDataSource = new HashMap<>();
        shipmentDataSource.put("Type", "ForwardingShipment");
        shipmentDataSource.put("Key", "SSSH1250617962");
        dataSources.add(shipmentDataSource);

        dataSourceCollection.put("DataSource", dataSources);
        shipmentDataContext.put("DataSourceCollection", dataSourceCollection);
        shipment.put("DataContext", shipmentDataContext);
        shipments.add(shipment);
        shipmentCollection.put("Shipment", shipments);
        transactionInfo.put("ShipmentCollection", shipmentCollection);

        universalTransaction.put("TransactionInfo", transactionInfo);
        body.put("UniversalTransaction", universalTransaction);
        payload.put("Body", body);

        String json = new ObjectMapper().writeValueAsString(payload);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("SHIPMENT");
        refNoInfo.setRefNo("SSSH1250617962");
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "SHIPMENT_TEST")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(Arrays.asList(createMockCwAccountTransactionInfo()));

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - SHIPMENT logic should remain unchanged
        verify(chargeLineProcessor, times(1)).handleChargeLineInShipment(
            any(), any(), any(), any(), argThat(request -> {
                // SHIPMENT should still extract from DataSourceCollection, not affected by NONJOB logic
                assertEquals("SSSH1250617962", request.getShipmentId(),
                    "SHIPMENT extraction should not be affected by NONJOB Job.Key logic");
                assertNull(request.getConsolNo(), "SHIPMENT should have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any(), any()
        );
    }

    private CwAccountTransactionInfo createMockCwAccountTransactionInfo() {
        CwAccountTransactionInfo info = new CwAccountTransactionInfo();
        info.setAccountTransactionHeaderPk(UUID.randomUUID());
        info.setAccountTransactionLinesPk(UUID.randomUUID());
        info.setAccountChargeCodePk(UUID.randomUUID());
        info.setChargeCode("DOC");
        info.setOsAmount(new BigDecimal("100.00"));
        info.setGstVatAmount(new BigDecimal("10.00"));
        info.setLineAmount(new BigDecimal("90.00"));
        info.setExchangeRate(new BigDecimal("1.0"));
        info.setCurrencyCode("CNY");
        info.setDisplaySequence(1);
        info.setJobNumber("TEST_JOB");
        info.setUsed(false);
        info.setCreditor("TEST_CREDITOR");
        info.setInvoiceNo("TEST_INV");
        return info;
    }

    // ========== NEW TESTS FOR FALLBACK LOGIC ==========

    @Test
    void testNonjobFallback_JobKeyMissing_UsesDataSourceCollection() throws Exception {
        // Arrange - Job.Key missing, should fall back to DataSourceCollection
        String json = createNonjobTestJsonWithDataSource("Job", null, true, Arrays.asList("AR INV 2511001019"));

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Should fall back to DataSourceCollection and trim whitespace
                assertEquals("ARINV2511001019", request.getShipmentId(),
                    "NONJOB with missing Job.Key should fall back to DataSourceCollection with whitespace trimmed");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_BothPresent_PrimaryTakesPrecedence() throws Exception {
        // Arrange - Both Job.Key and DataSourceCollection present, primary should win
        String json = createNonjobTestJsonWithDataSource("Job", "WI00000077", true, Arrays.asList("AR INV 2511001018"));

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Primary path (Job.Key) should take precedence over fallback
                assertEquals("WI00000077", request.getShipmentId(),
                    "NONJOB with both Job.Key and DataSourceCollection should use Job.Key (primary path)");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_DataSourceWithWhitespace_TrimmedCorrectly() throws Exception {
        // Arrange - DataSourceCollection value contains whitespace
        String json = createNonjobTestJsonWithDataSource("Job", null, true, Arrays.asList("  AR  INV  2511001018  "));

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // All whitespace should be removed using replaceAll("\\s+", "")
                assertEquals("ARINV2511001018", request.getShipmentId(),
                    "NONJOB fallback with whitespace should trim all spaces: '  AR  INV  2511001018  ' -> 'ARINV2511001018'");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_EmptyDataSourceArray_ShipmentIdNull() throws Exception {
        // Arrange - DataSourceCollection exists but has no AccountingInvoice entries
        String json = createNonjobTestJsonWithDataSource("Job", null, true, new ArrayList<>());

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Empty DataSource array should result in null shipmentId
                assertNull(request.getShipmentId(),
                    "NONJOB with empty DataSourceCollection array should have null shipmentId");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_MultipleAccountingInvoiceEntries_UsesFirst() throws Exception {
        // Arrange - Multiple AccountingInvoice entries, should use first match
        String json = createNonjobTestJsonWithDataSource("Job", null, true,
            Arrays.asList("AR INV FIRST", "AR INV SECOND", "AR INV THIRD"));

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Should use first match from multiple AccountingInvoice entries
                assertEquals("ARINVFIRST", request.getShipmentId(),
                    "NONJOB with multiple AccountingInvoice entries should use first match");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_BothPathsFail_ShipmentIdNull() throws Exception {
        // Arrange - Both Job.Key missing and DataSourceCollection missing
        String json = createNonjobTestJsonWithDataSource("Job", null, true, null);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Both paths fail → graceful null
                assertNull(request.getShipmentId(),
                    "NONJOB with both Job.Key and DataSourceCollection missing should gracefully return null");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobPrimary_JobKeyWithWhitespace_TrimmedCorrectly() throws Exception {
        // Arrange - Job.Key contains whitespace (should be trimmed in primary path)
        String json = createNonjobTestJsonWithDataSource("Job", "  WI 00000077  ", true, null);

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Job.Key with whitespace should be trimmed: '  WI 00000077  ' -> 'WI00000077'
                assertEquals("WI00000077", request.getShipmentId(),
                    "NONJOB primary path (Job.Key) with whitespace should trim all spaces");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testNonjobFallback_TrimmedResultEmpty_ShipmentIdNull() throws Exception {
        // Arrange - DataSourceCollection value is whitespace-only (should become null after trimming)
        String json = createNonjobTestJsonWithDataSource("Job", null, true, Arrays.asList("     "));

        List<RefNoInfo> refNoList = new ArrayList<>();
        RefNoInfo refNoInfo = new RefNoInfo();
        refNoInfo.setRefNoType("NONJOB");
        refNoInfo.setRefNo(null);
        refNoInfo.setJobHeader(null);
        refNoList.add(refNoInfo);

        lenient().when(queryService.getRefNo("AR", "INV", "NONJOB_TEST_123")).thenReturn(refNoList);
        lenient().when(queryService.getCWAccountTransactionInfo(anyString(), anyString(), anyString(), anyString(), anyString()))
            .thenReturn(new ArrayList<>()); // Not used by GL-Account type (lenient)

        // Act
        RestListResponse<TransactionChargeLineRequestBean> result = transactionMappingService.analyzePayloadRaw(json);

        // Assert - Payload has NO JobInvoiceNumber, so routes to GL-Account processing
        verify(chargeLineProcessor, times(1)).handleGLAccountChargeLines(
            any(), any(), any(), argThat(request -> {
                // Whitespace-only value becomes empty string after trim → should be null
                assertNull(request.getShipmentId(),
                    "NONJOB with whitespace-only value should become null after trimming");
                assertNull(request.getConsolNo(), "NONJOB should always have null consolNo");
                return true;
            }), any(), any(), any(), any(), any(), any(), any()
        );
    }
}
