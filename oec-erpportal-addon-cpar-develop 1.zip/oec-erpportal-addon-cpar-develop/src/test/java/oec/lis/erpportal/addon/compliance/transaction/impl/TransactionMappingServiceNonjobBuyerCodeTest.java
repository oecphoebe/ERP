package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import oec.lis.erpportal.addon.compliance.common.config.NonJobTransactionConfig;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;

import lombok.extern.slf4j.Slf4j;

/**
 * Unit tests for NONJOB buyerCode extraction logic with OrganizationAddress.OrganizationCode fallback.
 *
 * <p>Tests the two-phase extraction hierarchy:
 * <ol>
 *   <li>Phase 1 (Primary): Extract from $.CheckNumberOrPaymentRef</li>
 *   <li>Phase 2 (Fallback): Extract from $.OrganizationAddress.OrganizationCode</li>
 *   <li>Return null if both phases fail (graceful degradation)</li>
 * </ol>
 *
 * <p>These are direct method tests using the TransactionMappingService.extractBuyerCode() method.
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
public class TransactionMappingServiceNonjobBuyerCodeTest {

    @Mock
    private TransactionQueryService queryService;

    @Mock
    private TransactionValidationService validationService;

    @Mock
    private ChargeLineProcessor chargeLineProcessor;

    @Mock
    private AtAccountTransactionTableService atAccountTransactionTableService;

    @Mock
    private NonJobTransactionConfig nonJobConfig;

    @InjectMocks
    private TransactionMappingService transactionMappingService;

    private Configuration configWithoutException;

    @BeforeEach
    void setUp() {
        configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);
    }

    private Object createNonjobTestJson(String checkNumberOrPaymentRef, String organizationCode) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("  \"CheckNumberOrPaymentRef\": ");
        if (checkNumberOrPaymentRef == null) {
            json.append("null");
        } else {
            json.append("\"").append(checkNumberOrPaymentRef).append("\"");
        }
        json.append(",");
        json.append("  \"OrganizationAddress\": {");
        json.append("    \"OrganizationCode\": ");
        if (organizationCode == null) {
            json.append("null");
        } else {
            json.append("\"").append(organizationCode).append("\"");
        }
        json.append("  }");
        json.append("}");

        return JsonPath.using(configWithoutException).parse(json.toString()).json();
    }

    @Test
    void testNonjobBuyerCode_HappyPath_Primary() throws Exception {
        // Arrange - Both populated, primary should take precedence
        Object document = createNonjobTestJson("CUSTOMER_A", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("CUSTOMER_A", result,
                "Should use CheckNumberOrPaymentRef (primary) when both are populated");

        log.info("Test passed: Primary path used when both values present: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_EmptyPrimary_Fallback() throws Exception {
        // Arrange - Primary is empty string, fallback should be used
        Object document = createNonjobTestJson("", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("ORG_B", result,
                "Should fall back to OrganizationCode when CheckNumberOrPaymentRef is empty string");

        log.info("Test passed: Fallback used when primary is empty: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_NullPrimary_Fallback() throws Exception {
        // Arrange - Primary is null, fallback should be used
        Object document = createNonjobTestJson(null, "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("ORG_B", result,
                "Should fall back to OrganizationCode when CheckNumberOrPaymentRef is null");

        log.info("Test passed: Fallback used when primary is null: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_WhitespacePrimary_Fallback() throws Exception {
        // Arrange - Primary is whitespace-only, fallback should be used
        Object document = createNonjobTestJson("   ", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("ORG_B", result,
                "Should fall back to OrganizationCode when CheckNumberOrPaymentRef is whitespace-only");

        log.info("Test passed: Fallback used when primary is whitespace: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_BothEmpty_GracefulNull() throws Exception {
        // Arrange - Both are empty strings
        Object document = createNonjobTestJson("", "");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertNull(result,
                "Should return null gracefully when both CheckNumberOrPaymentRef and OrganizationCode are empty");

        log.info("Test passed: Graceful null when both empty");
    }

    @Test
    void testNonjobBuyerCode_BothNull_GracefulNull() throws Exception {
        // Arrange - Both are null
        Object document = createNonjobTestJson(null, null);

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertNull(result,
                "Should return null gracefully when both CheckNumberOrPaymentRef and OrganizationCode are null");

        log.info("Test passed: Graceful null when both null");
    }

    @Test
    void testNonjobBuyerCode_OnlyPrimaryPopulated() throws Exception {
        // Arrange - Only primary populated, fallback is null
        Object document = createNonjobTestJson("CUSTOMER_A", null);

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("CUSTOMER_A", result,
                "Should use CheckNumberOrPaymentRef when OrganizationCode is null (no fallback needed)");

        log.info("Test passed: Primary used when fallback is null: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_WhitespaceTrimming() throws Exception {
        // Arrange - Primary has leading/trailing whitespace
        Object document = createNonjobTestJson("  CUSTOMER_A  ", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("CUSTOMER_A", result,
                "Should trim leading/trailing whitespace from CheckNumberOrPaymentRef: '  CUSTOMER_A  ' -> 'CUSTOMER_A'");

        log.info("Test passed: Whitespace trimmed from primary: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_FallbackWhitespaceTrimming() throws Exception {
        // Arrange - Primary empty, fallback has leading/trailing whitespace
        Object document = createNonjobTestJson("", "  ORG_B  ");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("ORG_B", result,
                "Should trim leading/trailing whitespace from OrganizationCode fallback: '  ORG_B  ' -> 'ORG_B'");

        log.info("Test passed: Whitespace trimmed from fallback: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_FallbackWhitespaceOnly_GracefulNull() throws Exception {
        // Arrange - Primary empty, fallback is whitespace-only
        Object document = createNonjobTestJson("", "     ");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertNull(result,
                "Should return null when fallback OrganizationCode is whitespace-only: '     '");

        log.info("Test passed: Graceful null when fallback is whitespace-only");
    }

    @Test
    void testNonjobBuyerCode_PrimaryWithInternalSpaces() throws Exception {
        // Arrange - Primary has internal spaces (should NOT be removed, only leading/trailing)
        Object document = createNonjobTestJson("  CUSTOMER A B  ", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "NONJOB");

        // Assert
        assertEquals("CUSTOMER A B", result,
                "Should trim only leading/trailing whitespace, preserve internal spaces: '  CUSTOMER A B  ' -> 'CUSTOMER A B'");

        log.info("Test passed: Internal spaces preserved in primary: [{}]", result);
    }

    @Test
    void testNonjobBuyerCode_APLedger_SameBehavior() throws Exception {
        // Arrange - Test with AP ledger instead of AR (should have same NONJOB behavior)
        Object document = createNonjobTestJson("", "ORG_B");

        // Act
        String result = transactionMappingService.extractBuyerCode(document, "AP", "TEST123", "NONJOB");

        // Assert
        assertEquals("ORG_B", result,
                "NONJOB fallback should work the same for AP ledger as AR ledger");

        log.info("Test passed: AP ledger fallback works: [{}]", result);
    }

    @Test
    void testShipment_NotAffectedByNonjobLogic() throws Exception {
        // Arrange - Create a document for SHIPMENT (should not use NONJOB logic)
        Object document = createNonjobTestJson("SHOULD_NOT_BE_USED", "ALSO_SHOULD_NOT_BE_USED");

        // Act - refNoType is SHIPMENT, not NONJOB
        String result = transactionMappingService.extractBuyerCode(document, "AR", "TEST123", "SHIPMENT");

        // Assert - Should fall through to standard AR logic (returns null for this test JSON structure)
        // The important validation is that it doesn't use CheckNumberOrPaymentRef or OrganizationCode
        assertNull(result,
                "SHIPMENT transactions should not use NONJOB extraction logic");

        log.info("Test passed: SHIPMENT not affected by NONJOB logic");
    }
}
