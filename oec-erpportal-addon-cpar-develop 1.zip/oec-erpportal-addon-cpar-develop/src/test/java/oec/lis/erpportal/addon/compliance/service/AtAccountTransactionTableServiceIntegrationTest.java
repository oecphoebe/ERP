package oec.lis.erpportal.addon.compliance.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.util.BaseTransactionIntegrationTest;

/**
 * Simple integration test to verify our implemented service methods work correctly.
 * This test focuses on testing the service layer functionality without complex web layer setup.
 * Now extends BaseTransactionIntegrationTest to use TestContainers for proper database setup.
 */
class AtAccountTransactionTableServiceIntegrationTest extends BaseTransactionIntegrationTest {

    @Autowired
    private AtAccountTransactionTableService transactionTableService;

    @Test
    void testServiceImplementationExists() {
        assertNotNull(transactionTableService, "AtAccountTransactionTableService should be autowired");
    }

    @Test
    void testFindHeadersByTransactionNo_ReturnsEmptyForNonExistentTransaction() {
        // Test that our implemented method works (should return empty list for non-existent transaction)
        List<AtAccountTransactionHeaderBean> headers = transactionTableService
            .findHeadersByTransactionNo("NON_EXISTENT_TRANSACTION");
        
        assertNotNull(headers, "Method should return non-null list");
        assertTrue(headers.isEmpty(), "Should return empty list for non-existent transaction");
    }

    @Test
    void testFindLinesByHeaderPk_ReturnsEmptyForNonExistentHeader() {
        // Test that our implemented method works (should return empty list for non-existent header)
        List<AtAccountTransactionLinesBean> lines = transactionTableService
            .findLinesByHeaderPk(999999L);
        
        assertNotNull(lines, "Method should return non-null list");
        assertTrue(lines.isEmpty(), "Should return empty list for non-existent header");
    }

    @Test
    void testFindShipmentByJobNumber_ReturnsNullForNonExistentJob() {
        // Test that our implemented method works (should return null for non-existent job)
        AtShipmentInfoBean shipment = transactionTableService
            .findShipmentByJobNumber("NON_EXISTENT_JOB");
        
        assertNull(shipment, "Should return null for non-existent job number");
    }

    @Test
    void testCountAtAccountTransactionHeaderByTranNo_ReturnsZeroForNonExistent() {
        // Test existing method still works
        java.util.Optional<Integer> count = transactionTableService
            .countAtAccountTransactionHeaderByTranNo("NON_EXISTENT_TRANSACTION");
        
        assertTrue(count.isPresent(), "Method should return a count");
        assertEquals(0, count.get(), "Count should be 0 for non-existent transaction");
    }

    @Override
    protected void setupSpecificTestData() throws Exception {
        // This test doesn't require specific test data setup beyond what's already in the schema files
        // The test methods verify behavior with non-existent data
    }

    @Override
    protected String getTestDataSqlFile() {
        // This test uses only the base schema data, no additional test data file needed
        return null;
    }
}