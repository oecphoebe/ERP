package oec.lis.erpportal.addon.compliance.model.transaction;

import oec.lis.erpportal.addon.compliance.util.TestDataBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;

/**
 * Unit tests for TransactionChargeLineRequestBean VAT handling logic
 */
class TransactionChargeLineRequestBeanTest {

    private TransactionInfoRequestBean transactionInfo;

    @BeforeEach
    void setUp() {
        transactionInfo = TestDataBuilder.createTransactionInfoRequestBean("AR", "INV");
    }

    @Test
    @DisplayName("AR transaction with valid SellGSTVATID should extract tax code")
    void testARTransactionWithValidVAT() {
        // Given
        String chargeLineJson = TestDataBuilder.createChargeLineWithVAT("FREIGHT", "VAT10", new BigDecimal("1000"));
        
        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            chargeLineJson,
            "AR",
            "$.OSAmount",
            "$.OSGSTVATAmount"
        );
        
        // Then
        assertThat(bean.getTaxCode()).isEqualTo("VAT10");
        assertThat(bean.getItemCode()).isEqualTo("FREIGHT");
        assertThat(bean.getItemName()).isEqualTo("Test Charge - FREIGHT");
        assertThat(bean.getPrice()).isEqualByComparingTo(new BigDecimal("1000"));
        assertThat(bean.getTaxIncludedAmount()).isEqualByComparingTo(new BigDecimal("1100")); // 1000 + 100 (VAT included)
        assertThat(bean.getAmount()).isEqualByComparingTo(new BigDecimal("1000")); // Net amount (OSAmount is already net)
    }

    @Test
    @DisplayName("AR transaction without SellGSTVATID should have empty tax code")
    void testARTransactionWithoutVAT() {
        // Given
        String chargeLineJson = TestDataBuilder.createChargeLineWithoutVAT("FREIGHT", new BigDecimal("1000"));
        
        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            chargeLineJson,
            "AR",
            "$.OSAmount",
            "$.OSGSTVATAmount"
        );
        
        // Then
        assertThat(bean.getTaxCode()).isEmpty();
        assertThat(bean.getItemCode()).isEqualTo("FREIGHT");
        assertThat(bean.getPrice()).isEqualByComparingTo(new BigDecimal("1000"));
        assertThat(bean.getAmount()).isEqualByComparingTo(new BigDecimal("1000")); // No VAT to subtract
    }

    @Test
    @DisplayName("AP transaction should not extract tax code regardless of VAT presence")
    void testAPTransactionIgnoresVAT() {
        // Given
        String chargeLineJson = TestDataBuilder.createChargeLineWithVAT("FREIGHT", "VAT10", new BigDecimal("1000"));
        TransactionInfoRequestBean apTransaction = TestDataBuilder.createTransactionInfoRequestBean("AP", "INV");

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            apTransaction,
            chargeLineJson,
            "AP",
            "$.OSAmount",
            "$.OSGSTVATAmount"
        );

        // Then
        assertThat(bean.getTaxCode()).isNull(); // AP doesn't set tax code
        assertThat(bean.getPrice()).isEqualByComparingTo(new BigDecimal("-1000")); // AP negates amounts (net amount)
        assertThat(bean.getTaxIncludedAmount()).isEqualByComparingTo(new BigDecimal("-1100")); // -1000 + (-100) = gross amount
        assertThat(bean.getAmount()).isEqualByComparingTo(new BigDecimal("-1000")); // Net amount (same as price)
    }

    @ParameterizedTest
    @MethodSource("provideMalformedVATScenarios")
    @DisplayName("AR transaction with malformed VAT data should handle gracefully")
    void testARTransactionWithMalformedVAT(String scenario, String jsonChargeLine, String expectedTaxCode) {
        // When
        assertThatNoException().isThrownBy(() -> {
            TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
                transactionInfo,
                jsonChargeLine,
                "AR",
                "$.OSAmount",
                "$.OSGSTVATAmount"
            );
            
            // Then
            assertThat(bean.getTaxCode()).isEqualTo(expectedTaxCode);
        });
    }

    private static Stream<Arguments> provideMalformedVATScenarios() {
        return Stream.of(
            Arguments.of(
                "Empty SellGSTVATID object",
                "{\"ChargeCode\":{\"Code\":\"TEST\",\"Description\":\"Test Charge\"},\"SellGSTVATID\":{},\"OSAmount\":\"100\",\"OSGSTVATAmount\":\"10\"}",
                ""
            ),
            Arguments.of(
                "Null TaxCode in SellGSTVATID",
                "{\"ChargeCode\":{\"Code\":\"TEST\",\"Description\":\"Test Charge\"},\"SellGSTVATID\":{\"TaxCode\":null},\"OSAmount\":\"100\",\"OSGSTVATAmount\":\"10\"}",
                ""
            ),
            Arguments.of(
                "Empty string TaxCode",
                "{\"ChargeCode\":{\"Code\":\"TEST\",\"Description\":\"Test Charge\"},\"SellGSTVATID\":{\"TaxCode\":\"\"},\"OSAmount\":\"100\",\"OSGSTVATAmount\":\"10\"}",
                ""
            ),
            Arguments.of(
                "Whitespace TaxCode",
                "{\"ChargeCode\":{\"Code\":\"TEST\",\"Description\":\"Test Charge\"},\"SellGSTVATID\":{\"TaxCode\":\"   \"},\"OSAmount\":\"100\",\"OSGSTVATAmount\":\"10\"}",
                "   "
            )
        );
    }

    @Test
    @DisplayName("findAndSetTaxRate should match by charge code and sequence")
    void testFindAndSetTaxRate() {
        // Given
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean();
        bean.setItemCode("FREIGHT");
        
        List<PostingJournal> journals = Arrays.asList(
            createPostingJournal("FREIGHT", 1, 10),
            createPostingJournal("FREIGHT", 2, 15),
            createPostingJournal("HANDLING", 1, 5)
        );
        
        // When
        bean.findAndSetTaxRate(journals, 2);
        
        // Then
        assertThat(bean.getTaxRate()).isEqualTo(15); // Should match FREIGHT with sequence 2
    }

    @Test
    @DisplayName("findAndSetTaxRate should not set rate if no match found")
    void testFindAndSetTaxRateNoMatch() {
        // Given
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean();
        bean.setItemCode("FREIGHT");
        bean.setTaxRate(0); // Initial value
        
        List<PostingJournal> journals = Arrays.asList(
            createPostingJournal("HANDLING", 1, 10),
            createPostingJournal("DOCUMENTATION", 2, 5)
        );
        
        // When
        bean.findAndSetTaxRate(journals, 1);
        
        // Then
        assertThat(bean.getTaxRate()).isEqualTo(0); // Should remain unchanged
    }

    @Test
    @DisplayName("Copy constructor should properly clone all fields")
    void testCopyConstructor() {
        // Given
        TransactionChargeLineRequestBean original = new TransactionChargeLineRequestBean();
        original.setItemCode("FREIGHT");
        original.setItemName("Freight Charges");
        original.setTaxCode("VAT10");
        original.setPrice(new BigDecimal("1000"));
        original.setAmount(new BigDecimal("900"));
        original.setBillNo(transactionInfo.getBillNo());
        
        // When
        TransactionChargeLineRequestBean copy = new TransactionChargeLineRequestBean(original);
        
        // Then
        assertThat(copy).isNotSameAs(original);
        assertThat(copy.getItemCode()).isEqualTo(original.getItemCode());
        assertThat(copy.getItemName()).isEqualTo(original.getItemName());
        assertThat(copy.getTaxCode()).isEqualTo(original.getTaxCode());
        assertThat(copy.getPrice()).isEqualTo(original.getPrice());
        assertThat(copy.getAmount()).isEqualTo(original.getAmount());
        assertThat(copy.getBillNo()).isEqualTo(original.getBillNo());
    }

    private PostingJournal createPostingJournal(String chargeCode, int sequence, int taxRate) {
        PostingJournal journal = new PostingJournal();
        journal.setChargeCode(chargeCode);
        journal.setSequence(sequence);
        journal.setTaxRate(taxRate);
        return journal;
    }

    // ==================== NonJob ItemCode Extraction Tests ====================

    @Test
    @DisplayName("JOB_INVOICE type NonJob should extract itemCode from ChargeCode.Code (not Glaccount)")
    void testJobInvoiceNonJobExtractsChargeCode() {
        // Given: JOB_INVOICE type NonJob has BOTH ChargeCode AND Glaccount
        String nonJobChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Destination Documentation Fee"
                },
                "Glaccount": {
                    "AccountCode": "4070.10.10",
                    "Description": "Handling Revenue Actual"
                },
                "Osamount": 50.0,
                "Osgstvatamount": 0.0,
                "Oscurrency": {
                    "Code": "CNY",
                    "Description": "Chinese Yuan"
                }
            }
            """;

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            nonJobChargeLineJson,
            "AR",
            "$.Osamount",
            "$.Osgstvatamount"
        );

        // Then: Should use ChargeCode.Code, NOT Glaccount.AccountCode
        assertThat(bean.getItemCode())
            .as("JOB_INVOICE type NonJob should extract itemCode from ChargeCode.Code")
            .isEqualTo("DOC");
        assertThat(bean.getItemName())
            .as("JOB_INVOICE type NonJob should extract itemName from ChargeCode.Description")
            .isEqualTo("Destination Documentation Fee");
    }

    @Test
    @DisplayName("GL_ACCOUNT type NonJob should extract itemCode from Glaccount.AccountCode")
    void testGLAccountNonJobExtractsGlAccount() {
        // Given: GL_ACCOUNT type NonJob has ONLY Glaccount (no ChargeCode)
        String glAccountNonJobJson = """
            {
                "Glaccount": {
                    "AccountCode": "1210.00.10",
                    "Description": "Accounts Receivable Control-FMS Cus"
                },
                "Osamount": 38.0,
                "Osgstvatamount": 2.28,
                "Oscurrency": {
                    "Code": "CNY",
                    "Description": "Chinese Yuan"
                }
            }
            """;

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            glAccountNonJobJson,
            "AR",
            "$.Osamount",
            "$.Osgstvatamount"
        );

        // Then: Should use Glaccount.AccountCode
        assertThat(bean.getItemCode())
            .as("GL_ACCOUNT type NonJob should extract itemCode from Glaccount.AccountCode")
            .isEqualTo("1210.00.10");
        assertThat(bean.getItemName())
            .as("GL_ACCOUNT type NonJob should extract itemName from Glaccount.Description")
            .isEqualTo("Accounts Receivable Control-FMS Cus");
    }

    @Test
    @DisplayName("Standard ChargeLine should extract itemCode from ChargeCode.Code (existing behavior)")
    void testStandardChargeLineExtractsChargeCode() {
        // Given: Standard ChargeLine (no Osamount field)
        String standardChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "FRT",
                    "Description": "Freight Charges"
                },
                "OSAmount": 100.0,
                "OSGSTVATAmount": 10.0,
                "SellOSCurrency": {
                    "Code": "USD",
                    "Description": "US Dollar"
                }
            }
            """;

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            standardChargeLineJson,
            "AR",
            "$.OSAmount",
            "$.OSGSTVATAmount"
        );

        // Then: Should use ChargeCode.Code
        assertThat(bean.getItemCode())
            .as("Standard ChargeLine should extract itemCode from ChargeCode.Code")
            .isEqualTo("FRT");
        assertThat(bean.getItemName())
            .as("Standard ChargeLine should extract itemName from ChargeCode.Description")
            .isEqualTo("Freight Charges");
    }

    @Test
    @DisplayName("JOB_INVOICE NonJob with multiple charge codes should prioritize ChargeCode over Glaccount")
    void testJobInvoiceNonJobPrioritizesChargeCode() {
        // Given: JOB_INVOICE NonJob with both fields present
        String nonJobJson = """
            {
                "ChargeCode": {
                    "Code": "AMS",
                    "Description": "AMS Filing Fee"
                },
                "Glaccount": {
                    "AccountCode": "4080.20.00",
                    "Description": "Other Revenue"
                },
                "Osamount": 75.0,
                "Osgstvatamount": 0.0
            }
            """;

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            nonJobJson,
            "AR",
            "$.Osamount",
            "$.Osgstvatamount"
        );

        // Then: Should prioritize ChargeCode.Code over Glaccount.AccountCode
        assertThat(bean.getItemCode())
            .as("When both ChargeCode and Glaccount exist, should prioritize ChargeCode.Code")
            .isEqualTo("AMS")
            .isNotEqualTo("4080.20.00");
    }

    @Test
    @DisplayName("Empty ChargeCode.Code should fallback to Glaccount.AccountCode")
    void testEmptyChargeCodeFallsBackToGlAccount() {
        // Given: ChargeCode exists but Code is empty
        String nonJobJson = """
            {
                "ChargeCode": {
                    "Code": "",
                    "Description": "Empty Code"
                },
                "Glaccount": {
                    "AccountCode": "5010.00.00",
                    "Description": "GL Account Description"
                },
                "Osamount": 100.0,
                "Osgstvatamount": 0.0
            }
            """;

        // When
        TransactionChargeLineRequestBean bean = new TransactionChargeLineRequestBean(
            transactionInfo,
            nonJobJson,
            "AR",
            "$.Osamount",
            "$.Osgstvatamount"
        );

        // Then: Should fallback to Glaccount.AccountCode when ChargeCode.Code is empty
        assertThat(bean.getItemCode())
            .as("Empty ChargeCode.Code should fallback to Glaccount.AccountCode")
            .isEqualTo("5010.00.00");
    }
}