package oec.lis.erpportal.addon.compliance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplianceApplicationTests {

	@Test
	void contextLoads() {
	}

}
