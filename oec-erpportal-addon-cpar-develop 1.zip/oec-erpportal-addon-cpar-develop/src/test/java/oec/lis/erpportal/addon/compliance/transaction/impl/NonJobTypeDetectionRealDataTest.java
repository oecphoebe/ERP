package oec.lis.erpportal.addon.compliance.transaction.impl;

import oec.lis.erpportal.addon.compliance.model.transaction.NonJobType;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Test NonJob type detection with real reference data files.
 */
class NonJobTypeDetectionRealDataTest {

    @Test
    void testJobInvoiceTypeDetection_WithRealSampleFile() throws Exception {
        // Read the Job-Invoice type reference file
        String json = new String(Files.readAllBytes(
            Paths.get("reference/NonJob_AR_INV_2511001018-ADD.json")));

        // Detect type
        NonJobType detectedType = NonJobType.detectFromPayload(json);

        // Verify it's detected as JOB_INVOICE type
        assertEquals(NonJobType.JOB_INVOICE, detectedType,
            "Reference file NonJob_AR_INV_2511001018-ADD.json should be detected as JOB_INVOICE type " +
            "because it contains JobInvoiceNumber='WI00000077/A'");

        System.out.println("✅ Successfully detected JOB_INVOICE type from reference file");
        System.out.println("   File: NonJob_AR_INV_2511001018-ADD.json");
        System.out.println("   Expected: JOB_INVOICE");
        System.out.println("   Actual: " + detectedType);
    }

    @Test
    void testGLAccountTypeDetection_WithMissingJobInvoiceNumber() {
        // Create a payload without JobInvoiceNumber
        String json = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AR",
                            "TransactionType": "INV",
                            "Number": "TEST001"
                        }
                    }
                }
            }
            """;

        // Detect type
        NonJobType detectedType = NonJobType.detectFromPayload(json);

        // Verify it's detected as GL_ACCOUNT type
        assertEquals(NonJobType.GL_ACCOUNT, detectedType,
            "Payload without JobInvoiceNumber should be detected as GL_ACCOUNT type");

        System.out.println("✅ Successfully detected GL_ACCOUNT type (no JobInvoiceNumber)");
        System.out.println("   Expected: GL_ACCOUNT");
        System.out.println("   Actual: " + detectedType);
    }
}
