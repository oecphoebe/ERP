package oec.lis.erpportal.addon.compliance.util;

import lombok.Builder;
import lombok.Data;

/**
 * Data class containing transaction information extracted from JSON payload
 */
@Data
@Builder(toBuilder = true)
public class TransactionInfo {
    private String ledger;
    private String transactionType;
    private String transactionNo;
    private String eventType;
    private String jobNumber;
    private boolean isCancelled;
    private int expectedLineCount;

    /**
     * Creates a minimal TransactionInfo for testing purposes
     */
    public static TransactionInfo minimal(String ledger, String type, String transactionNo) {
        return TransactionInfo.builder()
            .ledger(ledger)
            .transactionType(type)
            .transactionNo(transactionNo)
            .eventType("ADD")
            .isCancelled(false)
            .expectedLineCount(1)
            .build();
    }

    /**
     * Checks if this is a valid transaction info
     */
    public boolean isValid() {
        return ledger != null && transactionType != null && transactionNo != null;
    }

    /**
     * Gets full transaction identifier
     */
    public String getFullTransactionId() {
        return String.format("%s_%s_%s", ledger, transactionType, transactionNo);
    }
}