package oec.lis.erpportal.addon.compliance.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit test for ReferenceDataLoader functionality without Spring context.
 */
class ReferenceDataLoaderUnitTest {

    private ReferenceDataLoader referenceDataLoader;

    @BeforeEach
    void setUp() {
        referenceDataLoader = new ReferenceDataLoader();
    }

    @Test
    void testExtractTransactionInfo_ValidJson() {
        String validTransactionJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AP",
                            "TransactionType": "INV",
                            "Number": "TEST_001",
                            "IsCancelled": false,
                            "Job": {
                                "Type": "Job",
                                "Key": "TESTJOB001"
                            },
                            "DataContext": {
                                "EventType": {
                                    "Code": "ADD"
                                },
                                "TriggerDate": "2025-08-12T15:46:10.767+08:00"
                            },
                            "PostingJournalCollection": {
                                "PostingJournal": [
                                    {
                                        "ChargeCode": {
                                            "Code": "FRT",
                                            "Description": "Freight Charges"
                                        },
                                        "LocalAmount": 1000.00,
                                        "Sequence": 1
                                    }
                                ]
                            }
                        }
                    }
                }
            }
            """;
        
        // Test our implemented extractTransactionInfo method
        TransactionInfo txnInfo = referenceDataLoader.extractTransactionInfo(validTransactionJson);
        
        assertNotNull(txnInfo, "Should extract transaction info from valid JSON");
        assertEquals("AP", txnInfo.getLedger(), "Should extract correct ledger");
        assertEquals("INV", txnInfo.getTransactionType(), "Should extract correct transaction type");
        assertEquals("TEST_001", txnInfo.getTransactionNo(), "Should extract correct transaction number");
        assertEquals("TESTJOB001", txnInfo.getJobNumber(), "Should extract correct job number");
        assertEquals("ADD", txnInfo.getEventType(), "Should extract correct event type");
        assertFalse(txnInfo.isCancelled(), "Should extract correct cancelled status");
        assertEquals(1, txnInfo.getExpectedLineCount(), "Should extract correct line count");
    }

    @Test
    void testExtractTransactionInfo_WithMultipleLines() {
        String validTransactionJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AR",
                            "TransactionType": "CRD",
                            "Number": "TEST_002",
                            "IsCancelled": true,
                            "Job": {
                                "Type": "Job",
                                "Key": "TESTJOB002"
                            },
                            "DataContext": {
                                "EventType": {
                                    "Code": "DEL"
                                }
                            },
                            "PostingJournalCollection": {
                                "PostingJournal": [
                                    {
                                        "ChargeCode": {
                                            "Code": "FRT",
                                            "Description": "Freight Charges"
                                        },
                                        "LocalAmount": 1000.00,
                                        "Sequence": 1
                                    },
                                    {
                                        "ChargeCode": {
                                            "Code": "DOC",
                                            "Description": "Documentation Fee"
                                        },
                                        "LocalAmount": 100.00,
                                        "Sequence": 2
                                    }
                                ]
                            }
                        }
                    }
                }
            }
            """;
        
        TransactionInfo txnInfo = referenceDataLoader.extractTransactionInfo(validTransactionJson);
        
        assertNotNull(txnInfo, "Should extract transaction info from valid JSON");
        assertEquals("AR", txnInfo.getLedger(), "Should extract correct ledger");
        assertEquals("CRD", txnInfo.getTransactionType(), "Should extract correct transaction type");
        assertEquals("TEST_002", txnInfo.getTransactionNo(), "Should extract correct transaction number");
        assertEquals("TESTJOB002", txnInfo.getJobNumber(), "Should extract correct job number");
        assertEquals("DEL", txnInfo.getEventType(), "Should extract correct event type");
        assertTrue(txnInfo.isCancelled(), "Should extract correct cancelled status");
        assertEquals(2, txnInfo.getExpectedLineCount(), "Should extract correct line count for multiple lines");
    }

    @Test
    void testValidateJsonStructure_ValidJson() {
        String validTransactionJson = """
            {
                "Body": {
                    "UniversalTransaction": {
                        "TransactionInfo": {
                            "Ledger": "AP",
                            "TransactionType": "INV",
                            "Number": "TEST_001"
                        }
                    }
                }
            }
            """;
        
        boolean isValid = referenceDataLoader.validateJsonStructure(validTransactionJson);
        assertTrue(isValid, "Should validate valid JSON structure");
    }

    @Test
    void testValidateJsonStructure_InvalidJson() {
        String invalidJson = """
            {
                "Body": {
                    "SomethingElse": {}
                }
            }
            """;
        
        boolean isValid = referenceDataLoader.validateJsonStructure(invalidJson);
        assertFalse(isValid, "Should reject invalid JSON structure");
    }

    @Test
    void testValidateJsonStructure_MalformedJson() {
        String malformedJson = "{invalid json syntax";
        
        boolean isValid = referenceDataLoader.validateJsonStructure(malformedJson);
        assertFalse(isValid, "Should reject malformed JSON");
    }

    @Test
    void testShouldSendToKafka_APTransaction() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AP", "INV");
        assertFalse(shouldSend, "AP transactions should not be sent to Kafka in legacy mode");
    }

    @Test
    void testShouldSendToKafka_ARTransaction() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AR", "INV");
        assertTrue(shouldSend, "AR transactions should be sent to Kafka in legacy mode");
    }

    @Test
    void testShouldSendToKafka_APCreditNote() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AP", "CRD");
        assertFalse(shouldSend, "AP credit notes should not be sent to Kafka in legacy mode");
    }

    @Test
    void testShouldSendToKafka_ARCreditNote() {
        boolean shouldSend = referenceDataLoader.shouldSendToKafka("AR", "CRD");
        assertTrue(shouldSend, "AR credit notes should be sent to Kafka in legacy mode");
    }

    @Test
    void testCreateCargowiseTestData() {
        TransactionInfo txnInfo = TransactionInfo.builder()
            .ledger("AP")
            .transactionType("INV")
            .transactionNo("TEST_001")
            .jobNumber("JOB001")
            .build();
        
        CargowiseTestData testData = referenceDataLoader.createCargowiseTestData(txnInfo);
        
        assertNotNull(testData, "Should create Cargowise test data");
        assertEquals("AP", testData.getLedger(), "Should set correct ledger");
        assertEquals("INV", testData.getTransactionType(), "Should set correct transaction type");
        assertEquals("TEST_001", testData.getTransactionNo(), "Should set correct transaction number");
        assertEquals("JOB001", testData.getJobNumber(), "Should set correct job number");
        assertEquals("TESTORG", testData.getOrganizationCode(), "Should set default organization code");
        assertEquals("TESTCHARGE", testData.getChargeCode(), "Should set default charge code");
    }

    @Test
    void testCreateCargowiseTestData_NullJobNumber() {
        TransactionInfo txnInfo = TransactionInfo.builder()
            .ledger("AR")
            .transactionType("CRD")
            .transactionNo("TEST_002")
            .jobNumber(null)
            .build();
        
        CargowiseTestData testData = referenceDataLoader.createCargowiseTestData(txnInfo);
        
        assertNotNull(testData, "Should create Cargowise test data even with null job number");
        assertEquals("AR", testData.getLedger(), "Should set correct ledger");
        assertEquals("CRD", testData.getTransactionType(), "Should set correct transaction type");
        assertEquals("TEST_002", testData.getTransactionNo(), "Should set correct transaction number");
        assertNull(testData.getJobNumber(), "Should handle null job number");
    }
}