package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

/**
 * Integration test to verify consolNo extraction from real JSON files
 */
@TestPropertySource(properties = {
    "transaction.nonjob.enabled=true"
})
public class ConsolNoExtractionIntegrationTest {

    private final Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

    @Test
    void testConsolExtractionFromRealJson_CSSH1250610990() throws IOException {
        // Test with CONSOL scenario using real AP_CRD_CSSH1250610990_0812_3.json
        String jsonPath = "/home/yinchao/erpportal/cpar/reference/AP_CRD_CSSH1250610990_0812_3.json";
        Path path = Paths.get(jsonPath);
        
        if (!Files.exists(path)) {
            // Skip test if file doesn't exist
            System.out.println("Skipping test - JSON file not found: " + jsonPath);
            return;
        }
        
        String json = Files.readString(path);
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        
        // Test extraction of ForwardingConsol (CONSOL scenario)
        String consolKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key";
        String shipmentKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key";
        
        try {
            Object consolKeys = JsonPath.using(configWithoutException).parse(allDocument).read(consolKeyPath);
            Object shipmentKeys = JsonPath.using(configWithoutException).parse(allDocument).read(shipmentKeyPath);
            
            System.out.println("CONSOL scenario test:");
            System.out.println("  ForwardingConsol keys: " + consolKeys);
            System.out.println("  ForwardingShipment keys: " + shipmentKeys);
            
            // For CONSOL scenario: consolKeys should have value, we extract consolNo only
            assertNotNull(consolKeys, "ForwardingConsol should be present in CONSOL scenario");
            
            // The extracted value should be CSSH1250610990
            if (consolKeys instanceof java.util.List && !((java.util.List<?>) consolKeys).isEmpty()) {
                String extractedConsolNo = (String) ((java.util.List<?>) consolKeys).get(0);
                assertEquals("CSSH1250610990", extractedConsolNo, "Expected CSSH1250610990 as consolNo");
                System.out.println("  ✓ Successfully extracted consolNo: " + extractedConsolNo);
            }
            
        } catch (Exception e) {
            fail("Failed to extract consolNo from real JSON: " + e.getMessage());
        }
    }

    @Test
    void testShipmentExtractionFromRealJson_AS20250812() throws IOException {
        // Test with SHIPMENT scenario using real AP_INV_AS20250812_2.json
        String jsonPath = "/home/yinchao/erpportal/cpar/reference/AP_INV_AS20250812_2.json";
        Path path = Paths.get(jsonPath);
        
        if (!Files.exists(path)) {
            // Skip test if file doesn't exist
            System.out.println("Skipping test - JSON file not found: " + jsonPath);
            return;
        }
        
        String json = Files.readString(path);
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        
        // Test extraction of ForwardingShipment (SHIPMENT scenario)
        String consolKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key";
        String shipmentKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key";
        
        try {
            Object consolKeys = JsonPath.using(configWithoutException).parse(allDocument).read(consolKeyPath);
            Object shipmentKeys = JsonPath.using(configWithoutException).parse(allDocument).read(shipmentKeyPath);
            
            System.out.println("SHIPMENT scenario test:");
            System.out.println("  ForwardingConsol keys: " + consolKeys);
            System.out.println("  ForwardingShipment keys: " + shipmentKeys);
            
            // For SHIPMENT scenario: shipmentKeys should have value, consolKeys should be empty
            assertNotNull(shipmentKeys, "ForwardingShipment should be present in SHIPMENT scenario");
            
            // The extracted value should be SSSH1250718350
            if (shipmentKeys instanceof java.util.List && !((java.util.List<?>) shipmentKeys).isEmpty()) {
                String extractedShipmentId = (String) ((java.util.List<?>) shipmentKeys).get(0);
                assertEquals("SSSH1250718350", extractedShipmentId, "Expected SSSH1250718350 as shipmentId");
                System.out.println("  ✓ Successfully extracted shipmentId: " + extractedShipmentId);
            }
            
            // consolKeys should be empty for SHIPMENT scenario
            if (consolKeys instanceof java.util.List) {
                assertTrue(((java.util.List<?>) consolKeys).isEmpty(), "ForwardingConsol should be empty in SHIPMENT scenario");
                System.out.println("  ✓ ForwardingConsol is empty as expected for SHIPMENT scenario");
            }
            
        } catch (Exception e) {
            fail("Failed to extract shipmentId from real JSON: " + e.getMessage());
        }
    }

    @Test
    void testJsonPathExtractionLogic() {
        // Simple test to verify our JsonPath logic works correctly
        String testJson = """
            {
              "Body": {
                "UniversalTransaction": {
                  "TransactionInfo": {
                    "ShipmentCollection": {
                      "Shipment": [
                        {
                          "DataContext": {
                            "DataSourceCollection": {
                              "DataSource": [
                                {
                                  "Type": "ForwardingConsol",
                                  "Key": "CSSH1250610990"
                                },
                                {
                                  "Type": "ForwardingShipment",
                                  "Key": "SSSH1250617962"
                                }
                              ]
                            }
                          }
                        }
                      ]
                    }
                  }
                }
              }
            }
            """;
        
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(testJson);
        
        // Test CONSOL extraction (should get ForwardingConsol only)
        String consolKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key";
        Object consolKeys = JsonPath.using(configWithoutException).parse(allDocument).read(consolKeyPath);
        
        if (consolKeys instanceof java.util.List && !((java.util.List<?>) consolKeys).isEmpty()) {
            String extractedConsolNo = (String) ((java.util.List<?>) consolKeys).get(0);
            assertEquals("CSSH1250610990", extractedConsolNo);
            System.out.println("✓ JsonPath extraction logic works correctly for consolNo: " + extractedConsolNo);
        }
        
        // Test SHIPMENT extraction (should get ForwardingShipment only)
        String shipmentKeyPath = "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key";
        Object shipmentKeys = JsonPath.using(configWithoutException).parse(allDocument).read(shipmentKeyPath);
        
        if (shipmentKeys instanceof java.util.List && !((java.util.List<?>) shipmentKeys).isEmpty()) {
            String extractedShipmentId = (String) ((java.util.List<?>) shipmentKeys).get(0);
            assertEquals("SSSH1250617962", extractedShipmentId);
            System.out.println("✓ JsonPath extraction logic works correctly for shipmentId: " + extractedShipmentId);
        }
    }
}