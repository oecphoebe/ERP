package oec.lis.erpportal.addon.compliance.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

/**
 * Test for TestValidationHelper functionality.
 */
@SpringBootTest
@TestPropertySource(properties = {
    "spring.profiles.active=test",
    "spring.cloud.config.enabled=false",
    "spring.kafka.bootstrap-servers=localhost:9092",
    "external.cwis.url=http://localhost:9999",
    "external.compliance.url=http://localhost:9999",
    "external.erpportal.url=http://localhost:9999",
    "external.profile.url=http://localhost:9999",
    "KAFKA_USERNAME=testuser",
    "KAFKA_PASSWORD=testpass",
    "EMAIL_USERNAME=testuser",
    "EMAIL_PASSWORD=testpass",
    "JOB_EMAIL_RECEIPIENTS=test@example.com"
})
class TestValidationHelperTest {

    @Autowired
    private TestValidationHelper validationHelper;

    @Test
    void testValidationHelperExists() {
        assertNotNull(validationHelper, "TestValidationHelper should be autowired");
    }

    @Test
    void testGetHeaderPK_ReturnsNullForNonExistentTransaction() {
        // Test our implemented method
        Long headerPK = validationHelper.getHeaderPK("NON_EXISTENT_TRANSACTION");
        
        assertNull(headerPK, "Should return null for non-existent transaction");
    }

    @Test
    void testGetLineCount_ReturnsZeroForNonExistentTransaction() {
        // Test our implemented method
        int lineCount = validationHelper.getLineCount("NON_EXISTENT_TRANSACTION");
        
        assertEquals(0, lineCount, "Should return 0 for non-existent transaction");
    }

    @Test
    void testValidateNoDuplicates_NoExceptionForNonExistentTransaction() {
        // Test our implemented method - should not throw exception
        assertDoesNotThrow(() -> {
            validationHelper.validateNoDuplicates("NON_EXISTENT_TRANSACTION");
        }, "Should not throw exception for non-existent transaction");
    }

    @Test
    void testValidateResponseContent_ValidJson() {
        String validJson = "{\"message\":\"test\"}";
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .payloadJson(validJson)
            .expectedTransactionNo("TEST_001")
            .build();
        
        // Should not throw exception for valid JSON
        assertDoesNotThrow(() -> {
            validationHelper.validateResponseContent(validJson, testData);
        }, "Should not throw exception for valid JSON");
    }

    @Test
    void testValidateProcessingMetrics_ValidMetrics() {
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();
        
        long processingTime = 1000L; // 1 second
        
        // Should not throw exception for reasonable processing time
        assertDoesNotThrow(() -> {
            validationHelper.validateProcessingMetrics(testData, processingTime);
        }, "Should not throw exception for reasonable processing time");
    }
}