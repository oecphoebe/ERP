package oec.lis.erpportal.addon.compliance.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;

/**
 * Utility class for loading and processing reference JSON data files.
 * Transforms real-world transaction data into test scenarios.
 */
@Component
@Slf4j
public class ReferenceDataLoader {
    
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Configuration lenientConfig = Configuration.defaultConfiguration()
            .addOptions(Option.SUPPRESS_EXCEPTIONS);

    /**
     * Loads all reference JSON files from the reference directory
     */
    public List<ReferenceTestData> loadAllReferenceData() {
        try {
            Path referencePath = Paths.get("reference");
            
            if (!Files.exists(referencePath)) {
                log.warn("Reference directory not found: {}", referencePath.toAbsolutePath());
                return List.of();
            }

            return Files.walk(referencePath)
                    .filter(path -> path.toString().endsWith(".json"))
                    .map(this::loadReferenceFile)
                    .collect(Collectors.toList());
                    
        } catch (IOException e) {
            log.error("Failed to load reference data", e);
            throw new RuntimeException("Failed to load reference data", e);
        }
    }

    /**
     * Loads a specific reference file by filename
     */
    public ReferenceTestData loadByFilename(String filename) {
        try {
            Path filePath = Paths.get("reference", filename);
            if (!Files.exists(filePath)) {
                throw new IllegalArgumentException("Reference file not found: " + filename);
            }
            return loadReferenceFile(filePath);
        } catch (Exception e) {
            log.error("Failed to load reference file: {}", filename, e);
            throw new RuntimeException("Failed to load reference file: " + filename, e);
        }
    }

    private ReferenceTestData loadReferenceFile(Path path) {
        try {
            String filename = path.getFileName().toString();
            String content = Files.readString(path);
            
            log.debug("Loading reference file: {}", filename);
            
            return ReferenceTestData.fromFilename(filename, content);
            
        } catch (Exception e) {
            log.error("Failed to process reference file: {}", path, e);
            throw new RuntimeException("Failed to process reference file: " + path, e);
        }
    }

    /**
     * Extracts transaction information from JSON content using JsonPath
     */
    public TransactionInfo extractTransactionInfo(String jsonContent) {
        try {
            Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonContent);
            
            String ledger = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.Ledger", String.class);
                
            String transactionType = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.TransactionType", String.class);
                
            String transactionNo = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.Number", String.class);
                
            String eventType = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.DataContext.EventType.Code", String.class);
                
            String jobNumber = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.Job.Key", String.class);
                
            Boolean isCancelled = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.IsCancelled", Boolean.class);

            // Count posting journal entries to estimate line items
            List<?> postingJournals = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction.TransactionInfo.PostingJournalCollection.PostingJournal", List.class);
            
            int expectedLineCount = postingJournals != null ? postingJournals.size() : 0;

            return TransactionInfo.builder()
                .ledger(ledger)
                .transactionType(transactionType)
                .transactionNo(transactionNo)
                .eventType(eventType)
                .jobNumber(jobNumber)
                .isCancelled(isCancelled != null && isCancelled)
                .expectedLineCount(expectedLineCount)
                .build();
                
        } catch (Exception e) {
            log.error("Failed to extract transaction info from JSON", e);
            throw new RuntimeException("Failed to extract transaction info", e);
        }
    }

    /**
     * Validates that JSON content has the expected UniversalTransaction structure
     */
    public boolean validateJsonStructure(String jsonContent) {
        try {
            Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonContent);
            
            Object universalTransaction = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransaction");
                
            return universalTransaction != null;
            
        } catch (Exception e) {
            log.warn("Invalid JSON structure detected", e);
            return false;
        }
    }

    /**
     * Determines if a transaction should be sent to Kafka based on ledger type
     * This mimics the routing logic for testing purposes
     */
    public boolean shouldSendToKafka(String ledger, String transactionType) {
        // In legacy mode: only AR transactions go to external system
        return "AR".equals(ledger);
    }

    /**
     * Creates test data for Cargowise database seeding based on transaction info
     */
    public CargowiseTestData createCargowiseTestData(TransactionInfo txnInfo) {
        return CargowiseTestData.builder()
            .transactionNo(txnInfo.getTransactionNo())
            .ledger(txnInfo.getLedger())
            .transactionType(txnInfo.getTransactionType())
            .jobNumber(txnInfo.getJobNumber())
            .organizationCode("TESTORG")
            .chargeCode("TESTCHARGE")
            .build();
    }
}