package oec.lis.erpportal.addon.compliance.util;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.sql.Connection;
import java.time.Duration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api18.client.ProfileClient;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;
import oec.lis.erpportal.addon.compliance.service.ShipmentViewService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;
import oec.lis.erpportal.addon.compliance.config.ShipmentProperties;

/**
 * Abstract base class for transaction integration tests that provides common setup and utilities.
 * 
 * This class includes:
 * - TestContainers setup for PostgreSQL and SQL Server
 * - Common Spring Boot test configuration
 * - Shared dependencies injection
 * - Database cleanup lifecycle
 * - Utility methods for common operations
 * 
 * Extending classes should focus on specific test logic rather than infrastructure setup.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Testcontainers
@TestPropertySource(locations = "classpath:test-integration-defaults.properties")
@Slf4j
public abstract class BaseTransactionIntegrationTest {

    // TestContainers for real database testing
    @Container
    protected static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15.9-alpine")
            .withDatabaseName("sopl_test")
            .withUsername("test")
            .withPassword("test")
            .withInitScript("test-schema-postgresql.sql");

    @Container
    protected static MSSQLServerContainer<?> sqlserver = new MSSQLServerContainer<>("mcr.microsoft.com/mssql/server:2022-latest")
            .withPassword("Test123!")
            .withSharedMemorySize(512 * 1024 * 1024L) // 512MB shared memory
            .withStartupTimeout(Duration.ofMinutes(5))
            .withInitScript("test-schema-sqlserver.sql")
            .acceptLicense();

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        // Configure PostgreSQL datasource (SOPL) - matching application-local.yml structure
        registry.add("spring.datasource.sopl.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.sopl.username", postgres::getUsername);
        registry.add("spring.datasource.sopl.password", postgres::getPassword);
        registry.add("spring.datasource.sopl.driver-class-name", () -> "org.postgresql.Driver");
        registry.add("spring.datasource.sopl.hikari.maximum-pool-size", () -> "5");
        registry.add("spring.datasource.sopl.hikari.pool-name", () -> "sopl-test-pool");

        // Configure SQL Server datasource (Cargowise) - matching application-local.yml structure  
        registry.add("spring.datasource.cargowise.url", sqlserver::getJdbcUrl);
        registry.add("spring.datasource.cargowise.username", sqlserver::getUsername);
        registry.add("spring.datasource.cargowise.password", sqlserver::getPassword);
        registry.add("spring.datasource.cargowise.driver-class-name", () -> "com.microsoft.sqlserver.jdbc.SQLServerDriver");
        registry.add("spring.datasource.cargowise.hikari.maximum-pool-size", () -> "3");
        registry.add("spring.datasource.cargowise.hikari.pool-name", () -> "cargowise-test-pool");
        registry.add("spring.datasource.cargowise.hikari.read-only", () -> "true");
        
        // Environment variables matching env.sh pattern (for application components that read them)
        registry.add("SOPL_DB_URL", postgres::getJdbcUrl);
        registry.add("SOPL_DB_USER", postgres::getUsername);
        registry.add("SOPL_DB_PASSWORD", postgres::getPassword);
        registry.add("CARGOWISE_DB_URL", sqlserver::getJdbcUrl);
        registry.add("CARGOWISE_DB_USER", sqlserver::getUsername);
        registry.add("CARGOWISE_DB_PASSWORD", sqlserver::getPassword);
        
        // Kafka configuration (disabled for database-only testing)
        registry.add("KAFKA_ENABLED", () -> "false");
        registry.add("KAFKA_URL", () -> "localhost:9092");
        registry.add("KAFKA_USERNAME", () -> "user1");
        registry.add("KAFKA_PASSWORD", () -> "44gmz7NVT7");
        
        // Email configuration (matching application-local.yml)
        registry.add("EMAIL_USERNAME", () -> "AKIARI2VVUAKJOCZJJZ7");
        registry.add("EMAIL_PASSWORD", () -> "BCHt/98aUNL1BpOPcJJOs0v9fMXUeBtXjkbrjgg/qj/L");
        registry.add("JOB_EMAIL_RECEIPIENTS", () -> "yinchao.tseng@oecgroup.com");
        
        // External API configuration (matching application-local.yml structure)
        registry.add("CWIS_API_URL", () -> "http://localhost:9999");
        registry.add("CWIS_CLIENT_ID", () -> "test_client");
        registry.add("CWIS_CLIENT_SECRET", () -> "test_secret");
        registry.add("COMPLIANCE_API_URL", () -> "http://localhost:9999");
        registry.add("COMPLIANCE_CLIENT_ID", () -> "test_client");
        registry.add("COMPLIANCE_CLIENT_SECRET", () -> "test_secret");
        registry.add("ERPPORTAL_CLIENT_ID", () -> "test_client");
        registry.add("ERPPORTAL_CLIENT_SECRET", () -> "test_secret");
        registry.add("ERPPORTAL_SERVICE_ACCOUNT", () -> "test@example.com");
    }

    // Common Spring dependencies
    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    protected AtAccountTransactionTableService transactionTableService;

    @Autowired
    protected ApiLogService apiLogService;

    @Autowired
    protected ApplicationContext applicationContext;

    // Real services that we want to test
    @Autowired
    protected TransactionRoutingService transactionRoutingService;

    // Shipment view service (may not be available if feature flag is disabled)
    @Autowired(required = false)
    protected ShipmentViewService shipmentViewService;

    // Shipment properties for feature flag control
    @Autowired
    protected ShipmentProperties shipmentProperties;

    // Common mock dependencies
    @MockitoBean
    protected CommonGlobalTableService globalTableService;

    @MockitoBean
    protected ProfileClient profileClient;

    // Database utilities
    protected DatabaseTestUtilities databaseUtils = new DatabaseTestUtilities();
    protected SqlTestUtilities sqlUtils = new SqlTestUtilities();
    protected MockServiceUtilities mockUtils = new MockServiceUtilities();
    protected TestPayloadLoader payloadLoader = new TestPayloadLoader();
    protected ServiceInvestigationUtilities investigationUtils = new ServiceInvestigationUtilities();
    protected TransactionVerificationUtilities verificationUtils = new TransactionVerificationUtilities();

    @BeforeAll
    static void setupContainers() throws Exception {
        log.info("Starting test containers...");
        log.info("PostgreSQL URL: {}", postgres.getJdbcUrl());
        log.info("SQL Server URL: {}", sqlserver.getJdbcUrl());
    }

    @AfterEach
    void cleanupTest() throws Exception {
        log.info("Cleaning up test data...");
        
        // Clean PostgreSQL database tables to ensure fresh state for next test
        try (Connection conn = postgres.createConnection("")) {
            databaseUtils.cleanupTestDatabase(conn);
            databaseUtils.resetReferenceData(conn);
            log.info("PostgreSQL test database cleaned successfully");
        } catch (Exception e) {
            log.warn("Failed to clean PostgreSQL test database: {}", e.getMessage());
        }
        
        // Reset all mocks
        mockUtils.resetAllMocks(globalTableService, profileClient);
    }

    /**
     * Execute a transaction against the correct /external/v1/ARTransaction endpoint
     */
    protected MvcResult executeTransaction(String jsonPayload) throws Exception {
        return mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonPayload))
                .andReturn();
    }

    /**
     * Get PostgreSQL connection for direct database access
     */
    protected Connection getPostgresConnection() throws Exception {
        return postgres.createConnection("");
    }

    /**
     * Get SQL Server connection for direct database access
     */
    protected Connection getSqlServerConnection() throws Exception {
        return sqlserver.createConnection("");
    }

    /**
     * Setup standard Cargowise test data for the given SQL file
     */
    protected void setupCargowiseTestData(String sqlFileName) throws Exception {
        try (Connection conn = getSqlServerConnection()) {
            sqlUtils.loadCargowiseTestData(conn, "src/test/resources/" + sqlFileName);
        }
    }

    /**
     * Abstract method for subclasses to implement their specific test data setup
     */
    protected abstract void setupSpecificTestData() throws Exception;

    /**
     * Abstract method for subclasses to specify their test data SQL file
     */
    protected abstract String getTestDataSqlFile();

    /**
     * Check if the view feature is enabled and available
     */
    protected boolean isViewFeatureAvailable() {
        return shipmentProperties.isViewEnabled() && shipmentViewService != null;
    }

    /**
     * Setup view test data for shipment lookup testing
     */
    protected void setupViewTestData() throws Exception {
        try (Connection conn = getPostgresConnection()) {
            // Insert additional test data for view testing if needed
            String viewTestDataSql = """
                INSERT INTO vw_shipment_info
                (shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl, carrier_book_no, shipment_type, cnsl_type, cnsl_first_leg_vssl, cnsl_first_leg_voy)
                VALUES
                ('STEST001', 'CTEST001', 'HBLTEST001', 'MBLTEST001', 'MASTERTEST001', 'CBKTEST001', 'SEA', 'FCL', 'TEST VESSEL', 'V999'),
                ('STEST002', 'CTEST002', 'HBLTEST002', 'MBLTEST002', 'MASTERTEST002', 'CBKTEST002', 'AIR', 'LCL', 'TEST PLANE', 'F999')
                ON CONFLICT DO NOTHING
                """;

            sqlUtils.executeSingleStatement(conn, viewTestDataSql);
            log.debug("View test data inserted successfully");
        }
    }

    /**
     * Verify view health and availability
     */
    protected boolean verifyViewHealth() {
        if (shipmentViewService == null) {
            log.warn("ShipmentViewService is not available");
            return false;
        }

        try {
            return shipmentViewService.isViewAvailable();
        } catch (Exception e) {
            log.warn("View health check failed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Toggle feature flag for testing both states
     */
    protected void setViewFeatureEnabled(boolean enabled) {
        // This would require reflection or test-specific properties
        // For now, we can test by checking the injected shipmentProperties
        log.info("View feature enabled: {} (current config: {})", enabled, shipmentProperties.isViewEnabled());
    }
}