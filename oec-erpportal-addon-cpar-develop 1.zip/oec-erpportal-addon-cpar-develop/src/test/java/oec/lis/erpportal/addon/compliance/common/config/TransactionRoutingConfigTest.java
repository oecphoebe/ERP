package oec.lis.erpportal.addon.compliance.common.config;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import oec.lis.erpportal.addon.compliance.common.config.TransactionRoutingConfig.RoutingRule;

/**
 * Unit tests for TransactionRoutingConfig
 */
class TransactionRoutingConfigTest {

    private TransactionRoutingConfig config;

    @BeforeEach
    void setUp() {
        config = new TransactionRoutingConfig();
    }

    @Test
    void testDefaultLegacyMode() {
        // Default should be legacy mode enabled
        assertTrue(config.isEnableLegacyMode());
    }

    @Test
    void testLegacyMode_ARShouldSendToExternal() {
        // Given: Legacy mode is enabled (default)
        assertTrue(config.isEnableLegacyMode());

        // When: Check AR transactions
        boolean arInv = config.shouldSendToExternal("AR", "INV");
        boolean arCrd = config.shouldSendToExternal("AR", "CRD");

        // Then: AR should send to external
        assertTrue(arInv);
        assertTrue(arCrd);
    }

    @Test
    void testLegacyMode_APShouldNotSendToExternal() {
        // Given: Legacy mode is enabled (default)
        assertTrue(config.isEnableLegacyMode());

        // When: Check AP transactions
        boolean apInv = config.shouldSendToExternal("AP", "INV");
        boolean apCrd = config.shouldSendToExternal("AP", "CRD");

        // Then: AP should NOT send to external
        assertFalse(apInv);
        assertFalse(apCrd);
    }

    @Test
    void testConfigMode_WithRules() {
        // Given: Config mode with specific rules
        config.setEnableLegacyMode(false);
        
        RoutingRule arInvRule = new RoutingRule();
        arInvRule.setLedger("AR");
        arInvRule.setTransactionType("INV");
        arInvRule.setSendToExternalSystem(true);
        arInvRule.setDescription("AR Invoice to external");

        RoutingRule arCrdRule = new RoutingRule();
        arCrdRule.setLedger("AR");
        arCrdRule.setTransactionType("CRD");
        arCrdRule.setSendToExternalSystem(true);
        arCrdRule.setDescription("AR Credit to external");

        RoutingRule apInvRule = new RoutingRule();
        apInvRule.setLedger("AP");
        apInvRule.setTransactionType("INV");
        apInvRule.setSendToExternalSystem(false);
        apInvRule.setDescription("AP Invoice DB only");

        RoutingRule apCrdRule = new RoutingRule();
        apCrdRule.setLedger("AP");
        apCrdRule.setTransactionType("CRD");
        apCrdRule.setSendToExternalSystem(true);
        apCrdRule.setDescription("AP Credit to external");

        config.setRules(Arrays.asList(arInvRule, arCrdRule, apInvRule, apCrdRule));

        // When: Check routing decisions
        boolean arInv = config.shouldSendToExternal("AR", "INV");
        boolean arCrd = config.shouldSendToExternal("AR", "CRD");
        boolean apInv = config.shouldSendToExternal("AP", "INV");
        boolean apCrd = config.shouldSendToExternal("AP", "CRD");

        // Then: Should follow configured rules
        assertTrue(arInv);
        assertTrue(arCrd);
        assertFalse(apInv);
        assertTrue(apCrd); // NEW: AP CRD can be sent to external
    }

    @Test
    void testConfigMode_NoMatchingRule() {
        // Given: Config mode with no matching rules
        config.setEnableLegacyMode(false);
        config.setRules(Arrays.asList()); // Empty rules

        // When: Check unknown transaction
        boolean result = config.shouldSendToExternal("XX", "YYY");

        // Then: Should default to false (not send)
        assertFalse(result);
    }

    @Test
    void testFindRuleDescription_Found() {
        // Given: Config with rules
        config.setEnableLegacyMode(false);
        
        RoutingRule rule = new RoutingRule();
        rule.setLedger("AP");
        rule.setTransactionType("CRD");
        rule.setSendToExternalSystem(true);
        rule.setDescription("AP Credit Note to China Compliance");

        config.setRules(Arrays.asList(rule));

        // When: Find description
        String description = config.findRuleDescription("AP", "CRD");

        // Then: Should return the description
        assertEquals("AP Credit Note to China Compliance", description);
    }

    @Test
    void testFindRuleDescription_NotFound() {
        // Given: Config with no matching rules
        config.setEnableLegacyMode(false);
        config.setRules(Arrays.asList());

        // When: Find description for non-existent rule
        String description = config.findRuleDescription("XX", "YYY");

        // Then: Should return default message
        assertEquals("No matching rule", description);
    }

    @Test
    void testRoutingRuleGettersSetters() {
        // Test RoutingRule properties
        RoutingRule rule = new RoutingRule();
        
        rule.setLedger("AP");
        assertEquals("AP", rule.getLedger());
        
        rule.setTransactionType("CRD");
        assertEquals("CRD", rule.getTransactionType());
        
        rule.setSendToExternalSystem(true);
        assertTrue(rule.isSendToExternalSystem());
        
        rule.setDescription("Test description");
        assertEquals("Test description", rule.getDescription());
    }

    @Test
    void testCaseSensitivity() {
        // Given: Config with specific case rules
        config.setEnableLegacyMode(false);
        
        RoutingRule rule = new RoutingRule();
        rule.setLedger("AR");
        rule.setTransactionType("INV");
        rule.setSendToExternalSystem(true);
        rule.setDescription("AR Invoice");

        config.setRules(Arrays.asList(rule));

        // When: Check with different case
        boolean exactMatch = config.shouldSendToExternal("AR", "INV");
        boolean lowerCase = config.shouldSendToExternal("ar", "inv");
        boolean mixedCase = config.shouldSendToExternal("Ar", "Inv");

        // Then: Should be case sensitive
        assertTrue(exactMatch);
        assertFalse(lowerCase); // Different case should not match
        assertFalse(mixedCase); // Different case should not match
    }
}