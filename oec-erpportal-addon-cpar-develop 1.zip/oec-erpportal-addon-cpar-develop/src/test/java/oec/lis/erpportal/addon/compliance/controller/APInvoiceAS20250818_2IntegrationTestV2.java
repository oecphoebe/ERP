package oec.lis.erpportal.addon.compliance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MvcResult;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.util.BaseTransactionIntegrationTest;

/**
 * V2 Integration test for AP_INV_AS20250818_2.json payload demonstrating utility-based testing.
 * 
 * This test validates the complete AP Invoice flow using the new utility classes:
 * - Extends BaseTransactionIntegrationTest for common setup
 * - Uses utility classes for all common operations
 * - Focuses on test logic rather than infrastructure
 * - Significantly reduced code complexity (~300 lines vs 1400+ in original)
 * 
 * Test Scenario:
 * 1. AP Invoice transaction (database only, legacy routing)
 * 2. 2 charge lines (DOC + FRT) processing
 * 3. SHIPMENT type transaction with buyer lookup
 * 4. Complete database persistence verification
 */
@TestPropertySource(properties = {
    // Override specific properties for AP Invoice testing
    "transaction.routing.enable-legacy-mode=false",
    "transaction.nonjob.enabled=false"
})
@Slf4j
class APInvoiceAS20250818_2IntegrationTestV2 extends BaseTransactionIntegrationTest {

    private String testPayloadJson;
    private Map<String, Integer> initialCounts;

    @Override
    protected void setupSpecificTestData() throws Exception {
        // Setup Cargowise test data specific to AP Invoice
        setupCargowiseTestData(getTestDataSqlFile());
        
        // Verify critical test data was loaded
        Map<String, Object> expectedData = new HashMap<>();
        expectedData.put("jobNumber", "SSSH1250818426");
        expectedData.put("shipmentRef", "SSSH1250818426");
        expectedData.put("chargeCodes", List.of("DOC", "FRT"));
        
        try (Connection conn = getSqlServerConnection()) {
            sqlUtils.verifyCargowiseTestData(conn, expectedData);
        }
    }

    @Override
    protected String getTestDataSqlFile() {
        return "test-data-cargowise-AS20250818_2-minimal.sql";
    }

    @BeforeEach
    void setupTest() throws Exception {
        log.info("Setting up AP Invoice test with utility-based configuration...");
        
        // Load and validate test payload
        testPayloadJson = payloadLoader.loadAndValidatePayload("reference/AP_INV_AS20250818_2.json");
        
        // Log payload summary for debugging
        payloadLoader.logPayloadSummary(testPayloadJson);
        
        // Setup mocks using utility
        mockUtils.setupBuyerInfoMock(globalTableService, "OECGRPORD", "OEC FREIGHT (NY), INC.");
        mockUtils.setupAPInvoiceRouting(transactionRoutingService, "AS20250818_2/");
        
        // Setup specific test data
        setupSpecificTestData();
        
        // Record initial database state
        try (Connection conn = getPostgresConnection()) {
            initialCounts = new HashMap<>();
            initialCounts.put("at_account_transaction_header", databaseUtils.countRecordsInTable(conn, "at_account_transaction_header"));
            initialCounts.put("at_account_transaction_lines", databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines"));
            initialCounts.put("at_shipment_info", databaseUtils.countRecordsInTable(conn, "at_shipment_info"));
            initialCounts.put("sys_api_log", databaseUtils.countRecordsInTable(conn, "sys_api_log"));
        }
        
        log.info("Initial DB state: {}", initialCounts);
    }

    /**
     * Test 1: Complete AP Invoice processing flow using utilities
     */
    @Test
    void testAPInvoiceCompleteProcessingFlow() throws Exception {
        log.info("=== Testing AP_INV_AS20250818_2.json complete processing flow (V2) ===");
        
        // Execute endpoint using base class utility
        MvcResult result = mockMvc.perform(post("/external/v1/ARTransaction")
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                .content(testPayloadJson))
                .andExpect(status().isAccepted())
                .andExpect(header().exists("X-Track-ID"))
                .andExpect(header().exists("X-API-ID"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("saved to DB only")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("CONFIG")))
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        log.info("Response: {}", responseBody);

        // Verify database changes using utilities
        try (Connection conn = getPostgresConnection()) {
            Map<String, Integer> expectedIncrements = new HashMap<>();
            expectedIncrements.put("at_account_transaction_header", 1);
            expectedIncrements.put("at_account_transaction_lines", 2); // DOC + FRT
            expectedIncrements.put("at_shipment_info", 1);
            expectedIncrements.put("sys_api_log", 1);
            
            verificationUtils.verifyDatabaseChanges(conn, initialCounts, expectedIncrements);
        }
        
        // Verify routing behavior - AP Invoice should NOT be sent to external system
        assertThat(responseBody).contains("AP INV Payload");
        
        // Verify mock interactions
        mockUtils.verifyServiceInteractions(globalTableService);
        
        log.info("=== Complete processing flow test PASSED (V2) ===");
    }

    /**
     * Test 2: Transaction header data verification using utilities
     */
    @Test
    void testTransactionHeaderDataPersistence() throws Exception {
        log.info("=== Testing transaction header data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify transaction header using utility
        try (Connection conn = getPostgresConnection()) {
            // Wait for async processing
            databaseUtils.waitForDatabaseRecords(conn, "at_account_transaction_header", 1, 5);
            
            // Setup expected values
            Map<String, Object> expectedHeader = new HashMap<>();
            expectedHeader.put("transactionNumber", "AS20250818_2/");
            expectedHeader.put("ledger", "AP");
            expectedHeader.put("transactionType", "INV");
            expectedHeader.put("organizationCode", "OECGRPORD");
            expectedHeader.put("currencyCode", "CNY");
            expectedHeader.put("invoiceAmount", -47.75);
            expectedHeader.put("outstandingAmount", -47.75);
            
            verificationUtils.verifyTransactionHeader(conn, expectedHeader);
        }
        
        log.info("=== Transaction header data test PASSED (V2) ===");
    }

    /**
     * Test 3: Transaction lines data verification using utilities
     */
    @Test
    void testTransactionLinesDataPersistence() throws Exception {
        log.info("=== Testing transaction lines data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify transaction lines using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "at_account_transaction_lines", 2, 5);
            
            // Setup expected lines (DOC + FRT charges)
            Map<String, Object> docLine = new HashMap<>();
            docLine.put("description", "Destination Documentation Fee");
            docLine.put("chargeAmount", -11.00);
            docLine.put("totalAmount", -11.00);
            
            Map<String, Object> frtLine = new HashMap<>();
            frtLine.put("description", "International Freight");
            frtLine.put("chargeAmount", -5.00);
            frtLine.put("totalAmount", -36.75);
            
            List<Map<String, Object>> expectedLines = List.of(docLine, frtLine);
            verificationUtils.verifyTransactionLines(conn, "AS20250818_2/", expectedLines);
        }
        
        log.info("=== Transaction lines data test PASSED (V2) ===");
    }

    /**
     * Test 4: Shipment info data verification using utilities
     */
    @Test
    void testShipmentInfoDataPersistence() throws Exception {
        log.info("=== Testing shipment info data persistence (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify shipment info using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "at_shipment_info", 1, 5);
            
            Map<String, Object> expectedShipment = new HashMap<>();
            expectedShipment.put("hblNumber", "OERT201702Y00586");
            expectedShipment.put("containerMode", "LCL");
            expectedShipment.put("shipmentType", "LCL");
            
            verificationUtils.verifyShipmentInfo(conn, "SSSH1250818426", expectedShipment);
        }
        
        log.info("=== Shipment info data test PASSED (V2) ===");
    }

    /**
     * Test 5: API log verification using utilities
     */
    @Test
    void testApiLogCreation() throws Exception {
        log.info("=== Testing API log creation (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify API log using utility
        try (Connection conn = getPostgresConnection()) {
            databaseUtils.waitForDatabaseRecords(conn, "sys_api_log", 1, 5);
            verificationUtils.verifyApiLog(conn, "DONE", "API14");
            // With legacy mode disabled, AP-INV policy: always saved to DB only, never sent to external
            verificationUtils.verifyTransactionStatus(conn, "DONE", "savedToDatabase\":true,\"readyForExternal\":false");
        }
        
        log.info("=== API log creation test PASSED (V2) ===");
    }

    /**
     * Test 6: Complete flow verification using single utility call
     */
    @Test
    void testCompleteFlowWithSingleVerification() throws Exception {
        log.info("=== Testing complete flow with single verification call (V2) ===");
        
        // Execute transaction
        executeTransaction(testPayloadJson);

        // Verify everything with one utility call
        try (Connection conn = getPostgresConnection()) {
            verificationUtils.verifyCompleteTransactionFlow(conn, "AS20250818_2/");
        }
        
        log.info("=== Complete flow single verification test PASSED (V2) ===");
    }

    /**
     * Test 7: Service investigation and debugging demonstration
     */
    @Test 
    void testServiceInvestigationCapabilities() throws Exception {
        log.info("=== Demonstrating service investigation utilities (V2) ===");
        
        // Use investigation utilities for debugging
        investigationUtils.verifyServiceRegistration(applicationContext);
        investigationUtils.findStrategyBeans(applicationContext, "transaction");
        investigationUtils.analyzeTransactionFlow(applicationContext, "AP", "INV");
        investigationUtils.inspectServiceConfiguration(applicationContext, 
            oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService.class);
        
        // Execute transaction
        executeTransaction(testPayloadJson);
        
        // Investigate mock interactions
        investigationUtils.investigateMockServices(globalTableService, profileClient);
        
        log.info("=== Service investigation demonstration COMPLETE (V2) ===");
    }
}