package oec.lis.erpportal.addon.compliance.match;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MatchNumberExtractorTest {

    @Test
    void testExtractFromDescription_ValidFormat() {
        // Test valid SOPL Match No format
        String description = "SOPL Match No:MSH12510130001";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertEquals("MSH12510130001", result);
    }

    @Test
    void testExtractFromDescription_ValidFormatWithSurroundingText() {
        // Test with surrounding text
        String description = "Payment for SOPL Match No:MSH12510130001 processed";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertEquals("MSH12510130001", result);
    }

    @Test
    void testExtractFromDescription_InvalidFormat() {
        // Test invalid format (no match pattern)
        String description = "REVERSAL RELATED TO PAY2509001001 - IAM";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertNull(result);
    }

    @Test
    void testExtractFromDescription_NullInput() {
        // Test null input
        String result = MatchNumberExtractor.extractFromDescription(null);
        assertNull(result);
    }

    @Test
    void testExtractFromDescription_EmptyInput() {
        // Test empty input
        String result = MatchNumberExtractor.extractFromDescription("");
        assertNull(result);
    }

    @Test
    void testExtractFromDescription_BlankInput() {
        // Test blank input
        String result = MatchNumberExtractor.extractFromDescription("   ");
        assertNull(result);
    }

    @Test
    void testExtractFromCheckNumber_ValidInput() {
        // Test direct extraction from check number
        String checkNumber = "MSH12510130001";
        String result = MatchNumberExtractor.extractFromCheckNumber(checkNumber);
        assertEquals("MSH12510130001", result);
    }

    @Test
    void testExtractFromCheckNumber_WithWhitespace() {
        // Test with whitespace (should be trimmed)
        String checkNumber = "  MSH12510130001  ";
        String result = MatchNumberExtractor.extractFromCheckNumber(checkNumber);
        assertEquals("MSH12510130001", result);
    }

    @Test
    void testExtractFromCheckNumber_NullInput() {
        // Test null input
        String result = MatchNumberExtractor.extractFromCheckNumber(null);
        assertNull(result);
    }

    @Test
    void testExtractFromCheckNumber_EmptyInput() {
        // Test empty input
        String result = MatchNumberExtractor.extractFromCheckNumber("");
        assertNull(result);
    }

    @Test
    void testExtractFromCheckNumber_BlankInput() {
        // Test blank input
        String result = MatchNumberExtractor.extractFromCheckNumber("   ");
        assertNull(result);
    }

    @Test
    void testExtractFromDescription_MultipleMatchNumbers() {
        // Test with multiple match numbers (should extract first one)
        String description = "SOPL Match No:MSH12510130001 and SOPL Match No:MSH12510130002";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertEquals("MSH12510130001", result);
    }

    @Test
    void testExtractFromDescription_LowercasePattern() {
        // Test that pattern is case sensitive (should fail)
        String description = "sopl match no:MSH12510130001";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertNull(result);
    }

    @Test
    void testExtractFromDescription_AlphanumericMatchNumber() {
        // Test with alphanumeric match number
        String description = "SOPL Match No:ABC123XYZ789";
        String result = MatchNumberExtractor.extractFromDescription(description);
        assertEquals("ABC123XYZ789", result);
    }
}
