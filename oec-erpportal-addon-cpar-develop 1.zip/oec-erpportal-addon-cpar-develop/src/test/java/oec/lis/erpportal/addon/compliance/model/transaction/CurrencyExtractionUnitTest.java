package oec.lis.erpportal.addon.compliance.model.transaction;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import lombok.extern.slf4j.Slf4j;

/**
 * Unit tests for currency extraction logic in TransactionChargeLineRequestBean.
 * 
 * These tests validate the enhanced currency extraction refactoring that:
 * 1. Extracts currency from charge-line specific fields for AR/AP transactions
 * 2. Supports NONJOB PostingJournal currency extraction from Oscurrency.Code
 * 3. Provides proper fallback mechanisms
 * 4. Maintains backward compatibility with existing logic
 * 
 * Test scenarios cover:
 * - AR transactions with SellOSCurrency.Code extraction
 * - AP transactions with CostOSCurrency.Code extraction 
 * - NONJOB transactions with PostingJournal Oscurrency.Code extraction
 * - Fallback behavior when charge-line currency is missing
 * - Error handling for malformed JSON structures
 */
@Slf4j
class CurrencyExtractionUnitTest {

    private TransactionInfoRequestBean mockTransactionInfoBean;

    @BeforeEach
    void setUp() {
        // Setup common test transaction info with fallback currency
        mockTransactionInfoBean = new TransactionInfoRequestBean();
        mockTransactionInfoBean.setCurrency("USD"); // Default fallback currency
        mockTransactionInfoBean.setBillNo("TEST-001");
        mockTransactionInfoBean.setTransactionType("INV");
    }

    @Test
    @DisplayName("AR transaction should extract currency from SellOSCurrency.Code")
    void testARTransactionCurrencyExtraction() {
        // Given: AR transaction with SellOSCurrency
        String arChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "SellOSAmount": "300.0",
                "SellOSGSTVATAmount": "30.0",
                "SellOSCurrency": {
                    "Code": "CNY",
                    "Description": "Chinese Yuan"
                },
                "CostOSAmount": "0.0",
                "CostOSGSTVATAmount": "0.0",
                "CostOSCurrency": {
                    "Code": "USD",
                    "Description": "United States Dollar"
                }
            }
            """;

        // When: Create TransactionChargeLineRequestBean for AR ledger
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, arChargeLineJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );

        // Then: Should extract CNY from SellOSCurrency.Code (AR sales side)
        assertThat(chargeLineBean.getCurrency()).isEqualTo("CNY");
        log.info("✓ AR transaction correctly extracted currency: {}", chargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("AP transaction should extract currency from CostOSCurrency.Code")
    void testAPTransactionCurrencyExtraction() {
        // Given: AP transaction with CostOSCurrency
        String apChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "FRT",
                    "Description": "Freight Charge"
                },
                "SellOSAmount": "0.0",
                "SellOSGSTVATAmount": "0.0",
                "SellOSCurrency": {
                    "Code": "USD",
                    "Description": "United States Dollar"  
                },
                "CostOSAmount": "500.0",
                "CostOSGSTVATAmount": "50.0",
                "CostOSCurrency": {
                    "Code": "EUR",
                    "Description": "Euro"
                }
            }
            """;

        // When: Create TransactionChargeLineRequestBean for AP ledger
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, apChargeLineJson, "AP", "$.CostOSAmount", "$.CostOSGSTVATAmount"
        );

        // Then: Should extract EUR from CostOSCurrency.Code (AP cost/vendor side)
        assertThat(chargeLineBean.getCurrency()).isEqualTo("EUR");
        log.info("✓ AP transaction correctly extracted currency: {}", chargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("NONJOB transaction should extract currency from PostingJournal Oscurrency.Code")
    void testNONJOBPostingJournalCurrencyExtraction() {
        // Given: NONJOB PostingJournal with Oscurrency (contains Osamount field)
        String nonjobPostingJournalJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "PostingReference": "NONJOB-REF-001",
                "Osamount": 750.0,
                "Osgstvatamount": 0.0,
                "Oscurrency": {
                    "Code": "GBP",
                    "Description": "British Pound"
                },
                "Department": {"Code": "FIN"},
                "Description": "NONJOB posting journal entry"
            }
            """;

        // When: Create TransactionChargeLineRequestBean for any ledger (NONJOB detection is automatic)
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, nonjobPostingJournalJson, "AR", "$.Osamount", "$.Osgstvatamount"
        );

        // Then: Should detect NONJOB structure and extract GBP from Oscurrency.Code
        assertThat(chargeLineBean.getCurrency()).isEqualTo("GBP");
        log.info("✓ NONJOB transaction correctly extracted currency: {}", chargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("Should fallback to header currency when charge-line currency is missing")
    void testCurrencyExtractionFallback() {
        // Given: AR transaction with missing SellOSCurrency
        String incompleteChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "AMS",
                    "Description": "US Port Security Fee"
                },
                "SellOSAmount": "50.0",
                "SellOSGSTVATAmount": "5.0",
                "CostOSAmount": "0.0",
                "CostOSGSTVATAmount": "0.0"
            }
            """;

        // When: Create TransactionChargeLineRequestBean for AR ledger
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, incompleteChargeLineJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );

        // Then: Should fallback to header currency (USD)
        assertThat(chargeLineBean.getCurrency()).isEqualTo("USD");
        log.info("✓ Fallback mechanism correctly used header currency: {}", chargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("Should handle mixed currency scenarios correctly")
    void testMixedCurrencyScenario() {
        // Given: Charge line with different sell vs cost currencies
        String mixedCurrencyJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "SellOSAmount": "100.0",
                "SellOSGSTVATAmount": "10.0",
                "SellOSCurrency": {
                    "Code": "JPY",
                    "Description": "Japanese Yen"
                },
                "CostOSAmount": "80.0",
                "CostOSGSTVATAmount": "8.0",
                "CostOSCurrency": {
                    "Code": "CHF",
                    "Description": "Swiss Franc"
                }
            }
            """;

        // When: Create beans for both AR and AP ledgers
        TransactionChargeLineRequestBean arChargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, mixedCurrencyJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );
        TransactionChargeLineRequestBean apChargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, mixedCurrencyJson, "AP", "$.CostOSAmount", "$.CostOSGSTVATAmount"
        );

        // Then: AR should use SellOSCurrency, AP should use CostOSCurrency
        assertThat(arChargeLineBean.getCurrency()).isEqualTo("JPY"); // AR uses sell side
        assertThat(apChargeLineBean.getCurrency()).isEqualTo("CHF"); // AP uses cost side
        
        log.info("✓ Mixed currency scenario - AR: {}, AP: {}", 
            arChargeLineBean.getCurrency(), apChargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("Should handle malformed JSON gracefully")
    void testMalformedJSONHandling() {
        // Given: Malformed JSON that might cause parsing issues
        String malformedJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "SellOSAmount": "100.0",
                "SellOSGSTVATAmount": "10.0",
                "SellOSCurrency": {
                    "Code": null
                },
                "CostOSAmount": "0.0",
                "CostOSGSTVATAmount": "0.0"
            }
            """;

        // When: Create TransactionChargeLineRequestBean
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, malformedJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );

        // Then: Should fallback gracefully to header currency
        assertThat(chargeLineBean.getCurrency()).isEqualTo("USD");
        log.info("✓ Malformed JSON handled gracefully with fallback: {}", chargeLineBean.getCurrency());
    }

    @Test
    @DisplayName("Should preserve existing charge amount extraction")
    void testChargeAmountExtractionPreservation() {
        // Given: Standard charge line with amounts
        String chargeLineWithAmountJson = """
            {
                "ChargeCode": {
                    "Code": "FRT",
                    "Description": "Freight Charge"
                },
                "SellOSAmount": "250.0",
                "SellOSGSTVATAmount": "25.0",
                "SellOSCurrency": {
                    "Code": "CAD",
                    "Description": "Canadian Dollar"
                },
                "CostOSAmount": "200.0",
                "CostOSGSTVATAmount": "20.0",
                "CostOSCurrency": {
                    "Code": "MXN", 
                    "Description": "Mexican Peso"
                }
            }
            """;

        // When: Create TransactionChargeLineRequestBean for AR
        TransactionChargeLineRequestBean chargeLineBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, chargeLineWithAmountJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );

        // Then: Should extract both currency and amount correctly
        assertThat(chargeLineBean.getCurrency()).isEqualTo("CAD");
        assertThat(chargeLineBean.getAmount().doubleValue()).isEqualTo(250.0); // Amount = SellOSAmount (net amount for AR)
        assertThat(chargeLineBean.getItemCode()).isEqualTo("FRT");
        
        log.info("✓ Charge amount extraction preserved - Amount: {}, Currency: {}, Code: {}", 
            chargeLineBean.getAmount(), chargeLineBean.getCurrency(), chargeLineBean.getItemCode());
    }

    @Test
    @DisplayName("Should validate NONJOB detection logic accuracy")
    void testNONJOBDetectionAccuracy() {
        // Given: Regular charge line vs NONJOB PostingJournal
        String regularChargeLineJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "SellOSAmount": "100.0",
                "SellOSGSTVATAmount": "10.0",
                "SellOSCurrency": {"Code": "USD"},
                "CostOSAmount": "0.0",
                "CostOSGSTVATAmount": "0.0"
            }
            """;
            
        String nonjobPostingJournalJson = """
            {
                "ChargeCode": {
                    "Code": "DOC",
                    "Description": "Documentation Fee"
                },
                "Osamount": "150.0",
                "Osgstvatamount": "15.0",
                "Oscurrency": {"Code": "EUR"},
                "Department": {"Code": "FIN"}
            }
            """;

        // When: Create beans for both types
        TransactionChargeLineRequestBean regularBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, regularChargeLineJson, "AR", "$.SellOSAmount", "$.SellOSGSTVATAmount"
        );
        TransactionChargeLineRequestBean nonjobBean = new TransactionChargeLineRequestBean(
            mockTransactionInfoBean, nonjobPostingJournalJson, "AR", "$.Osamount", "$.Osgstvatamount"
        );

        // Then: Should correctly differentiate between them
        assertThat(regularBean.getCurrency()).isEqualTo("USD"); // From SellOSCurrency
        assertThat(nonjobBean.getCurrency()).isEqualTo("EUR"); // From Oscurrency
        
        log.info("✓ NONJOB detection accurate - Regular: {}, NONJOB: {}", 
            regularBean.getCurrency(), nonjobBean.getCurrency());
    }
}