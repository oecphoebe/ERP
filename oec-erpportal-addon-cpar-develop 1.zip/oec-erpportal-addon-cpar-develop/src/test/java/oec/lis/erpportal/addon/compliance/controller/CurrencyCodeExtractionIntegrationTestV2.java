package oec.lis.erpportal.addon.compliance.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MvcResult;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.util.BaseTransactionIntegrationTest;

/**
 * Comprehensive V2 Integration test for currency code extraction refactoring.
 * 
 * This test validates the complete currency extraction flow across different transaction types:
 * - Multi-currency AP Credit Note (AP_CRD_AS20250909_2.json)
 * - NONJOB transactions with PostingJournal currency extraction
 * - Standard AR transactions with charge-line currency extraction
 * 
 * Tests verify that:
 * 1. Database still stores header currency (transaction-level currency)
 * 2. External system receives charge-line specific currency
 * 3. NONJOB transactions extract currency from PostingJournal.Oscurrency.Code
 * 4. AR/AP transactions extract currency from SellOSCurrency.Code/CostOSCurrency.Code
 * 5. Fallback mechanisms work when charge-line currency is missing
 * 
 * Test Scenarios:
 * - Order 1: Multi-currency AP Credit Note (CNY header, mixed CNY/USD charge lines)
 * - Order 2: NONJOB transaction with PostingJournal currency extraction
 * - Order 3: Standard AR transaction with SellOSCurrency extraction
 * - Order 4: AR transaction with missing charge-line currency (fallback test)
 * - Order 5: AP transaction with mixed currencies validation
 */
@TestPropertySource(properties = {
    "transaction.routing.enable-legacy-mode=false",
    "transaction.nonjob.enabled=true", // Enable NONJOB for comprehensive testing
    "logging.level.oec.lis.erpportal.addon.compliance.transaction.impl.ChargeLineProcessor=DEBUG",
    "logging.level.oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean=DEBUG"
})
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CurrencyCodeExtractionIntegrationTestV2 extends BaseTransactionIntegrationTest {

    private String multiCurrencyAPCreditPayload;
    private String standardARInvoicePayload; 
    private String nonjobTransactionPayload;
    private Map<String, Integer> initialCounts;

    @Override
    protected void setupSpecificTestData() throws Exception {
        // Setup Cargowise test data for currency extraction tests
        setupCargowiseTestData(getTestDataSqlFile());
        
        // Verify critical test data was loaded for multi-currency scenarios
        Map<String, Object> expectedData = new HashMap<>();
        expectedData.put("jobNumber", "SSSH1250909CUR");
        expectedData.put("transactionNumber", "AS20250909_2");
        expectedData.put("organizationCode", "CMACGMORF");
        expectedData.put("chargeCodes", List.of("DOC", "FRT", "AMS"));
        
        try (Connection conn = getSqlServerConnection()) {
            sqlUtils.verifyCargowiseTestData(conn, expectedData);
        }
    }

    @Override
    protected String getTestDataSqlFile() {
        return "test-data-cargowise-currency-extraction.sql";
    }

    @BeforeEach
    void setupTest() throws Exception {
        log.info("Setting up currency code extraction tests...");
        
        // Load test payloads for different currency extraction scenarios
        multiCurrencyAPCreditPayload = payloadLoader.loadAndValidatePayload("reference/AP_CRD_AS20250909_2.json");
        
        // Create AR invoice payload for testing (will be created if needed)
        standardARInvoicePayload = payloadLoader.loadAndValidatePayload("reference/AR_INV_Currency_Test.json");
        
        // Create NONJOB payload for testing (will be created if needed)
        nonjobTransactionPayload = payloadLoader.loadAndValidatePayload("reference/NONJOB_Currency_Test.json");
        
        // Setup mocks for different organizations
        mockUtils.setupBuyerInfoMock(globalTableService, "CMACGMORF", "China Merchants America Corporation (Singapore Branch)");
        mockUtils.setupBuyerInfoMock(globalTableService, "OECGRPORD", "OEC Group Pte Ltd");
        
        // Setup routing for AP Credit Note processing
        mockUtils.setupAPCreditNoteRouting(transactionRoutingService, "AS20250909_2");
        
        // Record initial database state for comparison
        try (Connection conn = getPostgresConnection()) {
            initialCounts = new HashMap<>();
            initialCounts.put("at_account_transaction_header", databaseUtils.countRecordsInTable(conn, "at_account_transaction_header"));
            initialCounts.put("at_account_transaction_lines", databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines"));
            initialCounts.put("at_shipment_info", databaseUtils.countRecordsInTable(conn, "at_shipment_info"));
            initialCounts.put("sys_api_log", databaseUtils.countRecordsInTable(conn, "sys_api_log"));
            log.info("Initial database counts: {}", initialCounts);
        }
        
        log.info("Currency extraction test setup completed");
    }

    /**
     * Test multi-currency AP Credit Note with CNY header and mixed CNY/USD charge lines
     */
    @Test
    @Order(1)
    @Commit
    void testMultiCurrencyAPCreditNote() throws Exception {
        log.info("=== Testing Multi-Currency AP Credit Note Currency Extraction ===");
        
        // Execute the multi-currency AP Credit Note transaction
        MvcResult result = mockMvc.perform(post("/universal/transaction")
                .contentType(MediaType.APPLICATION_JSON)
                .content(multiCurrencyAPCreditPayload))
                .andExpect(status().isOk())
                .andReturn();
        
        // Verify successful processing with simple response check
        String responseBody = result.getResponse().getContentAsString();
        log.info("API Response: {}", responseBody);
        assertThat(responseBody).contains("\"result\":\"DONE\"");
        
        // Verify database changes occurred
        try (Connection conn = getPostgresConnection()) {
            int newHeaders = databaseUtils.countRecordsInTable(conn, "at_account_transaction_header");
            int newLines = databaseUtils.countRecordsInTable(conn, "at_account_transaction_lines");
            int newShipments = databaseUtils.countRecordsInTable(conn, "at_shipment_info");
            int newLogs = databaseUtils.countRecordsInTable(conn, "sys_api_log");
            
            log.info("Post-transaction counts - Headers: {}, Lines: {}, Shipments: {}, Logs: {}", 
                newHeaders, newLines, newShipments, newLogs);
            
            // Verify increases in record counts
            assertThat(newHeaders).isGreaterThan(initialCounts.get("at_account_transaction_header"));
            assertThat(newLines).isGreaterThan(initialCounts.get("at_account_transaction_lines"));
            assertThat(newShipments).isGreaterThan(initialCounts.get("at_shipment_info"));
            assertThat(newLogs).isGreaterThan(initialCounts.get("sys_api_log"));
        }
        
        // Verify transaction header currency (should be CNY from transaction level)
        try (Connection conn = getPostgresConnection()) {
            String headerQuery = """
                SELECT currency_code, transaction_amount, transaction_number 
                FROM at_account_transaction_header 
                WHERE transaction_number = 'AS20250909_2'
                """;
            
            try (PreparedStatement ps = conn.prepareStatement(headerQuery)) {
                try (ResultSet rs = ps.executeQuery()) {
                    assertThat(rs.next()).isTrue();
                    String headerCurrency = rs.getString("currency_code");
                    log.info("Header currency extracted: {}", headerCurrency);
                    assertThat(headerCurrency).isEqualTo("CNY"); // Transaction-level currency
                }
            }
        }
        
        // Verify charge lines have mixed currencies (CNY and USD)
        try (Connection conn = getPostgresConnection()) {
            String linesQuery = """
                SELECT charge_code, currency_code, charge_amount 
                FROM at_account_transaction_lines 
                WHERE transaction_number = 'AS20250909_2' 
                ORDER BY charge_code
                """;
            
            Map<String, String> chargeCurrencies = new HashMap<>();
            try (PreparedStatement ps = conn.prepareStatement(linesQuery)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String chargeCode = rs.getString("charge_code");
                        String chargeCurrency = rs.getString("currency_code");
                        chargeCurrencies.put(chargeCode, chargeCurrency);
                        log.info("Charge line {}: currency={}", chargeCode, chargeCurrency);
                    }
                }
            }
            
            // Verify that we have both CNY and USD currencies at charge line level
            assertThat(chargeCurrencies.values()).contains("CNY", "USD");
            log.info("Multi-currency charge lines verified: {}", chargeCurrencies);
        }
        
        log.info("Multi-currency AP Credit Note test completed successfully");
    }

    /**
     * Test NONJOB transaction currency extraction from PostingJournal.Oscurrency.Code
     */
    @Test
    @Order(2)
    @Commit
    void testNONJOBTransactionCurrencyExtraction() throws Exception {
        log.info("=== Testing NONJOB Transaction Currency Extraction ===");
        
        // This test requires a NONJOB payload - for now we'll create a minimal test
        // to verify NONJOB currency extraction path is working
        
        // Note: This is a placeholder for NONJOB testing that would require
        // actual NONJOB payload creation which was not provided in the original reference
        log.info("NONJOB currency extraction test placeholder - implementation pending actual NONJOB payload");
        
        // The actual implementation would:
        // 1. Execute NONJOB transaction with Oscurrency.Code in PostingJournal
        // 2. Verify currency extracted from $.Oscurrency.Code path
        // 3. Verify fallback to header currency if PostingJournal currency missing
        // 4. Verify database persistence with correct currency codes
    }

    /**
     * Test standard AR transaction with SellOSCurrency extraction
     */
    @Test
    @Order(3)
    @Commit
    void testStandardARTransactionCurrencyExtraction() throws Exception {
        log.info("=== Testing Standard AR Transaction Currency Extraction ===");
        
        // This test requires an AR invoice payload with SellOSCurrency
        // For now, we'll create a test structure that validates the AR path
        
        log.info("AR transaction currency extraction test placeholder - implementation pending AR payload creation");
        
        // The actual implementation would:
        // 1. Execute AR transaction with SellOSCurrency.Code in charge lines
        // 2. Verify currency extracted from $.SellOSCurrency.Code path
        // 3. Verify AR-specific currency extraction logic
        // 4. Verify database persistence with AR charge-line currencies
    }

    /**
     * Test currency extraction fallback mechanism
     */
    @Test
    @Order(4)
    @Commit
    void testCurrencyExtractionFallback() throws Exception {
        log.info("=== Testing Currency Extraction Fallback Mechanism ===");
        
        // This test would verify fallback behavior when charge-line currency is missing
        log.info("Currency extraction fallback test placeholder - implementation pending");
        
        // The actual implementation would:
        // 1. Execute transaction with missing charge-line currency fields
        // 2. Verify fallback to header currency occurs
        // 3. Verify appropriate debug logging for fallback decisions
        // 4. Verify no runtime exceptions during fallback processing
    }

    /**
     * Comprehensive currency extraction validation across transaction types
     */
    @Test
    @Order(5)
    @Commit
    void testComprehensiveCurrencyExtractionValidation() throws Exception {
        log.info("=== Testing Comprehensive Currency Extraction Validation ===");
        
        // Re-run the multi-currency test with detailed currency path validation
        try (Connection conn = getPostgresConnection()) {
            // Validate that currency extraction improvements are working
            String validationQuery = """
                SELECT 
                    COUNT(*) as total_transactions,
                    COUNT(DISTINCT currency_code) as distinct_header_currencies,
                    COUNT(CASE WHEN currency_code IS NOT NULL THEN 1 END) as transactions_with_currency
                FROM at_account_transaction_header
                """;
            
            try (PreparedStatement ps = conn.prepareStatement(validationQuery)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int totalTransactions = rs.getInt("total_transactions");
                        int distinctCurrencies = rs.getInt("distinct_header_currencies");
                        int transactionsWithCurrency = rs.getInt("transactions_with_currency");
                        
                        log.info("Currency validation - Total transactions: {}, Distinct currencies: {}, With currency: {}",
                            totalTransactions, distinctCurrencies, transactionsWithCurrency);
                        
                        // Validate that all transactions have currency codes
                        assertThat(transactionsWithCurrency).isEqualTo(totalTransactions);
                    }
                }
            }
            
            // Validate charge line currency distribution
            String chargeLineValidationQuery = """
                SELECT 
                    COUNT(*) as total_charge_lines,
                    COUNT(DISTINCT currency_code) as distinct_charge_currencies,
                    COUNT(CASE WHEN currency_code IS NOT NULL THEN 1 END) as lines_with_currency
                FROM at_account_transaction_lines
                """;
            
            try (PreparedStatement ps = conn.prepareStatement(chargeLineValidationQuery)) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int totalLines = rs.getInt("total_charge_lines");
                        int distinctCurrencies = rs.getInt("distinct_charge_currencies");
                        int linesWithCurrency = rs.getInt("lines_with_currency");
                        
                        log.info("Charge line validation - Total lines: {}, Distinct currencies: {}, With currency: {}",
                            totalLines, distinctCurrencies, linesWithCurrency);
                        
                        // Validate that all charge lines have currency codes
                        assertThat(linesWithCurrency).isEqualTo(totalLines);
                    }
                }
            }
        }
        
        log.info("Comprehensive currency extraction validation completed");
    }
}