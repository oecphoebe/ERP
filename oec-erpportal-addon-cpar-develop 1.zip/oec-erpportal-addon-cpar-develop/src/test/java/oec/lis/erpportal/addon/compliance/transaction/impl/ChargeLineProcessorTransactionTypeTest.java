package oec.lis.erpportal.addon.compliance.transaction.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.PostingJournal;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionInfoRequestBean;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;

/**
 * Test to verify that the TransactionType is correctly passed to the routing service
 * instead of hardcoded "INV" values.
 */
@ExtendWith(MockitoExtension.class)
class ChargeLineProcessorTransactionTypeTest {

    @Mock
    private TransactionRoutingService transactionRoutingService;
    
    @Mock
    private TransactionValidationService validationService;
    
    @Mock
    private TransactionQueryService queryService;
    
    private ChargeLineProcessor chargeLineProcessor;
    
    @BeforeEach
    void setUp() {
        chargeLineProcessor = new ChargeLineProcessor(transactionRoutingService, validationService, queryService);
    }
    
    @Test
    void testAPCRDTransactionTypePassedCorrectlyToRoutingService() throws Exception {
        // Given: AP-CRD transaction data
        String ledger = "AP";
        String transactionType = "CRD";
        String transactionNo = "AS20250819_7/C";
        String refNoType = "CONSOL";
        
        List<TransactionChargeLineRequestBean> requestBeanList = new ArrayList<>();
        List<AtAccountTransactionLinesBean> linesBeanList = new ArrayList<>();
        List<CwAccountTransactionInfo> cwTransactionInfoList = new ArrayList<>();
        
        // Create mock transaction info
        TransactionInfoRequestBean transactionInfoRequestBean = new TransactionInfoRequestBean();
        transactionInfoRequestBean.setBillNo(transactionNo);
        
        AtAccountTransactionHeaderBean headerBean = new AtAccountTransactionHeaderBean();
        headerBean.setAcctTransHeaderId(UUID.randomUUID());
        
        // Create mock shipments with ConsolCostLine data
        List<Map<String, Object>> shipments = new ArrayList<>();
        Map<String, Object> shipment = new HashMap<>();
        
        // Create ConsolCostLine data
        List<Map<String, Object>> consolCostLine = new ArrayList<>();
        Map<String, Object> costLineItem = new HashMap<>();
        costLineItem.put("ChargeCode", Map.of("Code", "FREIGHT", "Description", "Freight Charge"));
        costLineItem.put("OutstandingAmount", "1000.00");
        costLineItem.put("OutstandingGSTVATAmount", "100.00");
        costLineItem.put("CostAPInvoiceNumber", transactionNo);
        // Add required fields for AP processing
        costLineItem.put("CostOSAmount", "1000.00");
        costLineItem.put("CostOSGSTVATAmount", "100.00");
        costLineItem.put("CostLocalAmount", "1100.00");
        costLineItem.put("CostOSCurrency", Map.of("Code", "USD"));
        costLineItem.put("CostExchangeRate", "1.0");
        consolCostLine.add(costLineItem);
        shipment.put("ConsolCostLine", consolCostLine);
        
        shipments.add(shipment);
        
        // Create mock CwAccountTransactionInfo
        CwAccountTransactionInfo cwTransactionInfo = new CwAccountTransactionInfo();
        cwTransactionInfo.setUsed(false);
        cwTransactionInfo.setChargeCode("FREIGHT");
        cwTransactionInfo.setInvoiceNo(transactionNo);
        cwTransactionInfo.setAccountTransactionLinesPk(UUID.randomUUID());
        cwTransactionInfo.setAccountChargeCodePk(UUID.randomUUID());
        cwTransactionInfoList.add(cwTransactionInfo);
        
        // Mock routing service response
        when(transactionRoutingService.shouldSendToExternalSystem(eq(ledger), eq(transactionType), eq(transactionNo)))
            .thenReturn(true);
        
        // When: Processing charge lines with AP-CRD transaction type
        chargeLineProcessor.handleChargeLineInShipment(
            requestBeanList, linesBeanList, cwTransactionInfoList, shipments,
            transactionInfoRequestBean, headerBean, ledger, transactionType,
            transactionNo, refNoType, "0", Optional.empty(), new ArrayList<>()
        );
        
        // Then: Verify that the routing service was called with correct transaction type "CRD" (not "INV")
        ArgumentCaptor<String> transactionTypeCaptor = ArgumentCaptor.forClass(String.class);
        verify(transactionRoutingService).shouldSendToExternalSystem(
            eq(ledger), 
            transactionTypeCaptor.capture(), 
            eq(transactionNo)
        );
        
        assertEquals("CRD", transactionTypeCaptor.getValue(), 
            "TransactionType should be 'CRD' for AP-CRD transactions, not hardcoded 'INV'");
    }
    
    @Test
    void testAPINVTransactionTypePassedCorrectlyToRoutingService() throws Exception {
        // Given: AP-INV transaction data
        String ledger = "AP";
        String transactionType = "INV";
        String transactionNo = "AS20250819_8/I";
        String refNoType = "CONSOL";
        
        List<TransactionChargeLineRequestBean> requestBeanList = new ArrayList<>();
        List<AtAccountTransactionLinesBean> linesBeanList = new ArrayList<>();
        List<CwAccountTransactionInfo> cwTransactionInfoList = new ArrayList<>();
        
        // Create mock transaction info
        TransactionInfoRequestBean transactionInfoRequestBean = new TransactionInfoRequestBean();
        transactionInfoRequestBean.setBillNo(transactionNo);
        
        AtAccountTransactionHeaderBean headerBean = new AtAccountTransactionHeaderBean();
        headerBean.setAcctTransHeaderId(UUID.randomUUID());
        
        // Create mock shipments with ConsolCostLine data
        List<Map<String, Object>> shipments = new ArrayList<>();
        Map<String, Object> shipment = new HashMap<>();
        
        // Create ConsolCostLine data
        List<Map<String, Object>> consolCostLine = new ArrayList<>();
        Map<String, Object> costLineItem = new HashMap<>();
        costLineItem.put("ChargeCode", Map.of("Code", "FREIGHT", "Description", "Freight Charge"));
        costLineItem.put("OutstandingAmount", "1000.00");
        costLineItem.put("OutstandingGSTVATAmount", "100.00");
        costLineItem.put("CostAPInvoiceNumber", transactionNo);
        // Add required fields for AP processing
        costLineItem.put("CostOSAmount", "1000.00");
        costLineItem.put("CostOSGSTVATAmount", "100.00");
        costLineItem.put("CostLocalAmount", "1100.00");
        costLineItem.put("CostOSCurrency", Map.of("Code", "USD"));
        costLineItem.put("CostExchangeRate", "1.0");
        consolCostLine.add(costLineItem);
        shipment.put("ConsolCostLine", consolCostLine);
        
        shipments.add(shipment);
        
        // Create mock CwAccountTransactionInfo
        CwAccountTransactionInfo cwTransactionInfo = new CwAccountTransactionInfo();
        cwTransactionInfo.setUsed(false);
        cwTransactionInfo.setChargeCode("FREIGHT");
        cwTransactionInfo.setInvoiceNo(transactionNo);
        cwTransactionInfo.setAccountTransactionLinesPk(UUID.randomUUID());
        cwTransactionInfo.setAccountChargeCodePk(UUID.randomUUID());
        cwTransactionInfoList.add(cwTransactionInfo);
        
        // Mock routing service response
        when(transactionRoutingService.shouldSendToExternalSystem(eq(ledger), eq(transactionType), eq(transactionNo)))
            .thenReturn(true);
        
        // When: Processing charge lines with AP-INV transaction type
        chargeLineProcessor.handleChargeLineInShipment(
            requestBeanList, linesBeanList, cwTransactionInfoList, shipments,
            transactionInfoRequestBean, headerBean, ledger, transactionType,
            transactionNo, refNoType, "0", Optional.empty(), new ArrayList<>()
        );
        
        // Then: Verify that the routing service was called with correct transaction type "INV"
        ArgumentCaptor<String> transactionTypeCaptor = ArgumentCaptor.forClass(String.class);
        verify(transactionRoutingService).shouldSendToExternalSystem(
            eq(ledger), 
            transactionTypeCaptor.capture(), 
            eq(transactionNo)
        );
        
        assertEquals("INV", transactionTypeCaptor.getValue(), 
            "TransactionType should be 'INV' for AP-INV transactions");
    }
}