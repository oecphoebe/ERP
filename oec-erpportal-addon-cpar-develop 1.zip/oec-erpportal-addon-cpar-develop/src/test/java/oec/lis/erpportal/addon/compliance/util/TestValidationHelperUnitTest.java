package oec.lis.erpportal.addon.compliance.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;

/**
 * Unit test for TestValidationHelper to verify our implemented methods.
 * This test uses mocks to avoid Spring context issues.
 */
@ExtendWith(MockitoExtension.class)
class TestValidationHelperUnitTest {

    @Mock
    private AtAccountTransactionTableService transactionService;

    private TestValidationHelper validationHelper;

    @BeforeEach
    void setUp() {
        validationHelper = new TestValidationHelper();
        // Use reflection to inject the mock service
        try {
            java.lang.reflect.Field field = TestValidationHelper.class.getDeclaredField("transactionService");
            field.setAccessible(true);
            field.set(validationHelper, transactionService);
        } catch (Exception e) {
            throw new RuntimeException("Failed to inject mock", e);
        }
    }

    @Test
    void testGetHeaderPK_ReturnsNullForNonExistentTransaction() {
        // Arrange
        String transactionNo = "NON_EXISTENT";
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of());

        // Act
        Long result = validationHelper.getHeaderPK(transactionNo);

        // Assert
        assertNull(result, "Should return null for non-existent transaction");
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testGetHeaderPK_ReturnsHashCodeForExistingTransaction() {
        // Arrange
        String transactionNo = "EXISTING_TXN";
        UUID testId = UUID.randomUUID();
        AtAccountTransactionHeaderBean mockHeader = new AtAccountTransactionHeaderBean();
        mockHeader.setAcctTransHeaderId(testId);
        
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of(mockHeader));

        // Act
        Long result = validationHelper.getHeaderPK(transactionNo);

        // Assert
        assertNotNull(result, "Should return non-null for existing transaction");
        assertEquals((long) testId.hashCode(), result.longValue(), "Should return UUID hashCode as Long");
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testGetLineCount_ReturnsZeroForNonExistentTransaction() {
        // Arrange
        String transactionNo = "NON_EXISTENT";
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of());

        // Act
        int result = validationHelper.getLineCount(transactionNo);

        // Assert
        assertEquals(0, result, "Should return 0 for non-existent transaction");
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testGetLineCount_ReturnsCorrectCountForExistingTransaction() {
        // Arrange
        String transactionNo = "EXISTING_TXN";
        UUID testId = UUID.randomUUID();
        AtAccountTransactionHeaderBean mockHeader = new AtAccountTransactionHeaderBean();
        mockHeader.setAcctTransHeaderId(testId);
        
        AtAccountTransactionLinesBean line1 = new AtAccountTransactionLinesBean();
        AtAccountTransactionLinesBean line2 = new AtAccountTransactionLinesBean();
        
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of(mockHeader));
        when(transactionService.findLinesByHeaderPk((long) testId.hashCode()))
            .thenReturn(List.of(line1, line2));

        // Act
        int result = validationHelper.getLineCount(transactionNo);

        // Assert
        assertEquals(2, result, "Should return correct line count");
        verify(transactionService, times(2)).findHeadersByTransactionNo(transactionNo); // Called by both getLineCount and getHeaderPK
        verify(transactionService).findLinesByHeaderPk((long) testId.hashCode());
    }

    @Test
    void testValidateNoDuplicates_PassesForNonExistentTransaction() {
        // Arrange
        String transactionNo = "NON_EXISTENT";
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of());

        // Act & Assert
        assertDoesNotThrow(() -> {
            validationHelper.validateNoDuplicates(transactionNo);
        }, "Should not throw for non-existent transaction");
        
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testValidateNoDuplicates_PassesForSingleTransaction() {
        // Arrange
        String transactionNo = "SINGLE_TXN";
        AtAccountTransactionHeaderBean mockHeader = new AtAccountTransactionHeaderBean();
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of(mockHeader));

        // Act & Assert
        assertDoesNotThrow(() -> {
            validationHelper.validateNoDuplicates(transactionNo);
        }, "Should not throw for single transaction");
        
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testValidateNoDuplicates_FailsForDuplicateTransactions() {
        // Arrange
        String transactionNo = "DUPLICATE_TXN";
        AtAccountTransactionHeaderBean header1 = new AtAccountTransactionHeaderBean();
        AtAccountTransactionHeaderBean header2 = new AtAccountTransactionHeaderBean();
        when(transactionService.findHeadersByTransactionNo(transactionNo))
            .thenReturn(List.of(header1, header2));

        // Act & Assert
        AssertionError exception = assertThrows(AssertionError.class, () -> {
            validationHelper.validateNoDuplicates(transactionNo);
        }, "Should throw for duplicate transactions");
        
        assertTrue(exception.getMessage().contains("should not have duplicates"), 
            "Exception message should indicate duplicates found");
        verify(transactionService).findHeadersByTransactionNo(transactionNo);
    }

    @Test
    void testValidateResponseContent_PassesForValidJson() {
        // Arrange
        String validJson = "{\"message\":\"test\",\"status\":\"success\"}";
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();

        // Act & Assert
        assertDoesNotThrow(() -> {
            validationHelper.validateResponseContent(validJson, testData);
        }, "Should not throw for valid JSON");
    }

    @Test
    void testValidateResponseContent_FailsForInvalidJson() {
        // Arrange
        String invalidJson = "{invalid json}";
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();

        // Act & Assert
        AssertionError exception = assertThrows(AssertionError.class, () -> {
            validationHelper.validateResponseContent(invalidJson, testData);
        }, "Should throw for invalid JSON");
        
        assertTrue(exception.getMessage().contains("should be valid JSON"), 
            "Exception message should indicate JSON validation failure");
    }

    @Test
    void testValidateProcessingMetrics_PassesForReasonableTime() {
        // Arrange
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();
        long processingTime = 5000L; // 5 seconds

        // Act & Assert
        assertDoesNotThrow(() -> {
            validationHelper.validateProcessingMetrics(testData, processingTime);
        }, "Should not throw for reasonable processing time");
    }

    @Test
    void testValidateProcessingMetrics_FailsForNegativeTime() {
        // Arrange
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();
        long processingTime = -1000L; // Negative time

        // Act & Assert
        AssertionError exception = assertThrows(AssertionError.class, () -> {
            validationHelper.validateProcessingMetrics(testData, processingTime);
        }, "Should throw for negative processing time");
        
        assertTrue(exception.getMessage().contains("should be non-negative"), 
            "Exception message should indicate negative time validation failure");
    }

    @Test
    void testValidateProcessingMetrics_FailsForExcessiveTime() {
        // Arrange
        ReferenceTestData testData = ReferenceTestData.builder()
            .filename("test.json")
            .expectedTransactionNo("TEST_001")
            .build();
        long processingTime = 35000L; // 35 seconds (over 30 second threshold)

        // Act & Assert
        AssertionError exception = assertThrows(AssertionError.class, () -> {
            validationHelper.validateProcessingMetrics(testData, processingTime);
        }, "Should throw for excessive processing time");
        
        assertTrue(exception.getMessage().contains("should be reasonable"), 
            "Exception message should indicate excessive time validation failure");
    }
}