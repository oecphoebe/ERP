package oec.lis.erpportal.addon.compliance.util;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;

/**
 * Mock service utilities for integration tests providing standardized mock configurations
 * and verification patterns.
 * 
 * This class centralizes common mock setups to reduce code duplication and ensure
 * consistent mock behavior across all integration tests.
 */
@Slf4j
public class MockServiceUtilities {

    /**
     * Setup BuyerInfo mock for CommonGlobalTableService.findBuyerReference()
     */
    public void setupBuyerInfoMock(CommonGlobalTableService globalTableService, String orgCode, String buyerName) {
        BuyerInfo mockBuyerInfo = new BuyerInfo();
        mockBuyerInfo.setBuyerReference(orgCode);
        mockBuyerInfo.setBuyerName(buyerName);
        
        // Mock specific organization code
        when(globalTableService.findBuyerReference(orgCode))
            .thenReturn(mockBuyerInfo);
        
        // Mock any string (fallback)
        when(globalTableService.findBuyerReference(anyString()))
            .thenReturn(mockBuyerInfo);
            
        log.debug("Setup BuyerInfo mock: orgCode={}, buyerName={}", orgCode, buyerName);
    }

    /**
     * Setup TransactionRoutingService mocks for routing decisions
     */
    public void setupTransactionRoutingMock(TransactionRoutingService routingService, String ledger, String transactionType, boolean sendToExternal) {
        when(routingService.shouldSendToExternalSystem(ledger, transactionType, anyString()))
            .thenReturn(sendToExternal);
        
        // Setup routing mode based on configuration
        String routingMode = sendToExternal ? "CONFIG" : "LEGACY";
        when(routingService.getRoutingMode()).thenReturn(routingMode);
        
        log.debug("Setup TransactionRouting mock: {}:{} -> sendExternal={}, mode={}", 
                 ledger, transactionType, sendToExternal, routingMode);
    }

    /**
     * Setup standard AP Invoice routing (database only, legacy mode)
     * Note: If routingService is null, this method does nothing (for testing with real routing service)
     */
    public void setupAPInvoiceRouting(TransactionRoutingService routingService, String transactionPrefix) {
        if (routingService != null && mockingDetails(routingService).isMock()) {
            when(routingService.shouldSendToExternalSystem("AP", "INV", transactionPrefix)).thenReturn(false);
            when(routingService.getRoutingMode()).thenReturn("LEGACY");
            log.debug("Setup AP Invoice routing mock: database only, legacy mode for {}", transactionPrefix);
        } else {
            log.debug("Using real AP Invoice routing service for {}", transactionPrefix);
        }
    }

    /**
     * Setup standard AR Invoice routing (send to external system)
     * Note: If routingService is null or not a mock, this method does nothing (for testing with real routing service)
     */
    public void setupARInvoiceRouting(TransactionRoutingService routingService, String transactionPrefix) {
        if (routingService != null && mockingDetails(routingService).isMock()) {
            when(routingService.shouldSendToExternalSystem("AR", "INV", transactionPrefix)).thenReturn(true);
            when(routingService.getRoutingMode()).thenReturn("CONFIG");
            log.debug("Setup AR Invoice routing mock: send to external, config mode for {}", transactionPrefix);
        } else {
            log.debug("Using real AR Invoice routing service for {}", transactionPrefix);
        }
    }

    /**
     * Setup standard AP Credit Note routing (send to external system - new capability)
     * Note: If routingService is null, this method does nothing (for testing with real routing service)
     */
    public void setupAPCreditNoteRouting(TransactionRoutingService routingService, String transactionPrefix) {
        if (routingService != null && mockingDetails(routingService).isMock()) {
            when(routingService.shouldSendToExternalSystem("AP", "CRD", transactionPrefix)).thenReturn(true);
            when(routingService.getRoutingMode()).thenReturn("CONFIG");
            log.debug("Setup AP Credit Note routing mock: send to external, config mode for {}", transactionPrefix);
        } else {
            log.debug("Using real AP Credit Note routing service for {}", transactionPrefix);
        }
    }

    /**
     * Setup standard AR Credit Note routing (send to external system)
     */
    public void setupARCreditNoteRouting(TransactionRoutingService routingService, String transactionPrefix) {
        when(routingService.shouldSendToExternalSystem("AR", "CRD", transactionPrefix)).thenReturn(true);
        when(routingService.getRoutingMode()).thenReturn("CONFIG");
        log.debug("Setup AR Credit Note routing: send to external, config mode for {}", transactionPrefix);
    }

    /**
     * Verify that GlobalTableService.findBuyerReference() was called with expected parameters
     */
    public void verifyBuyerReferenceCall(CommonGlobalTableService globalTableService, String expectedOrgCode, int expectedTimes) {
        verify(globalTableService, times(expectedTimes)).findBuyerReference(expectedOrgCode);
        log.debug("Verified GlobalTableService.findBuyerReference('{}') called {} times", expectedOrgCode, expectedTimes);
    }

    /**
     * Verify that TransactionRoutingService.shouldSendToExternalSystem() was called with expected parameters
     * Note: Only verifies if the service is a mock
     */
    public void verifyRoutingServiceCall(TransactionRoutingService routingService, String ledger, String transactionType, String transactionPrefix, int expectedTimes) {
        if (routingService != null && mockingDetails(routingService).isMock()) {
            verify(routingService, times(expectedTimes)).shouldSendToExternalSystem(ledger, transactionType, transactionPrefix);
            log.debug("Verified TransactionRoutingService.shouldSendToExternalSystem('{}', '{}', '{}') called {} times", 
                     ledger, transactionType, transactionPrefix, expectedTimes);
        } else {
            log.debug("Cannot verify real TransactionRoutingService calls - using real service");
        }
    }

    /**
     * Verify that routing mode was checked
     * Note: Only verifies if the service is a mock
     */
    public void verifyRoutingModeCall(TransactionRoutingService routingService, int expectedTimes) {
        if (routingService != null && mockingDetails(routingService).isMock()) {
            verify(routingService, atLeast(expectedTimes)).getRoutingMode();
            log.debug("Verified TransactionRoutingService.getRoutingMode() called at least {} times", expectedTimes);
        } else {
            log.debug("Cannot verify real TransactionRoutingService mode calls - using real service");
        }
    }

    /**
     * Verify all service interactions with flexible parameters
     */
    public void verifyServiceInteractions(Object... mocks) {
        for (Object mock : mocks) {
            if (mock instanceof CommonGlobalTableService) {
                // Check if GlobalTableService was called (might not be called for NONJOB transactions)
                if (mockingDetails(mock).getInvocations().isEmpty()) {
                    log.warn("⚠️ GlobalTableService.findBuyerReference() was NOT called - might be expected for NONJOB transactions");
                } else {
                    log.info("✅ GlobalTableService.findBuyerReference() was called");
                }
            } else if (mock instanceof TransactionRoutingService) {
                // TransactionRoutingService should always be called
                verify((TransactionRoutingService) mock, atLeastOnce()).shouldSendToExternalSystem(anyString(), anyString(), anyString());
                log.info("✅ TransactionRoutingService interactions verified");
            }
        }
    }

    /**
     * Reset all mocks to clean state
     */
    public void resetAllMocks(Object... mocks) {
        Arrays.stream(mocks).forEach(mock -> {
            if (mockingDetails(mock).isMock()) {
                reset(mock);
                log.debug("Reset mock: {}", mock.getClass().getSimpleName());
            }
        });
    }

    /**
     * Check if a service was called (any method)
     */
    public boolean wasServiceCalled(Object mock) {
        return !mockingDetails(mock).getInvocations().isEmpty();
    }

    /**
     * Get the number of times any method was called on a mock
     */
    public int getInvocationCount(Object mock) {
        return mockingDetails(mock).getInvocations().size();
    }

    /**
     * Setup multiple buyer references for different organization codes
     */
    public void setupMultipleBuyerInfoMocks(CommonGlobalTableService globalTableService, String[][] orgCodeBuyerPairs) {
        for (String[] pair : orgCodeBuyerPairs) {
            if (pair.length >= 2) {
                setupBuyerInfoMock(globalTableService, pair[0], pair[1]);
            }
        }
        log.debug("Setup multiple BuyerInfo mocks for {} organizations", orgCodeBuyerPairs.length);
    }

    /**
     * Setup comprehensive routing configuration for all transaction types
     */
    public void setupComprehensiveRouting(TransactionRoutingService routingService) {
        // AR Invoice - Send to external system
        when(routingService.shouldSendToExternalSystem("AR", "INV", anyString())).thenReturn(true);
        
        // AR Credit Note - Send to external system  
        when(routingService.shouldSendToExternalSystem("AR", "CRD", anyString())).thenReturn(true);
        
        // AP Invoice - Database only (not sent to external)
        when(routingService.shouldSendToExternalSystem("AP", "INV", anyString())).thenReturn(false);
        
        // AP Credit Note - Send to external system (NEW CAPABILITY)
        when(routingService.shouldSendToExternalSystem("AP", "CRD", anyString())).thenReturn(true);
        
        // Default routing mode
        when(routingService.getRoutingMode()).thenReturn("STANDARD");
        
        log.debug("Setup comprehensive routing configuration for all transaction types");
    }

    /**
     * Log mock interaction summary for debugging
     */
    public void logMockInteractionSummary(Object... mocks) {
        log.info("=== MOCK INTERACTION SUMMARY ===");
        for (Object mock : mocks) {
            String className = mock.getClass().getSimpleName();
            int invocations = getInvocationCount(mock);
            boolean wasCalled = wasServiceCalled(mock);
            
            log.info("Mock {}: {} invocations, called: {}", className, invocations, wasCalled);
            
            if (!wasCalled) {
                log.warn("⚠️ {} was not called during test execution", className);
            }
        }
        log.info("=== MOCK SUMMARY COMPLETE ===");
    }
}