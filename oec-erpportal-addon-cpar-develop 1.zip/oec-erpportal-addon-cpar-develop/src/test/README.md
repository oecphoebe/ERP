# ARTransaction Endpoint Integration Tests

## Overview

This test suite provides comprehensive integration testing for the `/external/v1/ARTransaction` endpoint using real-world transaction data and TestContainers for database validation.

## Test Architecture

### Key Components

- **ARTransactionEndpointRealDataIntegrationTest**: Main test class with TestContainers setup
- **ReferenceDataLoader**: Utility for loading and processing reference JSON files
- **TestValidationHelper**: Comprehensive validation methods for database, Kafka, and API logging
- **TestContainers**: PostgreSQL 15.9 and SQL Server 2022 containers for realistic database testing

### Test Data Sources

- **Reference Data**: Real-world transaction JSON files in `reference/` directory
  - `AP_INV_*.json` - AP Invoice transactions
  - `AP_CRD_*.json` - AP Credit Note transactions
  - Extensible for future transaction types

## Test Scenarios

### Core Functionality Tests

1. **Parameterized Reference Data Tests** (`testTransactionProcessingWithRealData`)
   - Processes all files in `reference/` directory
   - Validates complete transaction flow: JSON → Database persistence → Kafka routing
   - Verifies routing decisions (save-only vs save-and-send-external)

2. **AP Transaction Processing** (`testAPInvoiceTransaction_SaveOnly`)
   - Validates AP transactions save to database but don't send Kafka messages
   - Tests legacy mode routing behavior

3. **Collision Handling** (`testShipmentCollisionHandling`)
   - Tests duplicate transaction processing
   - Validates collision detection and prevention
   - Ensures no duplicate database records

### Routing Logic Tests

4. **Legacy Mode Routing**
   - AR transactions → Save to DB + send to Kafka
   - AP transactions → Save to DB only

5. **Config Mode Routing** (`testConfigModeRouting`)
   - Configurable routing rules
   - Different behavior from legacy mode

### Edge Cases and Error Handling

6. **Invalid Payload Handling** (`testInvalidPayloadHandling`)
   - Tests malformed JSON structure
   - Validates graceful error responses

7. **Missing Fields** (`testTransactionWithMissingFields`)
   - Tests minimal transaction payloads
   - Validates robust field handling

8. **Error Recovery** (`testErrorRecoveryMechanism`)
   - Simulates temporary service failures
   - Tests retry and recovery mechanisms

9. **Performance Testing** (`testLargeTransactionProcessing`)
   - Tests complex transactions with multiple line items
   - Validates processing time metrics

## Database Validation

### PostgreSQL (SOPL Database)
- **at_account_transaction_header**: Transaction master records
- **at_account_transaction_lines**: Transaction detail records  
- **at_shipment_info**: Shipment information with collision handling
- **api_log**: API request/response audit trail
- **cp_compliance**: Compliance tracking records

### SQL Server (Cargowise Database)
- **AccTransactionHeader**: Source transaction headers
- **AccTransactionLines**: Source transaction lines
- **AccChargeCode**: Charge code lookups
- **JobHeader**: Job number references
- **OrgHeader**: Organization code lookups

## Running the Tests

### Prerequisites

1. **Docker**: Required for TestContainers
2. **Java 21**: Required for Spring Boot 3.4.3
3. **Maven**: For test execution
4. **Reference Data**: JSON files must be present in `reference/` directory

### Test Execution Commands

```bash
# Run all integration tests
./mvnw test -Dtest=ARTransactionEndpointRealDataIntegrationTest

# Run specific test method
./mvnw test -Dtest=ARTransactionEndpointRealDataIntegrationTest#testAPInvoiceTransaction_SaveOnly

# Run tests with debug logging
./mvnw test -Dtest=ARTransactionEndpointRealDataIntegrationTest -Dlogging.level.oec.lis.erpportal.addon.compliance=DEBUG

# Run tests with container logs
./mvnw test -Dtest=ARTransactionEndpointRealDataIntegrationTest -Dtestcontainers.reuse.enable=false
```

### Test Configuration

Key test properties in `application-test.properties`:
```properties
spring.profiles.active=test
transaction.routing.enable-legacy-mode=true
logging.level.oec.lis.erpportal.addon.compliance=DEBUG
```

## Test Data Management

### Adding New Reference Data

1. Add new JSON files to `reference/` directory
2. Follow naming convention: `{LEDGER}_{TYPE}_{TRANSACTION_NO}.json`
3. Tests will automatically include new files via `@ParameterizedTest`

### Reference Data Format

Expected JSON structure:
```json
{
    "Body": {
        "UniversalTransaction": {
            "TransactionInfo": {
                "Ledger": "AP|AR",
                "TransactionType": "INV|CRD",
                "Number": "TRANSACTION_NUMBER",
                "Job": {
                    "Key": "JOB_NUMBER"
                },
                "DataContext": {
                    "EventType": {
                        "Code": "ADD|EDT"
                    }
                },
                "PostingJournalCollection": {
                    "PostingJournal": [...]
                }
            }
        }
    }
}
```

## Validation Framework

### Database Validation
- **Header Persistence**: Validates transaction header fields
- **Lines Persistence**: Validates transaction line items
- **Shipment Persistence**: Validates shipment information
- **Duplicate Detection**: Ensures no duplicate records
- **Collision Handling**: Tests concurrent processing scenarios

### Kafka Validation
- **Message Sending**: Verifies RetryRecord sent to correct topic
- **Routing Decisions**: Validates legacy vs config mode behavior
- **Message Content**: Validates Kafka payload structure

### API Logging Validation  
- **Audit Trail**: Verifies APILog records created
- **Status Tracking**: Validates RECEIVED → DONE → completion flow
- **Error Logging**: Validates error scenarios properly logged

## Mock Configuration

### External Dependencies
- **KafkaTemplate**: Mocked to verify message sending without actual Kafka
- **GlobalTableService**: Mocked for buyer reference resolution
- **TransactionRoutingService**: Configurable for testing routing modes

### Test Containers
- **PostgreSQL 15.9**: Real database for SOPL schema validation
- **SQL Server 2022**: Real database for Cargowise integration testing
- **Isolated Containers**: Each test class gets fresh database instances

## Test Reporting

### Success Criteria
- All reference files processed without errors
- Database records match expected transaction data
- Kafka messages sent/not sent according to routing rules
- API logs created with correct status progression
- No duplicate records in database
- Performance within acceptable limits (< 30 seconds per transaction)

### Failure Analysis
- Check container logs for database connection issues
- Verify reference data JSON structure
- Validate mock configurations match test expectations
- Review TestContainer startup logs for setup issues

## Troubleshooting

### Common Issues

1. **Container Startup Failures**
   ```bash
   # Check Docker daemon
   docker info
   
   # Clean up old containers
   docker system prune -a
   ```

2. **Reference Data Not Found**
   ```bash
   # Verify files exist
   ls -la reference/
   
   # Check file permissions
   chmod 644 reference/*.json
   ```

3. **Database Schema Issues**
   ```bash
   # Check schema files
   cat src/test/resources/test-schema-postgresql.sql
   cat src/test/resources/test-schema-sqlserver.sql
   ```

4. **Mock Configuration Problems**
   - Verify @MockitoBean annotations are present
   - Check mock setup in @BeforeEach methods
   - Ensure mock returns match expected data types

### Performance Optimization

1. **Container Reuse** (for development):
   ```properties
   testcontainers.reuse.enable=true
   ```

2. **Parallel Execution**:
   ```xml
   <plugin>
       <groupId>org.apache.maven.plugins</groupId>
       <artifactId>maven-surefire-plugin</artifactId>
       <configuration>
           <parallel>classes</parallel>
           <threadCount>4</threadCount>
       </configuration>
   </plugin>
   ```

## Extension Points

### Adding New Test Scenarios
1. Create new test methods in `ARTransactionEndpointRealDataIntegrationTest`
2. Use `TestValidationHelper` for consistent validation patterns
3. Add new reference data files as needed

### Custom Validation Logic
1. Extend `TestValidationHelper` with new validation methods
2. Create specialized validation classes for complex scenarios
3. Add custom assertions in test methods

### New Transaction Types
1. Add new JSON files to `reference/` directory
2. Update `ReferenceTestData.fromFilename()` if needed
3. Extend routing logic tests for new transaction types

This comprehensive test suite ensures the `/external/v1/ARTransaction` endpoint correctly handles real-world transaction data, maintains database integrity, and makes proper routing decisions for both save-only and save-and-send-external scenarios.