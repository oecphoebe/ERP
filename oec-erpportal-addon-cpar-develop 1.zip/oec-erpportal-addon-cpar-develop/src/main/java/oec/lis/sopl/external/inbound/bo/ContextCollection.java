package oec.lis.sopl.external.inbound.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.TypeValue;

/**
 * Context Collection
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class ContextCollection {
	
	@JsonProperty("Context")
	private List<TypeValue> ContextList;

}
