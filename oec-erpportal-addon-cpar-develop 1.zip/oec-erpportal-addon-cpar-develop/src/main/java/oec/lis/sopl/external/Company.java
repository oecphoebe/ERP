package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Company
 * 
 * @author Frank Yeh
 * @Date 2022-02-27
 */
@Data
public class Company {

	@JsonProperty("Code")
	private String code;

	@JsonProperty("Country")
	private CodeName country;

	@JsonProperty("Name")
	private String name;

}
