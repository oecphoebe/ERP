package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * TypeKey
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class TypeKey {

	@JsonProperty("Type")
	private String type;

	@JsonProperty("Key")
	private String key;
}
