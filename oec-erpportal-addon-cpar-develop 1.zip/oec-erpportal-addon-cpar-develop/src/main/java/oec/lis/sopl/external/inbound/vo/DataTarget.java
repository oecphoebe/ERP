package oec.lis.sopl.external.inbound.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * Data target
 * 
 * @author Frank Yeh
 * @Date 2023-3-5
 */
@Data
public class DataTarget {

	@JsonProperty("Type")
	private String type;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("Key")
	private String key;
}
