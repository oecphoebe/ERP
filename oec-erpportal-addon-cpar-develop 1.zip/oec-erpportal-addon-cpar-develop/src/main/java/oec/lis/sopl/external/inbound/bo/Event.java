package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Event
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class Event {

	@JsonProperty("DataContext")
	private DataContext dataContext;

	@JsonProperty("EventType")
	private String eventType;

	@JsonProperty("ContextCollection")
	private ContextCollection contextCollection;

}
