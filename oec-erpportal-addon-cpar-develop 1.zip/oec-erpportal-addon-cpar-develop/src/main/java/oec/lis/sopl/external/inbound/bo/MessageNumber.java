package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * MessageNumber
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class MessageNumber {

	@JsonProperty("Value")
	private String value;

	@JsonProperty("Type")
	private String type;

}
