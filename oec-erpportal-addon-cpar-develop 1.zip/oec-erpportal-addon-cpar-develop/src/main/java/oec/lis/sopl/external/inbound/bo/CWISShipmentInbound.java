package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * CWIS Shipment inbound
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class CWISShipmentInbound {

	@JsonProperty("TransactionId")
	private String transactionId;

	@JsonProperty("UniversalResponse")
	private UniversalResponse universalResponse;

}
