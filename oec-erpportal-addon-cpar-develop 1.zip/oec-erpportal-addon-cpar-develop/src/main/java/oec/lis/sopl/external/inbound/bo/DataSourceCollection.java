package oec.lis.sopl.external.inbound.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.TypeKey;

/**
 * DataSource collection
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class DataSourceCollection {

	@JsonProperty("DataSource")
	private List<TypeKey> dataSourceList;

}
