package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.Company;

/**
 * DataContext
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class DataContext {

	@JsonProperty("DataSourceCollection")
	private DataSourceCollection dataSourceCollection;

	@JsonProperty("Company")
	private Company company;

}
