package oec.lis.sopl.common.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonRestApiResponse {

    @Schema(description = "HTTP Status code", required = true)
    private String status = "200"; // 200: Success

    @Schema(description = "伺服器處理完成後的回覆內容", required = false)
    private List<String> msg = new ArrayList<>();
    
    @Schema(description = "Exec Time", required = false)
	private long execTime;

}
