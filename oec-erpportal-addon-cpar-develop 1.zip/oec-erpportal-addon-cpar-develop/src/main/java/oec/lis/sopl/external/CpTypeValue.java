package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * TypeValue
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class CpTypeValue {

	@JsonProperty("Type")
	private String type;

	@JsonProperty("Value")
	private String value;

}
