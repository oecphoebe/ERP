package oec.lis.sopl.external.inbound.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.CpTypeValue;

/**
 * Event view object (API12)
 * 
 * @author Teddy 
 * @Date 2024-9-12
 */
@Data
public class AdditionalFieldsToUpdateCollection {

	@JsonProperty("AdditionalFieldsToUpdate")
	private List<CpTypeValue> AdditionalFieldsToUpdateList;

}
	