package oec.lis.sopl.external.outbound.bo;

import java.util.List;

import lombok.Data;

/**
 * No info (Shipment No & Consol No)
 * 
 * @author Frank Yeh
 * @Date 2023-7-13
 */
@Data
public class NoInfo {

	/**
	 * Consol No
	 */
	private String consolNo;

	/**
	 * Shipment No
	 */
	private String masterShipmentNo;

	/**
	 * (1*Consol/N*Shipment) Shipment No list
	 */
	private List<String> shipmentNoList;

}
