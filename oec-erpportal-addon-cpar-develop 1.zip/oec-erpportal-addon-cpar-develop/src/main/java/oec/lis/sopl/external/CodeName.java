package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * Code and name
 * 
 * @author Frank Yeh
 * @Date 2022-02-27
 */
@Data
public class CodeName {

	@JsonProperty("Code")
	private String code;

	@JsonProperty("Name")
	@JsonInclude(Include.NON_NULL)
	private String name;
}
