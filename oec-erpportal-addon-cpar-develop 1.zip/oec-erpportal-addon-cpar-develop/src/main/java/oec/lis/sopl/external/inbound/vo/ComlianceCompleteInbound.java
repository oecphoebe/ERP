package oec.lis.sopl.external.inbound.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * API12 CP complete inbound
 * 
 * @author Teddy Meng
 * @Date 2023-5-1
 */
@Data
@NoArgsConstructor
public class ComlianceCompleteInbound {

	@JsonProperty("UniversalEvent")
	private UniversalEvent universalEvent;
}
