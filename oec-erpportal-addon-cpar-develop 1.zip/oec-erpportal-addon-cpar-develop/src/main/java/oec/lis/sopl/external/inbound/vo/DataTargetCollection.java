package oec.lis.sopl.external.inbound.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Data target collection
 * 
 * @author Frank Yeh
 * @Date 2023-3-5
 */
@Data
public class DataTargetCollection {

	@JsonProperty("DataTarget")
	private List<DataTarget> dataTargetList;

}
