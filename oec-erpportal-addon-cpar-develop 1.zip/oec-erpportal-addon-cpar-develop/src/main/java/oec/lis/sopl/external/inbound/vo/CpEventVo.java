package oec.lis.sopl.external.inbound.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event view object (API12)
 * 
 * @author Teddy 
 * @Date 2024-9-12
 */
@Data
@NoArgsConstructor
public class CpEventVo {

	@JsonProperty("DataContext")
	private InboundDataContext dataContext;

	@JsonProperty("EventType")
	private String eventType;
	
	@JsonProperty("EventTime")
	private String eventTime;
	
	@JsonProperty("IsEstimate")
	private String isEstimate;
	
	@JsonProperty("AdditionalFieldsToUpdateCollection")
	private AdditionalFieldsToUpdateCollection additionalFieldsToUpdateCollection;

}
