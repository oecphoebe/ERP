package oec.lis.sopl.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.extern.apachecommons.CommonsLog;

/**
 * Json Utils
 * 
 * @author Frank Yeh, Yinchao Tseng
 * @Date 2023-01-27
 * @Date 2025-05-02
 */
@CommonsLog
public final class JsonUtils {

	private final static ObjectMapper objectMapper = new ObjectMapper();
	private final static ObjectMapper objectMapperWithJavaTimeSupport = new ObjectMapper()
			.registerModule(new JavaTimeModule())
			.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

	/**
	 * Get json from object
	 * 
	 * @param object object
	 * @return json Object's json
	 */
	public static String getJson(final Object object) {
		String json = "";
		try {
			json = objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			log.error("e:" + e);
		}
		return json;
	}

	/**
	 *  Get formatted json from object
	 *  
	 * @param object object object
	 * @return json Object's json
	 */
	public static String getFormattedJson(final Object object) {
		String json = "";
		try {
			json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (JsonProcessingException e) {
			log.error("e:" + e);
		}
		return json;
	}

	/**
	 * Get object from json string
	 * 
	 * @param jsonString  Json string
	 * @param targetClass Target class
	 * @return object Object
	 */
	public static Object getObject(final String jsonString, final Class<?> targetClass) {
		Object object = null;
		try {
			object = objectMapper.readValue(jsonString, targetClass);
		} catch (Exception e) {
			log.error("e:" + e);
		}
		return object;
	}

	/**
	 * Print object's json content
	 * 
	 * @param object object
	 */
	public static void print(final Object object) {
		try {
			final String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
			log.info(json);
		} catch (JsonProcessingException e) {
			log.error("e:" + e);
		}
	}

	public static void printWithJavaTimeSupport(final Object object) {
		try {
			final String json = objectMapperWithJavaTimeSupport.writerWithDefaultPrettyPrinter().writeValueAsString(object);
			log.info(json);
		} catch (JsonProcessingException e) {
			log.error("e:" + e);
		}
	}

}
