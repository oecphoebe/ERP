package oec.lis.sopl.external.inbound.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * API12 CP complete inbound
 * 
 * @author Teddy Meng
 * @Date 2024-9-12
 */
@Data
@NoArgsConstructor
public class UniversalEvent {

	@JsonProperty("Event")
	private CpEventVo eventVo;
}
