package oec.lis.sopl.external.inbound.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * MessageNumberCollection
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class MessageNumberCollection {

	@JsonProperty("MessageNumber")
	private List<MessageNumber> messageNumberList;

}
