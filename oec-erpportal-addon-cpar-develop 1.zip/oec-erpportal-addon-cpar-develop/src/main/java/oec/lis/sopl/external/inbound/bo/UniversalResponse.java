package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Universal response
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class UniversalResponse {

	@JsonProperty("Xmlns")
	private String xmlns;

	@JsonProperty("Version")
	private String version;

	@JsonProperty("Status")
	private String status;

	@JsonProperty("Data")
	private UData data;
	
	@JsonProperty("ProcessingLog")
	private String processingLog;
	
	@JsonProperty("MessageNumberCollection")
	private MessageNumberCollection messageNumberCollection;

}
