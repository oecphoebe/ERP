package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Code
 * 
 * @author Frank Yeh
 * @Date 2022-02-27
 */
@Data
public class Code {
	
	@JsonProperty("Code")
	private String code;

}
