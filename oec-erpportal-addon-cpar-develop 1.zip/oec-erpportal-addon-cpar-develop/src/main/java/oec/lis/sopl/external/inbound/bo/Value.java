package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Value
 *
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class Value {

	@JsonProperty("Value")
	private String value;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("Description")
	private String description;

}
