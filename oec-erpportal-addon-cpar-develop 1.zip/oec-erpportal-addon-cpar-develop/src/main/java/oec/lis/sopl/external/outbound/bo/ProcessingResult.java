package oec.lis.sopl.external.outbound.bo;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * Processing result (API01&03/Redo)
 * 
 * @author Frank Yeh
 * @Date 2023-7-16
 */
@Data
public class ProcessingResult {
	
	@JsonInclude(Include.NON_NULL)
	private String reason;

	private UUID actionId;

	private UUID apiId;
	
	@JsonInclude(Include.NON_NULL)
	private String apiName;

	@JsonInclude(Include.NON_NULL)
	private String apiStatus;

	@JsonInclude(Include.NON_NULL)
	private NoInfo noInfo;

	@JsonInclude(Include.NON_NULL)
	private String processingLog;

}
