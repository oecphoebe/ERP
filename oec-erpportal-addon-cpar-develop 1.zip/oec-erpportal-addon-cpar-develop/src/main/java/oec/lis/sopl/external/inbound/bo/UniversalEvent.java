package oec.lis.sopl.external.inbound.bo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Universal event
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class UniversalEvent {

	@JsonProperty("Event")
	private Event event;

	@JsonProperty("Version")
	private String version;

}
