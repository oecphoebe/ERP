package oec.lis.sopl.external.inbound.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.Code;

/**
 * Data context (API02/04/05)
 * 
 * @author Frank Yeh
 * @Date 2023-3-5
 */
@Data
public class InboundDataContext {

	@JsonProperty("DataTargetCollection")
	@JsonInclude(Include.NON_NULL)
	private DataTargetCollection dataTargetCollection;

	@JsonProperty("Company")
	@JsonInclude(Include.NON_NULL)
	private Code company;

	@JsonProperty("CodesMappedToTarget")
	@JsonInclude(Include.NON_NULL)
	private Boolean codesMappedToTarget;

	@JsonProperty("EnterpriseID")
	@JsonInclude(Include.NON_NULL)
	private String enterpriseId;

	@JsonProperty("ServerID")
	@JsonInclude(Include.NON_NULL)
	private String serverID;
}
