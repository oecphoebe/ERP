package oec.lis.sopl.external;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import oec.lis.sopl.external.inbound.bo.Value;

/**
 * TypeValue
 * 
 * @author Frank Yeh
 * @Date 2023-3-6
 */
@Data
public class TypeValue {

	@JsonProperty("Type")
	private Value type;

	@JsonProperty("Value")
	private String value;

}
