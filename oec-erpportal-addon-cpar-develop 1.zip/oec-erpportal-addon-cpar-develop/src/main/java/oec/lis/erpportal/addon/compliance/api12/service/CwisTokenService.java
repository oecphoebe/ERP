package oec.lis.erpportal.addon.compliance.api12.service;

import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api12.client.AuthClient;
import oec.lis.erpportal.addon.compliance.api12.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api12.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.model.TokenInfo;
import oec.lis.erpportal.addon.compliance.common.api.service.AbstractTokenService;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class CwisTokenService extends AbstractTokenService {

    static final String TOKEN_CACHE_KEY = "cwisApiToken";
    static final Duration TOKEN_CACHE_DURATION = Duration.ofMinutes(11520); // 8 days
    private final AuthClient authClient;

    @Value("${external.cwis.userName}")
    private String clientId;
    @Value("${external.cwis.password}")
    private String clientSecret;

    public CwisTokenService(AuthClient authClient) {
        super(TOKEN_CACHE_KEY, TOKEN_CACHE_DURATION);
        this.authClient = authClient;
    }

    // @Override
    // protected boolean isExpiringSoon(TokenInfo tokenInfo) {
    //     // Consider token as expiring if less than 2 minutes remaining
    //     Instant currentTime = Instant.now();
    //     log.debug("current time = [{}] expirtTime = [{}] seconds, isExpiringSoon=[{}]", currentTime, tokenInfo.getExpiryTime(), tokenInfo.getExpiryTime().isBefore(currentTime.plusSeconds(120)));
    //     // return currentTime.isAfter(currentTime.plusSeconds(tokenInfo.getExpiryTime() - 120));
    //     return tokenInfo.getExpiryTime().isBefore(currentTime.plusSeconds(120));
    // }

    private AuthRequest buildAuthRequest() {
        return AuthRequest.getAuthRequest(this.clientId, this.clientSecret);
    }

    @Override
    @Synchronized
    protected String refreshToken() {
        try {
            log.info("Refreshing API token");
            AuthResponse response = authClient.authenticate(buildAuthRequest());
            JsonUtils.print(response);

            TokenInfo newToken = new TokenInfo(
                response.getAccessToken(),
                Instant.now().plusSeconds(response.getExpiresIn())
            );

            tokenCache.put(TOKEN_CACHE_KEY, newToken);
            log.info("Successfully refreshed API token");
            return newToken.getToken();
        } catch (Exception e) {
            TokenInfo existingToken = tokenCache.getIfPresent(TOKEN_CACHE_KEY);
            if (existingToken != null) {
                log.warn("Failed to refresh token, using existing token as fallback", e);
                // Return existing token even if expiring soon as fallback
                return existingToken.getToken();
            }
            log.error("Failed to obtain token and no fallback available", e);
            // throw new AuthenticationFailedException("Failed to obtain token and no fallback available", e);
        }
        return null;
    }
}
