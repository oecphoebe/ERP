package oec.lis.erpportal.addon.compliance.common.kafka;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api15.client.InvoiceClient;
import oec.lis.erpportal.addon.compliance.common.api.exception.TokenExpiredException;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
@ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
public class InvoiceProcessingService {
    private final InvoiceClient invoiceClient;
    private final ApiLogService apiLogService;
    private final RetryProducerService retryProducerService;

    public InvoiceProcessingService(
        InvoiceClient invoiceClient, 
        ApiLogService apiLogService, 
        RetryProducerService retryProducerService
    ) {
        this.invoiceClient = invoiceClient;
        this.apiLogService = apiLogService;
        this.retryProducerService = retryProducerService;
    }

    // @KafkaListener(topics = "${spring.profiles.active}-compliance-topic", groupId = "${spring.profiles.active}-compliance-group")
    public void processInvoice(
        // @Header(KafkaHeaders.RECEIVED_KEY) 
        String actionIdString,
        // @Payload 
        TransactionChargeLineRequestBean model
    ) throws InvoiceOutboundFaiiledException {
        log.debug("Key = [{}] Input model for sending invoice to compliance system:", actionIdString);
        // log.debug("Input model for sending invoice to compliance system:");
        JsonUtils.print(model);

        APILog apiLog = APILog.create("CPAR-API-SendTransactionInfo", "API15");
        apiLog.setActionId(UUID.fromString(actionIdString));
        apiLog.setApiStatus("SENDING");
        apiLog.setApiParameters(JsonUtils.getJson(model));
        apiLogService.saveLog(apiLog);

        Object response = null;
        try {
            response = invoiceClient.sendInvoice(model);
            log.debug("response from compliance system:");
            JsonUtils.print(response);

            String json = new ObjectMapper().writeValueAsString(response);
            Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
    
            Integer statusCode = JsonPath.read(allDocument, "$.statusCode");
            Boolean succeeded = JsonPath.read(allDocument, "$.succeeded");
            log.debug("Response with statusCode=[{}] and succeeded=[{}]", statusCode.toString(), succeeded.toString());
    
            if (statusCode == 200 && succeeded.booleanValue()) {
                apiLog.setApiStatus("DONE");
            } else {
                apiLog.setApiStatus("ERROR");
            }
            // Borrow cwStatus field for storing the response statusCode from invoiceClient
            apiLog.setCwStatus(statusCode.toString());        

            apiLog.setApiResponse(JsonUtils.getJson(response));
            
            // Update original API14 log with external system response
            updateOriginalApiLogWithExternalResponse(UUID.fromString(actionIdString), response, statusCode, succeeded);
            
        } catch (Exception e) {
            String errorMessage = String.format("Error sending compliance data to compliance system: %s", e.getMessage());
            log.error(errorMessage);
            apiLog.setApiStatus("ERROR");
            String correctlyFormattedJsonString = String.format("{\"Exception\": \"%s\"}",
                e.getMessage()
                .replace("\\", "\\\\") // Escape backslashes first
                .replace("\"", "\\\"") // Escape double quotes
                .replace("\n", "\\n") // Escape newlines
                .replace("\r", "\\r") // Escape carriage returns
                .replace("\t", "\\t") // Escape tabs
                 // Add other escapes as needed (e.g., control characters)
            );
            apiLog.setApiResponse(correctlyFormattedJsonString);
            
            // Update original API14 log with external system error
            // updateOriginalApiLogWithExternalError(UUID.fromString(actionIdString), e);
            
            throw new InvoiceOutboundFaiiledException(errorMessage);
        } finally {
            apiLogService.saveLog(apiLog);
        }
    }
    
    /**
     * Updates the original API14 log with external system response results
     * @param actionId The action ID linking API14 and API15 logs
     * @param response External system response
     * @param statusCode Response status code
     * @param succeeded Whether the call succeeded
     */
    private void updateOriginalApiLogWithExternalResponse(UUID actionId, Object response, Integer statusCode, Boolean succeeded) {
        try {
            // Fetch the original API14 log
            List<APILog> originalLogs = apiLogService.fetchByActionId(actionId);
            APILog originalLog = findApi14Log(originalLogs);
            
            if (originalLog != null) {
                // Parse existing api_response to add external system results
                Map<String, Object> existingResponse = parseExistingApiResponse(originalLog.getApiResponse());
                
                // Add external system results
                Map<String, Object> externalSystemResult = new LinkedHashMap<>();
                externalSystemResult.put("statusCode", statusCode);
                externalSystemResult.put("succeeded", succeeded);
                externalSystemResult.put("response", response);
                externalSystemResult.put("timestamp", java.time.Instant.now().toString());
                
                existingResponse.put("externalSystemResponse", externalSystemResult);
                
                // Update the original log
                originalLog.setApiResponse(JsonUtils.getJson(existingResponse));
                apiLogService.saveLog(originalLog);
                
                log.debug("Updated original API14 log with external system response for actionId: {}", actionId);
            } else {
                log.warn("Could not find original API14 log for actionId: {}", actionId);
            }
        } catch (Exception e) {
            log.error("Error updating original API log with external response for actionId: {}", actionId, e);
        }
    }
    
    /**
     * Updates the original API14 log with external system error
     * @param actionId The action ID linking API14 and API15 logs
     * @param exception The error that occurred
     */
    private void updateOriginalApiLogWithExternalError(UUID actionId, Exception exception) {
        try {
            // Fetch the original API14 log
            List<APILog> originalLogs = apiLogService.fetchByActionId(actionId);
            APILog originalLog = findApi14Log(originalLogs);
            
            if (originalLog != null) {
                // Parse existing api_response to add external system error
                Map<String, Object> existingResponse = parseExistingApiResponse(originalLog.getApiResponse());
                
                // Add external system error
                Map<String, Object> externalSystemError = new LinkedHashMap<>();
                externalSystemError.put("error", true);
                externalSystemError.put("errorMessage", exception.getMessage());
                externalSystemError.put("errorType", exception.getClass().getSimpleName());
                externalSystemError.put("timestamp", java.time.Instant.now().toString());
                
                existingResponse.put("externalSystemResponse", externalSystemError);
                
                // Update the original log
                originalLog.setApiResponse(JsonUtils.getJson(existingResponse));
                apiLogService.saveLog(originalLog);
                
                log.debug("Updated original API14 log with external system error for actionId: {}", actionId);
            } else {
                log.warn("Could not find original API14 log for actionId: {}", actionId);
            }
        } catch (Exception e) {
            log.error("Error updating original API log with external error for actionId: {}", actionId, e);
        }
    }
    
    /**
     * Finds the API14 log from a list of logs with the same action ID
     * @param logs List of API logs
     * @return API14 log or null if not found
     */
    private APILog findApi14Log(List<APILog> logs) {
        if (logs == null) return null;
        
        return logs.stream()
            .filter(log -> "API14".equals(log.getApiName()))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Parses existing API response JSON to a Map for updating
     * @param apiResponse Existing API response (JSON string or object)
     * @return Map representation of the response
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> parseExistingApiResponse(Object apiResponse) {
        if (apiResponse == null) {
            return new LinkedHashMap<>();
        }
        
        try {
            if (apiResponse instanceof String) {
                // Parse JSON string
                return new ObjectMapper().readValue((String) apiResponse, Map.class);
            } else if (apiResponse instanceof Map) {
                // Already a Map
                return new LinkedHashMap<>((Map<String, Object>) apiResponse);
            } else {
                // Convert object to Map via JSON
                String jsonString = JsonUtils.getJson(apiResponse);
                return new ObjectMapper().readValue(jsonString, Map.class);
            }
        } catch (Exception e) {
            log.warn("Error parsing existing API response, creating new map: {}", e.getMessage());
            return new LinkedHashMap<>();
        }
    }
}
