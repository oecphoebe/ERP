package oec.lis.erpportal.addon.compliance.api18.service;

import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api18.client.AuthClient;
import oec.lis.erpportal.addon.compliance.api18.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api18.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.model.TokenInfo;
import oec.lis.erpportal.addon.compliance.common.api.service.AbstractTokenService;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class ErpPortalTokenService extends AbstractTokenService {

    static final String TOKEN_CACHE_KEY = "erpPortalApiToken";
    static final Duration TOKEN_CACHE_DURATION = Duration.ofMinutes(4);
    private final AuthClient authClient;

    @Value("${external.erpportal.client-id}")
    private String clientId;
    @Value("${external.erpportal.client-secret}")
    private String clientSecret;

    public ErpPortalTokenService(AuthClient authClient) {
        super(TOKEN_CACHE_KEY, TOKEN_CACHE_DURATION);
        this.authClient = authClient;
    }

    private AuthRequest buildAuthRequest() {
        return AuthRequest.getAuthRequest(this.clientId, this.clientSecret);
    }

    @Override
    @Synchronized
    protected String refreshToken() {
        try {
            log.info("Refreshing API token");
            AuthResponse response = authClient.authenticate(buildAuthRequest());
            JsonUtils.print(response);

            TokenInfo newToken = new TokenInfo(
                response.getAccessToken(),
                Instant.now().plusSeconds(response.getExpiresIn())
            );

            tokenCache.put(TOKEN_CACHE_KEY, newToken);
            log.info("Successfully refreshed API token");
            return newToken.getToken();
        } catch (Exception e) {
            TokenInfo existingToken = tokenCache.getIfPresent(TOKEN_CACHE_KEY);
            if (existingToken != null) {
                log.warn("Failed to refresh token, using existing token as fallback", e);
                // Return existing token even if expiring soon as fallback
                return existingToken.getToken();
            }
            log.error("Failed to obtain token and no fallback available", e);
            // throw new AuthenticationFailedException("Failed to obtain token and no fallback available", e);
        }
        return null;
    }
}
