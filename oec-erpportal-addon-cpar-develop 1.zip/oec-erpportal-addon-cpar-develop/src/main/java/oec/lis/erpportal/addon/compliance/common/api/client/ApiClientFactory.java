package oec.lis.erpportal.addon.compliance.common.api.client;

import feign.Feign;
import feign.Logger;
import feign.slf4j.Slf4jLogger;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenAuthInterceptor;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenExpirationErrorDecoder;
import oec.lis.erpportal.addon.compliance.common.api.service.TokenService;

public class ApiClientFactory {
    public static <T> T createAuthClient(Class<T> clientClass, String url, TokenService tokenService) {
        return Feign.builder()
            // .client(new OkHttpClient())
            // .encoder(new JacksonEncoder())
            // .decoder(new JacksonDecoder())
            .logger(new Slf4jLogger(clientClass))
            .logLevel(Logger.Level.BASIC)
            .target(clientClass, url);
    }
    
    public static <T> T createTokenAuthClient(Class<T> clientClass, String url, TokenService tokenService) {
        return Feign.builder()
            // .client(new OkHttpClient())
            // .encoder(new JacksonEncoder())
            // .decoder(new JacksonDecoder())
            .requestInterceptor(new TokenAuthInterceptor(tokenService))
            .errorDecoder(new TokenExpirationErrorDecoder(tokenService))
            .logger(new Slf4jLogger(clientClass))
            .logLevel(Logger.Level.BASIC)
            .target(clientClass, url);
    }
}