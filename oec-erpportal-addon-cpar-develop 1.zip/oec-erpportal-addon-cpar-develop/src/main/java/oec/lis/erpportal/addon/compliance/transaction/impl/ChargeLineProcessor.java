package oec.lis.erpportal.addon.compliance.transaction.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.PostingJournal;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionInfoRequestBean;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;

@Service
@Slf4j
public class ChargeLineProcessor {

    // Configure JsonPath to suppress exceptions
    private final Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);
    
    private final TransactionRoutingService transactionRoutingService;
    private final TransactionValidationService validationService;
    private final TransactionQueryService queryService;

    // JSON path constants for charge line processing
    private String JSON_PATH_CHARGELINE_OSAMOUNT;
    private String JSON_PATH_CHARGELINE_OSGSTVATAMOUNT;
    private String JSON_PATH_CHARGELINE_LOCALAMOUNT;
    private String JSON_PATH_CHARGELINE_OSCURRENCY_CODE;
    private String JSON_PATH_CHARGELINE_EXCHANGE_RATE;

    public ChargeLineProcessor(
        TransactionRoutingService transactionRoutingService,
        TransactionValidationService validationService,
        TransactionQueryService queryService
    ) {
        this.transactionRoutingService = transactionRoutingService;
        this.validationService = validationService;
        this.queryService = queryService;
        initializeJsonPaths();
    }

    private void initializeJsonPaths() {
        JSON_PATH_CHARGELINE_OSAMOUNT = "$.OutstandingAmount";
        JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.OutstandingGSTVATAmount";
        JSON_PATH_CHARGELINE_LOCALAMOUNT = "$.LocalAmount";
        JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.OSCurrency.Code";
        JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.ExchangeRate";
    }

    public void handleChargeLineInShipment( 
        List<TransactionChargeLineRequestBean> requestBeanList, 
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        List<Map<String, Object>> shipments,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        final String ledger, 
        final String transactionType, 
        final String transactionNo,
        final String refNoType,
        final String zeroFlag,
        final Optional<UUID> companyUUID,
        final List<PostingJournal> postingJournalList
    ) throws JsonProcessingException {

        // Set ledger-specific JSON paths for AP/AR transactions (but not NONJOB)
        if (!StringUtils.equals("NONJOB", refNoType)) {
            if (StringUtils.equals("AP", ledger)) {
                JSON_PATH_CHARGELINE_OSAMOUNT = "$.CostOSAmount";
                JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.CostOSGSTVATAmount";
                JSON_PATH_CHARGELINE_LOCALAMOUNT = "$.CostLocalAmount";
                JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.CostOSCurrency.Code";
                JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.CostExchangeRate";
            } else {
                JSON_PATH_CHARGELINE_OSAMOUNT = "$.SellOSAmount";
                JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.SellOSGSTVATAmount";
                JSON_PATH_CHARGELINE_LOCALAMOUNT = "$.SellLocalAmount";
                JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.SellOSCurrency.Code";
                JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.SellExchangeRate";
            }
        }

        // NONJOB processing: Handle charge lines without shipment context
        if (StringUtils.equals("NONJOB", refNoType)) {
            // For NONJOB from handleChargeLineInShipment, we need to convert PostingJournal back to original structure
            // This is a fallback - normally NONJOB should be processed via processNonJobTransaction with original JSON
            log.warn("NONJOB processing called from handleChargeLineInShipment - using fallback PostingJournal processing");
            handleNonJobChargeLinesFallback(requestBeanList, linesBeanList, cwTransactionInfoList,
                                  transactionInfoRequestBean, headerBean, ledger, transactionType, 
                                  transactionNo, zeroFlag, companyUUID, postingJournalList);
            return;
        }

        // AP [INV|CRD] CONSOL 僅寫入一筆 consol cost 資料到 at_account_transaction_lines
        if (StringUtils.equals("AP", ledger) && "INV_CRD".contains(transactionType) && StringUtils.equals("CONSOL", refNoType)) {
            handleConsolChargeLines(requestBeanList, linesBeanList, cwTransactionInfoList, shipments, 
                                  transactionInfoRequestBean, headerBean, ledger, transactionType);
        } else {
            handleShipmentChargeLines(requestBeanList, linesBeanList, cwTransactionInfoList, shipments,
                                    transactionInfoRequestBean, headerBean, ledger, transactionType, 
                                    transactionNo, refNoType, zeroFlag, companyUUID, postingJournalList);
        }
    }

    private void handleConsolChargeLines(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        List<Map<String, Object>> shipments,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger,
        String transactionType) throws JsonProcessingException {

        // 只寫一筆資料到 at_account_transaction_lines
        String jsonShipmentListString = new ObjectMapper().writeValueAsString(shipments);
        List<List<Map<String, Object>>> consolCostLines = JsonPath.parse(jsonShipmentListString).read("$..ConsolCostLine");
        if (consolCostLines != null && !consolCostLines.isEmpty()) {
            List<Map<String, Object>> consolCostLineArray = consolCostLines.getFirst(); // 每個 Shipment 下的 consol cost 都一樣，故取第一個
            if (consolCostLineArray != null && !consolCostLineArray.isEmpty()) {
                log.debug("consolCostLineArray.size() = [{}]", consolCostLineArray.size());
                for (Map<String, Object> costLine : consolCostLineArray) {
                    processConsolCostLine(requestBeanList, linesBeanList, cwTransactionInfoList,
                                        costLine, transactionInfoRequestBean, headerBean, ledger, transactionType);
                }
            } else {
                log.warn("handleChargeLineInShipment() consolCostLineArray is null or empty.");
            }
        } else {
            log.warn("handleChargeLineInShipment() consolCostLines is null or empty.");
        }
    }

    private void processConsolCostLine(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        Map<String, Object> costLine,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger,
        String transactionType) throws JsonProcessingException {

        String jsonChargeLine = new ObjectMapper().writeValueAsString(costLine);
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());
        
        log.debug("CONSOL cost line processing - JSON paths: osAmount={}, currency={}", 
                 JSON_PATH_CHARGELINE_OSAMOUNT, JSON_PATH_CHARGELINE_OSCURRENCY_CODE);
                 
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean(
            transactionInfoRequestBean, jsonChargeLine, ledger, 
            JSON_PATH_CHARGELINE_OSAMOUNT, JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, shouldSendToExternal);

        AtAccountTransactionLinesBean linesBean = new AtAccountTransactionLinesBean(
            headerBean, jsonChargeLine, JSON_PATH_CHARGELINE_OSAMOUNT, 
            JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, JSON_PATH_CHARGELINE_LOCALAMOUNT, 
            JSON_PATH_CHARGELINE_OSCURRENCY_CODE, JSON_PATH_CHARGELINE_EXCHANGE_RATE);
        requestBean.setItemGuid(linesBean.getAccountTransactionLinesId());
        String currentInvoiceNo = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostAPInvoiceNumber"), "");

        if (cwTransactionInfoList != null && !cwTransactionInfoList.isEmpty()) {
            String currentChargeCode = JsonPath.read(jsonChargeLine, "$.ChargeCode.Code");
            for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
                log.debug("ledger = [{}], refNoType = [CONSOL], currentChargeCode = [{}], cwTransactionInfo.getChargeCode() = [{}], currentInvoiceNo = [{}], cwTransactionInfo.getInvoiceNo() = [{}]", 
                    ledger, currentChargeCode, cwTransactionInfo.getChargeCode(), currentInvoiceNo, cwTransactionInfo.getInvoiceNo());
                
                if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) 
                    && StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode()) 
                    && StringUtils.equals(currentInvoiceNo, cwTransactionInfo.getInvoiceNo())) {
                    
                    // 將 Cargowise 取得的值填入落地資料結構中
                    linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
                    linesBean.setCwAccountTransactionLinesPk(cwTransactionInfo.getAccountTransactionLinesPk());
                    linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                    // 將這筆 cwTransactionInfo 標註為已使用過
                    cwTransactionInfo.setUsed(true);
                    // 有找到對應的 CW record 才加入下一階段的工作
                    // 資料落地: Always add to database for AP CONSOL
                    linesBeanList.add(linesBean);
                    // 傳送給 compliance 系統: AP CONSOL typically goes to external system
                    requestBeanList.add(requestBean);
                    break; // Exit inner loop once a match is found
                }
            }
        } else {
            log.warn("handleChargeLineInShipment() cwTransactionInfoList is null or empty.");
        }
    }

    private void handleShipmentChargeLines(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        List<Map<String, Object>> shipments,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger,
        String transactionType,
        String transactionNo,
        String refNoType,
        String zeroFlag,
        Optional<UUID> companyUUID,
        List<PostingJournal> postingJournalList) throws JsonProcessingException {

        // AR, SHIPMENT 則逐筆 charge line 找對應的 displaySequence 寫入 at_account_transaction_lines
        int displaySequence = 0;
        String currentShipmentNo;
        String currentChargeCode;
        
        for (Map<String, Object> aRecord : shipments) {
            displaySequence = 0;
            currentShipmentNo = "";
            String jsonShipment = new ObjectMapper().writeValueAsString(aRecord);
            String transportMode = JsonPath.read(jsonShipment, "$.TransportMode.Code");
            List<String> shipmentNoList = JsonPath.read(jsonShipment, "$.DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key");
            if (!shipmentNoList.isEmpty()) {
                currentShipmentNo = shipmentNoList.getFirst();
            }
            transactionInfoRequestBean.setShipmentId(currentShipmentNo);
            
            // 然後再依照個別 Shipment 中的 JobCosting ... ChargeLine 發送資料
            List<Map<String, Object>> chargeLines = JsonPath.using(configWithoutException).parse(jsonShipment).read("$.JobCosting.ChargeLineCollection.ChargeLine");
            
            // ShipmentCollection.Shipment[].JobCosting 下沒有資料時, 改從 SubShipmentCollection.SubShipment 找
            if (chargeLines == null) {
                List<Map<String, Object>> subShipments = JsonPath.using(configWithoutException).parse(jsonShipment).read("$.SubShipmentCollection.SubShipment");
                handleChargeLineInShipment(requestBeanList, linesBeanList, cwTransactionInfoList, subShipments, 
                                         transactionInfoRequestBean, headerBean, ledger, transactionType, 
                                         transactionInfoRequestBean.getBillNo(), refNoType, zeroFlag, companyUUID, postingJournalList);
            } else {
                processChargeLines(requestBeanList, linesBeanList, cwTransactionInfoList, chargeLines,
                                 transactionInfoRequestBean, headerBean, ledger, transactionType, transactionNo,
                                 refNoType, currentShipmentNo, transportMode, companyUUID, postingJournalList, jsonShipment);
            }
        }
    }

    private void processChargeLines(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        List<Map<String, Object>> chargeLines,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger,
        String transactionType,
        String transactionNo,
        String refNoType,
        String currentShipmentNo,
        String transportMode,
        Optional<UUID> companyUUID,
        List<PostingJournal> postingJournalList,
        String jsonShipment) throws JsonProcessingException {

        // 以下作法會依照 chargeLine 筆數，逐筆寫入 at_account_transaction_lines
        if (chargeLines == null || (StringUtils.equals("AP", ledger) && "INV_CRD".contains(transactionType) && StringUtils.equals("CONSOL", refNoType))) {
            log.debug("[{}][{}][{}] finding ChargeLine by CostAPInvoiceNumber=[{}]", ledger, transactionType, refNoType, transactionNo);
            // Use safe method to find ChargeLines by CostAPInvoiceNumber to handle special characters in transaction numbers
            chargeLines = findChargeLinesByCostAPInvoiceNumber(jsonShipment, transactionNo, "$..ChargeLine");
        }
        
        if (chargeLines == null) {
            log.info("ChargeLine is null, skip this shipment = [{}].", currentShipmentNo);
            return;
        }

        // Filter AR data by SellGSTVATID presence
        int totalChargeLines = chargeLines.size();
        int processedChargeLines = 0;
        int filteredOutChargeLines = 0;

        for (Map<String, Object> cRecord : chargeLines) {
            String jsonChargeLine = new ObjectMapper().writeValueAsString(cRecord);
            
            // Check if ChargeLine has minimum required data for database persistence
            boolean validForDatabase = validationService.hasMinimumRequiredData(jsonChargeLine);
            if (!validForDatabase) {
                String chargeCode = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"), "UNKNOWN");
                log.warn("ChargeLine missing minimum required data, skipping: ChargeCode={}", chargeCode);
                continue;
            }
            
            // Check if ChargeLine meets external system requirements
            boolean validForExternalSystem = true;
            if (StringUtils.equals("AR", ledger)) {
                validForExternalSystem = validationService.hasValidSellGSTVATID(jsonChargeLine);
                if (!validForExternalSystem) {
                    filteredOutChargeLines++;
                    String chargeCode = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"), "UNKNOWN");
                    log.info("AR ChargeLine will be saved to DB but not sent to external system - missing SellGSTVATID: ChargeCode={}", chargeCode);
                }
            } else if (StringUtils.equals("AP", ledger)) {
                validForExternalSystem = validationService.hasValidCostGSTVATID(jsonChargeLine);
                if (!validForExternalSystem) {
                    filteredOutChargeLines++;
                    String chargeCode = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"), "UNKNOWN");
                    log.info("AP ChargeLine will be saved to DB but not sent to external system - missing CostGSTVATID: ChargeCode={}", chargeCode);
                }
            }

            processIndividualChargeLine(requestBeanList, linesBeanList, cwTransactionInfoList, jsonChargeLine,
                                      transactionInfoRequestBean, headerBean, ledger, currentShipmentNo,
                                      transportMode, companyUUID, postingJournalList, validForExternalSystem, refNoType, transactionType);
            processedChargeLines++;
        }
        
        // Log summary for all processing
        log.info("ChargeLine processing summary - Ledger: {}, Total: {}, Processed: {}, Saved to DB: {}, Sent to External: {}, Missing VAT: {}", 
                 ledger, totalChargeLines, processedChargeLines, linesBeanList.size(), requestBeanList.size(), filteredOutChargeLines);
    }

    private void processIndividualChargeLine(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        String jsonChargeLine,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger,
        String currentShipmentNo,
        String transportMode,
        Optional<UUID> companyUUID,
        List<PostingJournal> postingJournalList,
        boolean validForExternalSystem,
        String refNoType,
        String transactionType) throws JsonProcessingException {

        log.debug("Before creating TransactionChargeLineRequestBean for ledger: {} with currency path: {}", 
                 ledger, JSON_PATH_CHARGELINE_OSCURRENCY_CODE);
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean(
            transactionInfoRequestBean, jsonChargeLine, ledger, 
            JSON_PATH_CHARGELINE_OSAMOUNT, JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, shouldSendToExternal);

        int displaySequence = JsonPath.read(jsonChargeLine, "$.DisplaySequence");
        AtAccountTransactionLinesBean linesBean = new AtAccountTransactionLinesBean(
            headerBean, jsonChargeLine, JSON_PATH_CHARGELINE_OSAMOUNT, 
            JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, JSON_PATH_CHARGELINE_LOCALAMOUNT, 
            JSON_PATH_CHARGELINE_OSCURRENCY_CODE, JSON_PATH_CHARGELINE_EXCHANGE_RATE);
        requestBean.setItemGuid(linesBean.getAccountTransactionLinesId());
        requestBean.findAndSetTaxRate(postingJournalList, displaySequence);

        // 紀錄Local的幣別, 目前僅有CNY --> 從 cw_global_company.crncy_code where by json branch of this charge line
        Optional<String> localCurrencyCodeOptional = queryService.getLocalCurrencyCode(JsonPath.parse(jsonChargeLine).read("$.Branch.Code", String.class));
        localCurrencyCodeOptional.ifPresentOrElse(
            localCurrencyCode -> linesBean.setLocalCurrencyCode(localCurrencyCode),
            () -> linesBean.setLocalCurrencyCode("")
        );
        linesBean.setDisplaySequence(displaySequence);

        String currentChargeCode = JsonPath.read(jsonChargeLine, "$.ChargeCode.Code");
        // 只有 AP 才需要用到 Creditor 資訊, AR 則不用
        String currentCreditor = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Creditor.Key"), "");
        String currentInvoiceNo = Objects.toString(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostAPInvoiceNumber"), "");
        
        //依照 displaySequence 從 cwTransactionInfoList 找出 accountChargeCodeId, 再送去 cw_ref_account_charge_code 找中文的 item name
        for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
            if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) && 
                validationService.findMatch(ledger, refNoType, currentShipmentNo, displaySequence, currentChargeCode, currentCreditor, currentInvoiceNo, cwTransactionInfo)) {
                
                if (StringUtils.equals("AP", ledger)) { // AP直接使用 ChargeLine.Description 的資料
                    linesBean.setTransactionLineDescription(JsonPath.read(jsonChargeLine, "$.Description"));
                } else { // AR 才去找中文
                    Optional<String> itemNameOptional = queryService.getItemName(companyUUID.get(), transportMode, cwTransactionInfo.getAccountChargeCodePk());
                    // 如果從 DB 找到對應的 local 語系名稱的話，就更新
                    itemNameOptional.ifPresent(localChargeCodeDescription -> {
                        requestBean.setItemName(localChargeCodeDescription);
                        linesBean.setTransactionLineDescription(localChargeCodeDescription);
                    });
                }
                
                // 將 Cargowise 取得的值填入落地資料結構中
                linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
                linesBean.setCwAccountTransactionLinesPk(cwTransactionInfo.getAccountTransactionLinesPk());
                linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                // 將這筆 cwTransactionInfo 標註為已使用過
                cwTransactionInfo.setUsed(true);
                // 有找到對應的 CW record 才加入下一階段的工作
                // 資料落地: Always add to database if minimum data is present
                linesBeanList.add(linesBean);
                // 傳送給 compliance 系統: Only add if external system requirements are met
                if (validForExternalSystem) {
                    requestBeanList.add(requestBean);
                } else if (StringUtils.equals("AR", ledger)) {
                    log.debug("AR ChargeLine saved to DB but not sent to external system - ChargeCode: {}", currentChargeCode);
                }
                break; // Exit inner loop once a match is found
            }
        }
    }

    public List<Map<String, Object>> findChargeLinesByCostAPInvoiceNumber(Object document, String transactionNumber, String pathToChargeLines) {
        List<Map<String, Object>> matchingLines = new ArrayList<>();
        try {
            List<Map<String, Object>> allLines;
            if (document instanceof com.jayway.jsonpath.DocumentContext) {
                allLines = ((com.jayway.jsonpath.DocumentContext) document).read(pathToChargeLines);
            } else {
                allLines = JsonPath.read(document, pathToChargeLines);
            }
            
            log.debug("Searching {} ChargeLines for CostAPInvoiceNumber='{}'", allLines.size(), transactionNumber);
            
            for (Map<String, Object> line : allLines) {
                String costAPInvoiceNumber = (String) line.get("CostAPInvoiceNumber");
                if (transactionNumber.equals(costAPInvoiceNumber)) {
                    log.debug("Found matching ChargeLine: CostAPInvoiceNumber='{}'", costAPInvoiceNumber);
                    matchingLines.add(line);
                }
            }
        } catch (Exception e) {
            log.debug("Error finding ChargeLines by CostAPInvoiceNumber '{}': {}", transactionNumber, e.getMessage());
        }
        return matchingLines;
    }

    public String extractSupplierReferenceForAP(Object document, String transactionNumber, String refNoType) {
        log.debug("Extracting SupplierReference for AP transaction '{}' with refNoType '{}'", transactionNumber, refNoType);
        
        try {
            if ("CONSOL".equals(refNoType)) {
                return extractSupplierReferenceFromConsol(document, transactionNumber);
            } else {
                return extractSupplierReferenceFromShipment(document, transactionNumber);
            }
        } catch (Exception e) {
            log.error("Error extracting SupplierReference for transaction '{}': {}", transactionNumber, e.getMessage());
            return null;
        }
    }

    private String extractSupplierReferenceFromConsol(Object document, String transactionNumber) {
        log.debug("Searching for SupplierReference in CONSOL structure for transaction: {}", transactionNumber);
        
        try {
            List<Map<String, Object>> consolCostLines = findChargeLinesByCostAPInvoiceNumber(
                document, 
                transactionNumber, 
                "$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].ConsolCosts.ConsolCostLineCollection.ConsolCostLine[*]"
            );
            
            for (Map<String, Object> line : consolCostLines) {
                String supplierRef = (String) line.get("SupplierReference");
                if (supplierRef != null && !supplierRef.trim().isEmpty()) {
                    log.info("Successfully extracted SupplierReference '{}' for transaction '{}' from CONSOL structure", supplierRef, transactionNumber);
                    return supplierRef;
                }
            }
            log.debug("No SupplierReference found in {} CONSOL cost lines for transaction '{}'", consolCostLines.size(), transactionNumber);
        } catch (Exception e) {
            log.debug("CONSOL extraction failed: {}", e.getMessage());
        }
        return null;
    }

    private String extractSupplierReferenceFromShipment(Object document, String transactionNumber) {
        log.debug("Searching for SupplierReference in SHIPMENT structure for transaction: {}", transactionNumber);
        
        // Try primary SHIPMENT structure first
        try {
            List<Map<String, Object>> chargeLines = findChargeLinesByCostAPInvoiceNumber(
                document, 
                transactionNumber, 
                "$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]"
            );
            
            for (Map<String, Object> line : chargeLines) {
                String supplierRef = (String) line.get("SupplierReference");
                if (supplierRef != null && !supplierRef.trim().isEmpty()) {
                    log.info("Successfully extracted SupplierReference '{}' for transaction '{}' from SHIPMENT structure", supplierRef, transactionNumber);
                    return supplierRef;
                }
            }
            log.debug("No SupplierReference found in {} SHIPMENT charge lines for transaction '{}'", chargeLines.size(), transactionNumber);
        } catch (Exception e) {
            log.debug("SHIPMENT extraction failed: {}", e.getMessage());
        }
        
        // Fallback: Try SubShipment structure when primary SHIPMENT ChargeLines not found
        log.debug("Trying SubShipment structure fallback for transaction: {}", transactionNumber);
        
        try {
            List<Map<String, Object>> subChargeLines = findChargeLinesByCostAPInvoiceNumber(
                document, 
                transactionNumber, 
                "$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].SubShipmentCollection.SubShipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]"
            );
            
            for (Map<String, Object> line : subChargeLines) {
                String supplierRef = (String) line.get("SupplierReference");
                if (supplierRef != null && !supplierRef.trim().isEmpty()) {
                    log.info("Successfully extracted SupplierReference '{}' for transaction '{}' from SubShipment structure", supplierRef, transactionNumber);
                    return supplierRef;
                }
            }
            log.debug("No SupplierReference found in {} SubShipment charge lines for transaction '{}'", subChargeLines.size(), transactionNumber);
        } catch (Exception e) {
            log.debug("SubShipment extraction failed: {}", e.getMessage());
        }
        
        // Final fallback: If no exact match found, try to get any SupplierReference from ChargeLines
        log.debug("No exact CostAPInvoiceNumber match found, trying global fallback for any SupplierReference");
        
        try {
            List<Map<String, Object>> allChargeLines = JsonPath.read(document, 
                "$.Body.UniversalTransaction.ShipmentCollection.Shipment[*].JobCosting.ChargeLineCollection.ChargeLine[*]");
            
            for (Map<String, Object> line : allChargeLines) {
                String supplierRef = (String) line.get("SupplierReference");
                if (supplierRef != null && !supplierRef.trim().isEmpty()) {
                    log.info("Successfully extracted SupplierReference '{}' via global fallback for transaction '{}'", supplierRef, transactionNumber);
                    return supplierRef;
                }
            }
            log.debug("No SupplierReference found in global fallback search for transaction '{}'", transactionNumber);
        } catch (Exception e) {
            log.debug("Global fallback search failed: {}", e.getMessage());
        }
        
        return null;
    }

    public void handleNonJobChargeLines(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        String zeroFlag, Optional<UUID> companyUUID,
        List<Map<String, Object>> originalPostingJournalList) throws JsonProcessingException {
        
        log.info("Processing NONJOB charge lines for transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);
        
        if (originalPostingJournalList == null || originalPostingJournalList.isEmpty()) {
            log.warn("No PostingJournal data found for NONJOB transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);
            return;
        }
        
        // Process each posting journal entry as a charge line
        for (Map<String, Object> postingJournalMap : originalPostingJournalList) {
            try {
                processNonJobPostingJournalFromOriginalJson(requestBeanList, linesBeanList, cwTransactionInfoList,
                                          transactionInfoRequestBean, headerBean, ledger, 
                                          transactionType, transactionNo, postingJournalMap);
            } catch (Exception e) {
                log.error("Error processing NONJOB posting journal for transaction [{}][{}][{}]: {}", 
                         ledger, transactionType, transactionNo, e.getMessage(), e);
            }
        }
        
        log.debug("NONJOB charge line processing completed - processed {} posting journals", originalPostingJournalList.size());
    }

    /**
     * Handle GL-Account type NONJOB charge lines with composite key generation.
     *
     * This method processes GL-Account type NONJOB transactions where:
     * - AccTransactionLines may not exist in Cargowise (AL_PK can be NULL)
     * - Multiple rows from Cargowise query should all be processed
     * - Composite key must be generated when AL_PK is NULL: UUID(header_PK + PostingJournal_index)
     *
     * @param requestBeanList List to collect beans for external system
     * @param linesBeanList List to collect beans for database persistence
     * @param cwTransactionInfoList Cargowise transaction info (may contain rows with NULL AL_PK)
     * @param transactionInfoRequestBean Transaction info request bean
     * @param headerBean Transaction header bean
     * @param ledger Transaction ledger (AR/AP)
     * @param transactionType Transaction type (INV/CRD)
     * @param transactionNo Transaction number
     * @param zeroFlag Zero flag
     * @param companyUUID Company UUID
     * @param originalPostingJournalList PostingJournal entries from payload
     */
    public void handleGLAccountChargeLines(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        String zeroFlag, Optional<UUID> companyUUID,
        List<Map<String, Object>> originalPostingJournalList) throws JsonProcessingException {

        log.info("Processing GL-Account NONJOB charge lines for transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);

        if (originalPostingJournalList == null || originalPostingJournalList.isEmpty()) {
            log.warn("No PostingJournal data found for GL-Account NONJOB transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);
            return;
        }

        // Process each posting journal entry as a charge line with composite key generation
        int postingJournalIndex = 0;
        for (Map<String, Object> postingJournalMap : originalPostingJournalList) {
            try {
                processGLAccountPostingJournalFromOriginalJson(
                    requestBeanList, linesBeanList, cwTransactionInfoList,
                    transactionInfoRequestBean, headerBean, ledger,
                    transactionType, transactionNo, postingJournalMap,
                    postingJournalIndex);
                postingJournalIndex++;
            } catch (Exception e) {
                log.error("Error processing GL-Account NONJOB posting journal for transaction [{}][{}][{}]: {}",
                         ledger, transactionType, transactionNo, e.getMessage(), e);
            }
        }

        log.debug("GL-Account NONJOB charge line processing completed - processed {} posting journals", originalPostingJournalList.size());
    }

    /**
     * Process a single GL-Account PostingJournal entry with composite key generation.
     *
     * Composite key logic:
     * - If cwTransactionInfo.accountTransactionLinesPk (AL_PK) exists → use it directly
     * - If AL_PK is NULL → generate composite UUID from header_PK + postingJournalIndex
     *
     * @param postingJournalIndex Zero-based index of the current PostingJournal entry (for composite key)
     */
    private void processGLAccountPostingJournalFromOriginalJson(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        Map<String, Object> postingJournalMap,
        int postingJournalIndex) throws JsonProcessingException {

        // Convert original PostingJournal map to JSON for processing
        String jsonChargeLine = new ObjectMapper().writeValueAsString(postingJournalMap);

        // Determine if this should be sent to external system
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());

        // Use correct JSON paths for GL-Account NONJOB PostingJournal structure
        String osAmountPath = "$.Osamount";
        String gstVatAmountPath = "$.Osgstvatamount";
        String localAmountPath = "$.LocalAmount";
        String currencyCodePath = "$.Oscurrency.Code";

        log.debug("GL-Account NONJOB currency extraction - using path: {} for ledger: {}", currencyCodePath, ledger);

        // Create charge line request bean from original posting journal JSON
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean(
            transactionInfoRequestBean, jsonChargeLine, ledger,
            osAmountPath, gstVatAmountPath, shouldSendToExternal);

        // Create transaction lines bean for GL-Account NONJOB
        AtAccountTransactionLinesBean linesBean = createNonjobTransactionLinesBean(
            headerBean, jsonChargeLine, osAmountPath,
            gstVatAmountPath, localAmountPath,
            currencyCodePath);

        requestBean.setItemGuid(linesBean.getAccountTransactionLinesId());

        // Match with Cargowise transaction info if available
        // For GL-Account type: Match by GL account number (ag.AG_AccountNum), AL_PK may be NULL
        if (cwTransactionInfoList != null && !cwTransactionInfoList.isEmpty()) {
            String currentGlAccount = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.AccountCode");

            for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
                if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) &&
                    StringUtils.equals(currentGlAccount, cwTransactionInfo.getGlAccount())) {

                    // Map Cargowise primary keys and identifiers
                    linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
                    linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                    linesBean.setDisplaySequence(cwTransactionInfo.getDisplaySequence());

                    // Composite key logic for GL-Account type
                    UUID cwAccountTransactionLinesPk = cwTransactionInfo.getAccountTransactionLinesPk();
                    if (cwAccountTransactionLinesPk != null) {
                        // AL_PK exists in Cargowise - use it directly
                        linesBean.setCwAccountTransactionLinesPk(cwAccountTransactionLinesPk);
                        log.debug("GL-Account: Using existing AL_PK from Cargowise: {}", cwAccountTransactionLinesPk);
                    } else {
                        // AL_PK is NULL - generate composite key from header_PK + PostingJournal_index
                        UUID headerPk = headerBean.getCwAccTransHeaderPk();
                        if (headerPk != null) {
                            String compositeKeySource = headerPk.toString() + "-" + postingJournalIndex;
                            UUID compositeKey = UUID.nameUUIDFromBytes(compositeKeySource.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                            linesBean.setCwAccountTransactionLinesPk(compositeKey);
                            log.info("GL-Account: Generated composite key for AL_PK=NULL: {} (from header_PK={}, index={})",
                                    compositeKey, headerPk, postingJournalIndex);
                        } else {
                            log.warn("GL-Account: Cannot generate composite key - header_PK is NULL for transaction [{}][{}][{}]",
                                    ledger, transactionType, transactionNo);
                        }
                    }

                    // Override amounts with CW data if available (CW is authoritative source)
                    // CW database schema: AccTransactionLines.AL_OSAmount (Outstanding Amount) is inclusive of AL_GSTVAT (VAT)
                    // Therefore, use os_amount directly without adding VAT again
                    if (cwTransactionInfo.getOsAmount() != null) {
                        BigDecimal cwChargeAmount = cwTransactionInfo.getOsAmount();
                        linesBean.setChargeAmount(cwChargeAmount);
                    }

                    // NONJOB VAT amounts are NOT overridden from Cargowise because:
                    // - AL_GSTVAT contains LOCAL currency VAT (CNY), not OS currency (USD)
                    // - JSON PostingJournal provides accurate OS currency VAT (Osgstvatamount)
                    // - createNonjobTransactionLinesBean() correctly extracts both currencies
                    // Therefore, we keep the initial bean values from JSON PostingJournal

                    if (cwTransactionInfo.getLineAmount() != null) {
                        linesBean.setTotalAmount(cwTransactionInfo.getLineAmount());
                    }

                    if (cwTransactionInfo.getExchangeRate() != null) {
                        linesBean.setExchangeRate(cwTransactionInfo.getExchangeRate());
                    }

                    if (cwTransactionInfo.getCurrencyCode() != null) {
                        linesBean.setCurrencyCode(cwTransactionInfo.getCurrencyCode());
                    }

                    // Mark this CW record as used
                    cwTransactionInfo.setUsed(true);

                    log.debug("Matched GL-Account charge [{}] with CW transaction info - AL_PK={}, populated CW amounts",
                             currentGlAccount, cwAccountTransactionLinesPk);
                    break;
                }
            }
        }

        // Add to processing lists
        linesBeanList.add(linesBean);  // Always save to database
        if (shouldSendToExternal) {
            requestBeanList.add(requestBean);  // Send to compliance system if required
        }

        log.debug("Processed GL-Account NONJOB charge line: glAccountCode={}, index={}",
                 JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.AccountCode"),
                 postingJournalIndex);
    }

    public void handleNonJobChargeLinesFallback(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        String zeroFlag, Optional<UUID> companyUUID,
        List<PostingJournal> postingJournalList) throws JsonProcessingException {
        
        log.info("Processing NONJOB charge lines (fallback) for transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);
        
        if (postingJournalList == null || postingJournalList.isEmpty()) {
            log.warn("No PostingJournal data found for NONJOB transaction (fallback): [{}][{}][{}]", ledger, transactionType, transactionNo);
            return;
        }
        
        // Process each posting journal entry as a charge line using fallback method
        for (PostingJournal postingJournal : postingJournalList) {
            try {
                processNonJobPostingJournalFallback(requestBeanList, linesBeanList, cwTransactionInfoList,
                                          transactionInfoRequestBean, headerBean, ledger, 
                                          transactionType, transactionNo, postingJournal);
            } catch (Exception e) {
                log.error("Error processing NONJOB posting journal (fallback) for transaction [{}][{}][{}]: {}", 
                         ledger, transactionType, transactionNo, e.getMessage(), e);
            }
        }
        
        log.debug("NONJOB charge line processing (fallback) completed - processed {} posting journals", postingJournalList.size());
    }

    private void processNonJobPostingJournalFallback(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        PostingJournal postingJournal) throws JsonProcessingException {
        
        // Convert PostingJournal to JSON for processing (fallback method)
        String jsonChargeLine = new ObjectMapper().writeValueAsString(postingJournal);
        
        // Determine if this should be sent to external system
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());
        
        // Use simple JSON paths for flattened PostingJournal structure
        String osAmountPath = "$.osamount";  // Note: lowercase due to Jackson serialization
        String gstVatAmountPath = "$.osgstvatamount";
        String localAmountPath = "$.localAmount";
        String currencyCodePath = "$.currencyCode";  // This might not exist in PostingJournal
        String exchangeRatePath = "$.exchangeRate";   // This might not exist in PostingJournal
        
        log.warn("Using fallback NONJOB processing with limited data - some fields may be missing");
        
        // Create a simple lines bean using available data
        AtAccountTransactionLinesBean linesBean = new AtAccountTransactionLinesBean();
        linesBean.setAccountTransactionLinesId(UUID.randomUUID());
        linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
        linesBean.setCompanyCode(headerBean.getCompanyCode());
        linesBean.setCompanyBranch(headerBean.getCompanyBranch());
        linesBean.setCompanyDept(headerBean.getCompanyDepartment());
        
        // Set basic fields from PostingJournal
        linesBean.setDisplaySequence(postingJournal.getSequence());
        linesBean.setTransactionLineDescription("NONJOB Charge");
        
        // Match with Cargowise transaction info if available
        if (cwTransactionInfoList != null && !cwTransactionInfoList.isEmpty()) {
            String currentChargeCode = postingJournal.getChargeCode();
            
            for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
                if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) && 
                    StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode())) {
                    
                    // Map Cargowise data to fill missing information
                    linesBean.setCwAccountTransactionLinesPk(cwTransactionInfo.getAccountTransactionLinesPk());
                    linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                    linesBean.setDisplaySequence(cwTransactionInfo.getDisplaySequence());
                    
                    // Use CW data for amounts since PostingJournal may not have complete data
                    if (cwTransactionInfo.getOsAmount() != null) {
                        linesBean.setChargeAmount(cwTransactionInfo.getOsAmount());
                    }

                    // NONJOB VAT amounts are NOT overridden from Cargowise because:
                    // - AL_GSTVAT contains LOCAL currency VAT (CNY), not OS currency (USD)
                    // - JSON PostingJournal provides accurate OS currency VAT (Osgstvatamount)
                    // - createNonjobTransactionLinesBean() correctly extracts both currencies
                    // Therefore, we keep the initial bean values from JSON PostingJournal

                    if (cwTransactionInfo.getLineAmount() != null) {
                        linesBean.setTotalAmount(cwTransactionInfo.getLineAmount());
                    }
                    if (cwTransactionInfo.getExchangeRate() != null) {
                        linesBean.setExchangeRate(cwTransactionInfo.getExchangeRate());
                    }
                    if (cwTransactionInfo.getCurrencyCode() != null) {
                        linesBean.setCurrencyCode(cwTransactionInfo.getCurrencyCode());
                    }
                    
                    // Mark this CW record as used
                    cwTransactionInfo.setUsed(true);
                    
                    log.debug("Matched NONJOB charge [{}] with CW transaction info (fallback)", currentChargeCode);
                    break;
                }
            }
        }
        
        // Add to processing lists (database only for fallback)
        linesBeanList.add(linesBean);  // Always save to database
        
        log.debug("Processed NONJOB charge line (fallback): chargeCode={}", postingJournal.getChargeCode());
    }
    
    private void processNonJobPostingJournalFromOriginalJson(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        Map<String, Object> postingJournalMap) throws JsonProcessingException {

        // Convert original PostingJournal map to JSON for processing
        String jsonChargeLine = new ObjectMapper().writeValueAsString(postingJournalMap);

        // Determine if this should be sent to external system
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());

        // Use correct JSON paths for NONJOB PostingJournal structure
        String osAmountPath = "$.Osamount";
        String gstVatAmountPath = "$.Osgstvatamount";
        String localAmountPath = "$.LocalAmount";
        String currencyCodePath = "$.Oscurrency.Code";  // For NONJOB, currency is in PostingJournal.Oscurrency.Code

        log.debug("NONJOB currency extraction - using path: {} for ledger: {}", currencyCodePath, ledger);

        // Create charge line request bean from original posting journal JSON
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean(
            transactionInfoRequestBean, jsonChargeLine, ledger,
            osAmountPath, gstVatAmountPath, shouldSendToExternal);

        // Create transaction lines bean manually for NONJOB to handle different JSON structure
        // Note: Exchange rate comes from TransactionInfo (headerBean), not from individual PostingJournal entries
        AtAccountTransactionLinesBean linesBean = createNonjobTransactionLinesBean(
            headerBean, jsonChargeLine, osAmountPath,
            gstVatAmountPath, localAmountPath,
            currencyCodePath);

        requestBean.setItemGuid(linesBean.getAccountTransactionLinesId());

        // Match with Cargowise transaction info if available and populate missing fields
        if (cwTransactionInfoList != null && !cwTransactionInfoList.isEmpty()) {
            // Job-Invoice NONJOB uses ChargeCode.Code (acc.AC_Code) for matching
            String currentChargeCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code");

            for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
                if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) &&
                    StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode())) {
                    
                    // Map Cargowise primary keys and identifiers
                    linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
                    linesBean.setCwAccountTransactionLinesPk(cwTransactionInfo.getAccountTransactionLinesPk());
                    linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                    linesBean.setDisplaySequence(cwTransactionInfo.getDisplaySequence());
                    
                    // Override amounts with CW data if available (CW is authoritative source)
                    // CW database schema: AccTransactionLines.AL_OSAmount (Outstanding Amount) is inclusive of AL_GSTVAT (VAT)
                    // Therefore, use os_amount directly without adding VAT again
                    if (cwTransactionInfo.getOsAmount() != null) {
                        BigDecimal cwChargeAmount = cwTransactionInfo.getOsAmount();
                        linesBean.setChargeAmount(cwChargeAmount);
                    }

                    // NONJOB VAT amounts are NOT overridden from Cargowise because:
                    // - AL_GSTVAT contains LOCAL currency VAT (CNY), not OS currency (USD)
                    // - JSON PostingJournal provides accurate OS currency VAT (Osgstvatamount)
                    // - createNonjobTransactionLinesBean() correctly extracts both currencies
                    // Therefore, we keep the initial bean values from JSON PostingJournal

                    if (cwTransactionInfo.getLineAmount() != null) {
                        linesBean.setTotalAmount(cwTransactionInfo.getLineAmount());
                    }

                    if (cwTransactionInfo.getExchangeRate() != null) {
                        linesBean.setExchangeRate(cwTransactionInfo.getExchangeRate());
                    }

                    if (cwTransactionInfo.getCurrencyCode() != null) {
                        linesBean.setCurrencyCode(cwTransactionInfo.getCurrencyCode());
                    }

                    // Mark this CW record as used
                    cwTransactionInfo.setUsed(true);

                    log.debug("Matched NONJOB charge [{}] with CW transaction info - populated CW amounts: osAmount={}, gstVat={}, lineAmount={}",
                             currentChargeCode, cwTransactionInfo.getOsAmount(), cwTransactionInfo.getGstVatAmount(), cwTransactionInfo.getLineAmount());
                    break;
                }
            }
        }

        // Add to processing lists
        linesBeanList.add(linesBean);  // Always save to database
        if (shouldSendToExternal) {
            requestBeanList.add(requestBean);  // Send to compliance system if required
        }

        log.debug("Processed NONJOB charge line: glAccountCode={}, amount={}",
                 JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.AccountCode"),
                 JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Osamount"));
    }

    private AtAccountTransactionLinesBean createNonjobTransactionLinesBean(
        AtAccountTransactionHeaderBean headerBean,
        String jsonChargeLine,
        String jsonPathChargeLineOSAmount,
        String jsonPathChargeLineOsGstVatAmount,
        String jsonPathChargeLineLocalAmount,
        String jsonPathChargeLineOSCurrencyCode) {

        AtAccountTransactionLinesBean linesBean = new AtAccountTransactionLinesBean();
        linesBean.setAccountTransactionLinesId(UUID.randomUUID());
        linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());

        // Extract amounts from NONJOB PostingJournal JSON with safe parsing
        Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        BigDecimal outstandingAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOSAmount, String.class));
        BigDecimal outstandingGSTVatAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOsGstVatAmount, String.class));
        BigDecimal localAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineLocalAmount, String.class));

        // For NONJOB transactions, exchange rate comes from TransactionInfo (headerBean.exchangeRate)
        // PostingJournal entries don't have individual exchange rates
        BigDecimal chargeLineexchangeRate = headerBean.getExchangeRate();
        log.debug("NONJOB using TransactionInfo exchange rate: {}", chargeLineexchangeRate);

        // Apply (-1) multiplication only for AP ledger, AR uses positive amounts
        BigDecimal multiplier = "AP".equals(headerBean.getLedger()) ? new BigDecimal(-1) : BigDecimal.ONE;

        linesBean.setChargeAmount(outstandingAmount.add(outstandingGSTVatAmount).multiply(multiplier)); // 原幣含稅金額
        linesBean.setVatAmount(outstandingGSTVatAmount.multiply(multiplier)); // 原幣稅額
        linesBean.setTotalAmount(localAmount.multiply(multiplier)); // 本幣未稅金額
        linesBean.setLocalVatAmount(outstandingGSTVatAmount.multiply(chargeLineexchangeRate).multiply(multiplier).setScale(2, RoundingMode.HALF_UP)); // 本幣的稅額VAT Amount
        
        linesBean.setCompanyCode(headerBean.getCompanyCode());
        linesBean.setCompanyBranch(headerBean.getCompanyBranch());
        linesBean.setCompanyDept(headerBean.getCompanyDepartment());

        // Extract currency from NONJOB PostingJournal with safe parsing and debug logging
        String currencyCode = null;
        try {
            Object currencyObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read(jsonPathChargeLineOSCurrencyCode);
            currencyCode = (currencyObj instanceof String) ? (String) currencyObj : null;
        } catch (Exception e) {
            log.debug("Failed to extract NONJOB currency from {}: {}", jsonPathChargeLineOSCurrencyCode, e.getMessage());
        }
        
        if (StringUtils.isNotBlank(currencyCode)) {
            linesBean.setCurrencyCode(currencyCode);
            log.debug("NONJOB currency extracted from PostingJournal: {}", currencyCode);
        } else {
            // Fallback to header currency if PostingJournal currency is missing
            linesBean.setCurrencyCode(headerBean.getCurrencyCode());
            log.debug("NONJOB currency fallback to header: {}", headerBean.getCurrencyCode());
        }
        
        linesBean.setExchangeRate(chargeLineexchangeRate);
        
        // For NONJOB, use LocalCurrency for local currency (instead of CostOSCurrency which doesn't exist in PostingJournal)
        String localCurrencyCode = null;
        try {
            Object localCurrencyObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.LocalCurrency.Code");
            localCurrencyCode = (localCurrencyObj instanceof String) ? (String) localCurrencyObj : null;
        } catch (Exception e) {
            log.debug("Failed to extract NONJOB local currency: {}", e.getMessage());
        }
        
        if (StringUtils.isNotBlank(localCurrencyCode)) {
            linesBean.setLocalCurrencyCode(localCurrencyCode);
            log.debug("NONJOB local currency extracted: {}", localCurrencyCode);
        } else {
            linesBean.setLocalCurrencyCode("");
            log.debug("NONJOB local currency not found, using empty string");
        }

        // Priority-based description extraction for NONJOB PostingJournal (consistent with itemCode/itemName logic)
        // JOB_INVOICE type: ChargeCode.Description (charge-specific, e.g., "AMS Security Surcharge")
        // GL_ACCOUNT type: Glaccount.Description (account-specific, e.g., "Accounts Receivable - Trade")
        Object chargeCodeObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code");
        boolean hasChargeCode = chargeCodeObj != null && StringUtils.isNotBlank(chargeCodeObj.toString());

        String lineDescription;
        if (hasChargeCode) {
            // JOB_INVOICE type NONJOB - use ChargeCode.Description for charge-specific descriptions
            lineDescription = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Description");
            log.debug("NONJOB (JOB_INVOICE type) transaction line description from ChargeCode: {}", lineDescription);
        } else {
            // GL_ACCOUNT type NONJOB - use Glaccount.Description for account-specific descriptions
            lineDescription = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.Description");
            log.debug("NONJOB (GL_ACCOUNT type) transaction line description from Glaccount: {}", lineDescription);
        }

        linesBean.setTransactionLineDescription(lineDescription != null ? lineDescription : "");

        return linesBean;
    }
    
    private void processNonJobPostingJournal(
        List<TransactionChargeLineRequestBean> requestBeanList,
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<CwAccountTransactionInfo> cwTransactionInfoList,
        TransactionInfoRequestBean transactionInfoRequestBean,
        AtAccountTransactionHeaderBean headerBean,
        String ledger, String transactionType, String transactionNo,
        PostingJournal postingJournal) throws JsonProcessingException {
        
        // Convert PostingJournal to JSON for processing
        String jsonChargeLine = new ObjectMapper().writeValueAsString(postingJournal);
        
        // Determine if this should be sent to external system
        boolean shouldSendToExternal = transactionRoutingService.shouldSendToExternalSystem(ledger, transactionType, transactionInfoRequestBean.getBillNo());
        
        // Create charge line request bean from posting journal
        TransactionChargeLineRequestBean requestBean = new TransactionChargeLineRequestBean(
            transactionInfoRequestBean, jsonChargeLine, ledger, 
            JSON_PATH_CHARGELINE_OSAMOUNT, JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, shouldSendToExternal);

        // Create transaction lines bean for database storage
        AtAccountTransactionLinesBean linesBean = new AtAccountTransactionLinesBean(
            headerBean, jsonChargeLine, JSON_PATH_CHARGELINE_OSAMOUNT, 
            JSON_PATH_CHARGELINE_OSGSTVATAMOUNT, JSON_PATH_CHARGELINE_LOCALAMOUNT, 
            JSON_PATH_CHARGELINE_OSCURRENCY_CODE, JSON_PATH_CHARGELINE_EXCHANGE_RATE);
            
        requestBean.setItemGuid(linesBean.getAccountTransactionLinesId());
        
        // Match with Cargowise transaction info if available and populate missing fields
        if (cwTransactionInfoList != null && !cwTransactionInfoList.isEmpty()) {
            String currentChargeCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code");
            
            for (CwAccountTransactionInfo cwTransactionInfo : cwTransactionInfoList) {
                if (Boolean.FALSE.equals(cwTransactionInfo.isUsed()) && 
                    StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode())) {
                    
                    // Map Cargowise primary keys and identifiers
                    linesBean.setAccountTransactionHeaderId(headerBean.getAcctTransHeaderId());
                    linesBean.setCwAccountTransactionLinesPk(cwTransactionInfo.getAccountTransactionLinesPk());
                    linesBean.setChargeCodeId(cwTransactionInfo.getAccountChargeCodePk());
                    linesBean.setDisplaySequence(cwTransactionInfo.getDisplaySequence());
                    
                    // Override amounts with CW data if available (CW is authoritative source)
                    // CW database schema: AccTransactionLines.AL_OSAmount (Outstanding Amount) is inclusive of AL_GSTVAT (VAT)
                    // Therefore, use os_amount directly without adding VAT again
                    if (cwTransactionInfo.getOsAmount() != null) {
                        BigDecimal cwChargeAmount = cwTransactionInfo.getOsAmount();
                        linesBean.setChargeAmount(cwChargeAmount);
                    }

                    // NONJOB VAT amounts are NOT overridden from Cargowise because:
                    // - AL_GSTVAT contains LOCAL currency VAT (CNY), not OS currency (USD)
                    // - JSON PostingJournal provides accurate OS currency VAT (Osgstvatamount)
                    // - createNonjobTransactionLinesBean() correctly extracts both currencies
                    // Therefore, we keep the initial bean values from JSON PostingJournal

                    if (cwTransactionInfo.getLineAmount() != null) {
                        linesBean.setTotalAmount(cwTransactionInfo.getLineAmount());
                    }

                    if (cwTransactionInfo.getExchangeRate() != null) {
                        linesBean.setExchangeRate(cwTransactionInfo.getExchangeRate());
                    }

                    if (cwTransactionInfo.getCurrencyCode() != null) {
                        linesBean.setCurrencyCode(cwTransactionInfo.getCurrencyCode());
                    }

                    // Mark this CW record as used
                    cwTransactionInfo.setUsed(true);

                    log.debug("Matched NONJOB charge [{}] with CW transaction info - populated CW amounts: osAmount={}, gstVat={}, lineAmount={}",
                             currentChargeCode, cwTransactionInfo.getOsAmount(), cwTransactionInfo.getGstVatAmount(), cwTransactionInfo.getLineAmount());
                    break;
                }
            }
        }
        
        // Add to processing lists
        linesBeanList.add(linesBean);  // Always save to database
        if (shouldSendToExternal) {
            requestBeanList.add(requestBean);  // Send to compliance system if required
        }
        
        log.debug("Processed NONJOB charge line: chargeCode={}, amount={}", 
                 JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"),
                 JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Osamount"));
    }
}