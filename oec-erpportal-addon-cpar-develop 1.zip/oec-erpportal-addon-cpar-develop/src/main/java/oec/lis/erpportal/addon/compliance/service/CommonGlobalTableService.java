package oec.lis.erpportal.addon.compliance.service;

import java.util.Optional;

import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;

public interface CommonGlobalTableService {
    public Optional<String> getCompanyCodeByBranchCode( String branchCode );
    
    /**
     * Placeholder method for test compatibility.
     * TODO: Implement actual buyer reference lookup logic.
     */
    public BuyerInfo findBuyerReference(String reference);
}
