package oec.lis.erpportal.addon.compliance.transaction.impl;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.config.NonJobTransactionConfig;
import oec.lis.erpportal.addon.compliance.exception.BuyerReferenceNotFoundException;
import oec.lis.erpportal.addon.compliance.exception.CwAccountTransactionHeaderNotFoundException;
import oec.lis.erpportal.addon.compliance.exception.DebiterNameNotFoundException;
import oec.lis.erpportal.addon.compliance.exception.NonJobNotSupportedException;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.NonJobType;
import oec.lis.erpportal.addon.compliance.model.transaction.PostingJournal;
import oec.lis.erpportal.addon.compliance.model.transaction.RefNoInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionInfoRequestBean;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class TransactionMappingService {

    // max retry counts for atAccountTransactionTableService.saveSoplAccountTransactionTables()
    public static final int MAX_RETRIES = 5;
    public static final int INITIAL_RETRY_DELAY_MS = 1000; // 1000 ms

    // Configure JsonPath to suppress exceptions
    private final Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

    // JSON path constants
    private final String JSON_PATH_CHARGELINE_OSAMOUNT = "$.OutstandingAmount";
    private final String JSON_PATH_CHARGELINE_OSGSTVATAMOUNT = "$.OutstandingGSTVATAmount";
    private final String JSON_PATH_CHARGELINE_LOCALAMOUNT = "$.LocalAmount";
    private final String JSON_PATH_CHARGELINE_OSCURRENCY_CODE = "$.OSCurrency.Code";
    private final String JSON_PATH_CHARGELINE_EXCHANGE_RATE = "$.ExchangeRate";

    private final TransactionQueryService queryService;
    private final TransactionValidationService validationService;
    private final ChargeLineProcessor chargeLineProcessor;
    private final AtAccountTransactionTableService atAccountTransactionTableService;
    private final NonJobTransactionConfig nonJobConfig;

    public TransactionMappingService(
        TransactionQueryService queryService,
        TransactionValidationService validationService,
        ChargeLineProcessor chargeLineProcessor,
        AtAccountTransactionTableService atAccountTransactionTableService,
        NonJobTransactionConfig nonJobConfig
    ) {
        this.queryService = queryService;
        this.validationService = validationService;
        this.chargeLineProcessor = chargeLineProcessor;
        this.atAccountTransactionTableService = atAccountTransactionTableService;
        this.nonJobConfig = nonJobConfig;
    }

    public String logMessage(String message) {
        log.debug(message);
        return message;
    }

    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadRaw(String json) throws Exception {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();
        log.debug("analyzePayloadRaw()");

        ArrayList<String> debugMsg = new ArrayList<>();
        RestListResponse<TransactionChargeLineRequestBean> result = new RestListResponse<>();

        try {
            List<TransactionChargeLineRequestBean> requestList = generateRequestBeanRaw(json, debugMsg);
            result.setBody(requestList);
        } catch (NonJobNotSupportedException e) {
            // Re-throw NonJobNotSupportedException so it reaches UniversalController's exception handler
            log.error("Error in analyzePayloadRaw: {}", e.getMessage(), e);
            debugMsg.add(logMessage("Error: " + e.getMessage()));
            throw e; // This exception must reach the controller
        } catch (Exception e) {
            log.error("Error in analyzePayloadRaw: {}", e.getMessage(), e);
            debugMsg.add(logMessage("Error: " + e.getMessage()));
            result.setBody(Collections.emptyList());
        }

        // Profiling section
        instant = Instant.now();
        long methodEndTimeStampMillis = instant.toEpochMilli();
        debugMsg.add(logMessage(String.format("execution time = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);

        return result;
    }

    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadStrategy(String json, TransactionQueryService queryService, TransactionValidationService validationService, ChargeLineProcessor chargeLineProcessor) throws Exception {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();
        log.debug("analyzePayloadStrategy()");

        ArrayList<String> debugMsg = new ArrayList<>();
        RestListResponse<TransactionChargeLineRequestBean> result = new RestListResponse<>();

        // Strategy pattern removed in favor of configuration-based routing
        // Routing decisions are now handled by TransactionRoutingService
        // This method is kept for backward compatibility but delegates to analyzePayloadRaw

        // Profiling section
        instant = Instant.now();
        long methodEndTimeStampMillis = instant.toEpochMilli();
        debugMsg.add(logMessage(String.format("execution time = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);

        return result;
    }

    private List<TransactionChargeLineRequestBean> generateRequestBeanRaw(String json, ArrayList<String> debugMsg) throws JsonProcessingException, BuyerReferenceNotFoundException, DebiterNameNotFoundException, CwAccountTransactionHeaderNotFoundException {
        // = Root structure
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        
        final String triggerDateString = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.DataContext.TriggerDate");
        final String triggerReferenceString = JsonPath.using(configWithoutException).parse(allDocument).read("$.Body.UniversalTransaction.TransactionInfo.DataContext.TriggerReference");
        final String eventReference = JsonPath.using(configWithoutException).parse(allDocument).read("$.Body.UniversalTransaction.TransactionInfo.DataContext.EventReference");
        
        // = TransactionInfo structure
        Object document = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo");
        
        String ledger = JsonPath.read(document, "$.Ledger");
        String transactionType = JsonPath.read(document, "$.TransactionType");
        String transactionNo = JsonPath.read(document, "$.Number");
        Boolean isCancelled = JsonPath.read(document, "$.IsCancelled" );

        // 最終要寫入 at_account_transaction_header 的資料結構
        AtAccountTransactionHeaderBean headerBean = createTransactionHeader(document, triggerDateString, ledger, transactionType, transactionNo, isCancelled);
        
        debugMsg.add(logMessage(String.format("ledger = [%s], transactionType = [%s], transactionNo = [%s], isCancelled = [%s]", ledger, transactionType, transactionNo, isCancelled)));

        // 要傳送給 compliance 系統的資料結構 (subset of linesBeanList based on routing and VAT validation)
        List<TransactionChargeLineRequestBean> requestBeanList = new ArrayList<>();
        // 要寫入 at_account_transaction_lines 的資料結構 (all valid transaction data)
        List<AtAccountTransactionLinesBean> linesBeanList = new ArrayList<>();
        
        List<RefNoInfo> refNoList = queryService.getRefNo( ledger, transactionType, transactionNo );
        debugMsg.add(logMessage(String.format("refNoList.size() = %d", refNoList.size())));
        
        // DEBUGGING: Log the exact query parameters for investigation
        debugMsg.add(logMessage(String.format("RefNo query params: ledger=[%s], transactionType=[%s], transactionNo=[%s]", ledger, transactionType, transactionNo)));
        
        if (refNoList.isEmpty()) {
            // 找不到 refNoList 時, 回傳空的 List
            debugMsg.add(logMessage("RefNoInfo not found - returning empty list (no database persistence)"));
            debugMsg.add(logMessage("POSSIBLE CAUSES: 1) Transaction not in Cargowise DB, 2) Query parameters mismatch, 3) Data not loaded"));
            return new ArrayList<>();
        }

        // Check for reversed transactions first
        if (eventReference != null && "AR|CRD|Reversed_AR|INV|Reversed_AP|CRD|Reversed_AP|INV|Reversed".contains(eventReference) && Boolean.TRUE.equals(isCancelled)) {
            debugMsg.add(logMessage(String.format("Processing reversed transaction: [%s][%s][%s]", ledger, transactionType, transactionNo)));
            handleReversedTransaction(document, headerBean, ledger, transactionType, transactionNo, eventReference, debugMsg);
            return new ArrayList<>(); // Return empty list as reversed transactions don't need external processing
        }
        
        List<TransactionChargeLineRequestBean> result = processTransactionWithRefNo(allDocument, document, headerBean, requestBeanList, linesBeanList, 
                                         refNoList, ledger, transactionType, transactionNo, isCancelled, debugMsg);
        
        // Check if any lookup errors occurred during processing
        boolean hasLookupErrors = debugMsg.stream().anyMatch(msg -> msg.contains("Warning:") && (msg.contains("organization code") || msg.contains("buyer")));
        if (hasLookupErrors) {
            debugMsg.add(logMessage("LOOKUP_ERRORS_DETECTED: Transaction saved to database, but some external system lookups failed"));
        }
        
        return result;
    }

    private AtAccountTransactionHeaderBean createTransactionHeader(Object document, String triggerDateString, String ledger, String transactionType, String transactionNo, Boolean isCancelled) {
        AtAccountTransactionHeaderBean headerBean = new AtAccountTransactionHeaderBean();
        
        headerBean.setAcctTransHeaderId(UUID.randomUUID());
        if (StringUtils.equals("AR", ledger)) {
            // Use safe extraction for JobInvoiceNumber - may not exist for GL-Account NONJOB transactions
            String jobInvoiceNumber = JsonPath.using(configWithoutException).parse(document).read("$.JobInvoiceNumber", String.class);
            headerBean.setInvoiceNo(jobInvoiceNumber != null ? jobInvoiceNumber : transactionNo);
        } else {
            headerBean.setInvoiceNo(transactionNo);
        }
        headerBean.setInvoiceDate(JsonPath.read(document, "$.TransactionDate"));
        headerBean.setCurrencyCode(JsonPath.read(document, "$.Oscurrency.Code"));
        headerBean.setCompanyCode(JsonPath.read(document, "$.DataContext.Company.Code"));
        headerBean.setCompanyBranch(JsonPath.read(document, "$.Branch.Code"));
        headerBean.setCompanyDepartment(JsonPath.read(document, "$.Department.Code"));
        headerBean.setInvoiceOrgCode(JsonPath.read(document, "$.OrganizationAddress.OrganizationCode"));
        headerBean.setTransactionNo(JsonPath.read(document, "$.Number"));
        
        // Extract and set SellReference for AR transactions using existing method
        if (StringUtils.equals("AR", ledger)) {
            try {
                String sellReference = extractSellReferenceForAR(document, transactionNo, "UNKNOWN");
                if (StringUtils.isNotBlank(sellReference)) {
                    // Enforce 38-character limit for database column constraint
                    if (sellReference.length() > 38) {
                        log.warn("SellReference [{}] exceeds 38 characters, truncating to fit database constraint for transaction [{}]", 
                                sellReference, transactionNo);
                        sellReference = sellReference.substring(0, 38);
                    }
                    headerBean.setChequeOrReference(sellReference);
                    log.debug("Set chequeOrReference to SellReference [{}] for AR transaction [{}]", sellReference, transactionNo);
                } else {
                    log.debug("No SellReference found for AR transaction [{}], chequeOrReference remains null", transactionNo);
                }
            } catch (Exception e) {
                log.warn("Error extracting SellReference for AR transaction [{}]: {}", transactionNo, e.getMessage());
                // Continue processing - chequeOrReference will remain null
            }
        } else if (StringUtils.equals("AP", ledger)) {
            // Extract and set AP SellReference using new AP-specific method
            try {
                String sellReference = extractSellReferenceForAP(document, transactionNo, "UNKNOWN");
                if (StringUtils.isNotBlank(sellReference)) {
                    // Enforce 38-character limit for database column constraint
                    if (sellReference.length() > 38) {
                        log.warn("AP SellReference [{}] exceeds 38 characters, truncating to fit database constraint for transaction [{}]", 
                                sellReference, transactionNo);
                        sellReference = sellReference.substring(0, 38);
                    }
                    headerBean.setChequeOrReference(sellReference);
                    log.debug("Set chequeOrReference to AP SellReference [{}] for AP transaction [{}]", sellReference, transactionNo);
                } else {
                    log.debug("No AP SellReference found for AP transaction [{}], chequeOrReference remains null", transactionNo);
                }
            } catch (Exception e) {
                log.warn("Error extracting AP SellReference for AP transaction [{}]: {}", transactionNo, e.getMessage());
                // Continue processing - chequeOrReference will remain null
            }
        } else {
            log.debug("Non-AR/AP transaction [{}] - skipping SellReference extraction for chequeOrReference", transactionNo);
        }
        
        headerBean.setLedger(ledger);
        headerBean.setTransactionType(transactionType);
        headerBean.setCancelled(isCancelled);
        headerBean.setDueDate(headerBean.getInvoiceDate());
        headerBean.setInvoiceAmount(new BigDecimal(JsonPath.parse(document).read("$.Ostotal", String.class)));
        headerBean.setOutstandingAmount(new BigDecimal(JsonPath.parse(document).read("$.OutstandingAmount", String.class)));
        headerBean.setExchangeRate(new BigDecimal(JsonPath.parse(document).read("$.ExchangeRate", String.class)));
        headerBean.setLocalCurrencyCode(JsonPath.read(document, "$.LocalCurrency.Code"));
        headerBean.setTransactionDescription(JsonPath.read(document, "$.Description"));
        headerBean.setTotalVatAmount(new BigDecimal(JsonPath.parse(document).read("$.Osgstvatamount", String.class)));
        headerBean.setLocalTotalVatAmount(new BigDecimal(JsonPath.parse(document).read("$.LocalVATAmount", String.class)));

        // Parse the ISO8601 string and set trigger date (Convert to Instant (UTC))
        // Note: update_time uses business event timestamp to handle out-of-order webhook delivery
        OffsetDateTime odt = OffsetDateTime.parse(triggerDateString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        headerBean.setUpdateTime(odt.toInstant());
        headerBean.setUpdateBy("CPAR");
        headerBean.setCreateBy("CPAR");
        headerBean.setCreateTime(Instant.now());
        
        return headerBean;
    }

    private List<TransactionChargeLineRequestBean> processTransactionWithRefNo(
        Object allDocument, Object document, AtAccountTransactionHeaderBean headerBean,
        List<TransactionChargeLineRequestBean> requestBeanList, List<AtAccountTransactionLinesBean> linesBeanList,
        List<RefNoInfo> refNoList, String ledger, String transactionType, String transactionNo, Boolean isCancelled,
        ArrayList<String> debugMsg) throws JsonProcessingException, BuyerReferenceNotFoundException, DebiterNameNotFoundException, CwAccountTransactionHeaderNotFoundException {

        // Track lookup errors across all refNo processing
        Map<String, String> allLookupErrors = new HashMap<>();
        
        for (RefNoInfo aRefNo : refNoList) {
            String refNoType = aRefNo.getRefNoType();
            String refNo = aRefNo.getRefNo();
            debugMsg.add(logMessage(String.format("refNoType = [%s], refNo = [%s]", refNoType, refNo)));

            // Set refNo on headerBean for database save
            headerBean.setRefNo(refNo);

            processRefNoType(allDocument, document, headerBean, requestBeanList, linesBeanList,
                           ledger, transactionType, transactionNo, refNoType, refNo, debugMsg, allLookupErrors);
        }

        // Validate policy compliance before saving (don't let validation failures prevent database save)
        try {
            validationService.validatePolicyCompliance(linesBeanList, requestBeanList, ledger, transactionType, transactionNo);
            debugMsg.add(logMessage("Policy compliance validation passed"));
        } catch (Exception validationException) {
            log.warn("Policy compliance validation failed for [{}][{}][{}]: {}", 
                     ledger, transactionType, transactionNo, validationException.getMessage());
            debugMsg.add(logMessage("Warning: Policy compliance validation failed - " + validationException.getMessage()));
            allLookupErrors.put("policyValidation", "Policy validation failed: " + validationException.getMessage());
            // Continue to database save even if validation fails
        }

        // Save to database with retry mechanism (always succeed, even with lookup errors)
        saveTransactionDataWithRetry(headerBean, linesBeanList, requestBeanList, ledger, transactionType, isCancelled, debugMsg, allLookupErrors);

        return requestBeanList;
    }

    private void processRefNoType(
        Object allDocument, Object document, AtAccountTransactionHeaderBean headerBean,
        List<TransactionChargeLineRequestBean> requestBeanList, List<AtAccountTransactionLinesBean> linesBeanList,
        String ledger, String transactionType, String transactionNo, String refNoType, String refNo,
        ArrayList<String> debugMsg, Map<String, String> lookupErrors) throws JsonProcessingException, BuyerReferenceNotFoundException, DebiterNameNotFoundException, CwAccountTransactionHeaderNotFoundException {

        // NONJOB processing: Handle transactions without shipment/consol references
        if (StringUtils.equals("NONJOB", refNoType)) {
            // Check if NONJOB support is enabled
            if (!nonJobConfig.isEnabled()) {
                log.warn("NONJOB transaction rejected - support disabled: [{}][{}][{}]",
                         ledger, transactionType, transactionNo);
                throw new NonJobNotSupportedException(
                    nonJobConfig.getErrorMessage(),
                    ledger, transactionType, transactionNo
                );
            }

            // Detect NonJob type: JOB_INVOICE (has JobInvoiceNumber) or GL_ACCOUNT (no JobInvoiceNumber)
            // Need to pass the original JSON to detection method - extract from allDocument
            String fullJson = JsonUtils.getJson(allDocument);
            NonJobType nonJobType = NonJobType.detectFromPayload(fullJson);

            log.info("Processing NONJOB transaction: [{}][{}][{}] - Type: {}",
                     ledger, transactionType, transactionNo, nonJobType);
            debugMsg.add(logMessage(String.format("NONJOB type detected: %s", nonJobType)));

            // Route to type-specific processing
            if (nonJobType == NonJobType.JOB_INVOICE) {
                processJobInvoiceNonJob(allDocument, document, headerBean, requestBeanList, linesBeanList,
                                       ledger, transactionType, transactionNo, debugMsg);
            } else { // GL_ACCOUNT
                processGLAccountNonJob(allDocument, document, headerBean, requestBeanList, linesBeanList,
                                      ledger, transactionType, transactionNo, debugMsg);
            }
            return;
        }

        // Standard transaction processing (reversed transactions are handled earlier)

        // Standard transaction processing
        processStandardTransaction(allDocument, document, headerBean, requestBeanList, linesBeanList,
                                 ledger, transactionType, transactionNo, refNoType, refNo, debugMsg, lookupErrors);
    }

    private void handleReversedTransaction(Object document, AtAccountTransactionHeaderBean headerBean, String ledger, String transactionType, String transactionNo, String eventReference, ArrayList<String> debugMsg) {
        try {
            // Get original transaction details
            String originalTransactionNo = JsonPath.read(document, "$.OriginalReference.OriginalTransactionNumber");
            String originalTransactionType = transactionType;
            
            // Flip transaction type to find the original transaction
            if (StringUtils.equals("CRD", transactionType)) {
                originalTransactionType = "INV";
            } else if (StringUtils.equals("INV", transactionType)) {
                originalTransactionType = "CRD";
            }
            
            debugMsg.add(logMessage(String.format("Looking for original transaction: [%s][%s][%s]", ledger, originalTransactionType, originalTransactionNo)));
            
            // For reversed transactions, we need to find the original transaction's cw_acc_trans_header_pk
            // Use the header-only query to get just the PK
            String querySql = TransactionQueryService.QUERY_CW_ACCOUNT_TRANSACTION_INFO_HEADER;
            String organizationCode = JsonPath.read(document, "$.OrganizationAddress.OrganizationCode");
            
            List<CwAccountTransactionInfo> originalCwDataList = queryService.getCWAccountTransactionInfo(
                querySql, ledger, originalTransactionType, originalTransactionNo, organizationCode);
            
            if (originalCwDataList.isEmpty()) {
                debugMsg.add(logMessage(String.format("Warning: Original Cargowise transaction data not found: [%s][%s][%s][%s]", 
                    ledger, originalTransactionType, originalTransactionNo, organizationCode)));
                return;
            }
            
            // Extract cw_acc_trans_header_pk from the original transaction
            CwAccountTransactionInfo originalCwData = originalCwDataList.get(0);
            UUID cwAccTransHeaderPk = originalCwData.getAccountTransactionHeaderPk();
            
            debugMsg.add(logMessage(String.format("Found original transaction PK: [%s] for [%s][%s][%s]", 
                cwAccTransHeaderPk, ledger, originalTransactionType, originalTransactionNo)));
            
            // Set the original transaction's PK in the header bean for update
            headerBean.setCwAccTransHeaderPk(cwAccTransHeaderPk);
            headerBean.setUpdateTime(Instant.now());
            
            // Update the original transaction to set is_cancel = true
            int updated = atAccountTransactionTableService.updateAccountTransactionHeader(headerBean);
            debugMsg.add(logMessage(String.format("[%s][%s][%s] %d records updated to cancelled", ledger, transactionType, transactionNo, updated)));
            
            if (updated == 0) {
                debugMsg.add(logMessage(String.format("Warning: No records updated for reversal: [%s][%s][%s] with PK [%s]", 
                    ledger, transactionType, transactionNo, cwAccTransHeaderPk)));
            }
            
        } catch (Exception e) {
            log.error("Error handling reversed transaction: [{}][{}][{}]", ledger, transactionType, transactionNo, e);
            debugMsg.add(logMessage(String.format("Error handling reversed transaction: %s", e.getMessage())));
        }
    }

    private void processStandardTransaction(
        Object allDocument, Object document, AtAccountTransactionHeaderBean headerBean,
        List<TransactionChargeLineRequestBean> requestBeanList, List<AtAccountTransactionLinesBean> linesBeanList,
        String ledger, String transactionType, String transactionNo, String refNoType, String refNo,
        ArrayList<String> debugMsg, Map<String, String> lookupErrors) throws JsonProcessingException, BuyerReferenceNotFoundException, DebiterNameNotFoundException, CwAccountTransactionHeaderNotFoundException {

        // Create transaction info request bean using safe method for standard transactions
        TransactionInfoRequestBean transactionInfoRequestBean = createTransactionInfoRequestSafe(allDocument, document, ledger, transactionNo, refNo, refNoType, debugMsg, lookupErrors);
        
        // Enhance standard transaction info with additional fields from document and header bean
        enhanceStandardTransactionInfoRequest(transactionInfoRequestBean, document, headerBean, transactionType);
        
        // Get company UUID for AR transactions
        Optional<UUID> companyUUID = queryService.getCompanyUUID(headerBean.getCompanyCode());
        if (StringUtils.equals("AR", ledger) && companyUUID.isEmpty()) {
            debugMsg.add(logMessage("Company UUID not found for AR transaction: " + headerBean.getCompanyCode()));
        }

        // Get CW account transaction info
        List<CwAccountTransactionInfo> cwTransactionInfoList = getCwTransactionInfo(ledger, transactionType, transactionNo, refNoType, headerBean);
        headerBean.setCwAccTransHeaderPk(cwTransactionInfoList.getFirst().getAccountTransactionHeaderPk());

        // Get posting journal
        List<PostingJournal> postingJournalList = getPostingJournal(document);

        // Process shipments - handle gracefully if ShipmentCollection is missing or any other JSON parsing errors
        List<Map<String, Object>> shipments = new ArrayList<>();
        try {
            shipments = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment");
            log.debug("Found {} shipments to process", shipments.size());
        } catch (com.jayway.jsonpath.PathNotFoundException e) {
            log.warn("ShipmentCollection.Shipment path not found in transaction [{}][{}][{}] - will process without shipment data: {}", 
                     ledger, transactionType, transactionNo, e.getMessage());
            debugMsg.add(logMessage("Warning: ShipmentCollection.Shipment path not found - processing without shipment data"));
            // Continue with empty shipments list - transaction can still be saved to database
        } catch (Exception e) {
            log.error("Error parsing ShipmentCollection for transaction [{}][{}][{}] - will process without shipment data: {}", 
                     ledger, transactionType, transactionNo, e.getMessage(), e);
            debugMsg.add(logMessage("Warning: Error parsing ShipmentCollection - processing without shipment data: " + e.getMessage()));
            // Continue with empty shipments list - transaction can still be saved to database
        }
        
        chargeLineProcessor.handleChargeLineInShipment(
            requestBeanList, linesBeanList, cwTransactionInfoList, shipments,
            transactionInfoRequestBean, headerBean, ledger, transactionType, transactionNo,
            refNoType, "0", companyUUID, postingJournalList
        );

        debugMsg.add(logMessage(String.format("requestBeanList.size() = %d", requestBeanList.size())));
        debugMsg.add(logMessage(String.format("linesBeanList.size() = %d", linesBeanList.size())));
    }

    private TransactionInfoRequestBean createTransactionInfoRequestSafe(Object allDocument, Object document, String ledger, String transactionNo, String refNo, String refNoType, ArrayList<String> debugMsg, Map<String, String> lookupErrors) throws BuyerReferenceNotFoundException {
        TransactionInfoRequestBean transactionInfoRequestBean = new TransactionInfoRequestBean();
        transactionInfoRequestBean.setBillNo(transactionNo);
        
        // Extract shipmentId and consolNo from JSON payload based on refNoType
        String shipmentId = null;
        String consolNo = null;
        
        try {
            if ("SHIPMENT".equals(refNoType)) {
                // For SHIPMENT: extract ForwardingShipment, leave consolNo as null
                List<String> shipmentKeys = JsonPath.using(configWithoutException).parse(allDocument)
                    .read("$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingShipment')].Key");
                if (shipmentKeys != null && !shipmentKeys.isEmpty()) {
                    shipmentId = shipmentKeys.get(0);
                    debugMsg.add(logMessage(String.format("Extracted shipmentId from JSON: [%s]", shipmentId)));
                }
            } else if ("CONSOL".equals(refNoType)) {
                // For CONSOL: extract ForwardingConsol, leave shipmentId as null
                List<String> consolKeys = JsonPath.using(configWithoutException).parse(allDocument)
                    .read("$.Body.UniversalTransaction.TransactionInfo.ShipmentCollection.Shipment[0].DataContext.DataSourceCollection.DataSource[?(@.Type=='ForwardingConsol')].Key");
                if (consolKeys != null && !consolKeys.isEmpty()) {
                    consolNo = consolKeys.get(0);
                    debugMsg.add(logMessage(String.format("Extracted consolNo from JSON: [%s]", consolNo)));
                }
            } else if ("NONJOB".equals(refNoType)) {
                // For NONJOB: Extract Job.Key with two-level fallback using utility method
                JobKeyExtractionResult result = extractJobKeyWithFallback(allDocument, debugMsg, "NONJOB shipmentId");

                if (result != null) {
                    String rawKey = result.getExtractedValue();
                    String extractionSource = result.getExtractionSource();

                    // Apply whitespace trimming to extracted value
                    String trimmedKey = rawKey.replaceAll("\\s+", ""); // Remove ALL whitespace

                    if (StringUtils.isNotBlank(trimmedKey)) {
                        shipmentId = trimmedKey;
                        debugMsg.add(logMessage(String.format("NONJOB shipmentId set from [%s]: raw=[%s], trimmed=[%s]",
                            extractionSource, rawKey, shipmentId)));
                    } else {
                        debugMsg.add(logMessage(String.format("NONJOB extracted value [%s] is blank after whitespace trimming - shipmentId remains null", rawKey)));
                    }
                }
            }
            // For other refNoType values or extraction failures: both remain null
            debugMsg.add(logMessage(String.format("JSON extraction result for [%s]: shipmentId=[%s], consolNo=[%s]", refNoType, shipmentId, consolNo)));
        } catch (Exception e) {
            debugMsg.add(logMessage(String.format("Warning: Failed to extract shipmentId/consolNo from JSON for [%s]: %s", refNoType, e.getMessage())));
            log.warn("Failed to extract shipmentId/consolNo from JSON for refNoType [{}]: {}", refNoType, e.getMessage());
            // Continue with null values - don't fail the transaction
        }
        
        transactionInfoRequestBean.setShipmentId(shipmentId);
        transactionInfoRequestBean.setConsolNo(consolNo);

        String buyerCode = extractBuyerCode(document, ledger, transactionNo, refNoType);
        String debiterName = null;
        
        // Handle null buyerCode (missing SellReference/SupplierReference)
        if (buyerCode == null) {
            String errorMessage = StringUtils.equals("AR", ledger) 
                ? "No SellReference found for AR transaction! TransactionInfo.Number = [" + transactionNo + "]"
                : "No SupplierReference found for AP transaction! TransactionInfo.Number = [" + transactionNo + "]";
            lookupErrors.put("buyerCode", errorMessage);
            debugMsg.add(logMessage("Warning: " + errorMessage));
            
            // Set buyerCode and buyerName to null when reference is missing
            transactionInfoRequestBean.setBuyerCode(null);
            transactionInfoRequestBean.setBuyerName(null);
        } else {
            // Try to get debiterName, but don't fail if not found
            try {
                debiterName = queryService.getDebiterName(buyerCode);
            } catch (DebiterNameNotFoundException e) {
                lookupErrors.put("debiterName", e.getMessage());
                debugMsg.add(logMessage("Warning: " + e.getMessage()));
                debiterName = "UNKNOWN_" + buyerCode; // Set fallback value
            }
            
            transactionInfoRequestBean.setBuyerCode(buyerCode);
            transactionInfoRequestBean.setBuyerName(debiterName);
        }

        // Set additional buyer information (gracefully handle failures) - skip if buyerCode is null
        if (buyerCode != null) {
            try {
                Optional<BuyerInfo> buyerOrgInfo = queryService.getBuyerOrgInfo(buyerCode);
                buyerOrgInfo.ifPresent(info -> {
                    transactionInfoRequestBean.setBuyerAddr(info.getAddress1());
                });
            } catch (Exception e) {
                lookupErrors.put("buyerOrgInfo", "Failed to lookup buyer organization info: " + e.getMessage());
                debugMsg.add(logMessage("Warning: Failed to lookup buyer organization info for " + buyerCode));
            }

            try {
                Optional<String> buyerTaxNo = queryService.getBuyerTaxNo(buyerCode);
                buyerTaxNo.ifPresent(transactionInfoRequestBean::setBuyerTaxNo);
            } catch (Exception e) {
                lookupErrors.put("buyerTaxNo", "Failed to lookup buyer tax number: " + e.getMessage());
                debugMsg.add(logMessage("Warning: Failed to lookup buyer tax number for " + buyerCode));
            }

            try {
                String currencyCode = JsonPath.read(document, "$.Oscurrency.Code");
                Optional<BuyerInfo> buyerBankInfo = queryService.getBuyerBankInfo(buyerCode, currencyCode);
                buyerBankInfo.ifPresent(info -> {
                    transactionInfoRequestBean.setBuyerBankName(info.getBankName());
                    transactionInfoRequestBean.setBuyerBankAccount(info.getBankAccount());
                });
            } catch (Exception e) {
                lookupErrors.put("buyerBankInfo", "Failed to lookup buyer bank info: " + e.getMessage());
                debugMsg.add(logMessage("Warning: Failed to lookup buyer bank info for " + buyerCode));
            }
        } else {
            debugMsg.add(logMessage("Skipping buyer information lookups due to null buyerCode"));
        }

        debugMsg.add(logMessage(String.format("buyerCode = [%s], debiterName = [%s]", buyerCode, debiterName)));
        return transactionInfoRequestBean;
    }

    private TransactionInfoRequestBean createTransactionInfoRequest(Object allDocument, Object document, String ledger, String transactionNo, String refNo, String refNoType, ArrayList<String> debugMsg) throws BuyerReferenceNotFoundException, DebiterNameNotFoundException {
        // Legacy method that throws exceptions - kept for backward compatibility where errors should fail fast
        Map<String, String> lookupErrors = new HashMap<>();
        TransactionInfoRequestBean result = createTransactionInfoRequestSafe(allDocument, document, ledger, transactionNo, refNo, refNoType, debugMsg, lookupErrors);
        
        // If there were lookup errors, throw the first one to maintain backward compatibility
        if (!lookupErrors.isEmpty()) {
            String firstError = lookupErrors.values().iterator().next();
            if (firstError.contains("getDebiterName()")) {
                throw new DebiterNameNotFoundException(firstError);
            }
            throw new RuntimeException("Lookup failed: " + firstError);
        }
        
        return result;
    }

    private List<CwAccountTransactionInfo> getCwTransactionInfo(String ledger, String transactionType, String transactionNo, String refNoType, AtAccountTransactionHeaderBean headerBean) throws CwAccountTransactionHeaderNotFoundException {
        String querySql;
        String organizationCode = headerBean.getInvoiceOrgCode();

        if (StringUtils.equals("CONSOL", refNoType)) {
            querySql = TransactionQueryService.QUERY_CW_ACCOUNT_TRANSACTION_INFO_CONSOL;
        } else {
            querySql = TransactionQueryService.QUERY_CW_ACCOUNT_TRANSACTION_INFO_SHIPMENT;
        }

        List<CwAccountTransactionInfo> cwTransactionInfoList = queryService.getCWAccountTransactionInfo(querySql, ledger, transactionType, transactionNo, organizationCode);
        if (cwTransactionInfoList.isEmpty()) {
            String message = String.format("Cargowise AccountTransactionInfo not found for TransactionInfo.Number: [%s][%s][%s][%s]", ledger, transactionType, transactionNo, organizationCode);
            throw new CwAccountTransactionHeaderNotFoundException(message);
        }
        return cwTransactionInfoList;
    }

    public List<PostingJournal> getPostingJournal(Object document) throws JsonProcessingException {
        List<PostingJournal> resultList = new ArrayList<>();
        List<Map<String, Object>> postingJournalList = JsonPath.using(configWithoutException).parse(document).read("$.PostingJournalCollection.PostingJournal");
        if (postingJournalList != null && !postingJournalList.isEmpty()) {
            for (Map<String, Object> aJournal : postingJournalList) {
                String jsonJournalString = new ObjectMapper().writeValueAsString(aJournal);
                PostingJournal returnPostingJournal = new PostingJournal();
                returnPostingJournal.setChargeCode(JsonPath.read(jsonJournalString, "$.ChargeCode.Code"));
                returnPostingJournal.setSequence(JsonPath.read(jsonJournalString, "$.Sequence"));
                // Use configWithoutException for graceful handling of missing VattaxID
                String taxCode = JsonPath.using(configWithoutException).parse(jsonJournalString).read("$.VattaxID.TaxCode");
                Object taxRateObj = JsonPath.using(configWithoutException).parse(jsonJournalString).read("$.VattaxID.TaxRate");
                
                returnPostingJournal.setTaxCode(taxCode != null ? taxCode : "");
                returnPostingJournal.setTaxRate(taxRateObj != null ? Integer.parseInt(taxRateObj.toString()) : 0);
                
                if (taxCode == null) {
                    log.debug("VattaxID.TaxCode not found for ChargeCode: {}, Sequence: {}", 
                              returnPostingJournal.getChargeCode(), returnPostingJournal.getSequence());
                }
                resultList.add(returnPostingJournal);
            }
        }
        return resultList;
    }

    /**
     * Helper method to sanitize transaction numbers for JsonPath expressions
     * Escapes single quotes to prevent JsonPath injection issues
     */
    private String sanitizeForJsonPath(String value) {
        if (value == null) {
            return null;
        }
        return value.replace("'", "\\'");
    }

    /**
     * Enhanced AR buyer code extraction using JsonPath filtering
     * Matches SellPostedTransactionNumber with transaction number to find correct SellReference
     * 
     * @param document The JSON document to search
     * @param transactionNumber The transaction number to match
     * @param refNoType The reference number type for logging
     * @return SellReference matching the transaction number, or null if not found
     */
    private String extractSellReferenceForAR(Object document, String transactionNumber, String refNoType) {
        try {
            // Phase 1: Try filtered JsonPath to find SellReference where SellPostedTransactionNumber matches
            String sanitizedTransactionNumber = sanitizeForJsonPath(transactionNumber);
            String jsonPathExpression = String.format(
                "$..ChargeLine[?(@.SellPostedTransactionNumber=='%s')].SellReference", 
                sanitizedTransactionNumber
            );
            
            log.info("Enhanced AR extraction using JsonPath: {} for transaction: {}", 
                     jsonPathExpression, transactionNumber);
            
            List<String> filteredSellReferenceList = JsonPath.read(document, jsonPathExpression);
            log.info("Enhanced JsonPath returned: {} items", filteredSellReferenceList.size());
                
            if (!filteredSellReferenceList.isEmpty()) {
                String sellReference = filteredSellReferenceList.getFirst();
                log.info("Enhanced AR logic found matching SellReference [{}] for transaction [{}]", 
                        sellReference, transactionNumber);
                return sellReference;
            }

            // // Fallback: Use original logic if no matching SellPostedTransactionNumber found
            // log.debug("No matching SellPostedTransactionNumber found, falling back to original $..SellReference logic for transaction: {}", 
            //          transactionNumber);
            
            // List<String> sellReferenceList = JsonPath.read(document, "$..SellReference");
            // log.info("Fallback JsonPath $..SellReference returned: {} items", sellReferenceList.size());
            // if (!sellReferenceList.isEmpty()) {
            //     String sellReference = sellReferenceList.getFirst();
            //     log.debug("Fallback AR logic found SellReference [{}] for transaction [{}]", 
            //              sellReference, transactionNumber);
            //     return sellReference;
            // }
            
            // No SellReference found anywhere
            log.warn("No SellReference found for AR transaction! TransactionInfo.Number = [{}]", transactionNumber);
            return null;
            
        } catch (Exception e) {
            log.warn("Error during enhanced AR SellReference extraction for transaction [{}]: {}. Falling back to original logic.", 
                    transactionNumber, e.getMessage());
            
            // Final fallback to original simple logic
            // try {
            //     List<String> sellReferenceList = JsonPath.read(document, "$..SellReference");
            //     if (!sellReferenceList.isEmpty()) {
            //         return sellReferenceList.getFirst();
            //     }
            // } catch (Exception fallbackException) {
            //     log.error("Fallback AR logic also failed for transaction [{}]: {}", 
            //              transactionNumber, fallbackException.getMessage());
            // }
            return null;
        }
    }

    /**
     * Enhanced AP buyer code extraction using hierarchical field priority
     * Extracts payment reference from AP transaction JSON payload with graceful fallback
     * 
     * @param document The JSON document containing AP transaction data
     * @param transactionNumber The transaction number for logging purposes
     * @param refNoType The reference number type for logging purposes
     * @return Payment reference from CheckNumberOrPaymentRef, JobInvoiceNumber, or Description, or null if none found
     */
    private String extractSellReferenceForAP(Object document, String transactionNumber, String refNoType) {
        try {
            // Phase 1: Try CheckNumberOrPaymentRef (primary payment reference)
            String checkNumberOrPaymentRef = JsonPath.using(configWithoutException)
                .parse(document).read("$.CheckNumberOrPaymentRef", String.class);
            if (StringUtils.isNotBlank(checkNumberOrPaymentRef)) {
                log.info("AP extraction Phase 1 success: Found CheckNumberOrPaymentRef [{}] for transaction [{}]", 
                        checkNumberOrPaymentRef, transactionNumber);
                return checkNumberOrPaymentRef;
            }
            log.debug("AP extraction Phase 1: CheckNumberOrPaymentRef is empty for transaction [{}]", transactionNumber);

            // // Phase 2: Try JobInvoiceNumber (stable business identifier)  
            // String jobInvoiceNumber = JsonPath.using(configWithoutException)
            //     .parse(document).read("$.JobInvoiceNumber", String.class);
            // if (StringUtils.isNotBlank(jobInvoiceNumber)) {
            //     log.info("AP extraction Phase 2 fallback: Found JobInvoiceNumber [{}] for transaction [{}]", 
            //             jobInvoiceNumber, transactionNumber);
            //     return jobInvoiceNumber;
            // }
            // log.debug("AP extraction Phase 2: JobInvoiceNumber is empty for transaction [{}]", transactionNumber);

            // // Phase 3: Try Description (descriptive fallback)
            // String description = JsonPath.using(configWithoutException)
            //     .parse(document).read("$.Description", String.class);
            // if (StringUtils.isNotBlank(description)) {
            //     log.info("AP extraction Phase 3 fallback: Found Description [{}] for transaction [{}]", 
            //             description, transactionNumber);
            //     return description;
            // }
            // log.debug("AP extraction Phase 3: Description is empty for transaction [{}]", transactionNumber);
            
            // No suitable reference found
            log.warn("No AP SellReference found - all phases failed for AP transaction! TransactionInfo.Number = [{}]", transactionNumber);
            return null;
            
        } catch (Exception e) {
            log.warn("Error during AP SellReference extraction for transaction [{}]: {}",
                    transactionNumber, e.getMessage());
            return null;
        }
    }

    /**
     * Enhanced AP buyer code extraction using JsonPath filtering
     * Matches CostAPInvoiceNumber with transaction number to find correct SupplierReference
     * This method is similar to extractSellReferenceForAR but for AP transactions
     *
     * @param document The JSON document to search
     * @param transactionNumber The transaction number to match
     * @param refNoType The reference number type for logging
     * @return SupplierReference matching the transaction number, or null if not found
     */
    private String extractSupplierReferenceForAP_ByInvoiceNumber(Object document, String transactionNumber, String refNoType) {
        try {
            // Try filtered JsonPath to find SupplierReference where CostAPInvoiceNumber matches
            String sanitizedTransactionNumber = sanitizeForJsonPath(transactionNumber);
            String jsonPathExpression = String.format(
                "$..ChargeLine[?(@.CostAPInvoiceNumber=='%s')].SupplierReference",
                sanitizedTransactionNumber
            );

            log.info("Enhanced AP buyer code extraction using JsonPath: {} for transaction: {}",
                     jsonPathExpression, transactionNumber);

            List<String> filteredSupplierReferenceList = JsonPath.read(document, jsonPathExpression);
            log.info("Enhanced JsonPath returned: {} items", filteredSupplierReferenceList.size());

            if (!filteredSupplierReferenceList.isEmpty()) {
                String supplierReference = filteredSupplierReferenceList.getFirst();
                log.info("Enhanced AP logic found matching SupplierReference [{}] for transaction [{}]",
                        supplierReference, transactionNumber);
                return supplierReference;
            }

            // No SupplierReference found
            log.warn("No SupplierReference found for AP transaction! TransactionInfo.Number = [{}]", transactionNumber);
            return null;

        } catch (Exception e) {
            log.warn("Error during enhanced AP SupplierReference extraction for transaction [{}]: {}",
                    transactionNumber, e.getMessage());
            return null;
        }
    }

    /**
     * Extracts buyer code from transaction JSON with hierarchical fallback logic.
     *
     * <p>For NONJOB transactions, uses two-phase extraction:
     * <ol>
     *   <li>Phase 1 (Primary): Extract from $.CheckNumberOrPaymentRef</li>
     *   <li>Phase 2 (Fallback): Extract from $.OrganizationAddress.OrganizationCode if Phase 1 fails</li>
     *   <li>Return null if both phases fail (triggers graceful degradation)</li>
     * </ol>
     *
     * <p>For SHIPMENT/CONSOL transactions, uses standard AR/AP logic.
     *
     * @param document The TransactionInfo JSON object
     * @param ledger Ledger type ("AR" or "AP")
     * @param billNo Transaction number (for logging)
     * @param refNoType Reference type ("NONJOB", "SHIPMENT", "CONSOL")
     * @return Buyer code, or null if extraction fails (triggers graceful degradation in calling code)
     * @throws BuyerReferenceNotFoundException Only for unsupported ledger types
     */
    public String extractBuyerCode(Object document, String ledger, String billNo, String refNoType) throws BuyerReferenceNotFoundException {
        // NONJOB: Use CheckNumberOrPaymentRef with OrganizationAddress.OrganizationCode fallback
        if (StringUtils.equals("NONJOB", refNoType)) {
            // Phase 1: Try CheckNumberOrPaymentRef (primary payment/check reference)
            try {
                String checkNumberOrPaymentRef = JsonPath.using(configWithoutException)
                    .parse(document).read("$.CheckNumberOrPaymentRef", String.class);

                // Trim whitespace (leading/trailing only)
                String trimmedCheckNumber = checkNumberOrPaymentRef != null ? checkNumberOrPaymentRef.trim() : null;

                if (StringUtils.isNotBlank(trimmedCheckNumber)) {
                    log.info("NONJOB Phase 1 success: Found CheckNumberOrPaymentRef [{}] for transaction [{}]",
                            trimmedCheckNumber, billNo);
                    return trimmedCheckNumber;
                }

                log.debug("NONJOB Phase 1: CheckNumberOrPaymentRef is missing/null/blank for transaction [{}], trying Phase 2 fallback", billNo);

            } catch (Exception e) {
                log.debug("NONJOB Phase 1 extraction error for transaction [{}]: {} - trying Phase 2 fallback",
                        billNo, e.getMessage());
            }

            // Phase 2: Fallback to OrganizationAddress.OrganizationCode
            try {
                String organizationCode = JsonPath.using(configWithoutException)
                    .parse(document).read("$.OrganizationAddress.OrganizationCode", String.class);

                // Trim whitespace (leading/trailing only)
                String trimmedOrgCode = organizationCode != null ? organizationCode.trim() : null;

                if (StringUtils.isNotBlank(trimmedOrgCode)) {
                    log.info("NONJOB Phase 2 fallback success: Found OrganizationAddress.OrganizationCode [{}] for transaction [{}]",
                            trimmedOrgCode, billNo);
                    return trimmedOrgCode;
                }

                log.debug("NONJOB Phase 2: OrganizationAddress.OrganizationCode is missing/null/blank for transaction [{}]", billNo);

            } catch (Exception e) {
                log.debug("NONJOB Phase 2 extraction error for transaction [{}]: {}", billNo, e.getMessage());
            }

            // Both phases failed - return null for graceful degradation
            log.warn("NONJOB buyerCode extraction failed: Both CheckNumberOrPaymentRef (Phase 1) and OrganizationAddress.OrganizationCode (Phase 2) are missing/null/blank for transaction [{}]. Returning null for graceful degradation.", billNo);
            return null;
        }

        // Extract buyer code based on ledger type: AR uses SellReference, AP uses SupplierReference
        if (StringUtils.equals("AR", ledger)) {
            // Use enhanced extraction for AR transactions
            return extractSellReferenceForAR(document, billNo, refNoType);
        } else if (StringUtils.equals("AP", ledger)) {
            // Use enhanced extraction for AP transactions (matches CostAPInvoiceNumber)
            return extractSupplierReferenceForAP_ByInvoiceNumber(document, billNo, refNoType);
        } else {
            throw new BuyerReferenceNotFoundException("Unsupported ledger type [" + ledger + "] for buyer reference extraction! TransactionInfo.Number = ["+ billNo +"]");
        }
    }

    private void saveTransactionDataWithRetry(AtAccountTransactionHeaderBean headerBean, 
                                            List<AtAccountTransactionLinesBean> linesBeanList,
                                            List<TransactionChargeLineRequestBean> requestBeanList,
                                            String ledger, String transactionType, Boolean isCancelled,
                                            ArrayList<String> debugMsg, Map<String, String> lookupErrors) {
        int retryCount = 0;
        while (retryCount < MAX_RETRIES) {
            try {
                log.debug("at_acct_transaction_header :");
                JsonUtils.printWithJavaTimeSupport(headerBean);
                log.debug("at_acct_transaction_lines :");
                JsonUtils.print(linesBeanList);
                log.debug("request beans before save:");
                JsonUtils.print(requestBeanList);
                
                // Log lookup errors if any
                if (!lookupErrors.isEmpty()) {
                    log.warn("Lookup errors during transaction processing: {}", lookupErrors);
                    debugMsg.add(logMessage("Lookup errors: " + lookupErrors.size() + " failures"));
                }

                // Save to database and capture corrected requestBeanList with existing IDs
                List<TransactionChargeLineRequestBean> correctedRequestBeanList =
                    atAccountTransactionTableService.saveSoplAccountTransactionTables(headerBean, linesBeanList, requestBeanList, true);
                // Update in-place to propagate corrected IDs back to caller
                requestBeanList.clear();
                requestBeanList.addAll(correctedRequestBeanList);
                log.debug("[{}][{}][{}] saved successfully on retry {}", ledger, transactionType, isCancelled, retryCount + 1);
                debugMsg.add(logMessage(String.format("Database save successful on retry %d", retryCount + 1)));
                return;
            } catch (Exception e) {
                retryCount++;
                log.warn("Database save failed on attempt {}/{}: {}", retryCount, MAX_RETRIES, e.getMessage());
                if (retryCount >= MAX_RETRIES) {
                    log.error("Database save failed after {} retries, giving up", MAX_RETRIES);
                    debugMsg.add(logMessage(String.format("Database save failed after %d retries: %s", MAX_RETRIES, e.getMessage())));
                    throw new RuntimeException("Database save failed after " + MAX_RETRIES + " retries", e);
                } else {
                    try {
                        Thread.sleep(INITIAL_RETRY_DELAY_MS * (long) Math.pow(2, retryCount - 1));
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Retry interrupted", ie);
                    }
                }
            }
        }
    }

    private void saveTransactionDataWithRetry(AtAccountTransactionHeaderBean headerBean, 
                                            List<AtAccountTransactionLinesBean> linesBeanList,
                                            List<TransactionChargeLineRequestBean> requestBeanList,
                                            String ledger, String transactionType, Boolean isCancelled,
                                            ArrayList<String> debugMsg) {
        // Backward compatibility method - no lookup errors
        saveTransactionDataWithRetry(headerBean, linesBeanList, requestBeanList, ledger, transactionType, isCancelled, debugMsg, new HashMap<>());
    }

    /**
     * Process Job-Invoice type NONJOB transaction.
     *
     * Characteristics:
     * - Has JobInvoiceNumber in payload
     * - AccTransactionLines exists in Cargowise
     * - Uses AL_PK directly as cw_acct_trans_lines_pk
     * - Queries Cargowise WITH organizationCode filter
     *
     * @param allDocument Full JSON document root
     * @param document TransactionInfo section of JSON
     * @param headerBean Transaction header bean to populate
     * @param requestBeanList List to collect beans for external system
     * @param linesBeanList List to collect beans for database persistence
     * @param ledger Transaction ledger (AR/AP)
     * @param transactionType Transaction type (INV/CRD)
     * @param transactionNo Transaction number
     * @param debugMsg Debug message accumulator
     */
    private void processJobInvoiceNonJob(
        Object allDocument, Object document, AtAccountTransactionHeaderBean headerBean,
        List<TransactionChargeLineRequestBean> requestBeanList, List<AtAccountTransactionLinesBean> linesBeanList,
        String ledger, String transactionType, String transactionNo, ArrayList<String> debugMsg)
        throws JsonProcessingException, BuyerReferenceNotFoundException, CwAccountTransactionHeaderNotFoundException {

        debugMsg.add(logMessage("Processing Job-Invoice type NONJOB transaction - has JobInvoiceNumber"));

        // Extract JobInvoiceNumber for ref_no using utility method
        JobKeyExtractionResult result = extractJobKeyWithFallback(allDocument, debugMsg, "NONJOB-JOB-INVOICE ref_no");

        if (result != null) {
            String rawKey = result.getExtractedValue();
            String extractionSource = result.getExtractionSource();

            // Apply whitespace trimming to extracted value (remove ALL whitespace)
            String jobInvoiceNumber = rawKey.replaceAll("\\s+", "");

            if (StringUtils.isNotBlank(jobInvoiceNumber)) {
                headerBean.setRefNo(jobInvoiceNumber);
                debugMsg.add(logMessage(String.format("Set ref_no=[%s] from [%s] for NONJOB-JOB-INVOICE (raw=[%s])",
                    jobInvoiceNumber, extractionSource, rawKey)));
                log.info("NONJOB-JOB-INVOICE [{}][{}][{}]: Set ref_no=[{}] from [{}]",
                         ledger, transactionType, transactionNo, jobInvoiceNumber, extractionSource);
            } else {
                debugMsg.add(logMessage(String.format("Extracted value [%s] is blank after whitespace trimming - ref_no remains null", rawKey)));
                log.warn("NONJOB-JOB-INVOICE [{}][{}][{}]: Extracted value is blank after whitespace trimming - ref_no will remain null",
                         ledger, transactionType, transactionNo);
            }
        } else {
            debugMsg.add(logMessage("Warning: JobInvoiceNumber extraction failed - ref_no remains null"));
            log.warn("NONJOB-JOB-INVOICE [{}][{}][{}]: JobInvoiceNumber extraction failed - ref_no will remain null",
                     ledger, transactionType, transactionNo);
        }

        // Create transaction info request bean without shipment reference using safe method
        Map<String, String> lookupErrors = new HashMap<>();
        TransactionInfoRequestBean transactionInfoRequestBean = createTransactionInfoRequestSafe(allDocument, document, ledger, transactionNo, null, "NONJOB", debugMsg, lookupErrors);
        
        // Enhance NONJOB transaction info with additional fields from document and header
        enhanceNonjobTransactionInfoRequest(transactionInfoRequestBean, document, headerBean, transactionType);
        
        // Get company UUID for AR transactions
        Optional<UUID> companyUUID = queryService.getCompanyUUID(headerBean.getCompanyCode());
        if (StringUtils.equals("AR", ledger) && companyUUID.isEmpty()) {
            debugMsg.add(logMessage("Company UUID not found for AR NONJOB transaction: " + headerBean.getCompanyCode()));
        }

        // Get CW account transaction info for NONJOB
        List<CwAccountTransactionInfo> cwTransactionInfoList = getCwTransactionInfoForNonjob(ledger, transactionType, transactionNo, headerBean);
        if (!cwTransactionInfoList.isEmpty()) {
            headerBean.setCwAccTransHeaderPk(cwTransactionInfoList.getFirst().getAccountTransactionHeaderPk());
        }

        // Get original posting journal JSON for NONJOB processing
        List<Map<String, Object>> originalPostingJournalList = JsonPath.using(configWithoutException).parse(document).read("$.PostingJournalCollection.PostingJournal");
        
        // Process NONJOB charge lines directly from original PostingJournal JSON
        chargeLineProcessor.handleNonJobChargeLines(
            requestBeanList, linesBeanList, cwTransactionInfoList,
            transactionInfoRequestBean, headerBean, ledger, transactionType, transactionNo,
            "0", companyUUID, originalPostingJournalList
        );

        debugMsg.add(logMessage(String.format("Job-Invoice NONJOB processing completed - requestBeanList.size() = %d, linesBeanList.size() = %d",
                                            requestBeanList.size(), linesBeanList.size())));
    }

    /**
     * Process GL-Account type NONJOB transaction.
     *
     * Characteristics:
     * - NO JobInvoiceNumber in payload (null/missing)
     * - AccTransactionLines may NOT exist in Cargowise
     * - Uses composite key (header_PK + PostingJournal_index) when AL_PK is NULL
     * - Queries Cargowise WITHOUT organizationCode filter
     * - Processes ALL returned rows as separate line records
     *
     * @param allDocument Full JSON document root
     * @param document TransactionInfo section of JSON
     * @param headerBean Transaction header bean to populate
     * @param requestBeanList List to collect beans for external system
     * @param linesBeanList List to collect beans for database persistence
     * @param ledger Transaction ledger (AR/AP)
     * @param transactionType Transaction type (INV/CRD)
     * @param transactionNo Transaction number
     * @param debugMsg Debug message accumulator
     */
    private void processGLAccountNonJob(
        Object allDocument, Object document, AtAccountTransactionHeaderBean headerBean,
        List<TransactionChargeLineRequestBean> requestBeanList, List<AtAccountTransactionLinesBean> linesBeanList,
        String ledger, String transactionType, String transactionNo, ArrayList<String> debugMsg)
        throws JsonProcessingException, BuyerReferenceNotFoundException, CwAccountTransactionHeaderNotFoundException {

        debugMsg.add(logMessage("Processing GL-Account type NONJOB transaction - no JobInvoiceNumber"));

        // Create transaction info request bean without shipment reference using safe method
        Map<String, String> lookupErrors = new HashMap<>();
        TransactionInfoRequestBean transactionInfoRequestBean = createTransactionInfoRequestSafe(allDocument, document, ledger, transactionNo, null, "NONJOB", debugMsg, lookupErrors);

        // Enhance NONJOB transaction info with additional fields from document and header
        enhanceNonjobTransactionInfoRequest(transactionInfoRequestBean, document, headerBean, transactionType);

        // Get company UUID for AR transactions
        Optional<UUID> companyUUID = queryService.getCompanyUUID(headerBean.getCompanyCode());
        if (StringUtils.equals("AR", ledger) && companyUUID.isEmpty()) {
            debugMsg.add(logMessage("Company UUID not found for AR GL-Account NONJOB transaction: " + headerBean.getCompanyCode()));
        }

        // Get CW account transaction info for GL-Account NONJOB - WITHOUT organizationCode filter
        List<CwAccountTransactionInfo> cwTransactionInfoList = getCwTransactionInfoForGLAccount(ledger, transactionType, transactionNo, headerBean);
        if (!cwTransactionInfoList.isEmpty()) {
            headerBean.setCwAccTransHeaderPk(cwTransactionInfoList.getFirst().getAccountTransactionHeaderPk());
        }

        // Get original posting journal JSON for GL-Account NONJOB processing
        List<Map<String, Object>> originalPostingJournalList = JsonPath.using(configWithoutException).parse(document).read("$.PostingJournalCollection.PostingJournal");

        // Process GL-Account charge lines with composite key generation
        chargeLineProcessor.handleGLAccountChargeLines(
            requestBeanList, linesBeanList, cwTransactionInfoList,
            transactionInfoRequestBean, headerBean, ledger, transactionType, transactionNo,
            "0", companyUUID, originalPostingJournalList
        );

        debugMsg.add(logMessage(String.format("GL-Account NONJOB processing completed - requestBeanList.size() = %d, linesBeanList.size() = %d",
                                            requestBeanList.size(), linesBeanList.size())));
    }

    /**
     * Get Cargowise transaction info for GL-Account type NONJOB.
     * Uses GL-Account specific query WITHOUT organizationCode filter.
     * Processes ALL returned rows (no org filtering).
     *
     * @return List of CwAccountTransactionInfo - may be empty, may contain multiple rows
     */
    private List<CwAccountTransactionInfo> getCwTransactionInfoForGLAccount(String ledger, String transactionType, String transactionNo, AtAccountTransactionHeaderBean headerBean) throws CwAccountTransactionHeaderNotFoundException {
        // For GL-Account NONJOB, use dedicated GL-Account query WITHOUT organizationCode filter
        List<CwAccountTransactionInfo> cwTransactionInfoList = queryService.getCwTransactionInfoForGLAccount(ledger, transactionType, transactionNo);

        if (cwTransactionInfoList.isEmpty()) {
            log.warn("No Cargowise AccountTransactionInfo found for GL-Account NONJOB transaction: [{}][{}][{}]", ledger, transactionType, transactionNo);
            // For GL-Account NONJOB, we can continue without CW data as it may be purely internal
            return new ArrayList<>();
        }

        log.debug("Found {} CW transaction lines for GL-Account NONJOB transaction: [{}][{}][{}]",
                 cwTransactionInfoList.size(), ledger, transactionType, transactionNo);
        return cwTransactionInfoList;
    }

    private List<CwAccountTransactionInfo> getCwTransactionInfoForNonjob(String ledger, String transactionType, String transactionNo, AtAccountTransactionHeaderBean headerBean) throws CwAccountTransactionHeaderNotFoundException {
        // For NONJOB transactions, use dedicated NONJOB query to fetch AccTransactionLines data directly
        String organizationCode = headerBean.getInvoiceOrgCode();
        String querySql = TransactionQueryService.QUERY_CW_ACCOUNT_TRANSACTION_INFO_NONJOB; // Use NONJOB query for line-level data
        
        List<CwAccountTransactionInfo> cwTransactionInfoList = queryService.getCWAccountTransactionInfo(querySql, ledger, transactionType, transactionNo, organizationCode);
        if (cwTransactionInfoList.isEmpty()) {
            log.warn("No Cargowise AccountTransactionInfo found for NONJOB transaction: [{}][{}][{}][{}]", ledger, transactionType, transactionNo, organizationCode);
            // For NONJOB, we can continue without CW data as it may be purely internal
            return new ArrayList<>();
        }
        
        log.debug("Found {} CW transaction lines for NONJOB transaction: [{}][{}][{}][{}]", 
                 cwTransactionInfoList.size(), ledger, transactionType, transactionNo, organizationCode);
        return cwTransactionInfoList;
    }
    
    private void enhanceNonjobTransactionInfoRequest(
        TransactionInfoRequestBean transactionInfoRequestBean, 
        Object document, 
        AtAccountTransactionHeaderBean headerBean, 
        String transactionType) {
        
        // Preserve shipmentId and consolNo values already set from JSON extraction (both should be null for NONJOB)
        
        // Populate fields from transaction document JSON
        try {
            transactionInfoRequestBean.setTransactionType(transactionType);
            transactionInfoRequestBean.setBillDate(JsonPath.using(configWithoutException).parse(document).read("$.TransactionDate"));
            transactionInfoRequestBean.setCurrency(JsonPath.using(configWithoutException).parse(document).read("$.Oscurrency.Code"));
        } catch (Exception e) {
            log.warn("Failed to extract some fields from transaction document for NONJOB", e);
        }
        
        // Populate fields from header bean
        transactionInfoRequestBean.setCompanyCode(headerBean.getCompanyCode());
        transactionInfoRequestBean.setBranchCode(headerBean.getCompanyBranch());  
        transactionInfoRequestBean.setDepartmentCode(headerBean.getCompanyDepartment());
        
        // For NONJOB, set debiter info same as buyer since there's no separate debiter
        transactionInfoRequestBean.setDebiterCode(transactionInfoRequestBean.getBuyerCode());
        transactionInfoRequestBean.setDebiterName(transactionInfoRequestBean.getBuyerName());
        
        log.debug("Enhanced NONJOB TransactionInfoRequestBean with companyCode={}, branchCode={}, departmentCode={}, currency={}", 
                 transactionInfoRequestBean.getCompanyCode(), transactionInfoRequestBean.getBranchCode(), 
                 transactionInfoRequestBean.getDepartmentCode(), transactionInfoRequestBean.getCurrency());
    }

    private void enhanceStandardTransactionInfoRequest(
        TransactionInfoRequestBean transactionInfoRequestBean, 
        Object document, 
        AtAccountTransactionHeaderBean headerBean, 
        String transactionType) {
        
        // Preserve shipmentId and consolNo values already set from JSON extraction
        
        // Populate fields from transaction document JSON
        try {
            transactionInfoRequestBean.setTransactionType(transactionType);
            transactionInfoRequestBean.setBillDate(JsonPath.using(configWithoutException).parse(document).read("$.TransactionDate"));
            transactionInfoRequestBean.setCurrency(JsonPath.using(configWithoutException).parse(document).read("$.Oscurrency.Code"));
        } catch (Exception e) {
            log.warn("Failed to extract some fields from transaction document for standard transaction", e);
        }
        
        // Populate fields from header bean
        transactionInfoRequestBean.setCompanyCode(headerBean.getCompanyCode());
        transactionInfoRequestBean.setBranchCode(headerBean.getCompanyBranch());  
        transactionInfoRequestBean.setDepartmentCode(headerBean.getCompanyDepartment());
        
        // For standard transactions, set debiter info same as buyer (consistent with NONJOB behavior)
        transactionInfoRequestBean.setDebiterCode(transactionInfoRequestBean.getBuyerCode());
        transactionInfoRequestBean.setDebiterName(transactionInfoRequestBean.getBuyerName());
        
        log.debug("Enhanced standard TransactionInfoRequestBean with companyCode={}, branchCode={}, departmentCode={}, currency={}",
                 transactionInfoRequestBean.getCompanyCode(), transactionInfoRequestBean.getBranchCode(),
                 transactionInfoRequestBean.getDepartmentCode(), transactionInfoRequestBean.getCurrency());
    }

    /**
     * Simple data class to hold Job.Key extraction result
     */
    private static class JobKeyExtractionResult {
        private final String extractedValue;
        private final String extractionSource;

        public JobKeyExtractionResult(String extractedValue, String extractionSource) {
            this.extractedValue = extractedValue;
            this.extractionSource = extractionSource;
        }

        public String getExtractedValue() {
            return extractedValue;
        }

        public String getExtractionSource() {
            return extractionSource;
        }
    }

    /**
     * Extract Job.Key with two-level fallback for NONJOB transactions.
     *
     * This utility method implements the standard extraction pattern:
     * - Primary: TransactionInfo.Job.Key (when Job.Type == "Job")
     * - Fallback: DataSourceCollection.DataSource[Type='AccountingInvoice'].Key
     *
     * @param allDocument Full JSON document root
     * @param debugMsg Debug message accumulator
     * @param fieldName Field name for logging (e.g., "shipmentId", "ref_no")
     * @return JobKeyExtractionResult containing extracted value and source, or null if extraction failed
     */
    private JobKeyExtractionResult extractJobKeyWithFallback(Object allDocument, ArrayList<String> debugMsg, String fieldName) {
        String rawKey = null;
        String extractionSource = null;

        // Primary Path: Try Job.Key extraction
        try {
            String jobType = JsonPath.using(configWithoutException).parse(allDocument)
                .read("$.Body.UniversalTransaction.TransactionInfo.Job.Type", String.class);

            if ("Job".equals(jobType)) {
                String jobKey = JsonPath.using(configWithoutException).parse(allDocument)
                    .read("$.Body.UniversalTransaction.TransactionInfo.Job.Key", String.class);

                if (StringUtils.isNotBlank(jobKey)) {
                    rawKey = jobKey;
                    extractionSource = "TransactionInfo.Job.Key";
                    debugMsg.add(logMessage(String.format("%s primary extraction from Job.Key: [%s]", fieldName, rawKey)));
                } else {
                    debugMsg.add(logMessage(String.format("%s has Job.Type='Job' but Job.Key is blank/null - will try fallback", fieldName)));
                }
            } else {
                debugMsg.add(logMessage(String.format("%s Job.Type is [%s], not 'Job' - will try fallback extraction", fieldName, jobType)));
            }
        } catch (Exception e) {
            debugMsg.add(logMessage(String.format("%s Job.Key extraction failed (field may not exist): %s - will try fallback", fieldName, e.getMessage())));
        }

        // Fallback Path: Try DataSourceCollection extraction
        if (StringUtils.isBlank(rawKey)) {
            try {
                List<String> accountingInvoiceKeys = JsonPath.using(configWithoutException).parse(allDocument)
                    .read("$.Body.UniversalTransaction.TransactionInfo.DataContext.DataSourceCollection.DataSource[?(@.Type=='AccountingInvoice')].Key");

                if (accountingInvoiceKeys != null && !accountingInvoiceKeys.isEmpty()) {
                    rawKey = accountingInvoiceKeys.get(0);
                    extractionSource = "DataSourceCollection[Type='AccountingInvoice']";
                    debugMsg.add(logMessage(String.format("%s fallback extraction from DataSourceCollection: [%s]", fieldName, rawKey)));

                    if (accountingInvoiceKeys.size() > 1) {
                        debugMsg.add(logMessage(String.format("Warning: Multiple AccountingInvoice entries found (%d), using first match", accountingInvoiceKeys.size())));
                    }
                } else {
                    debugMsg.add(logMessage(String.format("%s fallback: No DataSource with Type='AccountingInvoice' found", fieldName)));
                }
            } catch (Exception e) {
                debugMsg.add(logMessage(String.format("%s fallback extraction failed: %s", fieldName, e.getMessage())));
            }
        }

        // Return result
        if (StringUtils.isNotBlank(rawKey)) {
            return new JobKeyExtractionResult(rawKey, extractionSource);
        } else {
            debugMsg.add(logMessage(String.format("%s: Both primary (Job.Key) and fallback (DataSourceCollection) extraction failed", fieldName)));
            return null;
        }
    }
}