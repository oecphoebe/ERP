package oec.lis.erpportal.addon.compliance.transaction.impl;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.exception.CwAccountTransactionHeaderNotFoundException;
import oec.lis.erpportal.addon.compliance.exception.NotSupportedTransactionException;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.sopl.common.model.CommonRestApiResponse;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class TransactionBatchProcessor {

    // Configure JsonPath to suppress exceptions
    private final Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

    private final TransactionQueryService queryService;
    private final AtAccountTransactionTableService atAccountTransactionTableService;

    public TransactionBatchProcessor(
        TransactionQueryService queryService,
        AtAccountTransactionTableService atAccountTransactionTableService
    ) {
        this.queryService = queryService;
        this.atAccountTransactionTableService = atAccountTransactionTableService;
    }

    public String logMessage(String message) {
        log.debug(message);
        return message;
    }

    public CommonRestApiResponse handleUniversalTransactionBatch(String json) throws Exception {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();
        log.debug("handleUniversalTransactionBatch()");

        ArrayList<String> debugMsg = new ArrayList<>();
        CommonRestApiResponse result = new CommonRestApiResponse();

        // = Root structure
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);

        final String triggerDateString = JsonPath.read(allDocument, "$.Body.UniversalTransactionBatch.TransactionBatch.DataContext.TriggerDate");
        final String triggerReferenceString = JsonPath.using(configWithoutException).parse(allDocument).read("$.Body.UniversalTransactionBatch.TransactionBatch.DataContext.TriggerReference");

        // = Transaction structure
        List<Map<String, Object>> transactionList = JsonPath.read(allDocument, "$.Body.UniversalTransactionBatch.TransactionBatch.TransactionCollection.Transaction");

        if (transactionList != null && !transactionList.isEmpty()) {
            for (Map<String, Object> aRecord : transactionList) {
                try {
                    processTransaction(aRecord, triggerDateString, debugMsg);
                } catch (Exception e) {
                    log.error("Error processing transaction in batch: {}", e.getMessage(), e);
                    debugMsg.add(logMessage("Transaction processing error: " + e.getMessage()));
                    // Continue processing other transactions in the batch
                }
            }
        } else {
            debugMsg.add(logMessage("No transactions found in batch"));
        }

        // Profiling section
        instant = Instant.now();
        long methodEndTimeStampMillis = instant.toEpochMilli();
        debugMsg.add(logMessage(String.format("execution time = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);

        return result;
    }

    private void processTransaction(Map<String, Object> aRecord, String triggerDateString, ArrayList<String> debugMsg) throws JsonProcessingException, CwAccountTransactionHeaderNotFoundException, NotSupportedTransactionException {
        String jsonTransaction = new ObjectMapper().writeValueAsString(aRecord);
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonTransaction);

        String ledger = JsonPath.read(document, "$.Ledger");
        String transactionType = JsonPath.read(document, "$.TransactionType");
        String transactionNo = JsonPath.read(document, "$.Number");
        Boolean isCancelled = JsonPath.read(document, "$.IsCancelled");

        debugMsg.add(logMessage(String.format("Processing transaction: [%s][%s][%s][%s]", ledger, transactionType, transactionNo, isCancelled)));

        // 最終要寫入 at_account_transaction_header 的資料結構
        AtAccountTransactionHeaderBean headerBean = createTransactionHeader(document, triggerDateString, ledger, transactionType, transactionNo, isCancelled);

        // Get CW transaction info for PAY/REV transactions
        List<CwAccountTransactionInfo> cwTransactionInfoList = queryService.getCWAccountTransactionInfo(
            TransactionQueryService.QUERY_CW_ACCOUNT_TRANSACTION_INFO_PAY_REC, 
            ledger, transactionType, transactionNo, null);
        
        if (cwTransactionInfoList.isEmpty()) {
            // 找不到 cwTransactionInfoList 時, 需回傳錯誤
            String message = String.format("Cargowise AccountTransactionInfo not found for TransactionInfo.Number: [%s][%s][%s]", ledger, transactionType, transactionNo);
            debugMsg.add(logMessage(message));
            throw new CwAccountTransactionHeaderNotFoundException(message);
        } else {
            headerBean.setCwAccTransHeaderPk(cwTransactionInfoList.getFirst().getAccountTransactionHeaderPk());
        }

        processTransactionByType(headerBean, ledger, transactionType, isCancelled, transactionNo, debugMsg);
    }

    private AtAccountTransactionHeaderBean createTransactionHeader(Object document, String triggerDateString, String ledger, String transactionType, String transactionNo, Boolean isCancelled) {
        AtAccountTransactionHeaderBean headerBean = new AtAccountTransactionHeaderBean();

        headerBean.setAcctTransHeaderId(UUID.randomUUID());
        headerBean.setInvoiceNo(transactionNo);
        headerBean.setInvoiceDate(JsonPath.read(document, "$.TransactionDate"));
        headerBean.setCurrencyCode(JsonPath.read(document, "$.Oscurrency.Code"));
        headerBean.setCompanyCode(JsonPath.read(document, "$.DataContext.Company.Code"));
        headerBean.setCompanyBranch(JsonPath.read(document, "$.Branch.Code"));
        headerBean.setCompanyDepartment(JsonPath.read(document, "$.Department.Code"));
        headerBean.setInvoiceOrgCode(JsonPath.read(document, "$.OrganizationAddress.OrganizationCode")); // 9 characters, normally; 紀錄這筆Transaction Header關聯到的Invoice對象(Creditor/Debtor)
        headerBean.setTransactionNo(JsonPath.read(document, "$.Number"));

        headerBean.setLedger(ledger); // 記錄這筆AccTransaction Header的Ledger; AR, AP, GL
        headerBean.setTransactionType(transactionType); // 記錄這筆AccTransaction Header的Transaction Type; INV, CRD, JNL, REV, PAY...
        headerBean.setCancelled(isCancelled); // 控制 尋找 at_shipment_info 的帶入參數
        headerBean.setDueDate(headerBean.getInvoiceDate());
        headerBean.setInvoiceAmount(new BigDecimal(JsonPath.parse(document).read("$.Ostotal", String.class)));
        headerBean.setOutstandingAmount(new BigDecimal(JsonPath.parse(document).read("$.OutstandingAmount", String.class)));
        headerBean.setExchangeRate(new BigDecimal(JsonPath.parse(document).read("$.ExchangeRate", String.class))); // AccTransactionHeader 的 AH_ExchangeRate; 幣別參照 Payment Batch Header 紀錄的幣別
        headerBean.setLocalCurrencyCode(JsonPath.read(document, "$.LocalCurrency.Code")); // 紀錄Local的幣別, 目前僅有CNY
        headerBean.setTransactionDescription(JsonPath.read(document, "$.Description")); // Transaction Header的Description
        headerBean.setTotalVatAmount(new BigDecimal(JsonPath.parse(document).read("$.Osgstvatamount", String.class))); // Transaction Header的Total VAT Amount
        headerBean.setLocalTotalVatAmount(new BigDecimal(JsonPath.parse(document).read("$.LocalVATAmount", String.class))); // Local幣別的total vat amt

        // 1. Parse the ISO8601 string
        OffsetDateTime odt = OffsetDateTime.parse(triggerDateString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);

        // 2. Convert to Instant (UTC)
        // Note: update_time uses business event timestamp to handle out-of-order webhook delivery
        headerBean.setUpdateTime(odt.toInstant());
        headerBean.setUpdateBy("CPAR");
        headerBean.setCreateBy("CPAR");

        return headerBean;
    }

    private void processTransactionByType(AtAccountTransactionHeaderBean headerBean, String ledger, String transactionType, Boolean isCancelled, String transactionNo, ArrayList<String> debugMsg) throws NotSupportedTransactionException {
        // save headerBean and linesBeanList to the database using atAccountTransactionTableService
        log.debug("at_acct_transaction_header :");
        JsonUtils.printWithJavaTimeSupport(headerBean); // etlUpdateTime is an Instant object, need different ObjectMapper for print
        
        // AP REC & PAY is_cancelled = false 時落地到 DB
        // AP REC & PAY is_cancelled = true 時，更新 at_account_transaction_header 的 is_cancelled = true
        // 有兩個方向 INV REVERSE CRD 跟 CRD REVERSE INV
        if (StringUtils.equals("AP", ledger) && "PAY_REV".contains(transactionType) && Boolean.TRUE.equals(isCancelled)) {
            updateCancelledTransaction(headerBean, ledger, transactionType, isCancelled, debugMsg);
        } else {
            String message = String.format("[%s][%s][%s] %s Not supported.", ledger, transactionType, isCancelled, transactionNo);
            log.warn(message);
            debugMsg.add(logMessage(message));
            throw new NotSupportedTransactionException(message);
        }
    }

    private void updateCancelledTransaction(AtAccountTransactionHeaderBean headerBean, String ledger, String transactionType, Boolean isCancelled, ArrayList<String> debugMsg) {
        try {
            int updated = atAccountTransactionTableService.updateAccountTransactionHeader(headerBean);
            log.debug("[{}][{}][{}] {} records updated.", ledger, transactionType, isCancelled, updated);
            debugMsg.add(logMessage(String.format("Updated %d records for cancelled transaction", updated)));
        } catch (Exception e) {
            log.error("Error updating cancelled transaction: {}", e.getMessage(), e);
            debugMsg.add(logMessage("Error updating cancelled transaction: " + e.getMessage()));
            throw new RuntimeException("Failed to update cancelled transaction", e);
        }
    }
}