package oec.lis.erpportal.addon.compliance.schedule;

import java.util.Map;
import java.util.Objects;

public record DataRecord(String id, Map<String, Object> attributes) {
    // Compact Constructor for validation/normalization
    // Runs *before* the canonical constructor assigns fields
    // Optional: Add a compact constructor for validation or defensive copying
    public DataRecord { // Note: No parameter list!
        Objects.requireNonNull(id, "id cannot be null");
        // Ensure attributes map is non-null and store an immutable copy
        // attributes = (attributes == null) ? Map.of() : Map.copyOf(attributes);
        // Ensure the passed map is not null and create an immutable copy
        attributes = Map.copyOf(Objects.requireNonNull(attributes, "Data map cannot be null"));
    }

    // Example instance method
    public boolean hasAttribute(String key) {
        return this.attributes.containsKey(key);
    }

    public Object setAttribute(String key, Object value) {
        return this.attributes.put(key, value);
    }

    public Object getAttribute(String key) {
        return this.attributes.get(key);
    }

    public <T> T getAttribute(String key, Class<T> type) {
        Object value = this.attributes.get(key);
        if (value != null && type.isInstance(value)) {
            return type.cast(value);
        }
        // throw new ClassCastException("Attribute " + key + " is not of type " + type.getName());
        return null;
    }

    // You can also add static methods or non-canonical constructors
    // (which must delegate to the canonical constructor using this(...))
    public static DataRecord createEmpty(String id) {
        return new DataRecord(id, Map.of()); // Delegates to canonical constructor
    }
}


