package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrganizationAddress {
    @JsonProperty("AddressType")
    private String addressType;

    @JsonProperty("AdditionalAddressInformation")
    private String additionalAddressInformation;

    @JsonProperty("Address1")
    private String address1;

    @JsonProperty("Address2")
    private String address2;

    @JsonProperty("AddressOverride")
    private boolean addressOverride;

    @JsonProperty("AddressShortCode")
    private String addressShortCode;

    @JsonProperty("City")
    private String city;

    @JsonProperty("CompanyName")
    private String companyName;

    @JsonProperty("Contact")
    private String contact;

    @JsonProperty("Country")
    private CodeName country;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Fax")
    private boolean fax;

    @JsonProperty("OrganizationCode")
    private String organizationCode;

    @JsonProperty("Phone")
    private boolean phone;

    @JsonProperty("Port")
    private CodeName port;

    @JsonProperty("PostCode")
    private int postCode;

    @JsonProperty("ScreeningStatus")
    private CodeDescription screeningStatus;

    @JsonProperty("State")
    private ValueString state;

    @JsonProperty("RegistrationNumberCollection")
    private RegistrationNumberCollection registrationNumberCollection;
    
}
