package oec.lis.erpportal.addon.compliance.model.transaction;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BuyerInfo {
    private String organizationCode;
    private String companyName;
    private String address1;
    private String address2;
    private String phone;
    private String email;
    private String bankName;
    private String bankAccount;
    
    // Additional properties for test compatibility
    private String buyerReference;
    private String buyerName;
}
