package oec.lis.erpportal.addon.compliance.transaction;

import oec.lis.erpportal.addon.compliance.model.outbound.TransactionOutbound;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.sopl.common.model.CommonRestApiResponse;
import oec.lis.sopl.common.model.RestListResponse;

public interface TransactionService {
    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadRaw(String json) throws Exception;
    public CommonRestApiResponse handleUniversalTransactionBatch(String json) throws Exception;
    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadStrategy(String json) throws Exception;
}
