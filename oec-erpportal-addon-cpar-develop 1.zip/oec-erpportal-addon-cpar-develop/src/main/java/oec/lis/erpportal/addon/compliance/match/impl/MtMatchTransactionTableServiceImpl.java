package oec.lis.erpportal.addon.compliance.match.impl;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.match.MtMatchTransactionTableService;
import oec.lis.erpportal.addon.compliance.model.transaction.MtMatchTransactionHeaderBean;

@Service
@Slf4j
public class MtMatchTransactionTableServiceImpl implements MtMatchTransactionTableService {

    private final NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    private static final String SQL_FIND_BY_MATCH_NO =
        "SELECT * FROM mt_match_transaction_header WHERE match_no = :matchNo";

    private static final String SQL_UPDATE_MATCH_STATUS =
        "UPDATE mt_match_transaction_header " +
        "SET mt_cw_status = :statusCode, " +
        "    update_by = :updateBy, " +
        "    update_time = :updateTime " +
        "WHERE match_no = :matchNo";

    private static final String SQL_INSERT_HISTORY =
        "INSERT INTO mt_match_transaction_header_history (" +
        "    mt_chg_time, match_trans_header_id, match_no, match_status_code, " +
        "    edit_status_code, msg_code, post_time, cmpny_code, cmpny_branch, " +
        "    pay_to_org_code, match_offset_date, match_description, match_type, " +
        "    match_ref_no, pymt_type, bank_acct, check_book_code, check_no, " +
        "    crncy_code, offset_amt, local_crncy_code, local_paid_amt, " +
        "    local_offset_amt, local_diff_amt, exchg_rate, remark, " +
        "    create_cmpny, create_branch, create_dept, create_by, create_time, " +
        "    update_cmpny, update_branch, update_dept, update_by, update_time, " +
        "    cw_match_no, check_drawer, check_bank, check_branch, post_date, " +
        "    match_flow, match_click_time, src_sys, mt_cw_status" +
        ") VALUES (" +
        "    now(), :matchTransHeaderId, :matchNo, :matchStatusCode, " +
        "    :editStatusCode, :msgCode, :postTime, :cmpnyCode, :cmpnyBranch, " +
        "    :payToOrgCode, :matchOffsetDate, :matchDescription, :matchType, " +
        "    :matchRefNo, :pymtType, :bankAcct, :checkBookCode, :checkNo, " +
        "    :crncyCode, :offsetAmt, :localCrncyCode, :localPaidAmt, " +
        "    :localOffsetAmt, :localDiffAmt, :exchgRate, :remark, " +
        "    :createCmpny, :createBranch, :createDept, :createBy, :createTime, " +
        "    :updateCmpny, :updateBranch, :updateDept, :updateBy, :updateTime, " +
        "    :cwMatchNo, :checkDrawer, :checkBank, :checkBranch, :postDate, " +
        "    :matchFlow, :matchClickTime, :srcSys, :mtCwStatus" +
        ")";

    public MtMatchTransactionTableServiceImpl(NamedParameterJdbcTemplate soplNamedJdbcTemplate) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    /**
     * Converts Instant to java.sql.Timestamp with null safety
     * @param instant The Instant to convert
     * @return Timestamp or null if instant is null
     */
    private java.sql.Timestamp toTimestamp(Instant instant) {
        return instant != null ? java.sql.Timestamp.from(instant) : null;
    }

    /**
     * Converts java.util.Date to java.sql.Date with null safety
     * @param date The Date to convert
     * @return java.sql.Date or null if date is null
     */
    private java.sql.Date toSqlDate(java.util.Date date) {
        return date != null ? new java.sql.Date(date.getTime()) : null;
    }

    @Override
    public Optional<MtMatchTransactionHeaderBean> findByMatchNo(String matchNo) {
        log.debug("findByMatchNo() matchNo = [{}]", matchNo);

        try {
            MtMatchTransactionHeaderBean result = soplNamedJdbcTemplate.queryForObject(
                SQL_FIND_BY_MATCH_NO,
                Map.of("matchNo", matchNo),
                new BeanPropertyRowMapper<>(MtMatchTransactionHeaderBean.class)
            );
            return Optional.ofNullable(result);
        } catch (EmptyResultDataAccessException e) {
            log.debug("No match transaction found for matchNo: {}", matchNo);
            return Optional.empty();
        } catch (Exception e) {
            log.error("Error finding match transaction by matchNo: {}", matchNo, e);
            return Optional.empty();
        }
    }

    @Override
    public int updateCargoWiseStatus(String matchNo, String statusCode, String updateBy) {
        log.info("updateCargoWiseStatus() matchNo = [{}], statusCode = [{}], updateBy = [{}]",
                 matchNo, statusCode, updateBy);

        try {
            MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("matchNo", matchNo)
                .addValue("statusCode", statusCode)
                .addValue("updateBy", updateBy)
                .addValue("updateTime", toTimestamp(Instant.now()));

            int rowsUpdated = soplNamedJdbcTemplate.update(SQL_UPDATE_MATCH_STATUS, params);

            if (rowsUpdated > 0) {
                log.info("Successfully updated match status for matchNo: {} to status: {}",
                         matchNo, statusCode);
            } else {
                log.warn("No rows updated for matchNo: {}. Match number may not exist.", matchNo);
            }

            return rowsUpdated;
        } catch (Exception e) {
            log.error("Error updating match status for matchNo: {}", matchNo, e);
            throw new RuntimeException("Failed to update match status for matchNo: " + matchNo, e);
        }
    }

    @Override
    public void saveToHistory(MtMatchTransactionHeaderBean bean) {
        log.info("saveToHistory() matchNo = [{}]", bean.getMatchNo());

        try {
            MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("matchTransHeaderId", bean.getMatchTransHeaderId())
                .addValue("matchNo", bean.getMatchNo())
                .addValue("matchStatusCode", bean.getMatchStatusCode())
                .addValue("editStatusCode", bean.getEditStatusCode())
                .addValue("msgCode", bean.getMsgCode())
                .addValue("postTime", toTimestamp(bean.getPostTime()))
                .addValue("cmpnyCode", bean.getCmpnyCode())
                .addValue("cmpnyBranch", bean.getCmpnyBranch())
                .addValue("payToOrgCode", bean.getPayToOrgCode())
                .addValue("matchOffsetDate", toSqlDate(bean.getMatchOffsetDate()))
                .addValue("matchDescription", bean.getMatchDescription())
                .addValue("matchType", bean.getMatchType())
                .addValue("matchRefNo", bean.getMatchRefNo())
                .addValue("pymtType", bean.getPymtType())
                .addValue("bankAcct", bean.getBankAcct())
                .addValue("checkBookCode", bean.getCheckBookCode())
                .addValue("checkNo", bean.getCheckNo())
                .addValue("crncyCode", bean.getCrncyCode())
                .addValue("offsetAmt", bean.getOffsetAmt())
                .addValue("localCrncyCode", bean.getLocalCrncyCode())
                .addValue("localPaidAmt", bean.getLocalPaidAmt())
                .addValue("localOffsetAmt", bean.getLocalOffsetAmt())
                .addValue("localDiffAmt", bean.getLocalDiffAmt())
                .addValue("exchgRate", bean.getExchgRate())
                .addValue("remark", bean.getRemark())
                .addValue("createCmpny", bean.getCreateCmpny())
                .addValue("createBranch", bean.getCreateBranch())
                .addValue("createDept", bean.getCreateDept())
                .addValue("createBy", bean.getCreateBy())
                .addValue("createTime", toTimestamp(bean.getCreateTime()))
                .addValue("updateCmpny", bean.getUpdateCmpny())
                .addValue("updateBranch", bean.getUpdateBranch())
                .addValue("updateDept", bean.getUpdateDept())
                .addValue("updateBy", bean.getUpdateBy())
                .addValue("updateTime", toTimestamp(bean.getUpdateTime()))
                .addValue("cwMatchNo", bean.getCwMatchNo())
                .addValue("checkDrawer", bean.getCheckDrawer())
                .addValue("checkBank", bean.getCheckBank())
                .addValue("checkBranch", bean.getCheckBranch())
                .addValue("postDate", toTimestamp(bean.getPostDate()))
                .addValue("matchFlow", bean.getMatchFlow())
                .addValue("matchClickTime", toTimestamp(bean.getMatchClickTime()))
                .addValue("srcSys", bean.getSrcSys())
                .addValue("mtCwStatus", bean.getMtCwStatus());

            soplNamedJdbcTemplate.update(SQL_INSERT_HISTORY, params);
            log.info("Successfully saved match transaction to history for matchNo: {}", bean.getMatchNo());
        } catch (Exception e) {
            log.error("Error saving match transaction to history for matchNo: {}", bean.getMatchNo(), e);
            throw new RuntimeException("Failed to save match transaction to history: " + bean.getMatchNo(), e);
        }
    }
}
