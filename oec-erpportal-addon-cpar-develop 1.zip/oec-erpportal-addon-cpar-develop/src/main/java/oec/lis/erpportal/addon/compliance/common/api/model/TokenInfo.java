package oec.lis.erpportal.addon.compliance.common.api.model;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TokenInfo {
    /**
     * Token string for specific API
     */
    private String token;
    /**
     * Expiry time in milliseconds since epoch
     */
    private Instant expiryTime;

}
