package oec.lis.erpportal.addon.compliance.match;

import oec.lis.erpportal.addon.compliance.model.transaction.MtMatchTransactionHeaderBean;
import java.util.Optional;

public interface MtMatchTransactionTableService {
    /**
     * Find match transaction header by match number
     * @param matchNo the match number to search for
     * @return Optional containing the match transaction header if found
     */
    Optional<MtMatchTransactionHeaderBean> findByMatchNo(String matchNo);

    /**
     * Update the match status for a given match number
     * @param matchNo the match number to update
     * @param statusCode the new mt_cw_status code (e.g., "Unmatch", "Reversed")
     * @param updateBy the user/system updating the record
     * @return number of rows updated (should be 1 if successful, 0 if not found)
     */
    int updateCargoWiseStatus(String matchNo, String statusCode, String updateBy);

    /**
     * Save match transaction header to history table
     * @param bean the match transaction header to archive
     */
    void saveToHistory(MtMatchTransactionHeaderBean bean);
}
