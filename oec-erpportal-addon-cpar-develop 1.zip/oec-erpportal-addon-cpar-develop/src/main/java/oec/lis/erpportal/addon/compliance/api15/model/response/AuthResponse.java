package oec.lis.erpportal.addon.compliance.api15.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {
    private String statusCode;
    // @JsonProperty("accessToken") // for temporary local test use
    private String data;
    private boolean succeeded;
    private String errors;
    // @JsonProperty("expiresIn") // for temporary local test use
    private long timestamp;

    @JsonIgnore
    private long expiresIn = 300; // default 300 seconds
}
