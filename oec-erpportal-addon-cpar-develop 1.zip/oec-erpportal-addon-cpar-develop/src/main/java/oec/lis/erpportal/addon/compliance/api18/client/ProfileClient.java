package oec.lis.erpportal.addon.compliance.api18.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import oec.lis.erpportal.addon.compliance.api18.config.ErpportalFeignConfig;

@FeignClient(name = "profileClient", url = "${external.profile.url}", configuration = ErpportalFeignConfig.class)
public interface ProfileClient {
    @GetMapping("/profile/v1/account/get/{userId}")
    public Object getAccount(
        @RequestHeader("userKey") String userKeyForService,
        @PathVariable("userId") String userId
    );
}
