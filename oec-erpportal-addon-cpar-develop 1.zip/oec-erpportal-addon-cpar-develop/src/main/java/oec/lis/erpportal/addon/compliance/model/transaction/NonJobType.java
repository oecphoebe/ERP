package oec.lis.erpportal.addon.compliance.model.transaction;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Enum defining the two types of NONJOB transactions.
 *
 * NONJOB transactions are transactions not associated with any job/shipment.
 * There are two distinct subtypes based on their source data structure in Cargowise:
 *
 * <h3>JOB_INVOICE Type:</h3>
 * <ul>
 *   <li>Has JobInvoiceNumber value in UniversalTransaction payload</li>
 *   <li>AccTransactionLines records exist in Cargowise database</li>
 *   <li>Uses AL_PK directly as cw_acct_trans_lines_pk for uniqueness</li>
 *   <li>Queries Cargowise WITH organizationCode filter</li>
 *   <li>Typical example: Job-related invoices without shipment reference</li>
 * </ul>
 *
 * <h3>GL_ACCOUNT Type:</h3>
 * <ul>
 *   <li>NO JobInvoiceNumber value (null or missing in payload)</li>
 *   <li>AccTransactionLines records may NOT exist in Cargowise database</li>
 *   <li>Uses composite key (header_PK + PostingJournal_index) when AL_PK is NULL</li>
 *   <li>Queries Cargowise WITHOUT organizationCode filter (no org association)</li>
 *   <li>Processes ALL returned rows as separate line records</li>
 *   <li>Populates data from PostingJournal array in payload</li>
 *   <li>Typical example: General ledger entries, manual corrections</li>
 * </ul>
 *
 * @see RefNoInfo
 */
@Slf4j
public enum NonJobType {
    /**
     * Job-Invoice type NONJOB transaction.
     * Has JobInvoiceNumber and AccTransactionLines exists in Cargowise.
     */
    JOB_INVOICE,

    /**
     * GL-Account type NONJOB transaction.
     * No JobInvoiceNumber and AccTransactionLines may not exist in Cargowise.
     */
    GL_ACCOUNT;

    /**
     * Detects the NonJob type from UniversalTransaction JSON payload.
     *
     * Detection Logic:
     * <ul>
     *   <li>If JobInvoiceNumber exists and is not blank → JOB_INVOICE type</li>
     *   <li>If JobInvoiceNumber is null/missing/blank → GL_ACCOUNT type</li>
     * </ul>
     *
     * @param json UniversalTransaction JSON payload
     * @return NonJobType - either JOB_INVOICE or GL_ACCOUNT
     */
    public static NonJobType detectFromPayload(String json) {
        // Configure JsonPath to suppress exceptions and return null for missing paths
        Configuration config = Configuration.builder()
            .options(Option.SUPPRESS_EXCEPTIONS, Option.DEFAULT_PATH_LEAF_TO_NULL)
            .build();

        try {
            // Extract JobInvoiceNumber from UniversalTransaction.TransactionInfo
            String jobInvoiceNumber = JsonPath.using(config)
                .parse(json)
                .read("$.Body.UniversalTransaction.TransactionInfo.JobInvoiceNumber", String.class);

            if (StringUtils.isNotBlank(jobInvoiceNumber)) {
                log.info("NonJob type detected: JOB_INVOICE (JobInvoiceNumber={})", jobInvoiceNumber);
                return JOB_INVOICE;
            } else {
                log.info("NonJob type detected: GL_ACCOUNT (JobInvoiceNumber is null/missing/blank)");
                return GL_ACCOUNT;
            }
        } catch (Exception e) {
            // If any error occurs during extraction, default to GL_ACCOUNT (safer option)
            log.warn("Error detecting NonJob type from payload, defaulting to GL_ACCOUNT: {}", e.getMessage());
            return GL_ACCOUNT;
        }
    }
}
