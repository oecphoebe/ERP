package oec.lis.erpportal.addon.compliance.common.api.config;

import java.io.IOException;

import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.api.service.TokenService;
import oec.lis.erpportal.addon.compliance.common.api.util.FeignUtil;

@Slf4j
public class TokenExpirationErrorDecoder implements ErrorDecoder {
    private final ErrorDecoder defaultDecoder = new Default();
    private final TokenService tokenService;
    
    public TokenExpirationErrorDecoder(TokenService tokenService) {
        this.tokenService = tokenService;
    }
    
    @Override
    public Exception decode(String methodKey, Response response) {
        log.debug("TokenExpirationErrorDecoder.decode() called for methodKey: {}", methodKey);
        log.debug("Response status: {}", response.status());
        if (response.status() == 401) {
            try {
                String responseBody = FeignUtil.toString(response);
                if (responseBody.contains("token expired") || responseBody.contains("invalid token")) {
                    log.info("Token has expired. Actively refresh token.");
                    tokenService.getValidToken();
                }
            } catch (IOException e) {
                // Fall through to default handler
            }
        }
        return defaultDecoder.decode(methodKey, response);
    }
}