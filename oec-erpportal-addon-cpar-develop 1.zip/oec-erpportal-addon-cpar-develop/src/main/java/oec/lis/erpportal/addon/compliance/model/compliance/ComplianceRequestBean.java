package oec.lis.erpportal.addon.compliance.model.compliance;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.util.DateTimeUtil;

@Data
@Slf4j
public class ComplianceRequestBean {

    @NotNull(message = "complianceId must not null")
    private UUID complianceId;

    @NotBlank(message = "complianceNo must not be blank")
    private String complianceNo;

    @NotBlank(message = "complianceDate must not be blank")
    private String complianceDate; // 接收外部資料的變數

    @Hidden private java.util.Date complianceDateDate; // 寫入資料表時之變數

    @NotBlank(message = "createCompany must not be blank")
    private String createCompany;

    @NotBlank(message = "createBranch must not be blank")
    private String createBranch;

    @NotBlank(message = "createDepartment must not be blank")
    private String createDepartment;

    private String createBy;

    private String createTime; // 接收外部資料的變數

    @Hidden private java.sql.Timestamp createTimeTimeStamp; // 寫入資料表時之變數

    @Hidden private String updateCompany;
    @Hidden private String updateBranch;
    @Hidden private String updateDepartment;
    @Hidden private String updateBy;
    @Hidden private String updateTime;

    @NotBlank(message = "complianceCode must not be blank")
    private String complianceCode;

    @Hidden private String buyerBranch;
    @Hidden private String vendorOrgCode;

    @NotBlank(message = "currencyCode must not be blank")
    private String currencyCode;

    private BigDecimal amount;

    private String remark;

    @Hidden private String sourceSystem = "CPAR";
    @Hidden private UUID complianceAcctTransHeaderLineLinkId = UUID.randomUUID();

    @NotBlank
    private String accountTransactionNo;

    @NotNull(message = "accountTransactionLinesId must not null")
    private UUID accountTransactionLinesId;

    private String statusCode = "C";

    private BigDecimal taxAmount;

    private BigDecimal excludeTaxAmount;

    @Hidden private String externalSyncStatus = "";
    @Hidden private String externalSyncTime = "";

    private BigDecimal exchangeRate;

    private String invoiceNote; // 2025/05/23 加上, 要寫入 compliance_rmk 欄位

    @JsonProperty("action")
    @NotBlank(message = "action must not be blank")
    private String action;

    public void setComplianceDate( String complianceDate ) {
        this.complianceDate = complianceDate;
        if(StringUtils.isNotBlank(complianceDate)) {
            this.complianceDateDate = DateTimeUtil.convertToDate(complianceDate);
        }
    }

    public void setCreateTime( String createTime ) {
        this.createTime = createTime;
        if(StringUtils.isNotBlank(createTime)) {
            this.createTimeTimeStamp = DateTimeUtil.convertToTimeStamp(createTime);
        } else {
            this.createTimeTimeStamp = java.sql.Timestamp.from(Instant.now());
        }
    }

    public void setAction( String action ) {
        this.action = action;
        this.sourceSystem = this.sourceSystem + "-" + action;
        log.debug("sourceSystem = [{}]", this.sourceSystem);
    }
}
