package oec.lis.erpportal.addon.compliance.common.kafka;

import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

import java.util.HashMap;
import java.util.Map;

@Configuration
@Slf4j
public class MultipleKafkaProducerConfig {

    @Value("${kafka.enabled:true}")
    private boolean kafkaEnabled;

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${kafka.username}")
    private String username;

    @Value("${kafka.password}")
    private String password;

    @Value("${spring.kafka.properties.security.protocol:NONE}")
    private String authenticationRequied;

    // Common Producer Configuration Properties
    private Map<String, Object> commonProducerConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        // Security Config
        log.debug("spring.kafka.properties.security.protocol = [{}]", authenticationRequied);
        if (!StringUtils.equals(authenticationRequied, "NONE")) {
            props.put("sasl.jaas.config", "org.apache.kafka.common.security.scram.ScramLoginModule required username=\"" + username + "\" password=\"" + password + "\";"); // other options can be used org.apache.kafka.common.security.plain.PlainLoginModule
            props.put("sasl.mechanism", "SCRAM-SHA-256");
            props.put("security.protocol", "SASL_PLAINTEXT");
        }
        // Other common producer properties like acks, retries, batch.size, etc. can go here
        props.put(ProducerConfig.RECONNECT_BACKOFF_MS_CONFIG, 1000);
        props.put(ProducerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG, 10000);
        props.put(ProducerConfig.RETRIES_CONFIG, 3);
        return props;
    }

    // --- Configuration for TransactionChargeLineRequestBean ---

    @Bean
    @ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
    public ProducerFactory<String, TransactionChargeLineRequestBean> invoiceProducerFactory() {
        Map<String, Object> props = commonProducerConfigs();
        // Value serializer specifically for TransactionChargeLineRequestBean
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        // Optional: Configure JsonSerializer if needed (e.g., type mapping)
        // props.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false); // Example
        props.put(JsonSerializer.TYPE_MAPPINGS, 
        "invoice:oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean, retry-invoice:oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord"
        // "greeting:com.baeldung.spring.kafka.Greeting, farewell:com.baeldung.spring.kafka.Farewell"
        );
        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean("invoiceKafkaTemplate") // Give it a specific name
    @ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
    public KafkaTemplate<String, TransactionChargeLineRequestBean> invoiceKafkaTemplate() {
        return new KafkaTemplate<>(invoiceProducerFactory());
    }

    // --- Configuration for RetryRecord ---

    @Bean
    @ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
    public ProducerFactory<String, RetryRecord> retryProducerFactory() {
        Map<String, Object> props = commonProducerConfigs();
        // Value serializer specifically for RetryRecord
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        // Optional: Configure JsonSerializer differently if needed for RetryRecord
        props.put(JsonSerializer.TYPE_MAPPINGS, 
        "retry-invoice:oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord"
        // "greeting:com.baeldung.spring.kafka.Greeting, farewell:com.baeldung.spring.kafka.Farewell"
        );
        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean("retryKafkaTemplate") // Give it a specific name
    @ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
    public KafkaTemplate<String, RetryRecord> retryKafkaTemplate() {
        return new KafkaTemplate<>(retryProducerFactory());
    }

}