package oec.lis.erpportal.addon.compliance.model.transaction;

import lombok.Data;

@Data
public class PostingJournal {
    private String chargeCode;
    private int sequence;
    private String taxCode;
    private int taxRate;
}
