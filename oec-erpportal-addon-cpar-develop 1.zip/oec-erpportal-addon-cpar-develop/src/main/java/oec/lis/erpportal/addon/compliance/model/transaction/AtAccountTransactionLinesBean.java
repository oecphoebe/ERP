package oec.lis.erpportal.addon.compliance.model.transaction;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.jayway.jsonpath.JsonPath;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AtAccountTransactionLinesBean {

    // CREATE TABLE sopl.at_account_transaction_lines (
    //     acc_trans_lines_id uuid NOT NULL,
    //     acct_trans_header_id uuid NOT NULL, -- 
    //     cw_acct_trans_lines_pk uuid NULL, -- 
    //     chrg_code_id uuid NULL, -- 
    //     crncy_code varchar(3) NULL,
    //     chrg_amt numeric(19, 4) NULL, -- 
    //     vat_amt numeric(19, 4) NULL, -- 
    //     total_amt numeric(19, 4) NULL, -- 
    //     exchg_rate numeric(18, 9) NULL, -- 
    //     local_crncy_code varchar(3) NULL, -- 
    //     local_vat_amt numeric(19, 4) NULL, -- 
    //     cmpny_code varchar(3) NULL, -- 
    //     cmpny_branch varchar(3) NULL, -- 
    //     cmpny_dept varchar(3) NULL, -- 
    //     CONSTRAINT pk_at_account_transaction_lines_acc_trans_lines_id PRIMARY KEY (acc_trans_lines_id)
    // );

    public AtAccountTransactionLinesBean(AtAccountTransactionHeaderBean headerBean, TransactionChargeLineRequestBean requestBean) {
        this.accountTransactionLinesId = UUID.randomUUID();
        this.accountTransactionHeaderId = headerBean.getAcctTransHeaderId(); // 紀錄該AccTransaction Lines是位於哪一個AccTransaction Header底下
        // this.cwAccountTransactionLinesPk; // CW內AccTransaction Lines 的 PK
        // this.chargeCodeId; // 該AccTransaction Line的CW Charge Code ID
        // this.currencyCode;
        this.chargeAmount = requestBean.getPrice(); // 對應至CW AccTransactionLines的AL_OSAmount
        this.vatAmount = BigDecimal.ZERO; // 對應至CW AccTransactionLines的AL_GSTVAT  --> SellOSGSTVATAmount
        this.totalAmount = requestBean.getAmount(); // 對應至CW AccTransactionLines的AL_LineAmount --> SellLocalAmount
        // this.exchangeRate; // 對應至CW AccTransactionLines的AL_ExchangeRate
        // this.localCurrencyCode; // 紀錄Local的幣別, 目前僅有CNY
        this.localVatAmount = BigDecimal.ZERO;; // Local幣別的VAT Amount --> SellPostedTransaction.OutstandingAmount - SellLocalAmount
        this.companyCode = headerBean.getCompanyCode(); // 紀錄Transantion Line所屬的Company
        this.companyBranch = headerBean.getCompanyBranch(); // 紀錄Transantion Line所屬的Branch
        this.companyDept = headerBean.getCompanyDepartment(); // 紀錄Transantion Line所屬的Department
    }

    public AtAccountTransactionLinesBean(
        final AtAccountTransactionHeaderBean headerBean, 
        final String jsonChargeLine, 
        final String jsonPathChargeLineOSAmount, 
        final String jsonPathChargeLineOsGstVatAmount,
        final String jsonPathChargeLineLocalAmount,
        final String jsonPathChargeLineOSCurrencyCode, 
        final String jsonPathChargeLineExchangeRate
    ) {
        this.accountTransactionLinesId = UUID.randomUUID();
        this.accountTransactionHeaderId = headerBean.getAcctTransHeaderId(); // 紀錄該AccTransaction Lines是位於哪一個AccTransaction Header底下
        // this.cwAccountTransactionLinesPk; // CW內AccTransaction Lines 的 PK
        // this.chargeCodeId; // 該AccTransaction Line的CW Charge Code ID

        BigDecimal outstandingAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOSAmount, String.class));
        BigDecimal outstandingGSTVatAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOsGstVatAmount, String.class));
        BigDecimal localAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineLocalAmount, String.class));
        BigDecimal chargeLineexchangeRate = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineExchangeRate, String.class));

        // Apply (-1) multiplication only for AP ledger, AR uses positive amounts
        BigDecimal multiplier = "AP".equals(headerBean.getLedger()) ? new BigDecimal(-1) : BigDecimal.ONE;
        
        this.chargeAmount = outstandingAmount.add(outstandingGSTVatAmount).multiply(multiplier); // 原幣含稅金額 // 對應至CW AccTransactionLines的AL_OSAmount --> SellOSAmount // 20250604 從 requestBean.getPrice();  改成新的定義
        this.vatAmount = outstandingGSTVatAmount.multiply(multiplier); // 原幣稅額(使用 al_gstvat/exchangeRate計算出來) // 對應至CW AccTransactionLines的AL_GSTVAT // 20250604 從 BigDecimal.ZERO 改成新的定義
        this.totalAmount = localAmount.multiply(multiplier); // 本幣未稅金額(CW 的 al_LineAmount) // 對應至CW AccTransactionLines的AL_LineAmount // 20250604 從 requestBean.getAmount(); 改成新的定義
        this.localVatAmount = outstandingGSTVatAmount.multiply(chargeLineexchangeRate).multiply(multiplier).setScale(2, RoundingMode.HALF_UP); // 本幣的稅額VAT Amount // 20250604 從 BigDecimal.ZERO 改成新的定義
        
        this.companyCode = headerBean.getCompanyCode(); // 紀錄Transantion Line所屬的Company
        this.companyBranch = headerBean.getCompanyBranch(); // 紀錄Transantion Line所屬的Branch
        this.companyDept = headerBean.getCompanyDepartment(); // 紀錄Transantion Line所屬的Department

        this.setCurrencyCode(JsonPath.read(jsonChargeLine,jsonPathChargeLineOSCurrencyCode));
        this.setExchangeRate(chargeLineexchangeRate); // 對應至CW AccTransactionLines的AL_ExchangeRate
        // 紀錄Local的幣別, 目前僅有CNY --> 原本從 cw_global_company.crncy_code where by json branch of this charge line 但 consol cost line 沒有此結構，改為直接抓 CostOSCurrency.Code
        this.setLocalCurrencyCode(JsonPath.parse(jsonChargeLine).read("$.CostOSCurrency.Code", String.class));
        this.setTransactionLineDescription(JsonPath.read(jsonChargeLine,"$.ChargeCode.Description"));
    }

    private UUID accountTransactionLinesId;
    private UUID accountTransactionHeaderId; // 紀錄該AccTransaction Lines是位於哪一個AccTransaction Header底下
    private UUID cwAccountTransactionLinesPk; // CW內AccTransaction Lines 的 PK
    private UUID chargeCodeId; // 該AccTransaction Line的CW Charge Code ID
    private String currencyCode;
    private BigDecimal chargeAmount; // 對應至CW AccTransactionLines的AL_OSAmount
    private BigDecimal vatAmount; // 對應至CW AccTransactionLines的AL_GSTVAT
    private BigDecimal totalAmount; // 對應至CW AccTransactionLines的AL_LineAmount
    private BigDecimal exchangeRate; // 對應至CW AccTransactionLines的AL_ExchangeRate
    private String localCurrencyCode; // 紀錄Local的幣別, 目前僅有CNY
    private BigDecimal localVatAmount; // Local幣別的VAT Amount
    private String companyCode; // 紀錄Transantion Line所屬的Company
    private String companyBranch; // 紀錄Transantion Line所屬的Branch
    private String companyDept; // 紀錄Transantion Line所屬的Department
    private int displaySequence=0; // 用來核對 CW-DB 查出來的 Sequence 定位資料
    // field name = trans_line_desc
    private String transactionLineDescription;
}
