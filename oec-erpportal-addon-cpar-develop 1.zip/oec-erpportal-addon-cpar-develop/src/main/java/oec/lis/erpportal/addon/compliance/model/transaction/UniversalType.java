package oec.lis.erpportal.addon.compliance.model.transaction;

public enum UniversalType {
    UNIVERSAL_TRANSACTION,
    UNIVERSAL_TRANSACTION_BATCH,
}
