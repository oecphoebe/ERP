package oec.lis.erpportal.addon.compliance.common.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * Configuration for transaction routing decisions.
 * Determines whether transactions should be sent to external systems based on configurable rules.
 */
@Component
@ConfigurationProperties(prefix = "transaction.routing")
@Data
public class TransactionRoutingConfig {
    
    /**
     * Enable legacy mode for backward compatibility.
     * When true: Only AR transactions are sent to external system (current behavior).
     * When false: Use configured rules to determine routing.
     * Default: true
     */
    private boolean enableLegacyMode = true;
    
    /**
     * List of routing rules to determine external system routing.
     * Used when enableLegacyMode is false.
     */
    private List<RoutingRule> rules = new ArrayList<>();
    
    /**
     * Routing rule definition for a specific ledger and transaction type combination.
     */
    @Data
    public static class RoutingRule {
        /**
         * Transaction ledger (AR, AP)
         */
        private String ledger;
        
        /**
         * Transaction type (INV, CRD)
         */
        private String transactionType;
        
        /**
         * Whether to send this transaction type to external system
         */
        private boolean sendToExternalSystem;
        
        /**
         * Description of this rule for audit logging purposes
         */
        private String description;
    }
    
    /**
     * Determines if a transaction should be sent to external system based on configuration.
     * 
     * @param ledger Transaction ledger (AR, AP)
     * @param transactionType Transaction type (INV, CRD)
     * @return true if transaction should be sent to external system, false otherwise
     */
    public boolean shouldSendToExternal(String ledger, String transactionType) {
        if (enableLegacyMode) {
            // Legacy behavior: only AR transactions go to external system
            return "AR".equals(ledger);
        }
        
        // Configuration-based routing
        return rules.stream()
            .filter(rule -> rule.getLedger().equals(ledger) 
                && rule.getTransactionType().equals(transactionType))
            .findFirst()
            .map(RoutingRule::isSendToExternalSystem)
            .orElse(false); // Default to not sending if no rule matches
    }
    
    /**
     * Finds the description for a matching rule.
     * 
     * @param ledger Transaction ledger
     * @param transactionType Transaction type
     * @return Rule description or "No matching rule" if not found
     */
    public String findRuleDescription(String ledger, String transactionType) {
        return rules.stream()
            .filter(rule -> rule.getLedger().equals(ledger) 
                && rule.getTransactionType().equals(transactionType))
            .findFirst()
            .map(RoutingRule::getDescription)
            .orElse("No matching rule");
    }
}