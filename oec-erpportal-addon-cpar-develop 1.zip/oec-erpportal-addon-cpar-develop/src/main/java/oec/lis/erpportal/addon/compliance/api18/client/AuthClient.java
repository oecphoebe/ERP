package oec.lis.erpportal.addon.compliance.api18.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import oec.lis.erpportal.addon.compliance.api18.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api18.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.config.BasicFeignConfig;

@FeignClient(name = "erpPortalAuthClient", url = "${external.erpportal.url}", configuration = BasicFeignConfig.class) // FeignConfigFactory.BasicConfig.class
public interface AuthClient {
    @PostMapping("/rest/token")
    AuthResponse authenticate(@RequestBody AuthRequest request);
}
