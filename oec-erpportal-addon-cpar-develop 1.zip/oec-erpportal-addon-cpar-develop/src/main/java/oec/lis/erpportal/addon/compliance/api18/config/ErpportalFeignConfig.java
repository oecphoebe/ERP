package oec.lis.erpportal.addon.compliance.api18.config;

import org.springframework.context.annotation.Bean;

import feign.Logger;
import feign.RequestInterceptor;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api18.service.ErpPortalTokenService;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenAuthInterceptor;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenExpirationErrorDecoder;

@Slf4j
public class ErpportalFeignConfig {

    @Bean
    public RequestInterceptor requestInterceptor(ErpPortalTokenService tokenService) {
        log.debug("requestInterceptor() Creating ErpPortal Feign RequestInterceptor for token authentication");
        return new TokenAuthInterceptor(tokenService);
    }

    @Bean
    public ErrorDecoder errorDecoder(ErpPortalTokenService tokenService) {
        return new TokenExpirationErrorDecoder(tokenService);
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }
}
