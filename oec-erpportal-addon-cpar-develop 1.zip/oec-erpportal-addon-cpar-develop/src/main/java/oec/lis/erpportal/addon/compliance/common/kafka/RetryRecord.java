package oec.lis.erpportal.addon.compliance.common.kafka;

import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

@Data
@NoArgsConstructor
public class RetryRecord implements Serializable{
    private UUID actionId;
    private TransactionChargeLineRequestBean request;
    private int attempt;
    private Instant nextAttempt;

    public RetryRecord(TransactionChargeLineRequestBean request) {
        this.request = request;
    }
}
