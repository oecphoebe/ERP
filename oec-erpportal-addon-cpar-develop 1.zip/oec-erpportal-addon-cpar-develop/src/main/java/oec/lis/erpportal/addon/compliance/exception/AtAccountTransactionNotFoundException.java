package oec.lis.erpportal.addon.compliance.exception;

public class AtAccountTransactionNotFoundException extends Exception {
    public AtAccountTransactionNotFoundException(String message) {
        super(message);
    }

    public AtAccountTransactionNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public AtAccountTransactionNotFoundException(Throwable cause) {
        super(cause);
    }

}
