package oec.lis.erpportal.addon.compliance.match;

import oec.lis.sopl.common.model.CommonRestApiResponse;

/**
 * Service for processing match transactions from Cargowise Universal Transaction Batch
 */
public interface MatchTransactionService {
    /**
     * Process Universal Transaction Batch payload and update match transaction statuses
     *
     * @param json the JSON payload containing UniversalTransactionBatch
     * @return CommonRestApiResponse with processing results
     * @throws Exception if processing fails
     */
    CommonRestApiResponse processUniversalTransactionBatch(String json) throws Exception;
}
