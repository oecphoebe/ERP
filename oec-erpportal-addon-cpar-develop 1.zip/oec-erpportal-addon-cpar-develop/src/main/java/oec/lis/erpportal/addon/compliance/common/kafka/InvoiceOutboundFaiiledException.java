package oec.lis.erpportal.addon.compliance.common.kafka;

public class InvoiceOutboundFaiiledException extends Exception {
    public InvoiceOutboundFaiiledException(String message) {
        super(message);
    }

    public InvoiceOutboundFaiiledException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvoiceOutboundFaiiledException(Throwable cause) {
        super(cause);
    }
    
}
