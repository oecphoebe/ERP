package oec.lis.erpportal.addon.compliance.model.transaction;

import java.math.BigDecimal;
import java.util.UUID;

import lombok.Data;

@Data
public class CwAccountTransactionInfo {
    private UUID accountTransactionHeaderPk;
    private int displaySequence;
    private String jobNumber;
    private UUID accountTransactionLinesPk;
    private UUID accountChargeCodePk;
    private String chargeCode;      // acc.AC_Code - Charge code (DOC, FRT, etc.) for Job-Invoice type
    private String glAccount;       // ag.AG_AccountNum - GL account number for GL-Account type
    private boolean isUsed;
    private String creditor;
    private String invoiceNo;
    
    // New fields for NONJOB line-level data from AccTransactionLines
    private BigDecimal osAmount;        // AL_OSAmount from AccTransactionLines
    private BigDecimal gstVatAmount;    // AL_GSTVAT from AccTransactionLines
    private BigDecimal lineAmount;      // AL_LineAmount from AccTransactionLines
    private BigDecimal exchangeRate;    // AL_ExchangeRate from AccTransactionLines
    private String currencyCode;        // AL_RX_NKTransactionCurrency from AccTransactionLines
}
