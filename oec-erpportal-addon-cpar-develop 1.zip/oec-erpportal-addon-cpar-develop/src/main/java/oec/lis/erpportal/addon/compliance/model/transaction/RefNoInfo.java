package oec.lis.erpportal.addon.compliance.model.transaction;

import lombok.Data;

/**
 * Reference number information for transactions
 * 
 * refNoType possible values:
 * - "SHIPMENT": Transaction associated with a direct shipment
 * - "CONSOL": Transaction associated with a consolidated shipment  
 * - "NONJOB": Transaction not associated with any job/shipment
 * 
 * NONJOB Implementation:
 * NONJOB refNoType is automatically assigned when:
 * 1. Database query returns empty results from cw_account_transaction_ref_no, OR
 * 2. Query returns records where both refNo and refNoType are null
 * 
 * NONJOB transactions represent charges not tied to specific shipments or consols:
 * - Administrative fees and adjustments
 * - Manual accounting corrections
 * - General ledger entries without shipment context
 * - Direct cost allocations
 * 
 * Processing characteristics:
 * - Charges extracted from PostingJournalCollection instead of ShipmentCollection
 * - Validation focuses on charge-level matching (chargeCode, creditor, invoiceNo)
 * - Skips shipment-based validations and processing paths
 */
@Data
public class RefNoInfo {
    private String refNo;
    private String refNoType;
    private String jobHeader;
}
