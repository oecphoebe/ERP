package oec.lis.erpportal.addon.compliance.common.api.exception;

public class BadTokenException extends Exception {
    public BadTokenException(String message) {
        super(message);
    }

    public BadTokenException(String message, Throwable cause) {
        super(message, cause);
    }

    public BadTokenException(Throwable cause) {
        super(cause);
    }

}
