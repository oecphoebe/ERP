package oec.lis.erpportal.addon.compliance.common.api.service;

public interface TokenService {
    public String getValidToken();
}
