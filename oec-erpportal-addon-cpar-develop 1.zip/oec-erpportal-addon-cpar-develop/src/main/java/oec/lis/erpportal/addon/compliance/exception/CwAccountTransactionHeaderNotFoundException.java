package oec.lis.erpportal.addon.compliance.exception;

public class CwAccountTransactionHeaderNotFoundException extends Exception {
    public CwAccountTransactionHeaderNotFoundException(String message) {
        super(message);
    }

    public CwAccountTransactionHeaderNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public CwAccountTransactionHeaderNotFoundException(Throwable cause) {
        super(cause);
    }

}
