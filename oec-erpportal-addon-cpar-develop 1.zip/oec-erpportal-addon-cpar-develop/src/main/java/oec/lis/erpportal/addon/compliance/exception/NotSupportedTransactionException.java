package oec.lis.erpportal.addon.compliance.exception;

public class NotSupportedTransactionException extends Exception {
    public NotSupportedTransactionException(String message) {
        super(message);
    }

    public NotSupportedTransactionException(String message, Throwable cause) {
        super(message, cause);
    }

    public NotSupportedTransactionException(Throwable cause) {
        super(cause);
    }

}
