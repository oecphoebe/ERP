package oec.lis.erpportal.addon.compliance.schedule;

import java.util.List;

public record ComparisonResult(
    List<DataRecord> sourceData,
    List<DataRecord> targetData,
    List<DataRecord> missingInSource
) {

}
