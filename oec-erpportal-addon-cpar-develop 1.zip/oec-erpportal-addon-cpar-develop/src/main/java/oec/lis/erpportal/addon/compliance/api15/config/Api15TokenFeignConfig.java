package oec.lis.erpportal.addon.compliance.api15.config;

import org.springframework.context.annotation.Bean;

import feign.Logger;
import feign.RequestInterceptor;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api15.service.API15TokenService;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenAuthInterceptor;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenExpirationErrorDecoder;

@Slf4j
public class Api15TokenFeignConfig {

    @Bean
    public RequestInterceptor requestInterceptor(API15TokenService tokenService) {
        log.debug("requestInterceptor() Creating Compliance Feign RequestInterceptor for token authentication");
        // return new TokenRefreshInterceptor(tokenService);
        return new TokenAuthInterceptor(tokenService);
    }

    @Bean
    public ErrorDecoder errorDecoder(API15TokenService tokenService) {
        // return new TokenExpirationAwareErrorDecoder(tokenService);
        return new TokenExpirationErrorDecoder(tokenService);
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }
}
