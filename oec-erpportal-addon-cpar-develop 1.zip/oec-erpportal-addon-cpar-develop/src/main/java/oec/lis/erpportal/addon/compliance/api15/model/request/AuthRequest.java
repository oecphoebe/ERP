package oec.lis.erpportal.addon.compliance.api15.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthRequest {
    // @JsonProperty("clientId") // for temporary local test use
    private final String userId;
    // @JsonProperty("secret") // for temporary local test use
    private final String password;

    public static AuthRequest getAuthRequest( String userId, String password ) {
        return new AuthRequest(userId, password);
    }

    private AuthRequest( String userId, String password ) {
        this.userId = userId;
        this.password = password;
    }
}
