package oec.lis.erpportal.addon.compliance.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * Configuration for NONJOB transaction processing.
 * Controls whether transactions without shipment/consol references are supported.
 */
@Component
@ConfigurationProperties(prefix = "transaction.nonjob")
@Data
public class NonJobTransactionConfig {
    
    /**
     * Enable NONJOB transaction processing.
     * When false: NONJOB transactions will be rejected with HTTP 400.
     * When true: NONJOB transactions will be processed normally.
     * Default: false (disabled - must be explicitly enabled)
     */
    private boolean enabled = false;
    
    /**
     * Error message returned when NONJOB is disabled.
     * Default: "NONJOB transactions are not supported in this environment"
     */
    private String errorMessage = "NONJOB transactions are not supported in this environment";
}