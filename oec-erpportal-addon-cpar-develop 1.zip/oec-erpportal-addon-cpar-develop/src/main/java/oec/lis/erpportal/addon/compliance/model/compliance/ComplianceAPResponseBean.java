package oec.lis.erpportal.addon.compliance.model.compliance;

import java.math.BigDecimal;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;

@Data
public class ComplianceAPResponseBean {


    @Hidden
    @JsonIgnore
    private UUID complianceId;
    /**
     * 税票发票号码 
     */
    private String complianceNo;
    /**
     * 税票日期 
     */
    private String complianceDate;
    /**
     * 税票日期+30天 
     */
    private String complianceDatePlus;
    /**
     * 税票卖方 org code
     */
    private String supplierCompanyOrgCode;
    /**
     * 税票卖方抬头 
     */
    private String supplierCompanyName;
    /**
     * BRANCH = buyer_branch
     */
    private String settleBranch;
    /**
     * 买方名称 
     */
    private String settleCompanyName;
    /**
     * 原幣税票税额 = compliance_taxamt
     */
    private BigDecimal taxAmountFor;
    /**
     * 原幣税票不含税金额 = compliance_extaxamt
     */
    private BigDecimal noTaxAmountFor;
    /**
     * 稅票幣別 = crncy_code
     */
    private String currencyCode;
    /**
     * 開票匯率 = compliance_exrate
     */
    private BigDecimal exchangeRate;
    /**
     * 本幣稅票含稅金額 = compliance_local_amt
     */
    private BigDecimal localAmountFor;
}
