package oec.lis.erpportal.addon.compliance.model.outbound;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TransactionInfo {
    @JsonProperty("DataContext")
    private DataContext dataContext;

    @JsonProperty("ArAccountGroup")
    private CodeDescription arAccountGroup;

    @JsonProperty("Branch")
    private CodeName branch;

    @JsonProperty("BranchAddress")
    private OrganizationAddress branchAddress;

    @JsonProperty("Category")
    private String category;

    @JsonProperty("CheckDrawer")
    private boolean checkDrawer;

    @JsonProperty("CheckNumberOrDrawerRef")
    private boolean checkNumberOrDrawerRef;

    @JsonProperty("ComplianceSubType")
    private String complianceSubType;

    @JsonProperty("CreateTime")
    private String createTime;

    @JsonProperty("CreateUser")
    private ValueString createUser;

    @JsonProperty("Department")
    private CodeName department;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("DrawerBank")
    private boolean drawerBank;
    @JsonProperty("DrawerBranch")
    private boolean drawerBranch;

    @JsonProperty("DueDate")
    private String duedate;

    @JsonProperty("ExchangeRate")
    private BigDecimal exchangeRate;
    @JsonProperty("FullyPaidDate")
    private String fullypaiddate;

    @JsonProperty("InvoiceTerm")
    private String invoiceTerm;

    @JsonProperty("InvoiceTermDays")
    private int invoiceTermDays;
    @JsonProperty("IsCancelled")
    private boolean isCancelled;

    @JsonProperty("IsCreatedByMatchingProcess")
    private boolean isCreatedByMatchingProcess;

    @JsonProperty("IsPrinted")
    private boolean isPrinted;

    @JsonProperty("Job")
    private TypeKey job;

    @JsonProperty("JobInvoiceNumber")
    private String jobInvoiceNumber;

    @JsonProperty("Ledger")
    private String ledger;

    @JsonProperty("LocalCurrency")
    private CodeDescription localCurrency;

    @JsonProperty("LocalExVatAmount")
    private BigDecimal localExVatAmount;
    @JsonProperty("LocalTaxTransactionsAmount")
    private BigDecimal localTaxTransactionsAmount;
    @JsonProperty("LocalTotal")
    private BigDecimal localTotal;
    @JsonProperty("LocalVatAmount")
    private BigDecimal localVatAmount;

    @JsonProperty("Number")
    private String number;

    @JsonProperty("NumberOfSupportingDocuments")
    private int numberOfSupportingDocuments;

    @JsonProperty("OrganizationAddress")
    private OrganizationAddress organizationAddress;

    @JsonProperty("Oscurrency")
    private CodeDescription osCurrency;

    @JsonProperty("OsexGSTVATAmount")
    private BigDecimal osExGSTVATAmount;
    @JsonProperty("Osgstvatamount")
    private BigDecimal osGstVatAmount;
    @JsonProperty("OstaxTransactionsAmount")
    private BigDecimal osTaxTransactionsAmount;
    @JsonProperty("Ostotal")
    private BigDecimal osTotal;
    @JsonProperty("OsVatAmount")
    private BigDecimal outstandingAmount;

    @JsonProperty("PlaceOfIssue")
    private String placeOfIssue;
    @JsonProperty("PostDate")
    private String postDate;

    @JsonProperty("ReceiptOrDirectDebitNumber")
    private boolean receiptOrDirectDebitNumber;
    @JsonProperty("RequisitionStatus")
    private boolean requisitionStatus;

    @JsonProperty("TransactionDate")
    private String transactionDate;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("PostingJournalCollection")
    private PostingJournalCollection postingJournalCollection;

    // private MessageNumberCollection messageNumberCollection;
    @JsonProperty("ShipmentCollection")
    private ShipmentCollection shipmentCollection;
}
