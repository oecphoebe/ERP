package oec.lis.erpportal.addon.compliance.model.transaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AtAccountTransactionHeaderBean {

    // CREATE TABLE sopl.at_account_transaction_header (
    //     acct_trans_header_id uuid NOT NULL,
    //     ref_no varchar(20) NULL, -- 
    //     cw_acc_trans_header_pk uuid NULL, -- 
    //     ledger varchar(3) NULL, -- 
    //     trans_type varchar(3) NULL, -- 
    //     inv_no varchar(38) NULL,
    //     inv_date date NULL, -- Invoice Date
    //     due_date date NULL,
    //     crncy_code varchar(3) NULL,
    //     inv_amt numeric(19, 4) NULL, -- Invoice Amount
    //     outstanding_amt numeric(19, 4) NULL,
    //     cmpny_dept varchar(3) NULL, -- 
    //     exchg_rate numeric(18, 9) NULL, -- 
    //     inv_org_code varchar(12) NULL, -- 
    //     local_crncy_code varchar(3) NULL, -- 
    //     cmpny_branch varchar(3) NULL, -- 
    //     trans_desc varchar(128) NULL, -- 
    //     total_vat_amt numeric(19, 4) NULL, -- 
    //     local_total_vat_amt numeric(19, 4) NULL, -- 
    //     cmpny_code varchar(3) NULL, -- 
    //     trans_no varchar(38) NULL, -- 
    //     is_cancel bool DEFAULT false NOT NULL,
    //     create_by varchar(50) NULL,
    //     create_time timestamp NULL,
    //     update_by varchar(50) NULL,
    //     update_time timestamp NULL,
    //     CONSTRAINT pk_at_account_transaction_header_acct_trans_header_id PRIMARY KEY (acct_trans_header_id)
    // );

    public AtAccountTransactionHeaderBean(TransactionInfoRequestBean requestBean) {
        this.acctTransHeaderId = UUID.randomUUID();
        // this.refNo; // AccTransactionHeader關聯到的Shipment No 或 Consol No
        // this.cwAccTransHeaderPk; // 來自於CW AccTransactionHeader的PK
        // this.ledger = "AR"; // 記錄這筆 AccTransaction Header是AR or AP 20250423 改由外面設定
        // this.transactionType; // 記錄這筆AccTransaction Header的Transaction Type; REV, INV, CRD...
        // this.invoiceNo; // 2025/05/29 改由 TranactionInfo.JobInvoiceNumber 取得
        this.invoiceDate = requestBean.getBillDate();
        // this.dueDate;
        this.currencyCode = requestBean.getCurrency();
        // this.invoiceAmount;
        // this.outstandingAmount;
        this.companyDepartment = requestBean.getDepartmentCode(); // 紀錄Transantion Header 所屬的 Department
        // this.exchangeRate; // AccTransactionHeader 的 AH_ExchangeRate; 幣別參照 Payment Batch Header 紀錄的幣別
        this.invoiceOrgCode = requestBean.getDebiterCode(); // 9 characters, normally; 紀錄這筆Transaction Header關聯到的Invoice對象(Creditor/Debtor)
        // this.localCurrencyCode; // 紀錄Local的幣別, 目前僅有CNY
        this.companyBranch = requestBean.getBranchCode(); // 紀錄Transantion Header所屬的Branch
        // this.transactionDescription; // Transaction Header的Description
        // this.totalVatAmount; // Transaction Header的Total VAT Amount
        // this.localTotalVatAmount; // Local幣別的total vat amt
        this.companyCode = requestBean.getCompanyCode(); // 紀錄Transantion Header所屬的Company
        this.transactionNo = requestBean.getBillNo(); //AccTransactionHeader的Trans No
    }

    private UUID acctTransHeaderId;
    private String refNo; // AccTransactionHeader關聯到的Shipment No 或 Consol No
    private UUID cwAccTransHeaderPk; // 來自於CW AccTransactionHeader的PK
    private String ledger; // 記錄這筆 AccTransaction Header是AR or AP
    private String transactionType; // 記錄這筆AccTransaction Header的Transaction Type; REV, INV, CRD...
    private String invoiceNo;
    private String invoiceDate;
    private String dueDate;
    private String currencyCode;
    private BigDecimal invoiceAmount;
    private BigDecimal outstandingAmount;
    private String companyDepartment; // 紀錄Transantion Header 所屬的 Department
    private BigDecimal exchangeRate; // AccTransactionHeader 的 AH_ExchangeRate; 幣別參照 Payment Batch Header 紀錄的幣別
    private String invoiceOrgCode; // 9 characters, normally; 紀錄這筆Transaction Header關聯到的Invoice對象(Creditor/Debtor)
    private String localCurrencyCode; // 紀錄Local的幣別, 目前僅有CNY
    private String companyBranch; // 紀錄Transantion Header所屬的Branch
    private String transactionDescription; // Transaction Header的Description
    private BigDecimal totalVatAmount; // Transaction Header的Total VAT Amount
    private BigDecimal localTotalVatAmount; // Local幣別的total vat amt
    private String companyCode; // 紀錄Transantion Header所屬的Company
    private String transactionNo; //AccTransactionHeader的Trans No
    private String chequeOrReference; // AR transaction sell reference field, max 38 characters
    private UUID matchTransHeaderId; // Links to mt_match_transaction_header

    private boolean isCancelled;
    // private LocalDateTime etlCreateTime;
    private String createBy; // 記錄建立這筆 invoice 記錄的系統 or 使用者
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "UTC")
    private Instant createTime;
    private String updateBy; // 記錄更新這筆 invoice 記錄的系統 or 使用者
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "UTC")
    private Instant updateTime;

}
