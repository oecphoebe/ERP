package oec.lis.erpportal.addon.compliance.match.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.match.MatchNumberExtractor;
import oec.lis.erpportal.addon.compliance.match.MatchTransactionService;
import oec.lis.erpportal.addon.compliance.match.MtMatchTransactionTableService;
import oec.lis.erpportal.addon.compliance.model.transaction.MtMatchTransactionHeaderBean;
import oec.lis.sopl.common.model.CommonRestApiResponse;

@Service
@Slf4j
public class MatchTransactionServiceImpl implements MatchTransactionService {

    private final MtMatchTransactionTableService matchTransactionTableService;

    public MatchTransactionServiceImpl(MtMatchTransactionTableService matchTransactionTableService) {
        this.matchTransactionTableService = matchTransactionTableService;
    }

    @Override
    public CommonRestApiResponse processUniversalTransactionBatch(String json) throws Exception {
        log.info("Processing Universal Transaction Batch for match transactions");

        CommonRestApiResponse response = new CommonRestApiResponse();
        List<String> messages = new ArrayList<>();
        Map<String, Object> processingResults = new LinkedHashMap<>();

        int totalTransactions = 0;
        int unmatchCount = 0;
        int reverseCount = 0;
        int skippedCount = 0;
        int errorCount = 0;

        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        try {
            // Parse the JSON to extract transactions
            Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);

            // Extract transaction array from UniversalTransactionBatch structure
            List<Map<String, Object>> transactions = JsonPath.using(lenientConfig)
                .parse(document)
                .read("$.Body.UniversalTransactionBatch.TransactionBatch.TransactionCollection.Transaction");

            if (transactions == null || transactions.isEmpty()) {
                log.warn("No transactions found in payload");
                messages.add("No transactions found in UniversalTransactionBatch payload");
                response.setStatus("NO_DATA");
                response.setMsg(messages);
                return response;
            }

            totalTransactions = transactions.size();
            log.info("Found {} transactions to process", totalTransactions);

            // Process each transaction
            for (int i = 0; i < transactions.size(); i++) {
                Map<String, Object> transaction = transactions.get(i);
                try {
                    String result = processTransaction(transaction, i);
                    messages.add(result);

                    // Count by result type
                    if (result.contains("UNMATCH")) {
                        unmatchCount++;
                    } else if (result.contains("REVERSE")) {
                        reverseCount++;
                    } else if (result.contains("SKIPPED")) {
                        skippedCount++;
                    }
                } catch (Exception e) {
                    errorCount++;
                    String errorMsg = String.format("Error processing transaction #%d: %s", i, e.getMessage());
                    log.error(errorMsg, e);
                    messages.add(errorMsg);
                }
            }

            // Build processing summary
            processingResults.put("totalTransactions", totalTransactions);
            processingResults.put("unmatchUpdates", unmatchCount);
            processingResults.put("reverseUpdates", reverseCount);
            processingResults.put("skipped", skippedCount);
            processingResults.put("errors", errorCount);

            // Add summary to messages
            messages.add("PROCESSING_SUMMARY: " + processingResults.toString());

            // Determine overall status
            if (errorCount > 0) {
                response.setStatus("PARTIAL");
            } else if (unmatchCount + reverseCount > 0) {
                response.setStatus("SUCCESS");
            } else {
                response.setStatus("NO_UPDATES");
            }

            response.setMsg(messages);

            log.info("Processing complete: {}", processingResults);

        } catch (Exception e) {
            log.error("Fatal error processing UniversalTransactionBatch", e);
            response.setStatus("ERROR");
            messages.add("Fatal error: " + e.getMessage());
            response.setMsg(messages);
            throw e;
        }

        return response;
    }

    /**
     * Process a single transaction and determine if it's UNMATCH or REVERSE
     */
    private String processTransaction(Map<String, Object> transaction, int index) {
        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        // Extract key fields directly from transaction map
        String ledger = JsonPath.using(lenientConfig).parse(transaction).read("$.Ledger");
        String transactionType = JsonPath.using(lenientConfig).parse(transaction).read("$.TransactionType");
        String transactionNo = JsonPath.using(lenientConfig).parse(transaction).read("$.Number");
        Boolean isCancelled = JsonPath.using(lenientConfig).parse(transaction).read("$.IsCancelled");

        log.info("Transaction #{}: Ledger={}, Type={}, Number={}, IsCancelled={}",
                 index, ledger, transactionType, transactionNo, isCancelled);

        // Only process AP PAY and AP REC transactions
        if (!"AP".equals(ledger) || (!"PAY".equals(transactionType) && !"REC".equals(transactionType))) {
            String msg = String.format("Transaction #%d SKIPPED: Not AP PAY or AP REC (Ledger=%s, Type=%s)",
                                       index, ledger, transactionType);
            log.info(msg);
            return msg;
        }

        // Check if this is a REVERSE transaction (IsCancelled = true)
        if (isCancelled != null && isCancelled) {
            return processReverseTransaction(transaction, transactionNo, index);
        } else {
            return processUnmatchTransaction(transaction, transactionNo, index);
        }
    }

    /**
     * Process UNMATCH transaction: OutstandingAmount == Ostotal
     */
    private String processUnmatchTransaction(Map<String, Object> transaction, String transactionNo, int index) {
        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        // Extract OutstandingAmount and Ostotal
        Object outstandingAmtObj = JsonPath.using(lenientConfig).parse(transaction).read("$.OutstandingAmount");
        Object ostotalObj = JsonPath.using(lenientConfig).parse(transaction).read("$.Ostotal");

        BigDecimal outstandingAmount = convertToBigDecimal(outstandingAmtObj);
        BigDecimal ostotal = convertToBigDecimal(ostotalObj);

        log.debug("Transaction #{}: OutstandingAmount={}, Ostotal={}", index, outstandingAmount, ostotal);

        // Check if OutstandingAmount == Ostotal (indicating UNMATCH scenario)
        if (outstandingAmount != null && ostotal != null &&
            outstandingAmount.compareTo(ostotal) == 0) {

            // Extract match number from CheckNumberOrPaymentRef
            String checkNumberOrPaymentRef = JsonPath.using(lenientConfig)
                .parse(transaction).read("$.CheckNumberOrPaymentRef");

            String matchNo = MatchNumberExtractor.extractFromCheckNumber(checkNumberOrPaymentRef);

            if (matchNo == null) {
                String msg = String.format("Transaction #%d SKIPPED: Cannot extract match number from CheckNumberOrPaymentRef=%s",
                                           index, checkNumberOrPaymentRef);
                log.warn(msg);
                return msg;
            }

            // Update match status to UNMATCH
            int rowsUpdated = matchTransactionTableService.updateCargoWiseStatus(matchNo, "Unmatch", "CPAR-MT");

            if (rowsUpdated > 0) {
                // Archive to history after successful update
                Optional<MtMatchTransactionHeaderBean> updatedBean =
                    matchTransactionTableService.findByMatchNo(matchNo);
                updatedBean.ifPresent(bean -> matchTransactionTableService.saveToHistory(bean));

                String msg = String.format("Transaction #%d UNMATCH: Updated matchNo=%s to status Unmatch",
                                           index, matchNo);
                log.info(msg);
                return msg;
            } else {
                String msg = String.format("Transaction #%d WARNING: Match number %s not found in database",
                                           index, matchNo);
                log.warn(msg);
                return msg;
            }
        } else {
            String msg = String.format("Transaction #%d SKIPPED: Not an UNMATCH scenario (OutstandingAmount=%s, Ostotal=%s)",
                                       index, outstandingAmount, ostotal);
            log.info(msg);
            return msg;
        }
    }

    /**
     * Process REVERSE transaction: IsCancelled == true
     */
    private String processReverseTransaction(Map<String, Object> transaction, String transactionNo, int index) {
        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        // First try to extract match number from CheckNumberOrPaymentRef (primary method)
        String checkNumberOrPaymentRef = JsonPath.using(lenientConfig)
            .parse(transaction).read("$.CheckNumberOrPaymentRef");

        String matchNo = MatchNumberExtractor.extractFromCheckNumber(checkNumberOrPaymentRef);

        // If not found in CheckNumberOrPaymentRef, fall back to Description field
        if (matchNo == null) {
            log.debug("Match number not found in CheckNumberOrPaymentRef, trying Description field");
            String description = JsonPath.using(lenientConfig).parse(transaction).read("$.Description");
            matchNo = MatchNumberExtractor.extractFromDescription(description);

            if (matchNo != null) {
                log.info("Match number extracted from Description (fallback): {}", matchNo);
            }
        } else {
            log.debug("Match number extracted from CheckNumberOrPaymentRef: {}", matchNo);
        }

        if (matchNo == null) {
            String msg = String.format("Transaction #%d SKIPPED: Cannot extract match number from CheckNumberOrPaymentRef or Description",
                                       index);
            log.warn(msg);
            return msg;
        }

        // Update match status to REVERSED
        int rowsUpdated = matchTransactionTableService.updateCargoWiseStatus(matchNo, "Reverse", "CPAR-MT");

        if (rowsUpdated > 0) {
            // Archive to history after successful update
            Optional<MtMatchTransactionHeaderBean> updatedBean =
                matchTransactionTableService.findByMatchNo(matchNo);
            updatedBean.ifPresent(bean -> matchTransactionTableService.saveToHistory(bean));

            String msg = String.format("Transaction #%d REVERSE: Updated matchNo=%s to status Reverse",
                                       index, matchNo);
            log.info(msg);
            return msg;
        } else {
            String msg = String.format("Transaction #%d WARNING: Match number %s not found in database",
                                       index, matchNo);
            log.warn(msg);
            return msg;
        }
    }

    /**
     * Helper method to convert various numeric types to BigDecimal
     */
    private BigDecimal convertToBigDecimal(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof BigDecimal) {
            return (BigDecimal) value;
        }
        if (value instanceof Number) {
            return BigDecimal.valueOf(((Number) value).doubleValue());
        }
        if (value instanceof String) {
            try {
                return new BigDecimal((String) value);
            } catch (NumberFormatException e) {
                log.warn("Cannot convert string to BigDecimal: {}", value);
                return null;
            }
        }
        log.warn("Unknown type for numeric conversion: {}", value.getClass());
        return null;
    }
}
