package oec.lis.erpportal.addon.compliance.model.compliance;

import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComplianceRequestMetaBean {

    private UUID acctTransHeaderId;
    private String ledger;
    private String transactionType;
    private String accountTransactionNo;
    private Boolean isCancel;
    private UUID complianceId;
    private String complianceNo;
    private String complianceCode;
    private String createCompany;
    private int distinctComplianceRecordsCount;
}
