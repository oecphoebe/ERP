package oec.lis.erpportal.addon.compliance.api12.config;

import org.springframework.context.annotation.Bean;

import feign.Logger;
import feign.RequestInterceptor;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api12.service.CwisTokenService;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenAuthInterceptor;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenExpirationErrorDecoder;

@Slf4j
public class CwisFeignConfig {

    @Bean
    public RequestInterceptor requestInterceptor(CwisTokenService tokenService) {
        log.debug("requestInterceptor() Creating CWIS Feign RequestInterceptor for token authentication");
        return new TokenAuthInterceptor(tokenService);
    }

    @Bean
    public ErrorDecoder errorDecoder(CwisTokenService tokenService) {
        return new TokenExpirationErrorDecoder(tokenService);
    }

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }
}
