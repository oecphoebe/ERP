package oec.lis.erpportal.addon.compliance.common.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.apachecommons.CommonsLog;
import oec.lis.erpportal.addon.compliance.common.api.exception.AuthorizationException;
import oec.lis.erpportal.addon.compliance.common.api.exception.BadTokenException;
import oec.lis.sopl.common.model.CommonRestApiResponse;

@RestControllerAdvice
@CommonsLog
public class ControllerExceptionHandler {

    /**
     * 所有非預期的 Exception fall back 到這裡
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public CommonRestApiResponse handleException(Exception ex) {
        log.error("Unexpected error occurred!", ex);

        List<String> msg = new ArrayList<>();
        msg.add(ExceptionUtils.getStackTrace(ex));
        return new CommonRestApiResponse(
            Integer.toString(HttpStatus.INTERNAL_SERVER_ERROR.value()),
            msg,
            0
            );
    }

    /**
     * 呼叫 /compliance/v1/complianceAP 時, Header 中沒有帶入 userKey 
     * @param e
     * @return
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<String> handleMissingRequestHeaderException( MissingRequestHeaderException e) {
        return ResponseEntity.badRequest().body("Missing request header. Please follow correct call-flow!");
    }

    /**
     * 呼叫 /compliance/v1/complianceAP 時, 使用者帶入的 Token 找不到 subject = clientId => 無法判斷權限
     * @param e
     * @return
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BadTokenException.class)
    public ResponseEntity<String> handleBadTokenException( BadTokenException e) {
        return ResponseEntity.badRequest().body("Bad Token format. Please check if logined correctly!");
    }

    /**
     * 呼叫 /compliance/v1/complianceAP 時, 使用者的角色清單中沒有 CPAR-QUERY-API, 不允許執行
     * @param e
     * @return
     */
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ExceptionHandler(AuthorizationException.class)
    public ResponseEntity<String> handleAuthorizationException( AuthorizationException e) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN.value()).body("Not authorized for this operation! " + e.getMessage());
    }

    /**
     * @Valid 檢核報錯時到這裡
     */
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public CommonRestApiResponse handleValidException(MethodArgumentNotValidException e) {
        List<String> msg = e.getBindingResult()
            .getAllErrors()
            .stream()
            .map(row -> {
                return row.getDefaultMessage();
            })
            .collect(Collectors.toList());

        return new CommonRestApiResponse(
            Integer.toString(HttpStatus.UNPROCESSABLE_ENTITY.value()),
            msg,
            0
            );
    }

    /**
     * SOPL 應用程式發生異常時到這裡
     */
    // @ExceptionHandler(UnauthorizedException.class)
    // public CommonRestApiResponse handleSoplException(final UnauthorizedException unauthorizedException) {
    //     log.error("UnauthorizedException occurred!", unauthorizedException);

    //     final List<String> msgList = new ArrayList<>();
    //     msgList.add(unauthorizedException.getMessage());
    //     final CommonRestApiResponse commonRestApiResponse = new CommonRestApiResponse();
    //     commonRestApiResponse.setExecTime(0);
    //     commonRestApiResponse.setStatus( String.valueOf(HttpStatus.UNAUTHORIZED.value()) );
    //     commonRestApiResponse.setMsg(msgList);
    // 	return commonRestApiResponse;
    // }

}
