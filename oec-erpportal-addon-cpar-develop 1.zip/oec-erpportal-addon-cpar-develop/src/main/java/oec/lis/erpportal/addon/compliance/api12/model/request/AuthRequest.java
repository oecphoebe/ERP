package oec.lis.erpportal.addon.compliance.api12.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthRequest {

	@JsonProperty("username")
	private String userName;

	@JsonProperty("password")
	private String password;

    public static AuthRequest getAuthRequest( String userName, String password ) {
        return new AuthRequest(userName, password);
    }

    private AuthRequest( String userId, String password ) {
        this.userName = userId;
        this.password = password;
    }
}
