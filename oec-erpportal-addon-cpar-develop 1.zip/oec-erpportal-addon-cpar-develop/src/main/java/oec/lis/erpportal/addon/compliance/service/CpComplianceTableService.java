package oec.lis.erpportal.addon.compliance.service;

import java.util.List;
import java.util.UUID;

import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPRequestBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPResponseBean;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.model.RestRequest;

public interface CpComplianceTableService {
    public List<UUID> getAccountTransactionHeaderIdByComplianceId(List<UUID> complianceId);
    public RestListResponse<ComplianceAPResponseBean> queryComplianceAPInfo( RestRequest<ComplianceAPRequestBean> model, String companyCode );
    public int batchUpdateComplianceSyncStatus(List<UUID> complianceIdList);
}
