package oec.lis.erpportal.addon.compliance.model.transaction;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.Option;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
@Slf4j
public class TransactionChargeLineRequestBean extends TransactionInfoRequestBean {
    private UUID itemGuid;
    private String itemCode;
    private String itemName;
    private String itemUnit = "";
    private int qty = 1;
    private String taxCode;
    private String zeroFlag;
    private BigDecimal discountAmt;
    private BigDecimal discountTaxAmt;
    private BigDecimal discountAmtIncludeTax;
    private BigDecimal price;
    private BigDecimal taxIncludedAmount;
    private BigDecimal amount;

    public TransactionChargeLineRequestBean(TransactionChargeLineRequestBean aRecord) {
        BeanUtils.copyProperties(aRecord, this);
    }

    public TransactionChargeLineRequestBean(TransactionInfoRequestBean aRecord) {
        BeanUtils.copyProperties(aRecord, this);
    }

    public TransactionChargeLineRequestBean(
        final TransactionInfoRequestBean aRecord, 
        final String jsonChargeLine,
        final String ledger, 
        final String jsonPathChargeLineOSAmount, 
        final String jsonPathChargeLineOSGSTVATAmount
    ) {
        this(aRecord, jsonChargeLine, ledger, jsonPathChargeLineOSAmount, jsonPathChargeLineOSGSTVATAmount, false);
    }

    public TransactionChargeLineRequestBean(
        final TransactionInfoRequestBean aRecord, 
        final String jsonChargeLine,
        final String ledger, 
        final String jsonPathChargeLineOSAmount, 
        final String jsonPathChargeLineOSGSTVATAmount,
        final boolean shouldSendToExternal
    ) {
        BeanUtils.copyProperties(aRecord, this);

        // Configure JsonPath to suppress exceptions for missing fields
        Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        // Detect if ChargeCode exists (priority for JOB_INVOICE type NonJob and standard ChargeLines)
        Object chargeCodeObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code");
        boolean hasChargeCode = chargeCodeObj != null && StringUtils.isNotBlank(chargeCodeObj.toString());

        // Detect if this is a NONJOB PostingJournal structure by looking for specific fields
        boolean isNonjobPostingJournal = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Osamount") != null;

        // Extract itemCode and itemName based on transaction type with proper prioritization
        if (hasChargeCode) {
            // JOB_INVOICE type NonJob or standard ChargeLine - use ChargeCode
            this.setItemCode(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code"));
            this.setItemName(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Description"));
            log.debug("Extracted itemCode from ChargeCode: {}, itemName: {}", this.getItemCode(), this.getItemName());
        } else if (isNonjobPostingJournal) {
            // GL_ACCOUNT type NonJob - use Glaccount (only when ChargeCode doesn't exist)
            this.setItemCode(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.AccountCode"));
            this.setItemName(JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Glaccount.Description"));
            log.debug("Extracted GL_ACCOUNT NonJob itemCode: {}, itemName: {}", this.getItemCode(), this.getItemName());
        } else {
            // Fallback to ChargeCode (for safety, should rarely happen)
            this.setItemCode(JsonPath.read(jsonChargeLine,"$.ChargeCode.Code"));
            this.setItemName(JsonPath.read(jsonChargeLine,"$.ChargeCode.Description"));
            log.debug("Fallback: Extracted itemCode from ChargeCode: {}, itemName: {}", this.getItemCode(), this.getItemName());
        }

        this.setItemUnit(null); // 放空值
        this.setQty(1); // 固定放1
        this.setZeroFlag(zeroFlag);
        this.setDiscountAmt(BigDecimal.ZERO); // 放空值 0
        this.setDiscountTaxAmt(BigDecimal.ZERO); // 放空值 0
        this.setDiscountAmtIncludeTax(BigDecimal.ZERO); // 放空值 0
        
        // Extract currency from charge-line level based on ledger type with graceful fallback to header currency
        String chargeLineCurrency = null;

        try {
            
            if (isNonjobPostingJournal) {
                // NONJOB PostingJournal uses Oscurrency.Code for currency
                Object currencyObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.Oscurrency.Code");
                chargeLineCurrency = (currencyObj instanceof String) ? (String) currencyObj : null;
                log.debug("Extracted NONJOB PostingJournal currency: {}", chargeLineCurrency);
            } else if (StringUtils.equals("AR", ledger)) {
                // AR uses SellOSCurrency.Code (sales side)
                Object currencyObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellOSCurrency.Code");
                chargeLineCurrency = (currencyObj instanceof String) ? (String) currencyObj : null;
                log.debug("Extracted AR charge-line currency: {}", chargeLineCurrency);
            } else if (StringUtils.equals("AP", ledger)) {
                // AP uses CostOSCurrency.Code (cost/vendor side)  
                Object currencyObj = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostOSCurrency.Code");
                chargeLineCurrency = (currencyObj instanceof String) ? (String) currencyObj : null;
                log.debug("Extracted AP charge-line currency: {}", chargeLineCurrency);
            }
        } catch (Exception e) {
            log.warn("Failed to extract charge-line currency for ledger {}: {}", ledger, e.getMessage());
            chargeLineCurrency = null; // Ensure null value for fallback
        }
        
        // Set currency with graceful fallback to header currency if charge-line currency is missing
        if (StringUtils.isNotBlank(chargeLineCurrency)) {
            this.setCurrency(chargeLineCurrency);
            log.debug("Using charge-line currency: {}", chargeLineCurrency);
        } else {
            log.debug("Fallback to header currency: {}", aRecord.getCurrency());
            // Currency already copied from aRecord via BeanUtils.copyProperties()
        }
        
        // Extract TaxCode for AR always, and for AP when sending to external system
        if (StringUtils.equals("AR", ledger) ||
            (StringUtils.equals("AP", ledger) && shouldSendToExternal)) {
            String taxCode;

            if (isNonjobPostingJournal) {
                // NONJOB PostingJournal uses VattaxID for tax code
                taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.VattaxID.TaxCode");
                log.debug("Extracted NONJOB PostingJournal taxCode: {}", taxCode);
            } else if (StringUtils.equals("AR", ledger)) {
                // AR uses SellGSTVATID (sales side)
                taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellGSTVATID.TaxCode");
            } else {
                // AP uses CostGSTVATID (cost/vendor side)
                taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID.TaxCode");
            }

            this.setTaxCode(taxCode != null ? taxCode : "");
        }
        BigDecimal outstandingAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOSAmount, String.class));
        if (StringUtils.equals("AP", ledger)) {
            outstandingAmount = outstandingAmount.multiply(new BigDecimal(-1));
        }
        this.setPrice(outstandingAmount);

        // Extract VAT amount and apply ledger-specific multiplier
        BigDecimal outstandingGstVatAmount = new BigDecimal(JsonPath.parse(jsonChargeLine).read(jsonPathChargeLineOSGSTVATAmount, String.class));
        if (StringUtils.equals("AP", ledger)) {
            outstandingGstVatAmount = outstandingGstVatAmount.multiply(new BigDecimal(-1));
        }

        // Calculate taxIncludedAmount based on ledger type:
        // Both AR and AP: OSAmount is net amount, so add VAT to get gross amount
        // AR: positive values (net + VAT)
        // AP: negative values (net + VAT, both already negated)
        this.setTaxIncludedAmount(outstandingAmount.add(outstandingGstVatAmount));

        // Calculate amount based on ledger type:
        // Both AR and AP: OSAmount is already net amount, use directly
        // AR: positive net amount
        // AP: negative net amount (already negated)
        this.setAmount(outstandingAmount);
    }

    public void findAndSetTaxRate(final List<PostingJournal> postingJournalList, final int displaySequence) {
        for (PostingJournal aJournal : postingJournalList) {
            if (StringUtils.equalsIgnoreCase(aJournal.getChargeCode(), this.itemCode) && aJournal.getSequence()==displaySequence ) {
                this.setTaxRate(aJournal.getTaxRate());
                break;
            }
        }
    }
}
