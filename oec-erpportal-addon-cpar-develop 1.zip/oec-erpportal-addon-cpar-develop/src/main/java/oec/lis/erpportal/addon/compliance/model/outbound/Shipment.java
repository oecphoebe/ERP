package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Shipment {
    @JsonProperty("DataContext")
    private DataContext dataContext;

    @JsonProperty("JobCosting")
    private JobCosting JobCosting;

    @JsonProperty("SubShipmentCollection")
    private SubShipmentCollection subShipmentCollection;
}
