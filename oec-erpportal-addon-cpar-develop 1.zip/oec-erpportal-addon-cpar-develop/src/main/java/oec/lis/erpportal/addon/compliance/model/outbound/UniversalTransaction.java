package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UniversalTransaction {
    @JsonProperty("TransactionInfo")
    private TransactionInfo transactionInfo;
}