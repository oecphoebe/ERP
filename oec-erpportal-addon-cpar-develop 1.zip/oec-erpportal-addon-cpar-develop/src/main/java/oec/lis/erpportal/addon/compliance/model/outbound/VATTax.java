package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VATTax {
    @JsonProperty("TaxCode")
    private String taxCode;

    @JsonProperty("Description")
    private String description;

    // 税率(6:税率=0.06   0:税率=0) 
    @JsonProperty("TaxRate")
    private int taxRate;

    @JsonProperty("TaxType")
    private CodeString taxType;
}
