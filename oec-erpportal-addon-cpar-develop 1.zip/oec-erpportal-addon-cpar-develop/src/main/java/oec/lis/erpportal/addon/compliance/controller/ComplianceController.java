package oec.lis.erpportal.addon.compliance.controller;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.controller.AbstractController;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.compliance.CheckResponseBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceRequestBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.ComplianceCheckService;
import oec.lis.erpportal.addon.compliance.service.ComplianceSendService;
import oec.lis.erpportal.addon.compliance.service.CpComplianceTableService;
import oec.lis.sopl.common.model.CommonRestApiResponse;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.model.RestRequest;
import oec.lis.sopl.common.util.JsonUtils;
import oec.lis.sopl.external.inbound.vo.ComlianceCompleteInbound;

@RestController
@RequestMapping("/compliance")
@Tag(name = "Receive, Save and Verify Compliance Information", description ="Receive China compliance information")
@Slf4j
public class ComplianceController extends AbstractController{

    private ComplianceCheckService complianceCheckService;
    private ComplianceSendService complianceSendService;
    private CpComplianceTableService cpComplianceTableService;
    private AtAccountTransactionTableService atAccountTransactionService;

    private ApiLogService apiLogService;

    public ComplianceController(
        ComplianceCheckService complianceCheckService,
        ComplianceSendService complianceSendService,
        CpComplianceTableService cpComplianceTableService,
        AtAccountTransactionTableService atAccountTransactionService,
        ApiLogService apiLogService
    ) {
        this.complianceCheckService = complianceCheckService;
        this.complianceSendService = complianceSendService;
        this.cpComplianceTableService = cpComplianceTableService;
        this.atAccountTransactionService = atAccountTransactionService;
        this.apiLogService = apiLogService;
    }

    /**
     * 提供給 China 稅票系統回寫 Invoice 與 compliance no 之關係
     * 然後再使用 CwisController.sendInvoice() 將 complianceNo 與 invoiceNo 之間的關係回寫到 CW
     * @param model
     * @return
     * @throws Exception
     */
    @PostMapping("/v1/complianceInfo")
    public ResponseEntity<CommonRestApiResponse> saveComplianceAndLink(
        @Valid 
        @RequestBody RestRequest<List<ComplianceRequestBean>> model // 多筆模式
        // @RequestBody ComplianceRequestBean model // 單筆模式
    ) throws Exception {
        log.info("CPAR inbound for saving compliance info : ");
        JsonUtils.print(model);

        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();

        APILog apiLog = APILog.create("CPAR-API-SaveComplianceInfo", "API16");
        // apiLog.setCompanyCode(model.getCreateCompany()); // 單筆模式 才能直接取到 createCompany
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(JsonUtils.getJson(model));
        apiLogService.saveLog(apiLog);

        log.info("saveComplianceAndLink() Track ID: {}", apiLog.getActionId());

        ArrayList<String> debugMsg = new ArrayList<>();
        debugMsg.add("trackId: " + apiLog.getActionId());

        // 將 model 轉成 complianceList & compliankLinkList
        List<ComplianceRequestBean> sourceComplianceList = model.getBody(); // 多筆模式
        // ComplianceRequestBean sourceComplianceInfo = model; // 單筆模式
        if (sourceComplianceList == null || sourceComplianceList.isEmpty()) { // 多筆模式
        // if (sourceComplianceInfo==null) { // 單筆模式
            debugMsg.add(logMessage("Compliance info is empty"));
            apiLog.setApiStatus("ERROR");
            apiLog.setApiResponse(JsonUtils.getJson(debugMsg));
            apiLogService.saveLog(apiLog);

            CommonRestApiResponse result = new CommonRestApiResponse();
            result.setStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()));
            result.setMsg(debugMsg);
            return ResponseEntity.badRequest().body(result);
        }
        // Separate source list into different lists based on the value of ComplianceRequestBean::getAction
        List<ComplianceRequestBean> createList = new ArrayList<>();
        List<ComplianceRequestBean> deleteList = new ArrayList<>();
        List<ComplianceRequestBean> unknownList = new ArrayList<>();
        List<UUID> complianceIdList = new ArrayList<>();
        List<String> transactionNoList = new ArrayList<>();

        for (ComplianceRequestBean bean : sourceComplianceList) { // 多筆模式
        // ComplianceRequestBean bean = sourceComplianceInfo; // 單筆模式
            complianceIdList.add(bean.getComplianceId());
            String action = bean.getAction();
            if ("A".equalsIgnoreCase(action)) { // Add
                createList.add(bean);
                transactionNoList.add(bean.getAccountTransactionNo());
            } else if ("D".equalsIgnoreCase(action)) { // Delete
                deleteList.add(bean);
            } else {
                unknownList.add(bean);
                log.warn("Unknown action: {} at complianceNo = {}", action, bean.getComplianceNo());
            }
        } // 單筆跟多筆都要這個 }

        // Log the sizes of each list
        if (!createList.isEmpty()) { debugMsg.add(logMessage(String.format("CREATE list size: %d", createList.size()))); }
        if (!deleteList.isEmpty()) { debugMsg.add(logMessage(String.format("DELETE list size: %d", deleteList.size()))); }
        if (!unknownList.isEmpty()) { debugMsg.add(logMessage(String.format("UNKNOWN list size: %d", unknownList.size()))); }

        List<UUID> accountTransactionHeaderIdList = Collections.emptyList();
        CommonRestApiResponse result = new CommonRestApiResponse();
        try {
            // Get current accountTransactionHeaderId before links are modified
            accountTransactionHeaderIdList = cpComplianceTableService.getAccountTransactionHeaderIdByComplianceId(complianceIdList);
            if (!transactionNoList.isEmpty()) {
                accountTransactionHeaderIdList.addAll(atAccountTransactionService.fetchAtAccountTransactionHeaderIdByTransactionNo(transactionNoList));
            }
            // Save compliance information and link it to the invoice
            complianceCheckService.saveComplianceAndLink(createList, deleteList);
        } catch (Exception e) {
            String message = String.format("Error saving compliance information: %s", e.getMessage());
            log.error("Error saving compliance information: ", e);
            debugMsg.add(message);

            // 更新 apiLog
            apiLog.setApiStatus("ERROR");
            apiLog.setApiResponse(JsonUtils.getJson(debugMsg));
            apiLogService.saveLog(apiLog);

            result.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
            result.setMsg(debugMsg);
            return ResponseEntity.internalServerError().body(result);
        }
        // 更新 apiLog
        // apiLog.setApiStatus("DONE");
        // apiLog.setApiResponse(JsonUtils.getJson(debugMsg));
        // apiLogService.saveLog(apiLog);
    
        // Profiling section
        instant = Instant.now();
        long methodEndTimeStampMillis = instant.toEpochMilli();
        debugMsg.add(logMessage(String.format("Controller execution time 1 = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        // result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        // result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);


        // return ResponseEntity.ok(result);

        if (accountTransactionHeaderIdList.isEmpty()) {
            String message = String.format("Cannot found account_transaction_header_id from compliance_id [%s]", complianceIdList.toString());
            apiLog.setApiStatus("ERROR");
            String mergedJsonString = String.format("{\"Reason\": \"%s\"}", getStringForJson(message));
            apiLog.setApiResponse(mergedJsonString);
            apiLogService.saveLog(apiLog);
            return ResponseEntity.badRequest().body(result);
        }

        //--------------------------------------------------------------------------------------------------------------
        long methodBeginTimeStampMillis2 = instant.toEpochMilli();
        //--- Generate information for sending to CWIS API-12
        // APILog apiLog2 = APILog.create("CPAR-API-SaveComplianceInfo", "API16");
        // apiLog2.setCompanyCode(model.getCreateCompany());
        // apiLog2.setApiStatus("RECEIVED");
        // apiLog2.setApiParameters(JsonUtils.getJson(model));
        // apiLogService.saveLog(apiLog2);

        List<ComlianceCompleteInbound> complianceCompleteInboundList = Collections.emptyList();
        try {
            // 傳入完整 model (多筆 item) 回傳需要更新的 invoice no 集合
            complianceCompleteInboundList = complianceSendService.generateComplianceData(accountTransactionHeaderIdList);
            log.debug("Input model for sending invoice to CWIS API12:");
            JsonUtils.print(complianceCompleteInboundList);
    
            apiLog.setApiStatus("DONE");
            apiLog.setApiResponse(JsonUtils.getJson(complianceCompleteInboundList));

        } catch (Exception e) {
            String message = String.format("Error sending compliance data to CWIS while generating request: %s", e.getMessage());
            log.error(message, e);
            debugMsg.add(logMessage(message));
            apiLog.setApiStatus("ERROR");
            String mergedJsonString = String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage()));
            apiLog.setApiResponse(mergedJsonString);

            result.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
            result.setMsg(debugMsg);
            return ResponseEntity.internalServerError().body(result);
        } finally {
            apiLogService.saveLog(apiLog);
        }

        //--- Send to CWIS API-12 one by one
        for (ComlianceCompleteInbound complianceCompleteInbound : complianceCompleteInboundList) {
            APILog apiLog2 = APILog.create("CPAR-API-SendComplianceData", "API12-AR");
            apiLog2.setActionId(apiLog.getActionId()); // 同一個流程的 API 記錄相同的 actionId
            apiLog2.setCompanyCode(apiLog.getCompanyCode());
            apiLog2.setApiStatus("SENDING");
            apiLog2.setApiParameters(JsonUtils.getJson(complianceCompleteInbound));
            apiLogService.saveLog(apiLog2);
    
            Object response = null;
            try {
                response = complianceSendService.sendComplianceData( complianceCompleteInbound );
                log.debug("response from CWIS system:");
                JsonUtils.print(response);
    
                String cwStatus = getCwStatus(response);
                log.debug("cwStatus = [{}]", cwStatus);
                apiLog2.setCwStatus(cwStatus);
                apiLog2.setApiStatus(getApiStatusByCwStatus(cwStatus));
                apiLog2.setApiResponse(JsonUtils.getJson(response));
            } catch (Exception e) {
                log.error("Error sending compliance data to CWIS: {}", e.getMessage());
                apiLog2.setApiStatus("ERROR");
                String correctlyFormattedJsonString = getStringForJson(e.getMessage());
                String mergedJsonString = null;
                if (response!=null) {
                    mergedJsonString = String.format("{\"Message\":[{\"response\": %s}, {\"Exception\": \"%s\"}]}", 
                        JsonUtils.getJson(response),
                        correctlyFormattedJsonString );
                    // log.debug(mergedJsonString);
                } else {
                    mergedJsonString = String.format("{\"Exception\": \"%s\"}", correctlyFormattedJsonString);
                }
                apiLog2.setApiResponse(mergedJsonString);
            } finally {
                apiLogService.saveLog(apiLog2);
            }
        }

        // Profiling section
        methodEndTimeStampMillis = Instant.now().toEpochMilli();
        debugMsg.add(logMessage(String.format("Controller execution time 2 = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis2)));
        debugMsg.add(logMessage(String.format("Controller execution time all = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);

        return ResponseEntity.ok(result);
    }

    /**
     * 提供給 China 稅票系統檢查該 compliance no 相關的 invoice 是否已經銷帳或關帳
     * @param branchCode
     * @param complianceNo
     * @return
     * @throws Exception
     */
    @GetMapping("/v1/check/{branchCode}/{complianceNo}")
    public ResponseEntity<RestListResponse<CheckResponseBean>> verifyMatchOrClose(
        @PathVariable String branchCode,
        @PathVariable String complianceNo
    ) throws Exception {
        log.info("CPAR inbound for checking complianceNo is matched or closed : branchCode = {}, complianceNo = {}", branchCode, complianceNo);
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();

        APILog apiLog = APILog.create("CPAR-API-CheckComplianceInfo", "API17");
        apiLog.setApiStatus("RECEIVED");
        String inputParam = new StringBuilder()
            .append("{\"branchCode\":\"")
            .append(branchCode)
            .append("\",\"complianceNo\":\"")
            .append(complianceNo)
            .append("\"}")
            .toString();
        apiLog.setApiParameters(inputParam);
        apiLogService.saveLog(apiLog);

        if (branchCode == null || branchCode.isEmpty() || complianceNo == null || complianceNo.isEmpty()) {
            log.warn("Branch code or compliance no is empty, returning bad request");
            return ResponseEntity.badRequest().build();
        }

        log.info("verifyMatchOrClose() Track ID: {}", apiLog.getActionId());

        ArrayList<String> debugMsg = new ArrayList<>();
        debugMsg.add("trackId: " + apiLog.getActionId());

        RestListResponse<CheckResponseBean> result = new RestListResponse<>();
        try {
            // verify compliance information if matched or closed
            result = complianceCheckService.checkComplianceNoIfMatchedOrClosed( branchCode, complianceNo );
            debugMsg.addAll(result.getMsg());
        } catch (Exception e) {
            log.error("Error verifing compliance information: ", e);
            debugMsg.add("Error verifing compliance information!");

            // 更新 apiLog
            apiLog.setApiStatus("ERROR");
            apiLog.setApiResponse(JsonUtils.getJson(e.getMessage()));
            apiLogService.saveLog(apiLog);

            result.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
            result.setMsg(debugMsg);
            return ResponseEntity.internalServerError().body(result);
        }
    
        // Profiling section
        long methodEndTimeStampMillis = Instant.now().toEpochMilli();
        debugMsg.add(logMessage(String.format("Controller execution time = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);

        // 更新 apiLog
        apiLog.setApiStatus("DONE");
        apiLog.setApiResponse(JsonUtils.getJson(result));
        apiLogService.saveLog(apiLog);

        return ResponseEntity.ok(result);
    }

    private String logMessage( String message ) {
        log.debug(message);
        return message;
    }

}
