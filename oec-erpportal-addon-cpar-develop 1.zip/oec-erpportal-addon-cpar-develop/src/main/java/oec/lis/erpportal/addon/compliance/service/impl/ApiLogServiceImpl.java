package oec.lis.erpportal.addon.compliance.service.impl;

import java.sql.Types;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;

@Service
@Slf4j
public class ApiLogServiceImpl implements ApiLogService {

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    public ApiLogServiceImpl(
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    @Transactional(propagation=Propagation.REQUIRES_NEW, transactionManager = "soplTransactionManager")
    public void saveLog(APILog apiLog) {

        String sql = new StringBuilder()
            .append("INSERT INTO sys_api_log (")
            .append("  action_id, api_id,")
            .append("  action_name, api_name,")
            .append("  api_type, api_status, cw_status,")
            .append("  cmpny_code,")
            .append("  api_parameters,")
            .append("  api_response,")
            .append("  update_by")
            .append(") VALUES ( ")
            .append("  :actionId, :apiId,")
            .append("  :actionName,")
            .append("  :apiName,")
            .append("  :apiType,")
            .append("  :apiStatus,")
            .append("  :cwStatus,")
            .append("  :cmpnyCode,")
            .append("  :apiParameters,")
            .append("  :apiResponse,")
            .append("  :updateBy")
            .append(") ON CONFLICT (action_id, api_id) DO UPDATE SET ")
            .append("  action_name = EXCLUDED.action_name, api_name = EXCLUDED.api_name,")
            .append("  api_type = EXCLUDED.api_type, api_status = EXCLUDED.api_status,")
            .append("  cw_status = EXCLUDED.cw_status,")
            .append("  cmpny_code = EXCLUDED.cmpny_code,")
            .append("  api_response = EXCLUDED.api_response,")
            .append("  update_time = CURRENT_TIMESTAMP,")
            .append("  update_by = EXCLUDED.update_by")
            .toString();

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("actionId", apiLog.getActionId())
            .addValue("apiId", apiLog.getApiId())
            .addValue("actionName", apiLog.getActionName())
            .addValue("apiName", apiLog.getApiName())
            .addValue("apiType", apiLog.getApiType())
            .addValue("apiStatus", apiLog.getApiStatus())
            .addValue("cwStatus", apiLog.getCwStatus())
            .addValue("cmpnyCode", apiLog.getCompanyCode())
            .addValue("apiParameters", apiLog.getApiParameters(), Types.OTHER)
            .addValue("apiResponse", apiLog.getApiResponse(), Types.OTHER)
            .addValue("updateBy", apiLog.getUpdateBy())
            ;

        soplNamedJdbcTemplate.update(sql, params);
    }

    @Transactional(readOnly = true, transactionManager = "soplTransactionManager")
    public List<APILog> fetchByUniqueKey( UUID actionId, UUID apiId ) {
        String query = new StringBuilder()
            .append("select ")
            .append("action_id")
            .append(",api_id")
            .append(",action_name")
            .append(",api_name")
            .append(",api_type")
            .append(",api_status")
            .append(",cw_status")
            .append(",cnsl_no")
            .append(",shipment_no")
            .append(",cmpny_code")
            .append(",agent_org_code")
            .append(",api_parameters")
            .append(",api_response")
            .append(",create_time")
            .append(",update_time")
            .append(",update_by")
            .append(" FROM sys_api_log ")
            .append(" WHERE action_id = :actionId AND api_id = :apiId ")
            .toString();
        
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("actionId", actionId)
            .addValue("apiId", apiId)
            ;

        return soplNamedJdbcTemplate.query(query, namedParameters, new BeanPropertyRowMapper<APILog>(APILog.class));

    }
    
    @Transactional(readOnly = true, transactionManager = "soplTransactionManager")
    public List<APILog> fetchByActionId( UUID actionId ) {
        String query = new StringBuilder()
            .append("select ")
            .append("action_id")
            .append(",api_id")
            .append(",action_name")
            .append(",api_name")
            .append(",api_type")
            .append(",api_status")
            .append(",cw_status")
            .append(",cnsl_no")
            .append(",shipment_no")
            .append(",cmpny_code")
            .append(",agent_org_code")
            .append(",api_parameters")
            .append(",api_response")
            .append(",create_time")
            .append(",update_time")
            .append(",update_by")
            .append(" FROM sys_api_log ")
            .append("WHERE action_id = :actionId ")
            .toString();
        
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("actionId", actionId)
            ;

        return soplNamedJdbcTemplate.query(query, namedParameters, new BeanPropertyRowMapper<APILog>(APILog.class));
    }
}
