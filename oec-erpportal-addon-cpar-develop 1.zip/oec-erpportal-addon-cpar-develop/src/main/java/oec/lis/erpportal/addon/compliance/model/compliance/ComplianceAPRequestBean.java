package oec.lis.erpportal.addon.compliance.model.compliance;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class ComplianceAPRequestBean {

    private int maxQueryDaysRange = 60;

    @Hidden private String ledger = "AP";

    @NotBlank
    private String userId;

    @NotBlank
    private String companyCode;

    // settleBranch（必须）（SQL CONDITION : =）
    @NotBlank
    private String settleBranch;

    // complianceNo （非必须）（SQL CONDITION : =）
    private String complianceNo;

    // complianceDateFrom （非必须）（SQL CONDITION : >=）
    @Size(min = 0, max = 10, message = "Please provide correct complianceDateFrom in yyyy-MM-dd format!(size check)")
    private String complianceDateFrom;

    // complianceDateTo （非必须）（SQL CONDITION : <=）
    @Size(min = 0, max = 10, message = "Please provide correct complianceDateTo in yyyy-MM-dd format!(size check)")
    private String complianceDateTo;

    // supplierCompanyName （非必须）（SQL CONDITION : like）
    private String supplierCompanyName;

    // currency （非必须）（SQL CONDITION : =）
    private String currencyCode;

    /**
     * 檢查日期欄位是否為正確格式 yyyy-mm-dd
     */
    @Hidden
    @JsonIgnore
    @AssertTrue(message = "complianceDateFrom should be in 'yyyy-MM-dd' format! (format validation)")
    public boolean isValidComplianceDateFrom() {
        if (StringUtils.isEmpty(complianceDateFrom)) {return true;}
        try {
            DateUtils.parseDate(complianceDateFrom, "yyyy-MM-dd");
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }

    /**
     * 檢查日期欄位是否為正確格式 yyyy-mm-dd
     */
    @Hidden
    @JsonIgnore
    @AssertTrue(message = "complianceDateTo should be in 'yyyy-MM-dd' format and reasonable complianceDateFrom! (format and value validation)")
    public boolean isValidComplianceDateTo() {
        if (StringUtils.isEmpty(complianceDateTo)) {return true;}
        try {
            // DateUtils.parseDate(complianceDateTo, "yyyy-MM-dd");
            LocalDate toDate = LocalDate.parse(complianceDateTo, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            if (StringUtils.isNotBlank(complianceDateFrom)) {
                LocalDate fromDate = LocalDate.parse(complianceDateFrom, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                if (fromDate.isAfter(toDate)) {
                    return false;
                }
                if (fromDate.isBefore(toDate.minusDays(maxQueryDaysRange))) {
                    return false;
                }
            }
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

}
