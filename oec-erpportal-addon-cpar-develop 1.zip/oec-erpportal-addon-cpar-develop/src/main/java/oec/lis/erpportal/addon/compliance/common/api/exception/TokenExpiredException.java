package oec.lis.erpportal.addon.compliance.common.api.exception;

public class TokenExpiredException extends Exception {
    public TokenExpiredException(String message) {
        super(message);
    }
}
