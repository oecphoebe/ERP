package oec.lis.erpportal.addon.compliance.schedule;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SourceDataService {
    @Value("${job.email.retrieve_days:1}")
    private int days;

    private NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate;

    public SourceDataService(
        @Qualifier("cargowiseNamedJdbcTemplate") NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate
    ) {
        this.cargowiseNamedJdbcTemplate = cargowiseNamedJdbcTemplate;
    }

    final Map<String,Class<?>> desiredColumns = Map.of(
        "id", UUID.class,
        "transaction_type", String.class,
        "transaction_no", String.class,
        "update_time", java.sql.Timestamp.class
    );

    public List<DataRecord> fetchData() {
        String query = new StringBuilder()
            .append("SELECT ath.AH_PK as id, ath.AH_TransactionType as transaction_type, ath.AH_TransactionNum as transaction_no, ath.AH_PostDate as update_time ")
            .append("FROM AccTransactionHeader ath ")
            .append("WHERE ath.AH_TransactionType in ('INV','CRD') ")
            .append("and ath.AH_Ledger='AR' ")
            .append("and ath.AH_PostDate >= DATEADD(day, -").append(days).append(", GETDATE()) ")
            .append("ORDER BY AH_PostDate")
            .toString();
        return cargowiseNamedJdbcTemplate.query(
            query, 
            rs -> {
                // log.debug("Source ResultSet handling()");
                List<DataRecord> results = new ArrayList<>();
                String id = null;
                // int loopCounter = 0;
                Set<String> columnsToExtract = desiredColumns.keySet();
                while (rs.next()) {
                    // log.debug("Source ResultSet loop [{}]", loopCounter++);
                    id = null;
                    Map<String, Object> rowData = new HashMap<>();
                    for (String columnName : columnsToExtract) {
                        try {
                            Object value = rs.getObject(columnName);
                            rowData.put(columnName, value);
                            if (StringUtils.equals(columnName, "transaction_no")) {
                                id = rs.getObject(columnName, String.class);
                            }
                        } catch (SQLException e) {
                            log.error("Warning: Column '{}}' not found or error reading it: {}", columnName, e.getMessage());
                            // Optionally put null: rowData.put(columnName, null);
                            rowData.put(columnName, null);
                        }
                    }
                    if (!rowData.isEmpty()) {
                        results.add(new DataRecord(id, rowData));
                    }
                }
                return results;
            }
        );
    }
}