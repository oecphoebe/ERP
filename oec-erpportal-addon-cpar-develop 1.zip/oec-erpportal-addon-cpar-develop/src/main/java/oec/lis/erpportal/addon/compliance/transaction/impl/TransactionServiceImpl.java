package oec.lis.erpportal.addon.compliance.transaction.impl;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.transaction.TransactionService;
import oec.lis.sopl.common.model.CommonRestApiResponse;
import oec.lis.sopl.common.model.RestListResponse;

@Service
@Slf4j
public class TransactionServiceImpl implements TransactionService {

    private final TransactionMappingService mappingService;
    private final TransactionBatchProcessor batchProcessor;

    public TransactionServiceImpl(
        TransactionMappingService mappingService,
        TransactionBatchProcessor batchProcessor
    ) {
        this.mappingService = mappingService;
        this.batchProcessor = batchProcessor;
    }

    @Override
    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadRaw(String json) throws Exception {
        log.debug("TransactionServiceImpl.analyzePayloadRaw() - delegating to TransactionMappingService");
        return mappingService.analyzePayloadRaw(json);
    }

    @Override
    public RestListResponse<TransactionChargeLineRequestBean> analyzePayloadStrategy(String json) throws Exception {
        log.debug("TransactionServiceImpl.analyzePayloadStrategy() - delegating to TransactionMappingService");
        return mappingService.analyzePayloadStrategy(json, null, null, null);
    }

    @Override
    public CommonRestApiResponse handleUniversalTransactionBatch(String json) throws Exception {
        log.debug("TransactionServiceImpl.handleUniversalTransactionBatch() - delegating to TransactionBatchProcessor");
        return batchProcessor.handleUniversalTransactionBatch(json);
    }
}
