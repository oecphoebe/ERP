package oec.lis.erpportal.addon.compliance.common.kafka;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
public class RetryService {
    private final KafkaTemplate<String, RetryRecord> kafkaTemplate;
    private InvoiceProcessingService invoiceProcessingService;

    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Value("${external.compliance.retries:2}")
    private int maxRetries; // Maximum number of retry attempts

    public RetryService(
        KafkaTemplate<String, RetryRecord> kafkaTemplate, 
        InvoiceProcessingService invoiceProcessingService
    ) {
        this.kafkaTemplate = kafkaTemplate;
        this.invoiceProcessingService = invoiceProcessingService;
    }

    @KafkaListener(topics = "${spring.profiles.active}-invoice-retry", groupId = "${spring.profiles.active}-retry-processing-group")
    public void processRetry(
        @Header(KafkaHeaders.RECEIVED_KEY) String actionIdString,
        @Payload RetryRecord record
    ) {
        if (Instant.now().isBefore(record.getNextAttempt())) {
            // Skip processing if the next attempt time is not reached
            // Not yet time to retry, put back in queue
            kafkaTemplate.send(activeProfile + "-invoice-retry", actionIdString, record);
            return;
        }
        // Process the record
        try {
            // Call the invoice processing logic here
            invoiceProcessingService.processInvoice(record.getActionId().toString(), record.getRequest());
            // If successful, remove from retry queue
        } catch (Exception e) {
            // If failed, increment attempt and reschedule
            if (record.getAttempt() >= maxRetries) {
                // If max attempts reached, move to dead-letter topic for manual intervention
                kafkaTemplate.send(activeProfile + "-invoice-dead-letter", actionIdString, record);
                log.warn("Max attempts reached for record: {}", record.toString());
                return;
            } else {
                // schedule next retry with exponential backoff
                log.warn("Retry failed for record: {}, Exception is {}", record.toString(), e.getMessage());
                record.setAttempt(record.getAttempt() + 1);
                record.setNextAttempt(calculateNextAttempt(record.getAttempt()));
                kafkaTemplate.send(activeProfile + "-invoice-retry", actionIdString, record);
            }
        }
    }

    private Instant calculateNextAttempt(int attempt) {
        // Exponential backoff: 2^attempt seconds (e.g., 2, 4, 8, 16...)
        return Instant.now().plusSeconds((long) Math.pow(2, attempt));
    }
}
