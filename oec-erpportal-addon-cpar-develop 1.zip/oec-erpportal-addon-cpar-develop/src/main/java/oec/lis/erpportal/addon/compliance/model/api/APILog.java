package oec.lis.erpportal.addon.compliance.model.api;

import java.io.Serializable;
import java.time.Instant;
import java.util.UUID;

import lombok.Data;

/**
 * API log persistence object
 */
@Data
// @Entity
// @Table(name = "sys_api_log")
// @IdClass(APILogPK.class)
// @Convert(attributeName = "jsonb", converter = JsonBinaryType.class) // Spring Boot 3.x
public class APILog implements Serializable {

	// CREATE TABLE sopl.sys_api_log (
	// 	action_id uuid NOT NULL,
	// 	api_id uuid NOT NULL,
	// 	action_name varchar(30) NOT NULL,
	// 	api_name varchar(20) NOT NULL,
	// 	api_type varchar(3) NOT NULL,
	// 	api_status varchar(20) NOT NULL,
	// 	cw_status bpchar(3),
	// 	cnsl_no varchar(20),
	// 	shipment_no varchar(20),
	// 	cmpny_code varchar(3),
	// 	agent_org_code varchar(12),
	// 	api_parameters json,
	// 	api_response json,
	// 	create_time timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
	// 	update_time timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
	// 	update_by varchar(20) NOT NULL,
	// 	CONSTRAINT pk_sys_api_log_action_id_api_id PRIMARY KEY (action_id, api_id)
	// );

	public static final int LENGTH_ACTION_NAME = 30;
	public static final int LENGTH_API_NAME = 20;
	public static final int LENGTH_API_TYPE = 3;
	public static final int LENGTH_API_STATUS = 20;
	public static final int LENGTH_CONSOL_NO = 20;
	public static final int LENGTH_SHIPMENT_NO = 20;
	public static final int LENGTH_UPDATE_BY = 20;

	private static final long serialVersionUID = 1L;

	public static APILog create( String actionName, String apiName) {
		APILog apiLog = new APILog();
		apiLog.setActionId(UUID.randomUUID());
		apiLog.setApiId(UUID.randomUUID());
		apiLog.setActionName(actionName);
		apiLog.setApiName(apiName);
		apiLog.setUpdateBy("CPAR-API"); // 在 CPAR 寫入的都是 CPAR-API
		switch (apiName) {
			case "API14" // 從 CWIS 送入的 UniversalTransaction, 是 Cargowise 的 Outbound
			, "API15": // 從 CPAR 呼叫 China 稅票系統, 是 CPAR 的 Outbound
				apiLog.setApiType("OUT");
				break;
			case "API12-AR" // 從 CPAR 呼叫 CWIS UniversalEvent, 是 Cargowise 的 Inbound
			, "API16" // 從 China 稅票系統 呼叫的 save compliance , 是 CPAR 的 Inbound
			, "API17": // 從 China 稅票系統 呼叫的 check if matched or closed, 是 CPAR 的 Inbound
				apiLog.setApiType("IN");
				break;
			case "API18": // 從 China User computer (金蝶系統) 呼叫的 query compliance AP, 是 CPAR 的 Inbound
				apiLog.setApiType("IN");
				apiLog.setUpdateBy("CPAP-API");
				break;
			default:
				apiLog.setApiType("XXX");
		}
		// log.debug("Current Instant in ISO 8601 format: {}", DateTimeFormatter.ISO_INSTANT.format(Instant.now()));
		apiLog.setCreatedTime(Instant.now()); // Timestamp.from(Instant.now())
		apiLog.setUpdatedTime(Instant.now()); // Timestamp.from(Instant.now())
		return apiLog;
	}

	// Following two columns are unique key
	private UUID actionId;
	private UUID apiId;

	/**
	 * @See APIType (IN/OUT)
	 */
	private String apiType;

	/**
	 * @See ActionName (e.g. SO0101-Approve, SO0201-Import, PL0101-submit)
	 */
	private String actionName;

	/**
	 * @See APIName (API01-API17)
	 */
	private String apiName;

	/**
	 * @See APIStatus
	 */
	private String apiStatus;

	/**
	 * @See CargowiseStatus
	 */
	private String cwStatus;

	private String consolNo;

	private String shipmentNo;

	private String companyCode;

	private String agentOrgCode;

	private Object apiParameters;

	private Object apiResponse;

	private Instant createdTime;

	private Instant updatedTime;

	private String updateBy;

	public void setActionName(String actionName) {
		if (actionName != null && actionName.length() > LENGTH_ACTION_NAME) {
			actionName = actionName.substring(0, LENGTH_ACTION_NAME);
		}
		this.actionName = actionName;
	}
	public void setApiName(String apiName) {
		if (apiName != null && apiName.length() > LENGTH_API_NAME) {
			apiName = apiName.substring(0, LENGTH_API_NAME);
		}
		this.apiName = apiName;
	}
	public void setApiType(String apiType) {
		if (apiType != null && apiType.length() > LENGTH_API_TYPE) {
			apiType = apiType.substring(0, LENGTH_API_TYPE);
		}
		this.apiType = apiType;
	}
	public void setApiStatus(String apiStatus) {
		if (apiStatus != null && apiStatus.length() > LENGTH_API_STATUS) {
			apiStatus = apiStatus.substring(0, LENGTH_API_STATUS);
		}
		this.apiStatus = apiStatus;
	}
}
