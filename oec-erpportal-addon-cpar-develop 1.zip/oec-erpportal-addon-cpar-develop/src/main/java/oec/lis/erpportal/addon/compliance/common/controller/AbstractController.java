package oec.lis.erpportal.addon.compliance.common.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

public abstract class AbstractController {
    @Value("${runtime.environment}")
    protected String environment;

    public String getStringForJson( String str) {
        return str == null ? "" : str
        .replace("\\", "\\\\") // Escape backslashes first
        .replace("\"", "\\\"") // Escape double quotes
        .replace("\n", "") // Escape newlines \\n
        .replace("\r", "") // Escape carriage returns \\r
        .replace("\t", "") // Escape tabs \\t
         // Add other escapes as needed (e.g., control characters)
        ;
    }

    public String getCwStatus( Object responseFromCargowise ) throws JsonProcessingException{ 
        String json = new ObjectMapper().writeValueAsString(responseFromCargowise); // UniversalResponse
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);

        String cwStatus = "";
        // $.body.UniversalResponse.Status 第一個 PRS 沒有參考價值, 要取用裡面的 ProcessingStatusCode
        // $.body.UniversalResponse.Data.UniversalEvent[0].Event.ContextCollection.Context[?(@.Type.Value=='ProcessingStatusCode')].Value // 自己產的
        // $.body.UniversalResponse.Data.UniversalEvent[0].Event.ContextCollection.Context[?(@.Type.Value=='ProcessingStatusCode')].Value // 教 AI 產生的
        // $.body.UniversalResponse.Data.UniversalEvent[0].Event.ContextCollection.Context[1].Value // AI 第二次產生的
        List<Map<String,Object>> contextList = JsonPath.read(allDocument, "$.body.UniversalResponse.Data.UniversalEvent[0].Event.ContextCollection.Context");
        if (!contextList.isEmpty()) {
            for (Map<String,Object> aRecord : contextList) {
                String jsonContext = new ObjectMapper().writeValueAsString(aRecord);
                String contextType = JsonPath.read(jsonContext, "$.Type.Value");
                if (StringUtils.equals("ProcessingStatusCode", contextType)) {
                    cwStatus = JsonPath.read(jsonContext, "$.Value");
                    break;
                }
            }
        }
        return cwStatus;
    }

    public String getApiStatusByCwStatus( String cwStatus ) {
        String apiStatus = "";
        switch (cwStatus) {
            case "PRS": 
                apiStatus = "DONE"; 
                break;
            case "DCD": 
            case "WAR": 
                apiStatus = "ERROR";
                break;
            default:
                apiStatus = "UNKNOWN";
        }
        return apiStatus;
    }

}
