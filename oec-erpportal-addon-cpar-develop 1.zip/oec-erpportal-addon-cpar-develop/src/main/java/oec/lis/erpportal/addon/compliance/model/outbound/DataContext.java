package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataContext {
    @JsonProperty("DataSourceCollection")
    private DataSourceCollection dataSourceCollection;

    @JsonProperty("ActionPurpose")
    private CodeDescription actionPurpose;

    @JsonProperty("Company")
    private Company company;

    @JsonProperty("DataProvider")
    private String dataProvider;

    @JsonProperty("EnterpriseID")
    private String enterpriseId;

    @JsonProperty("EventBranch")
    private CodeName eventBranch;

    @JsonProperty("EventDepartment")
    private CodeName eventDepartment;

    @JsonProperty("EventType")
    private CodeDescription eventType;

    @JsonProperty("EventUser")
    private CodeName eventUser;

    @JsonProperty("ServerId")
    private String serverId;

    @JsonProperty("TriggerDate")
    private String triggerDate;
}
