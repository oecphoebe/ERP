package oec.lis.erpportal.addon.compliance.model.transaction;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TransactionInfoRequestBean implements Serializable {
    private String billNo;
    private String transactionType;
    private String billDate;
    private String companyCode; // 20250421 added
    private String branchCode;
    private String departmentCode; // 20250421 added
    private String currency;
    private String shipmentId;
    private String consolNo;
    private String debiterCode;
    private String debiterName;
    private String buyerCode;
    private String buyerName;
    private String buyerTaxNo;
    private String buyerAddr;
    private String buyerTel;
    private String buyerBankName;
    private String buyerBankAccount;
    private String buyerEmail;
    private int taxRate;
    private String oldBillNo;
    private String oldBillType;
}
