package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistrationNumber {
    @JsonProperty("Type")
    private CodeString type;

    @JsonProperty("CountryOfIssue")
    private CodeName countryOfIssue;

    // 這個欄位有可能是字串或數字，所以用 Object
    @JsonProperty("Value")
    private Object value;
}