package oec.lis.erpportal.addon.compliance.model.outbound;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChargeLine {

    @JsonProperty("ApcashAdvanceRequired")
    private boolean apCashAdvanceRequired;
    
    @JsonProperty("ArcashAdvanceRequired")
    private boolean arCashAdvanceRequired;

    @JsonProperty("Branch")
    private CodeName branch;

    @JsonProperty("ChargeCode")
    private CodeDescription chargeCode;

    @JsonProperty("ChargeCodeGroup")
    private CodeDescription chargeCodeGroup;

    @JsonProperty("CostApportionmentConsolNumber")
    private TypeKey costApportionmentConsolNumber;

    @JsonProperty("CostExchangeRate")
    private BigDecimal costExchangeRate;

    @JsonProperty("CostGSTVATID")
    private Tax costGSTVATID;

    @JsonProperty("CostIsPosted")
    private boolean costIsPosted;

    @JsonProperty("CostLocalAmount")
    private BigDecimal costLocalAmount;

    @JsonProperty("CostOSAmount")
    private BigDecimal costOSAmount;

    @JsonProperty("CostOSCurrency")
    private CodeDescription costOSCurrency;

    @JsonProperty("CostOSGSTVATAmount")
    private BigDecimal costOSGSTVATAmount;

    @JsonProperty("CostRatingBehaviour")
    private CodeDescription costRatingBehaviour;

    @JsonProperty("Creditor")
    private TypeKey creditor;

    @JsonProperty("Debtor")
    private TypeKey debtor;

    @JsonProperty("Department")
    private CodeName department;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("DisplaySequence")
    private int displaySequence;

    @JsonProperty("SellExchangeRate")
    private BigDecimal sellExchangeRate;

    @JsonProperty("SellGSTVATID")
    private Tax sellGstVatId;

    @JsonProperty("SellInvoiceType")
    private String sellInvoiceType; // TODO: 有字串 "FIN" 也有 boolean value = true

    @JsonProperty("SellIsPosted")
    private boolean sellIsPosted;

    @JsonProperty("SellLocalAmount")
    private BigDecimal sellLocalAmount;

    @JsonProperty("SellOSAmount")
    private BigDecimal sellOSAmount;

    @JsonProperty("SellOSCurrency")
    private CodeDescription sellOSCurrency;

    @JsonProperty("SellOSGSTVATAmount")
    private BigDecimal sellOSGSTVATAmount;

    @JsonProperty("SellPostedTransaction")
    private PostedTransaction sellPostedTransaction;

    @JsonProperty("SellPostedTransactionNumber")
    private String sellPostedTransactionNumber;

    @JsonProperty("SellPostedTransactionType")
    private String sellPostedTransactionType;

    @JsonProperty("SellRatingBehaviour")
    private CodeDescription sellRatingBehaviour;

    // @JsonProperty("CostRatingBasisCollection")
    // private List<CostRatingBasis> costRatingBasisCollection;

    // @JsonProperty("SellRatingBasisCollection")
    // private List<SellRatingBasis> sellRatingBasisCollection;
}