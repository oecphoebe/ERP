package oec.lis.erpportal.addon.compliance.common.api.config;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.api.service.TokenService;

@Slf4j
public class TokenAuthInterceptor implements RequestInterceptor {
    private final TokenService tokenService;
    
    public TokenAuthInterceptor(TokenService tokenService) {
        this.tokenService = tokenService;
    }
    
    @Override
    public void apply(RequestTemplate template) {
        log.debug("TokenAuthInterceptor.apply() called for url: {}", template.url());
        // Always get a fresh token for each request
        String token = tokenService.getValidToken();
        template.header("Authorization", "Bearer " + token);
    }
}