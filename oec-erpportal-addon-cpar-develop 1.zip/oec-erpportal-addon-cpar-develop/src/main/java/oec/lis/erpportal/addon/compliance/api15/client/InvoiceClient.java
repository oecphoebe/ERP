package oec.lis.erpportal.addon.compliance.api15.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import oec.lis.erpportal.addon.compliance.api15.config.Api15TokenFeignConfig;
import oec.lis.erpportal.addon.compliance.common.api.client.FeignConfigFactory;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

@FeignClient(name = "invoiceClient", url = "${external.compliance.url}", configuration = Api15TokenFeignConfig.class) // FeignConfigFactory.TokenAuthConfig.class
public interface InvoiceClient {
    @PostMapping("/api/Invoice/v1/Bill")
    // @PostMapping("/cpar-api/compliance/v1/complianceInfo") // for local test endpoint use
    Object sendInvoice(@RequestBody TransactionChargeLineRequestBean data);
}
