package oec.lis.erpportal.addon.compliance.common.api.config;

import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.Logger;
import feign.Retryer;

@Configuration
public class BasicFeignConfig {

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }

    // @Bean
    // public Retryer retryer() {
    //     return new Retryer.Default(1000, TimeUnit.SECONDS.toMillis(2), 3);
    // }
}
