package oec.lis.erpportal.addon.compliance.common.api.model;

public interface AuthResponseModel {
    String getToken();
    long getExpiryTime();
}