package oec.lis.erpportal.addon.compliance.api15.service;

import java.time.Duration;
import java.time.Instant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api15.client.AuthClient;
import oec.lis.erpportal.addon.compliance.api15.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api15.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.exception.AuthenticationFailedException;
import oec.lis.erpportal.addon.compliance.common.api.model.TokenInfo;
import oec.lis.erpportal.addon.compliance.common.api.service.AbstractTokenService;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class API15TokenService extends AbstractTokenService {
    static final String TOKEN_CACHE_KEY = "complianceApiToken";
    static final Duration TOKEN_CACHE_DURATION = Duration.ofMinutes(20);
    private final AuthClient authClient;

    @Value("${external.compliance.client-id}")
    private String clientId;
    @Value("${external.compliance.client-secret}")
    private String clientSecret;

    public API15TokenService(AuthClient authClient) {
        super(TOKEN_CACHE_KEY, TOKEN_CACHE_DURATION);
        this.authClient = authClient;
    }

    // @Override
    // protected boolean isExpiringSoon(TokenInfo tokenInfo) {
    //     return false; // for test only
    //     // Consider token as expiring if less than 2 minutes remaining
    //     // TODO: 要用回傳的 JWT 解開, 取得 claims 中的 exp 值
    //     // return Instant.ofEpochMilli(tokenInfo.getExpiryTime()).isBefore(Instant.now().plusSeconds(120));
    // }

    private AuthRequest buildAuthRequest() {
        return AuthRequest.getAuthRequest(this.clientId, this.clientSecret);
    }

    @Override
    @Synchronized
    protected String refreshToken() {
        try {
            log.info("Refreshing API token");
            AuthResponse response = authClient.authenticate(buildAuthRequest());
            JsonUtils.print(response);

            // remark following lines for local test only
            if (!response.isSucceeded()) {
                throw new AuthenticationFailedException(
                    "Authentication failed: " + response.getErrors(), 
                    null
                );
            }

            TokenInfo newToken = new TokenInfo(
                    response.getData(),
                    // 第二個參數預期寫入這個 token 的逾期時間點, 由 API 回傳的 expires_in 秒數 加上現在時間算出來
                    Instant.now().plusSeconds(response.getExpiresIn()) // temporary test use
                );

            tokenCache.put(TOKEN_CACHE_KEY, newToken);
            log.info("Successfully refreshed API token");
            return newToken.getToken();
        } catch (Exception e) {
            TokenInfo existingToken = tokenCache.getIfPresent(TOKEN_CACHE_KEY);
            if (existingToken != null) {
                log.warn("Failed to refresh token, using existing token as fallback", e);
                // Return existing token even if expiring soon as fallback
                return existingToken.getToken();
            }
            log.error("Failed to obtain token and no fallback available", e);
            // throw new AuthenticationFailedException("Failed to obtain token and no fallback available", e);
        }
        return null;
    }
    
}
