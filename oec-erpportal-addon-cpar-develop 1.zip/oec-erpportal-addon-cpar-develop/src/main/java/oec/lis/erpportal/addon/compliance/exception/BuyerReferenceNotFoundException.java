package oec.lis.erpportal.addon.compliance.exception;

public class BuyerReferenceNotFoundException extends Exception {
    public BuyerReferenceNotFoundException(String message) {
        super(message);
    }

    public BuyerReferenceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public BuyerReferenceNotFoundException(Throwable cause) {
        super(cause);
    }

}
