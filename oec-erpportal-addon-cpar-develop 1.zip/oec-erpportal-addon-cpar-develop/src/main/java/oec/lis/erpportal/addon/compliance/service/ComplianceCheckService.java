package oec.lis.erpportal.addon.compliance.service;

import java.util.List;

import oec.lis.erpportal.addon.compliance.model.compliance.CheckResponseBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceRequestBean;
import oec.lis.sopl.common.model.RestListResponse;

public interface ComplianceCheckService {
    public RestListResponse<CheckResponseBean> checkComplianceNoIfMatchedOrClosed( String branchCode, String complianceNo );
    public void saveComplianceAndLink( List<ComplianceRequestBean> createList, List<ComplianceRequestBean> deleteList );
}
