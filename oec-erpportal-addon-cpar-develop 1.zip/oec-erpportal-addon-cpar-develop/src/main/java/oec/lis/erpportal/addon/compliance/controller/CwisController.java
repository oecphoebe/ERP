package oec.lis.erpportal.addon.compliance.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.controller.AbstractController;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceRequestBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.ComplianceSendService;
import oec.lis.erpportal.addon.compliance.service.CpComplianceTableService;
import oec.lis.sopl.common.util.JsonUtils;
import oec.lis.sopl.external.inbound.vo.ComlianceCompleteInbound;

@RestController
@RequestMapping("/compliance")
@Slf4j
public class CwisController extends AbstractController {

    private ApiLogService apiLogService;
    private ComplianceSendService complianceSendService;
    private CpComplianceTableService cpComplianceTableService;
    private AtAccountTransactionTableService atAccountTransactionService;

    public CwisController(
        ApiLogService apiLogService, 
        ComplianceSendService complianceSendService,
        CpComplianceTableService cpComplianceTableService,
        AtAccountTransactionTableService atAccountTransactionService
    ) {
        this.apiLogService = apiLogService;
        this.complianceSendService = complianceSendService;
        this.cpComplianceTableService = cpComplianceTableService;
        this.atAccountTransactionService = atAccountTransactionService;
    }

    /**
     * 接收單筆 compliance 資料，並傳送到 CWIS API-12
     * @param model
     * @return
     * @throws Exception
     */
    @PostMapping("/v1/cwisApi12")
    public ResponseEntity<Object> sendInvoice(
        @Valid 
        @RequestBody ComplianceRequestBean model
    ) throws Exception {
        log.debug("Input model for sending compliance info to cwis :");
        JsonUtils.print(model);

        //--- Generate information for sending to CWIS API-12
        APILog apiLog = APILog.create("CPAR-API-SaveComplianceInfo", "API16");
        apiLog.setCompanyCode(model.getCreateCompany());
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(JsonUtils.getJson(model));
        apiLogService.saveLog(apiLog);

        List<ComplianceRequestBean> complianceInfoList = List.of(model);

        log.debug("Input model for preparing invoice-compliance model to CWIS API12:");
        JsonUtils.print(model);

        List<UUID> complianceIdList = new ArrayList<>();
        List<String> transactionNoList = new ArrayList<>();
        for (ComplianceRequestBean bean : complianceInfoList) { // 多筆模式
            complianceIdList.add(bean.getComplianceId());
            String action = bean.getAction();
            if ("A".equalsIgnoreCase(action)) { // Add
                transactionNoList.add(bean.getAccountTransactionNo());
            }
        } // 單筆跟多筆都要這個 }
        List<UUID> accountTransactionHeaderIdList = Collections.emptyList();
        List<ComlianceCompleteInbound> complianceCompleteInboundList = Collections.emptyList();
        try {
            // Get current accountTransactionHeaderId before links are modified
            accountTransactionHeaderIdList = cpComplianceTableService.getAccountTransactionHeaderIdByComplianceId(complianceIdList);
            accountTransactionHeaderIdList.addAll(atAccountTransactionService.fetchAtAccountTransactionHeaderIdByTransactionNo(transactionNoList));
            // 傳入完整 model (多筆 item) 回傳需要更新的 invoice no List集合
            complianceCompleteInboundList = complianceSendService.generateComplianceData(accountTransactionHeaderIdList);
    
            apiLog.setApiStatus("DONE");
            apiLog.setApiResponse(JsonUtils.getJson(complianceCompleteInboundList));

        } catch (Exception e) {
            String message = String.format("Error sending compliance data to CWIS while generating request: %s", e.getMessage());
            logMessage(message);
            apiLog.setApiStatus("ERROR");
            apiLog.setApiResponse(String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage())));

            return ResponseEntity.internalServerError().body(message);
        } finally {
            apiLogService.saveLog(apiLog);
        }

        //--- Send to CWIS API-12 one by one
        for (ComlianceCompleteInbound complianceCompleteInbound : complianceCompleteInboundList) {
            log.debug("Input model for sending invoice to CWIS API12:");
            JsonUtils.print(complianceCompleteInbound);

            APILog apiLog2 = APILog.create("CPAR-API-SendComplianceData", "API12-AR");
            apiLog2.setActionId(apiLog.getActionId()); // 同一個流程的 API 記錄相同的 actionId
            apiLog2.setCompanyCode(apiLog.getCompanyCode());
            apiLog2.setApiStatus("SENDING");
            apiLog2.setApiParameters(JsonUtils.getJson(complianceCompleteInbound));
            apiLogService.saveLog(apiLog2);
    
            Object response = null;
            try {
                response = complianceSendService.sendComplianceData( complianceCompleteInbound );
                log.debug("response from CWIS system:");
                JsonUtils.print(response);
    
                String cwStatus = getCwStatus(response);
                log.debug("cwStatus = [{}]", cwStatus);
                apiLog2.setCwStatus(cwStatus);
                apiLog2.setApiStatus(getApiStatusByCwStatus(cwStatus));
                apiLog2.setApiResponse(JsonUtils.getJson(response));
            } catch (Exception e) {
                log.error("Error sending compliance data to CWIS: {}", e.getMessage());
                apiLog2.setApiStatus("ERROR");
                String correctlyFormattedJsonString = getStringForJson(e.getMessage());
                String mergedJsonString = null;
                if (response!=null) {
                    mergedJsonString = String.format("{\"Message\":[{\"response\": %s}, {\"Exception\": \"%s\"}]}", 
                        JsonUtils.getJson(response),
                        correctlyFormattedJsonString );
                    // log.debug(mergedJsonString);
                } else {
                    mergedJsonString = String.format("{\"Exception\": \"%s\"}", correctlyFormattedJsonString);
                }
                apiLog2.setApiResponse(mergedJsonString);
                return ResponseEntity.internalServerError().body(mergedJsonString);
            } finally {
                apiLogService.saveLog(apiLog2);
            }
        }

        return ResponseEntity.ok(String.format("Send compliance data to CWIS API12 successfully, total %d records.", complianceCompleteInboundList.size()));
    }

    private String logMessage( String message ) {
        log.debug(message);
        return message;
    }

}
