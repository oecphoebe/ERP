package oec.lis.erpportal.addon.compliance.model.transaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MtMatchTransactionHeaderBean {
    // Primary key
    private UUID matchTransHeaderId;

    // Business key
    private String matchNo; // varchar(20), UNIQUE

    // Status and flow
    private String matchStatusCode; // varchar(10) - e.g., "UNMATCH", "REVERSED", "MATCHED"
    private String editStatusCode; // varchar(10)
    private String msgCode; // varchar(10)
    private String matchType; // varchar(10)
    private String matchFlow; // char(2)

    // Cargowise status tracking
    private String mtCwStatus; // varchar(10), default ''

    // Dates and times
    private Instant postTime;
    private Instant postDate;
    private Date matchOffsetDate;
    private Instant matchClickTime;

    // Company and organization
    private String cmpnyCode; // varchar(3)
    private String cmpnyBranch; // varchar(3)
    private String payToOrgCode; // varchar(12)

    // Financial details
    private String crncyCode; // varchar(3)
    private String localCrncyCode; // varchar(3)
    private BigDecimal offsetAmt; // numeric(19, 4)
    private BigDecimal localPaidAmt; // numeric(19, 4)
    private BigDecimal localOffsetAmt; // numeric(19, 4)
    private BigDecimal localDiffAmt; // numeric(19, 4)
    private BigDecimal exchgRate; // numeric(18, 4)

    // Payment details
    private String pymtType; // varchar(3)
    private String bankAcct; // varchar(20)
    private String checkBookCode; // varchar(30)
    private String checkNo; // varchar(50)
    private String checkDrawer; // varchar(30)
    private String checkBank; // varchar(20)
    private String checkBranch; // varchar(20)

    // Description and reference
    private String matchDescription; // varchar(100)
    private String matchRefNo; // varchar(38)
    private String cwMatchNo; // varchar(20)
    private String remark; // varchar(255)
    private String srcSys; // varchar(20)

    // Audit fields - Create
    private String createCmpny; // varchar(3)
    private String createBranch; // varchar(3)
    private String createDept; // varchar(3)
    private String createBy; // varchar(50)
    private Instant createTime;

    // Audit fields - Update
    private String updateCmpny; // varchar(3)
    private String updateBranch; // varchar(3)
    private String updateDept; // varchar(3)
    private String updateBy; // varchar(50)
    private Instant updateTime;
}
