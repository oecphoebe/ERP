package oec.lis.erpportal.addon.compliance.controller;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import io.micrometer.common.util.StringUtils;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api18.client.ProfileClient;
import oec.lis.erpportal.addon.compliance.common.api.exception.AuthorizationException;
import oec.lis.erpportal.addon.compliance.common.api.exception.BadTokenException;
import oec.lis.erpportal.addon.compliance.common.controller.AbstractController;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPRequestBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPResponseBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;
import oec.lis.erpportal.addon.compliance.service.CpComplianceTableService;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.model.RestRequest;
import oec.lis.sopl.common.util.JsonUtils;

@RestController
@RequestMapping("/compliance")
@Tag(name = "Reply Compliance AP Information", description ="Reply Compliance AP Information")
@Slf4j
public class ComplianceAPController extends AbstractController{

    @Value("${external.erpportal.service-account}")
    private String serviceAccountId;

    private int maxQueryDaysRange = 60;

    private CpComplianceTableService cpComplianceTableService;
    private CommonGlobalTableService commonGlobalTableService;
    private final ProfileClient profileClient;

    private ApiLogService apiLogService;

    public ComplianceAPController(
        CpComplianceTableService cpComplianceTableService,
        CommonGlobalTableService commonGlobalTableService,
        ProfileClient profileClient,
        ApiLogService apiLogService
    ) {
        this.cpComplianceTableService = cpComplianceTableService;
        this.commonGlobalTableService = commonGlobalTableService;
        this.profileClient = profileClient;
        this.apiLogService = apiLogService;
    }

    /**
     * 第二版實作：讓 中介程式帶 userId 進來，不檢查 userId 權限
     * @param model
     * @return
     * @throws Exception
     */
    @PostMapping("/v1/complianceAP")
    public RestListResponse<ComplianceAPResponseBean> fetchComplianceAPInfo(
        @Valid @RequestBody RestRequest<ComplianceAPRequestBean> model
    ) throws Exception {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();

        log.info("CPAP inbound for querying AP compliance info : ");
        JsonUtils.print(model);

        if (model.getBody()==null) {
            APILog apiLog = APILog.create("CPAP-API-QueryComplianceAP", "API18");
            // apiLog.setCompanyCode(model.getCreateCompany()); // 單筆模式 才能直接取到 createCompany
            apiLog.setApiStatus("RECEIVED");
            apiLog.setApiParameters(JsonUtils.getJson(model)); // Add userId
            apiLogService.saveLog(apiLog);
            RestListResponse<ComplianceAPResponseBean> result = new RestListResponse<>();
            result.setStatus("400"); // Bad Request
            result.setMsg(List.of("Json format is not comply!"));
            return result;
        }
        // 1. 直接從 model 取得 userId

        // Define the desired date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate fromDate = null;
        LocalDate toDate = null;

        // 2. 處理日期欄位
        // 2-1. complianceDateFrom has value, complianceDateTo is null
        // 2-2. complianceDateFrom is null, complianceDateTo has value
        // 2-3. complianceDateFrom has value, complianceDateTo has value
        // 2-4. both complianceDateFrom and complianceDateTo are null
        String complianceDateFrom = model.getBody().getComplianceDateFrom();
        String complianceDateTo = model.getBody().getComplianceDateTo();
        if (StringUtils.isNotBlank(complianceDateFrom) && StringUtils.isBlank(complianceDateTo)) {
            fromDate = LocalDate.parse(complianceDateFrom, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            toDate = fromDate.plusDays(maxQueryDaysRange);

        } else if (StringUtils.isBlank(complianceDateFrom) && StringUtils.isNotBlank(complianceDateTo)) {
            toDate = LocalDate.parse(complianceDateTo, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            fromDate = toDate.minusDays(maxQueryDaysRange);

        } else if (StringUtils.isNotBlank(complianceDateFrom) && StringUtils.isNotBlank(complianceDateTo)) {
            fromDate = LocalDate.parse(complianceDateFrom, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            toDate = LocalDate.parse(complianceDateTo, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        } else {
            // Get the current date in UTC
            toDate = LocalDate.now(ZoneOffset.UTC);
            // Subtract the specified number of days
            fromDate = toDate.minusDays(maxQueryDaysRange);

        }
        // Format the LocalDate object into a String
        model.getBody().setComplianceDateFrom(fromDate.format(formatter));
        model.getBody().setComplianceDateTo(toDate.format(formatter));

        APILog apiLog = APILog.create("CPAP-API-QueryComplianceAP", "API18");
        // apiLog.setCompanyCode(model.getCreateCompany()); // 單筆模式 才能直接取到 createCompany
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(JsonUtils.getJson(model)); // Add userId
        apiLogService.saveLog(apiLog);

        log.info("fetchComplianceAPInfo() Track ID: {}", apiLog.getActionId());

        // 2. 用 userKey 去 profile service 取得 userInfo
        // Object userObject = profileClient.getAccount(serviceAccountId, model.getBody().getUserId());
        // JsonUtils.print(userObject);
        // Sample of resopnse:
        // {
        //     "userEmail" : "test_user_9th@yinchaotsengoutlook.onmicrosoft.com",
        //     "userName" : "Test User 9th",
        //     "userObjectId" : "9195d6fa-f6ba-40f9-a078-d20de6b9d447",
        //     "roles" : "8b555b16-bf8a-4cb8-954d-fb7dbd8b45a9, 141fcb04-c7b3-4c33-8d12-7d8a14760b9f, 0cc197ca-346a-4429-832e-79e2ded6056e",
        //     "roleNames" : "OP,Pricing,CPAP-QUERY-API",
        //     "branch" : "SH1",
        //     "policyData" : "{\"carrier\": \"Maersk, Evergreen\"}",
        //     "lastLoginTime" : "2025-04-26 21:02:57",
        //     "createTime" : "2025-04-26 19:37:34",
        //     "updateTime" : "2025-04-26 19:37:34",
        //     "active" : true
        // }
        // String json = new ObjectMapper().writeValueAsString(userObject);
        // Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
        // String roles = JsonPath.read(document, "$.roleNames");
        // Boolean isActive = JsonPath.read(document, "$.active");
        // String branchCode = JsonPath.read(document, "$.branch");
        // Optional<String> companyCodeOptional = commonGlobalTableService.getCompanyCodeByBranchCode(branchCode);
        // String companyCode = "";
        // if (companyCodeOptional.isPresent()) {
        //     companyCode = companyCodeOptional.get();
        // }
        // if (!containsAnyElement(roles, "CPAP-QUERY-API", true) || isActive == false) {
        //     String message = String.format("End user [%s] isActivt = [%b] roles = [%s] is not active or doesn't have the role of CPAP-QUERY-API", userIdString, isActive, roles);
        //     log.warn(message);
        //     apiLog.setApiStatus("REJECTED");
        //     String mergedJsonString = String.format("{\"Reason\": \"%s\"}", getStringForJson(message));
        //     apiLog.setApiResponse(mergedJsonString);
        //     apiLogService.saveLog(apiLog);
        //     throw new AuthorizationException("Not enough privilege for CPAP query");
        // }

        try {
            RestListResponse<ComplianceAPResponseBean> result = cpComplianceTableService.queryComplianceAPInfo(model, model.getBody().getCompanyCode());
            apiLog.setApiStatus("DONE");
            String mergedJsonString = String.format("{\"Number of result\": \"%d\"}", result.getBody().size());
            apiLog.setApiResponse(mergedJsonString);

            List<UUID> toBeMarkedComplianceIdList = result.getBody().stream()
                .map(ComplianceAPResponseBean::getComplianceId)
                .collect(Collectors.toList());
            log.debug("The size of toBeMarkedComplianceIdList = [{}]", toBeMarkedComplianceIdList.isEmpty()?0:toBeMarkedComplianceIdList.size());

            // send to Kafak topic for handling 
            int updates = cpComplianceTableService.batchUpdateComplianceSyncStatus(toBeMarkedComplianceIdList);
            log.debug("at_account_transaction_header updated {} record(s).", updates);

            return result;
        } catch (Exception e) {
            String message = String.format("Error querying compalicne AP info: %s", e.getMessage());
            log.error(message, e);
            // debugMsg.add(logMessage(message));
            apiLog.setApiStatus("ERROR");
            String mergedJsonString = String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage()));
            apiLog.setApiResponse(mergedJsonString);
            throw e;
        } finally {
            apiLogService.saveLog(apiLog);
        }
    }

    /**
     * 第一版實作：要讓 end user client application 完成 Microsoft Entra ID 登入後，才能使用本 API
     * @param authHeader
     * @param userKey
     * @param model
     * @return
     * @throws Exception
     */
    public RestListResponse<ComplianceAPResponseBean> fetchComplianceAPInfoOld(
        @RequestHeader(value = "Authorization", required = false) String authHeader,
        // If the header is missing, Spring will throw a MissingRequestHeaderException by default.
        @RequestHeader(value = "userkey", required = false) String userKey,
        @RequestBody RestRequest<ComplianceAPRequestBean> model
    ) throws Exception {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();

        log.info("CPAP inbound for querying AP compliance info Authorization = [{}] userKey = [{}]: ", authHeader!=null, userKey );
        JsonUtils.print(model);

        // 1. 從 token 取得 userInfo
        Optional<String> userIdOptional = getClientIdFromToken(authHeader.replace("Bearer ", ""));
        String userIdString = "";
        if (userIdOptional.isPresent()) {
            userIdString = userIdOptional.get();
            model.getBody().setUserId(userIdString);
        } else {
            throw new BadTokenException("No subject from from token!");
        }

        // Get the current date in UTC
        LocalDate todayUtc = LocalDate.now(ZoneOffset.UTC);

        // Subtract the specified number of days
        LocalDate dateBeforeTodayUtc = todayUtc.minusDays(maxQueryDaysRange);

        // Define the desired date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Format the LocalDate object into a String
        model.getBody().setComplianceDateFrom(dateBeforeTodayUtc.format(formatter));
        model.getBody().setComplianceDateTo(todayUtc.format(formatter));

        APILog apiLog = APILog.create("CPAP-API-QueryComplianceAP", "API18");
        // apiLog.setCompanyCode(model.getCreateCompany()); // 單筆模式 才能直接取到 createCompany
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(JsonUtils.getJson(model)); // Add userId
        apiLogService.saveLog(apiLog);

        log.info("fetchComplianceAPInfo() Track ID: {}", apiLog.getActionId());

        // 2. 用 userKey 去 profile service 取得 userInfo
        Object userObject = profileClient.getAccount(serviceAccountId, userIdString);
        JsonUtils.print(userObject);
        // Sample of resopnse:
        // {
        //     "userEmail" : "test_user_9th@yinchaotsengoutlook.onmicrosoft.com",
        //     "userName" : "Test User 9th",
        //     "userObjectId" : "9195d6fa-f6ba-40f9-a078-d20de6b9d447",
        //     "roles" : "8b555b16-bf8a-4cb8-954d-fb7dbd8b45a9, 141fcb04-c7b3-4c33-8d12-7d8a14760b9f, 0cc197ca-346a-4429-832e-79e2ded6056e",
        //     "roleNames" : "OP,Pricing,CPAP-QUERY-API",
        //     "branch" : "SH1",
        //     "policyData" : "{\"carrier\": \"Maersk, Evergreen\"}",
        //     "lastLoginTime" : "2025-04-26 21:02:57",
        //     "createTime" : "2025-04-26 19:37:34",
        //     "updateTime" : "2025-04-26 19:37:34",
        //     "active" : true
        // }
        String json = new ObjectMapper().writeValueAsString(userObject);
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
        String roles = JsonPath.read(document, "$.roleNames");
        Boolean isActive = JsonPath.read(document, "$.active");
        String branchCode = JsonPath.read(document, "$.branch");
        Optional<String> companyCodeOptional = commonGlobalTableService.getCompanyCodeByBranchCode(branchCode);
        String companyCode = "";
        if (companyCodeOptional.isPresent()) {
            companyCode = companyCodeOptional.get();
        }
        if (!containsAnyElement(roles, "CPAP-QUERY-API", true) || isActive == false) {
            String message = String.format("End user [%s] isActivt = [%b] roles = [%s] is not active or doesn't have the role of CPAP-QUERY-API", userIdString, isActive, roles);
            log.warn(message);
            apiLog.setApiStatus("REJECTED");
            String mergedJsonString = String.format("{\"Reason\": \"%s\"}", getStringForJson(message));
            apiLog.setApiResponse(mergedJsonString);
            apiLogService.saveLog(apiLog);
            throw new AuthorizationException("Not enough privilege for CPAP query");
        }

        try {
            RestListResponse<ComplianceAPResponseBean> result = cpComplianceTableService.queryComplianceAPInfo(model, companyCode);
            apiLog.setApiStatus("DONE");
            String mergedJsonString = String.format("{\"Number of result\": \"%d\"}", result.getBody().size());
            apiLog.setApiResponse(mergedJsonString);

            List<UUID> toBeMarkedComplianceIdList = result.getBody().stream()
                .map(ComplianceAPResponseBean::getComplianceId)
                .collect(Collectors.toList());
            log.debug("The size of toBeMarkedComplianceIdList = [{}]", toBeMarkedComplianceIdList.isEmpty()?0:toBeMarkedComplianceIdList.size());

            // send to Kafak topic for handling 
            int updates = cpComplianceTableService.batchUpdateComplianceSyncStatus(toBeMarkedComplianceIdList);
            log.debug("at_account_transaction_header updated {} record(s).", updates);

            return result;
        } catch (Exception e) {
            String message = String.format("Error querying compalicne AP info: %s", e.getMessage());
            log.error(message, e);
            // debugMsg.add(logMessage(message));
            apiLog.setApiStatus("ERROR");
            String mergedJsonString = String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage()));
            apiLog.setApiResponse(mergedJsonString);
            throw e;
        } finally {
            apiLogService.saveLog(apiLog);
        }
    }

    private Optional<String> getClientIdFromToken( String jwtToken ) {
        try {
            // Decode the token without verification
            DecodedJWT decodedJWT = JWT.decode(jwtToken);

            // Access the claims
            Claim clientIdClaim = decodedJWT.getClaim("clientId");
            String subjectClaim = decodedJWT.getSubject(); // Standard 'sub' claim

            // Extract the clientId value
            if (!clientIdClaim.isNull()) {
                String clientId = clientIdClaim.asString();
                log.debug("Successfully decoded JWT (without verification).");
                log.debug("Extracted Client ID: " + clientId);
            } else {
                log.debug("JWT decoded, but 'clientId' claim not found or is null.");
            }

            // You can access other claims similarly
            //  if (subjectClaim != null && !subjectClaim.isNull()) {
            if (StringUtils.isNotBlank(subjectClaim)) {
                log.debug("Subject (sub) claim: {}", subjectClaim);
            }

            // Get all claims
            log.debug("\nAll Claims (decoded):");
            decodedJWT.getClaims().forEach((key, value) -> {
                if (value != null && !value.isNull()) {
                    log.debug(key + ": " + value.asString()); // Attempt to print as string, handle other types as needed
                } else {
                    log.debug(key + ": null");
                }
            });

            return Optional.ofNullable(subjectClaim);

        } catch (JWTDecodeException exception){
            // Invalid token format (e.g., not enough parts, not valid Base64)
            log.error("Failed to decode JWT: " + exception.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Checks if at least one element in stringB (comma-separated) is present
     * within stringA (comma-separated).
     *
     * @param stringA The first comma-separated string (the source list).
     * @param stringB The second comma-separated string (the list to check for presence).
     * @param ignoreCase Whether to ignore case during comparison.
     * @return true if at least one element of stringB is found in stringA, false otherwise.
     */
    public boolean containsAnyElement(String stringA, String stringB, boolean ignoreCase) {
        // 1. If either stringA or stringB is null, return false.
        if (stringA == null || stringB == null) {
            return false;
        }

        // 2. Split strings into lists of elements, handling empty/whitespace strings
        List<String> listA = splitAndTrim(stringA);
        List<String> listB = splitAndTrim(stringB);

        // 3. If listB is empty after splitting/trimming, no elements can match, return false.
        // If listA is empty and listB is not, no elements from B can be in A, return false.
        if (listB.isEmpty() || listA.isEmpty()) {
            return false;
        }

        // 4. Convert listA to a Set for efficient lookup
        Set<String> setA;
        List<String> listBForCheck;

        if (ignoreCase) {
            setA = listA.stream()
                        .map(String::toLowerCase) // Convert to lowercase for case-insensitive comparison
                        .collect(Collectors.toSet());
            listBForCheck = listB.stream()
                                 .map(String::toLowerCase) // Convert listB elements to lowercase for checking
                                 .collect(Collectors.toList());
        } else {
            setA = listA.stream()
                        .collect(Collectors.toSet());
            listBForCheck = listB; // Use original listB for case-sensitive check
        }

        // 5. Check if any element of listBForCheck is present in setA
        // We can use stream's anyMatch for this.
        return listBForCheck.stream()
                            .anyMatch(setA::contains);
    }

    /**
     * Helper method to split a comma-separated string and trim each element.
     * Handles cases with extra spaces around commas and empty elements.
     *
     * @param input The comma-separated string.
     * @return A list of trimmed elements.
     */
    private List<String> splitAndTrim(String input) {
        if (input == null || input.trim().isEmpty()) {
            return List.of(); // Return empty list for null or empty input
        }
        return Arrays.stream(input.split(","))
                     .map(String::trim) // Trim whitespace from each element
                     .filter(element -> !element.isEmpty()) // Remove any empty strings resulting from split (e.g., ",a,b," or "a,,b")
                     .collect(Collectors.toList());
    }

}
