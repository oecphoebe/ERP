package oec.lis.erpportal.addon.compliance.transaction.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

@Service
@Slf4j
public class TransactionValidationService {

    // Configure JsonPath to suppress exceptions
    private final Configuration configWithoutException = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

    /**
     * Validates if a ChargeLine has minimum required data for database persistence
     * @param jsonChargeLine JSON string of the charge line
     * @return true if minimum required data is present, false otherwise
     */
    public boolean hasMinimumRequiredData(String jsonChargeLine) {
        try {
            String chargeCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.ChargeCode.Code");
            return StringUtils.isNotBlank(chargeCode);
        } catch (Exception e) {
            log.debug("Error checking minimum data for charge line: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Validates if a ChargeLine has valid SellGSTVATID for AR transactions
     * @param jsonChargeLine JSON string of the charge line
     * @return true if SellGSTVATID exists and is valid, false otherwise
     */
    public boolean hasValidSellGSTVATID(String jsonChargeLine) {
        try {
            Object sellGSTVATID = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellGSTVATID");
            if (sellGSTVATID == null) return false;
            
            // Check if TaxCode exists and is not empty
            String taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.SellGSTVATID.TaxCode");
            return StringUtils.isNotBlank(taxCode);
        } catch (Exception e) {
            log.debug("Error checking SellGSTVATID for charge line: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Validates if a ChargeLine has valid CostGSTVATID for AP transactions
     * @param jsonChargeLine JSON string of the charge line
     * @return true if CostGSTVATID exists and is valid, false otherwise
     */
    public boolean hasValidCostGSTVATID(String jsonChargeLine) {
        try {
            Object costGSTVATID = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID");
            if (costGSTVATID == null) return false;
            
            // Check if TaxCode exists and is not empty
            String taxCode = JsonPath.using(configWithoutException).parse(jsonChargeLine).read("$.CostGSTVATID.TaxCode");
            return StringUtils.isNotBlank(taxCode);
        } catch (Exception e) {
            log.debug("Error checking CostGSTVATID for charge line: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Validates policy compliance - ensures all valid transaction data is saved to database
     * @param linesBeanList List of lines saved to database
     * @param requestBeanList List of lines ready for external system
     * @param ledger Transaction ledger (AR/AP)
     * @param transactionType Transaction type (INV/CRD)
     * @param transactionNo Transaction number for logging
     */
    public void validatePolicyCompliance(
        List<AtAccountTransactionLinesBean> linesBeanList,
        List<TransactionChargeLineRequestBean> requestBeanList,
        String ledger, String transactionType, String transactionNo) {
        
        // Policy: All valid transaction data must be saved to database regardless of external system requirements
        boolean hasValidData = !linesBeanList.isEmpty();
        
        // Log policy compliance status
        log.info("Policy compliance check - Transaction: {} [{}:{}], DB records: {}, External records: {}, Compliant: {}",
                 transactionNo, ledger, transactionType, linesBeanList.size(), requestBeanList.size(), hasValidData);
        
        // For AR transactions, log separation statistics
        if (StringUtils.equals("AR", ledger)) {
            int missingVATCount = linesBeanList.size() - requestBeanList.size();
            if (missingVATCount > 0) {
                log.info("AR transaction policy compliance: {} records saved to DB, {} missing VAT info not sent to external system",
                         linesBeanList.size(), missingVATCount);
            }
        }
    }

    /**
     * 
     * @param ledger ledger of this TransactionInfo {"AR","AP"}
     * @param refNoType reference no type of this TransactionInfo {"SHIPMENT","CONSOL"}
     * @param currentShipmentNo current shipment no of TransactionInfo.ShipmentCollection.Shipment[]
     * @param displaySequence current displaySequence of the ChargeLine of Shipment of TransactionInfo
     * @param currentChargeCode current ChargeCode of the ChargeLine of Shipment of TransactionInfo
     * @param currentCreditor current creditor of the ChargeLine
     * @param currentInvoiceNo current invoice number of the ChargeLine
     * @param cwTransactionInfo acctTransactionLines which was queried from Cargowise by transaction no
     * @return true if match found, false otherwise
     */
    public boolean findMatch(String ledger, String refNoType, String currentShipmentNo, int displaySequence, 
                           String currentChargeCode, String currentCreditor, String currentInvoiceNo, 
                           CwAccountTransactionInfo cwTransactionInfo) {
        log.debug("ledger = [{}], refNoType = [{}], currentShipmentNo = [{}], cwTransactionInfo.getJobNumber() = [{}]; displaySequence = [{}], cwTransactionInfo.getDisplaySequence() = [{}]; currentChargeCode = [{}], cwTransactionInfo.getChargeCode() = [{}], currentCreditor = [{}], cwTransactionInfo.getCreditor() = [{}], currentInvoiceNo = [{}], cwTransactionInfo.getInvoiceNo() = [{}]", 
            ledger, refNoType,
            currentShipmentNo, cwTransactionInfo.getJobNumber(), 
            displaySequence, cwTransactionInfo.getDisplaySequence(), 
            currentChargeCode, cwTransactionInfo.getChargeCode(),
            currentCreditor, cwTransactionInfo.getCreditor(),
            currentInvoiceNo, cwTransactionInfo.getInvoiceNo()
        );
        
        // NONJOB validation: Different matching criteria for non-job transactions
        if (StringUtils.equals("NONJOB", refNoType)) {
            // For NONJOB transactions, skip shipment-based validations
            // Focus on charge-level matching: chargeCode, creditor, and invoiceNo
            boolean matches = StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode()) &&
                             StringUtils.equals(currentCreditor, cwTransactionInfo.getCreditor()) &&
                             StringUtils.equals(currentInvoiceNo, cwTransactionInfo.getInvoiceNo());
            
            if (matches) {
                log.debug("NONJOB validation passed - charge match: [{}][{}][{}]", 
                         currentChargeCode, currentCreditor, currentInvoiceNo);
            } else {
                log.debug("NONJOB validation failed - charge mismatch: expected[{}][{}][{}] vs actual[{}][{}][{}]",
                         currentChargeCode, currentCreditor, currentInvoiceNo,
                         cwTransactionInfo.getChargeCode(), cwTransactionInfo.getCreditor(), cwTransactionInfo.getInvoiceNo());
            }
            return matches;
        }
        
        if (StringUtils.equals("AR", ledger) 
            && displaySequence == cwTransactionInfo.getDisplaySequence()) {
            // AR 就比對 displaySequence, 符合就通過
            log.debug("Rule 1: AR and displaySequence matched.");
            return true;
        }
        
        if (StringUtils.equals("AP", ledger) 
            && StringUtils.equals("SHIPMENT", refNoType) 
            && StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode())
            && StringUtils.equals(currentCreditor, cwTransactionInfo.getCreditor())
            && StringUtils.equals(currentInvoiceNo, cwTransactionInfo.getInvoiceNo())) {
            // AP SHIPMENT only 也比對 displaySequence, 符合就通過
            log.debug("Rule 2: AP-SHIPMENT and chargeCode and creditor matched.");
            return true;
        }
        
        if (StringUtils.equals("AP", ledger) 
            && StringUtils.equals("CONSOL", refNoType) 
            && StringUtils.equals(currentShipmentNo, cwTransactionInfo.getJobNumber())
            && StringUtils.equals(currentChargeCode, cwTransactionInfo.getChargeCode()) 
            && StringUtils.equals(currentInvoiceNo, cwTransactionInfo.getInvoiceNo())) {
            // AP CONSOL 時，比對 shipmentNo + chargeCode, 符合才通過
            log.debug("Rule 3: AP-CONSOL and shipmentNo + chargeCode matched.");
            return true;
        }
        
        return false;
    }
}