package oec.lis.erpportal.addon.compliance.model.transaction;

import java.sql.Timestamp;
import java.util.UUID;

import lombok.Data;

@Data
public class AtShipmentInfoBean {
    // CREATE  TABLE sopl.at_shipment_info ( 
    //     ref_no               varchar(20)  NOT NULL  ,
    //     shipment_no          varchar(20)    ,
    //     cnsl_no              varchar(20)    ,
    //     hbl_no               varchar(20)    ,
    //     mbl_no               varchar(35)    ,
    //     master_mbl           varchar(35)    ,
    //     shipment_id          uuid    ,
    //     master_shipment_id   uuid    ,
    //     carrier_book_no      varchar(35)    ,
    //     etd                  timestamp    ,
    //     atd                  timestamp    ,
    //     ata                  timestamp    ,
    //     shipment_type        varchar(3)    ,
    //     cnsl_type            varchar(3)    ,
    //     cntr_mode            char(3)    ,
    //     cntr_list            varchar(2500)    ,
    //     cnsl_first_leg_vssl  varchar(35)    ,
    //     cnsl_first_leg_voy   varchar(10)    ,
    //     create_cmpny         varchar(3)    ,
    //     create_branch        varchar(3)    ,
    //     create_dept          varchar(3)    ,
    //     create_by            varchar(50)    ,
    //     create_time          timestamp    ,
    //     CONSTRAINT pk_at_shipment_info PRIMARY KEY ( ref_no )
    //  );

    private String refNo; // length = 20
    private String shipmentNo; // length = 20
    private String consolNo; // length = 20
    private String hblNo; // length = 20
    private String mblNo; // length = 35
    private String masterMbl; // length = 35
    private UUID shipmentId;
    private UUID masterShipmentId;
    private String carrierBookingNo; // length = 35
    private Timestamp etd;
    private Timestamp atd;
    private Timestamp ata;
    private String shipmentType;
    private String consolType;
    private String containerMode;
    private String containerList; // length = 2500
    private String consolFirstLegVessel;
    private String consolFirstLegVoyage;
    private String createCompany;
    private String createBranch;
    private String createDepartment;
    private String createBy;
    private Timestamp createTime;
}
