package oec.lis.erpportal.addon.compliance.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

/**
 * Configuration properties for shipment information processing.
 * This class binds to 'shipment' prefix in application configuration
 * and provides type-safe access to shipment-related settings.
 *
 * <p>Configuration Example:
 * <pre>
 * shipment:
 *   use-view: true
 *   retry-attempts: 3
 *   retry-delay-ms: 1000
 *   fallback-enabled: true
 *   log-level: DEBUG
 * </pre>
 *
 * <p>Features:
 * - Feature flag control for view vs table implementation
 * - Configurable retry mechanisms for failed queries
 * - Fallback behavior configuration
 * - Logging level control for debugging
 * - Bean validation for configuration integrity
 */
@Slf4j
@Data
@Component
@ConfigurationProperties(prefix = "shipment")
public class ShipmentProperties {

    /**
     * Feature flag to enable view-based shipment information access.
     * When true, uses vw_shipment_info view implementation.
     * When false, uses traditional table-based implementation.
     * Default: false (maintains backward compatibility)
     */
    private Boolean useView = false;

    /**
     * Number of retry attempts for empty view results.
     * Used when view queries return no data to handle potential timing issues.
     * Minimum value: 1 (at least one attempt must be made)
     * Default: 3
     */
    private Integer retryAttempts = 3;

    /**
     * Delay in milliseconds between retry attempts.
     * Helps prevent overwhelming the database with rapid retry requests.
     * Set to 0 to disable retry delays.
     * Default: 1000ms (1 second)
     */
    private Long retryDelayMs = 1000L;

    /**
     * Enable fallback to table-based implementation when view access fails.
     * When true, automatically falls back to existing table implementation
     * if view access encounters errors.
     * Default: true (enables graceful degradation)
     */
    private Boolean fallbackEnabled = true;

    /**
     * Logging level for shipment service operations.
     * Controls the verbosity of shipment-related logging output.
     * Supported values: TRACE, DEBUG, INFO, WARN, ERROR
     * Default: INFO
     */
    private String logLevel = "INFO";

    /**
     * Timeout in milliseconds for view query operations.
     * Maximum time to wait for view queries before timing out.
     * Helps prevent long-running queries from blocking the application.
     * Default: 30000ms (30 seconds)
     */
    private Long queryTimeoutMs = 30000L;

    /**
     * Enable performance monitoring and metrics collection.
     * When true, collects timing and performance metrics for view operations.
     * Useful for monitoring and optimization in production environments.
     * Default: false
     */
    private Boolean metricsEnabled = false;

    /**
     * Maximum number of records to return in bulk operations.
     * Prevents memory issues when querying large datasets.
     * Applies to findAll* methods in the repository.
     * Default: 1000
     */
    private Integer maxResultSize = 1000;

    /**
     * Cache size for frequently accessed shipment information.
     * Number of shipment records to keep in memory cache.
     * Set to 0 to disable caching.
     * Default: 100
     */
    private Integer cacheSize = 100;

    /**
     * Cache TTL (Time To Live) in minutes.
     * How long to keep cached shipment records before expiration.
     * Only applicable when cacheSize > 0.
     * Default: 60 minutes
     */
    private Integer cacheTtlMinutes = 60;

    /**
     * Enable case-insensitive searches for shipment lookups.
     * When true, performs case-insensitive matching for reference numbers.
     * May impact query performance on large datasets.
     * Default: false
     */
    private Boolean caseInsensitiveSearch = false;

    /**
     * Database connection pool size for view operations.
     * Number of dedicated database connections for shipment view queries.
     * Set to 0 to use default connection pool.
     * Default: 0 (use default pool)
     */
    private Integer connectionPoolSize = 0;

    /**
     * Enable health check monitoring for view availability.
     * When true, periodically checks view accessibility for monitoring.
     * Provides operational visibility into view health status.
     * Default: true
     */
    private Boolean healthCheckEnabled = true;

    /**
     * Health check interval in minutes.
     * How frequently to perform view availability checks.
     * Only applicable when healthCheckEnabled = true.
     * Default: 5 minutes
     */
    private Integer healthCheckIntervalMinutes = 5;

    // Convenience methods for common configuration checks

    /**
     * Check if view-based implementation is enabled.
     *
     * @return true if view implementation should be used
     */
    public boolean isViewEnabled() {
        return Boolean.TRUE.equals(useView);
    }

    /**
     * Check if fallback mechanism is enabled.
     *
     * @return true if fallback to table implementation is allowed
     */
    public boolean isFallbackEnabled() {
        return Boolean.TRUE.equals(fallbackEnabled);
    }

    /**
     * Check if performance metrics collection is enabled.
     *
     * @return true if metrics should be collected
     */
    public boolean isMetricsEnabled() {
        return Boolean.TRUE.equals(metricsEnabled);
    }

    /**
     * Check if caching is enabled.
     *
     * @return true if caching should be used
     */
    public boolean isCacheEnabled() {
        return cacheSize != null && cacheSize > 0;
    }

    /**
     * Check if case-insensitive search is enabled.
     *
     * @return true if case-insensitive matching should be used
     */
    public boolean isCaseInsensitiveSearchEnabled() {
        return Boolean.TRUE.equals(caseInsensitiveSearch);
    }

    /**
     * Check if health check monitoring is enabled.
     *
     * @return true if health checks should be performed
     */
    public boolean isHealthCheckEnabled() {
        return Boolean.TRUE.equals(healthCheckEnabled);
    }

    /**
     * Get retry delay in milliseconds, ensuring minimum value.
     *
     * @return retry delay in milliseconds, minimum 0
     */
    public long getRetryDelayMs() {
        return retryDelayMs != null ? Math.max(0, retryDelayMs) : 1000L;
    }

    /**
     * Get query timeout in milliseconds, ensuring minimum value.
     *
     * @return query timeout in milliseconds, minimum 1000
     */
    public long getQueryTimeoutMs() {
        return queryTimeoutMs != null ? Math.max(1000, queryTimeoutMs) : 30000L;
    }

    /**
     * Diagnostic method to log shipment configuration at startup.
     * This helps identify configuration loading issues and property resolution problems.
     */
    @PostConstruct
    public void logShipmentConfigurationDiagnostics() {
        log.info("=== SHIPMENT CONFIGURATION DIAGNOSTICS ===");
        log.info("shipment.use-view: {} (raw value: {})", isViewEnabled(), useView);
        log.info("shipment.fallback-enabled: {} (raw value: {})", isFallbackEnabled(), fallbackEnabled);
        log.info("shipment.retry-attempts: {}", retryAttempts);
        log.info("shipment.retry-delay-ms: {}", getRetryDelayMs());
        log.info("shipment.query-timeout-ms: {}", getQueryTimeoutMs());
        log.info("shipment.metrics-enabled: {} (raw value: {})", isMetricsEnabled(), metricsEnabled);
        log.info("shipment.cache-enabled: {} (cache-size: {})", isCacheEnabled(), cacheSize);
        log.info("shipment.health-check-enabled: {} (raw value: {})", isHealthCheckEnabled(), healthCheckEnabled);
        log.info("Configuration loaded successfully - view implementation: {}",
                 isViewEnabled() ? "ENABLED" : "DISABLED");
        log.info("=== END SHIPMENT CONFIGURATION DIAGNOSTICS ===");
    }
}