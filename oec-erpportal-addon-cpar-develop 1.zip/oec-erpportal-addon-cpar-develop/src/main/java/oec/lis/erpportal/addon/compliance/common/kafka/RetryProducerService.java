package oec.lis.erpportal.addon.compliance.common.kafka;

import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

@Service
@ConditionalOnProperty(name = "kafka.enabled", havingValue = "true", matchIfMissing = true)
public class RetryProducerService {
    private final KafkaTemplate<String, RetryRecord> kafkaTemplate;

    @Value("${spring.profiles.active}")
    private String activeProfile;

    public RetryProducerService(@Qualifier("retryKafkaTemplate") KafkaTemplate<String, RetryRecord> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void scheduleRetry(String actionIdString, TransactionChargeLineRequestBean request) {
        RetryRecord retryRecord = new RetryRecord(request);
        retryRecord.setActionId(UUID.fromString(actionIdString));
        retryRecord.setAttempt(1);
        retryRecord.setNextAttempt(calculateNextAttempt(1));
        kafkaTemplate.send(activeProfile + "-invoice-retry", actionIdString, retryRecord);
    }

    private Instant calculateNextAttempt(int attempt) {
        // Exponential backoff: 2^attempt seconds (e.g., 2, 4, 8, 16...)
        return Instant.now().plusSeconds((long) Math.pow(2, attempt));
    }

}
