package oec.lis.erpportal.addon.compliance.schedule;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Service;

@Service
public class ExcelReportGenerator {
    
    public File generateReport(ComparisonResult result) throws IOException {
        File tempFile = File.createTempFile("comparison-report-", ".xlsx");
        
        try (Workbook workbook = new SXSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Data Comparison");

            //------------------------------------------------------------
            // 1. Get a CreationHelper
            CreationHelper createHelper = workbook.getCreationHelper();

            // 2. Create a CellStyle
            CellStyle timestampCellStyle = workbook.createCellStyle();

            // 3. Get a DataFormat from the CreationHelper
            DataFormat dataFormat = createHelper.createDataFormat();

            // 4. Define your desired date/time format string
            // Common formats:
            // "yyyy-MM-dd HH:mm:ss"
            // "MM/dd/yyyy h:mm:ss AM/PM"
            // "yyyy-MM-dd" (for date only)
            // "HH:mm:ss" (for time only)
            // "yyyy-MM-dd HH:mm:ss.SSS" (if you need milliseconds, although display depends on Excel)
            String dateFormat = "yyyy-MM-dd HH:mm:ss";

            // 5. Get the format index for your string
            short dateFormatIndex = dataFormat.getFormat(dateFormat);

            // 6. Set the data format on the CellStyle
            timestampCellStyle.setDataFormat(dateFormatIndex);
            //------------------------------------------------------------
            // Using the heuristic with padding (e.g., 2 character padding)
            sheet.setColumnWidth(0, (20+ 2) * 256);
            sheet.setColumnWidth(4, (20 + 2) * 256);
            // sheet.setColumnWidth(8, (20 + 2) * 256);

            sheet.setColumnWidth(2, (36 + 2) * 256);
            sheet.setColumnWidth(6, (36 + 2) * 256);
            // sheet.setColumnWidth(10, (36 + 2) * 256);

            sheet.setColumnWidth(3, (22 + 2) * 256);
            sheet.setColumnWidth(7, (22 + 2) * 256);
            // sheet.setColumnWidth(11, (22 + 2) * 256);
            
            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Source Data: AH_TransactionNum");
            headerRow.createCell(1).setCellValue("AH_TransactionType");
            headerRow.createCell(2).setCellValue("AH_PK");
            headerRow.createCell(3).setCellValue("AH_PostDate");
            headerRow.createCell(4).setCellValue("Target Data: trans_no");
            headerRow.createCell(5).setCellValue("trans_type");
            headerRow.createCell(6).setCellValue("acct_trans_header_id");
            headerRow.createCell(7).setCellValue("update_time");
            // headerRow.createCell(8).setCellValue("Missing in Source: trans_no");
            // headerRow.createCell(5).setCellValue("trans_type");
            // headerRow.createCell(6).setCellValue("acct_trans_header_id");
            // headerRow.createCell(7).setCellValue("update_time");
            
            // Populate data...
            // Implement logic to populate comparison results
            Map<String, Integer> sourceIndexMap = new HashMap<>();
            int currentRowIndex = 1;
            for( DataRecord aRecord : result.sourceData()) {
                Row currentRow = sheet.createRow(currentRowIndex++);
                currentRow.createCell(0).setCellValue(aRecord.id());
                currentRow.createCell(1).setCellValue(aRecord.getAttribute("transaction_type", String.class));
                currentRow.createCell(2).setCellValue(aRecord.getAttribute("id", String.class));
                Cell cell4 = currentRow.createCell(3);
                cell4.setCellValue(aRecord.getAttribute("update_time", Timestamp.class));
                cell4.setCellStyle(timestampCellStyle);

                // Find if there is a match transaction_no in targetData
                List<DataRecord> matchInTarget = result.targetData().stream()
                    .filter(record -> StringUtils.equals(record.id(), aRecord.id()) && StringUtils.equals(record.getAttribute("transaction_type", String.class), aRecord.getAttribute("transaction_type", String.class)) )
                    .collect(Collectors.toList());
                // if found, add currentRowIndex into DataRecord
                if (!matchInTarget.isEmpty()) {
                    // DataRecord is designed to be immutable
                    // matchInTarget.get(0).setAttribute("index", Integer.valueOf(currentRowIndex));
                    sourceIndexMap.put(aRecord.id(), Integer.valueOf(currentRowIndex));
                }
            }
            
            // currentRowIndex++; // 多空一列
            // 進入 Target list 處理部分
            for( DataRecord aRecord : result.targetData()) {
                if ( sourceIndexMap.containsKey(aRecord.id()) ) { // aRecord.hasAttribute("index")
                    Integer rowIndex = sourceIndexMap.get(aRecord.id()); //aRecord.getAttribute("index", Integer.class);
                    Row currentRow = sheet.getRow(rowIndex-1);
                    currentRow.createCell(4).setCellValue(aRecord.id());
                    currentRow.createCell(5).setCellValue(aRecord.getAttribute("transaction_type", String.class));
                    currentRow.createCell(6).setCellValue(aRecord.getAttribute("id", UUID.class).toString());
                    Cell cell4 = currentRow.createCell(7);
                    cell4.setCellValue(aRecord.getAttribute("update_time", Timestamp.class));
                    cell4.setCellStyle(timestampCellStyle);
                } else {
                    Row currentRow = sheet.createRow(currentRowIndex++);
                    currentRow.createCell(4).setCellValue(aRecord.id());
                    currentRow.createCell(5).setCellValue(aRecord.getAttribute("transaction_type", String.class));
                    currentRow.createCell(6).setCellValue(aRecord.getAttribute("id", UUID.class).toString());
                    Cell cell4 = currentRow.createCell(7);
                    cell4.setCellValue(aRecord.getAttribute("update_time", Timestamp.class));
                    cell4.setCellStyle(timestampCellStyle);
                }
            }
            // currentRowIndex++; // 多空一列
            // 進入 Missing list 處理部分
            // 先關掉, 除了 trans_no, 還要比對 transaction_type
            // for( DataRecord aRecord : result.missingInSource()) {
            //     Row currentRow = sheet.createRow(currentRowIndex++);
            //     currentRow.createCell(8).setCellValue(aRecord.id());
            //     currentRow.createCell(9).setCellValue(aRecord.getAttribute("transaction_type", String.class));
            //     currentRow.createCell(10).setCellValue(aRecord.getAttribute("id", String.class));
            //     Cell cell4 = currentRow.createCell(11);
            //     cell4.setCellValue(aRecord.getAttribute("update_time", Timestamp.class));
            //     cell4.setCellStyle(timestampCellStyle);
            // }
            
            // Write to file
            try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                workbook.write(outputStream);
            }
        }
        
        return tempFile;
    }
}