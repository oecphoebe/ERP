package oec.lis.erpportal.addon.compliance.model.outbound;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostingJournalDetail {
    @JsonProperty("CreditGLAccount")
    private GLAccount creditGLAccount;

    @JsonProperty("DebitGLAccount")
    private GLAccount debitGLAccount;

    @JsonProperty("PostingAmount")
    private BigDecimal postingAmount;

    @JsonProperty("PostingCurrency")
    private CodeDescription postingCurrency;

    @JsonProperty("PostingDate")
    private String postingDate;

    @JsonProperty("PostingPeriod")
    private int postingPeriod;
}
