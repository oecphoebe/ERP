package oec.lis.erpportal.addon.compliance.service.impl;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.service.CommonGlobalTableService;

@Service
@Slf4j
public class CommonGlobalTableServiceImpl implements CommonGlobalTableService {

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    public CommonGlobalTableServiceImpl(
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    @Override
    public Optional<String> getCompanyCodeByBranchCode(String branchCode) {
        String query = new StringBuilder()
            .append("select cgc.cmpny_code from cw_global_branch cgb ")
            .append("inner join cw_global_company cgc on cgc.global_cmpny_id = cgb.global_cmpny_id ")
            .append("where cgb.branch_code = :branchCode")
            .toString();

        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("branchCode", branchCode)
            ;

        try {
            return Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, String.class));
        } catch (EmptyResultDataAccessException e) {
            log.info("getCompanyCodeByBranchCode() no existing record found : branchCode=[{}] {}", branchCode, e.getMessage());
        }
        return Optional.empty();

    }

    @Override
    public BuyerInfo findBuyerReference(String reference) {
        log.info("Looking up buyer reference: {}", reference);
        
        String query = new StringBuilder()
            .append("SELECT org_header_id, org_code, full_name ")
            .append("FROM cw_org_header ")
            .append("WHERE org_code = :orgCode AND is_active = true")
            .toString();

        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("orgCode", reference);

        try {
            return soplNamedJdbcTemplate.queryForObject(query, namedParameters, (rs, rowNum) -> {
                BuyerInfo buyerInfo = new BuyerInfo();
                buyerInfo.setOrganizationCode(rs.getString("org_code"));
                buyerInfo.setCompanyName(rs.getString("full_name"));
                buyerInfo.setBuyerReference(rs.getString("org_code"));
                buyerInfo.setBuyerName(rs.getString("full_name"));
                log.info("Found buyer: {} - {}", buyerInfo.getOrganizationCode(), buyerInfo.getCompanyName());
                return buyerInfo;
            });
        } catch (EmptyResultDataAccessException e) {
            log.warn("No buyer found for reference: {}", reference);
            return null; // Return null to indicate lookup failure
        }
    }
    
}
