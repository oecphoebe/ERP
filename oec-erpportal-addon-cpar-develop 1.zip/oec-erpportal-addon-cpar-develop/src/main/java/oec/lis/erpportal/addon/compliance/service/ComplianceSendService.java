package oec.lis.erpportal.addon.compliance.service;

import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;

import oec.lis.erpportal.addon.compliance.exception.AtAccountTransactionNotFoundException;
import oec.lis.sopl.external.inbound.bo.CWISShipmentInbound;
import oec.lis.sopl.external.inbound.vo.ComlianceCompleteInbound;

public interface ComplianceSendService {
    public List<ComlianceCompleteInbound> generateComplianceData( List<UUID> accountTransactionHeaderIdList ) throws AtAccountTransactionNotFoundException;
    public ResponseEntity<CWISShipmentInbound> sendComplianceData( ComlianceCompleteInbound complianceCompleteInbound ) throws Exception;
}
