package oec.lis.erpportal.addon.compliance.api15.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import oec.lis.erpportal.addon.compliance.api15.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api15.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.client.FeignConfigFactory;
import oec.lis.erpportal.addon.compliance.common.api.config.BasicFeignConfig;

@FeignClient(name = "authClient", url = "${external.compliance.url}", configuration = BasicFeignConfig.class) // FeignConfigFactory.BasicConfig.class
public interface AuthClient {
    @PostMapping("/api/Invoice/v1/ApiToken")
    // @PostMapping("/rest/token") // for local test endpoint use
    AuthResponse authenticate(@RequestBody AuthRequest request);
}
