package oec.lis.erpportal.addon.compliance.controller;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.controller.AbstractController;
import oec.lis.erpportal.addon.compliance.common.kafka.RetryRecord;
import oec.lis.erpportal.addon.compliance.exception.NonJobNotSupportedException;
import oec.lis.erpportal.addon.compliance.exception.NotSupportedTransactionException;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.outbound.TransactionOutbound;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.UniversalType;
import oec.lis.erpportal.addon.compliance.match.MatchTransactionService;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.erpportal.addon.compliance.service.TransactionRoutingService;
import oec.lis.erpportal.addon.compliance.transaction.TransactionService;
import oec.lis.sopl.common.model.CommonRestApiResponse;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.util.JsonUtils;

@RestController
@RequestMapping("/external")
@Tag(name = "/external", description ="Receive Cargowise outbound information: universalTransaction and handle")
@Slf4j
public class UniversalController extends AbstractController {

    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Value("${kafka.enabled:true}")
    private boolean kafkaEnabled;

    private TransactionService transactionService;
    // private final KafkaTemplate<String, TransactionChargeLineRequestBean> kafkaTemplate;
    private final KafkaTemplate<String, RetryRecord> kafkaTemplate;

    private ApiLogService apiLogService;
    private final TransactionRoutingService routingService;
    private final MatchTransactionService matchTransactionService;

    public UniversalController(
        TransactionService transactionService,
        ApiLogService apiLogService,
        // @Qualifier("invoiceKafkaTemplate") KafkaTemplate<String, TransactionChargeLineRequestBean> kafkaTemplate
        @Autowired(required = false) @Qualifier("retryKafkaTemplate") KafkaTemplate<String, RetryRecord> kafkaTemplate,
        TransactionRoutingService routingService,
        MatchTransactionService matchTransactionService
    ) {
        this.apiLogService = apiLogService;
        this.transactionService = transactionService;
        this.kafkaTemplate = kafkaTemplate;
        this.routingService = routingService;
        this.matchTransactionService = matchTransactionService;
    }

    @PostMapping("/v0/ARTransaction")
    public RestListResponse<TransactionChargeLineRequestBean> confirmPayload(
        @Valid @RequestBody final Object transactionOutbound
        ) throws Exception {
        log.info("CWIS outbound UniversalTransaction content : ");
        JsonUtils.print(transactionOutbound);
        RestListResponse<TransactionChargeLineRequestBean> response = null;
        return response;
    }

    @PostMapping("/v1/ARTransaction")
    public ResponseEntity<String> receivePayload(
        @RequestBody Map<String, Object> payload
    ) throws Exception {
        long startTime = System.currentTimeMillis(); // Track execution time for all responses
        String json = new ObjectMapper().writeValueAsString(payload);
        log.info("CWIS outbound UniversalTransaction content : \n{}", json);

        // Extract common transaction identifying information first
        // Use Option.SUPPRESS_EXCEPTIONS for robustness if paths might not exist
        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        APILog apiLog = APILog.create("CPAR-API-UniversalTransaction", "API14");
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(json);
        apiLog.setUpdateBy("CWIS");
        apiLogService.saveLog(apiLog);


        UniversalType universalType = UniversalType.UNIVERSAL_TRANSACTION;
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        Map<String, Object> universalStructure = JsonPath.using(lenientConfig).parse(allDocument).read("$.Body.UniversalTransaction");
        if (universalStructure == null) {
            universalStructure = JsonPath.using(lenientConfig).parse(allDocument).read("$.Body.UniversalTransactionBatch");
            if (universalStructure != null) {
                universalType = UniversalType.UNIVERSAL_TRANSACTION_BATCH;
            } else {
                return ResponseEntity.badRequest()
                    .header("X-Track-ID", apiLog.getActionId().toString())
                    .header("X-API-ID", apiLog.getApiId().toString())
                    .body("Unsupported data strucutre! Track ID: " + apiLog.getApiId() );
            }
        }

        if (universalType.equals(UniversalType.UNIVERSAL_TRANSACTION)) {

            RestListResponse<TransactionChargeLineRequestBean> response = null;
            try {
    
                // --- 以下為處理 ADD 資料的邏輯 -> 避免讓系統同時處理 ADD 與 EDT, 發生矛盾或重複
                // "ADD" 與 "EDT" 發送時間非常接近，為避免重複發送，將 ADD 送入 delay queue 中，在這裡先處理 EDT 資料；
                // 這樣安排的話，萬一沒有收到 EDT 資料，還有機會從 delay queue 處理 ADD 資料
                // 處理 ADD 資料時，需先判斷 at_account_transaction_header 是否已經有資料了，若有則不處理 ADD 資料
                // 處理 EDT 資料時，需先判斷 at_account_transaction_header 是否已經有資料了，若有則判斷 update time，若這筆的 Trigger Date 早於 update time 則不處理 EDT 資料
                // TriggerDate 含有時區資訊，可用在其他 Date value 的時區指定或轉換 （BillDate, DueDate精度只到 Date 不需要時區資訊）
                // 將 TriggerDate 存入 APILog.update_time，提供處理 EDT 資料判斷是否有尚未更新的舊資料
                String triggerDateString = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.DataContext.TriggerDate");
                String eventTypeCode = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.DataContext.EventType.Code");
                String ledger = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.Ledger");
                String transactionType = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.TransactionType");
                String transactionNo = JsonPath.read(allDocument, "$.Body.UniversalTransaction.TransactionInfo.Number");
                log.info("Track id : {} EventType.Code = [{}] Ledger = [{}], TransactionType = [{}], TransactionNo = [{}], TriggerDate = [{}]", 
                        apiLog.getActionId(), eventTypeCode, ledger, transactionType, transactionNo, triggerDateString);
                // if (StringUtils.equals("ADD", eventTypeCode)) {
                //     apiLog.setApiStatus("SKIP");
                //     String correctlyFormattedJsonString = String.format("{\"Exception\": \"%s\"}", "Ledger is AP, skip this payload");
                //     apiLog.setApiResponse(correctlyFormattedJsonString);
                //     apiLogService.saveLog(apiLog);
                //     // 20250421 先跳過, 不處理這筆資料
    
                // 解析 JSON 並儲存至資料庫
                response = transactionService.analyzePayloadRaw(json);
    
                // Extract transaction number from response for validation (don't overwrite original transactionNo)
                String responseTransactionNo = response.getBody() != null && !response.getBody().isEmpty() 
                    ? response.getBody().get(0).getBillNo() 
                    : null;
                
                // Extract processing result for enhanced ApiLog tracking
                Map<String, Object> apiResponse = new LinkedHashMap<>();
                
                // Check for lookup errors in the response messages
                boolean hasLookupErrors = response.getMsg() != null && 
                    response.getMsg().stream().anyMatch(msg -> 
                        msg.contains("LOOKUP_ERRORS_DETECTED") || 
                        msg.contains("No SellReference found") || 
                        msg.contains("No SupplierReference found") || 
                        msg.contains("Warning: "));
                
                // Use routing service to determine if should send to external system
                boolean shouldSendToExternal = routingService.shouldSendToExternalSystem(ledger, transactionType, transactionNo);
                
                // Determine status based on routing configuration and lookup errors
                String status;
                boolean readyForExternal = !hasLookupErrors; // Not ready if there are lookup errors
                
                if (!shouldSendToExternal) {
                    // If routing says no external system, status is DONE regardless of lookup errors
                    status = "DONE";
                    apiResponse.put("status", status);
                    apiResponse.put("savedToDatabase", true);
                    apiResponse.put("readyForExternal", false); // No external system needed
                } else if (hasLookupErrors) {
                    // If routing requires external system but has lookup errors, status is PARTIAL
                    status = "PARTIAL";
                    apiResponse.put("status", status);
                    apiResponse.put("savedToDatabase", true);
                    apiResponse.put("readyForExternal", false); // Cannot send to external due to errors
                } else {
                    // No lookup errors and routing requires external system
                    status = "DONE"; // Will be DONE if external send succeeds
                    apiResponse.put("status", status);
                    apiResponse.put("savedToDatabase", true);
                    apiResponse.put("readyForExternal", true);
                }
                
                // Add lookup error details if present
                if (hasLookupErrors) {
                    Map<String, Object> detailedErrors = extractLookupErrorDetails(response.getMsg());
                    apiResponse.put("lookupErrors", detailedErrors);
                }
                
                apiResponse.put("transactionProcessing", extractProcessingResult(response));
                apiResponse.put("messageCount", response.getBody() != null ? response.getBody().size() : 0);
                apiResponse.put("executionTime", response.getExecTime());
                
                apiLog.setApiStatus(status);
                apiLog.setApiResponse(JsonUtils.getJson(apiResponse));
                
                // Handle different routing scenarios
                if (!shouldSendToExternal) {
                    log.info("Transaction {} processed: saved to DB only (routing decision: no external system)", transactionNo);
                    return ResponseEntity.accepted()
                        .header("X-Track-ID", apiLog.getActionId().toString())
                        .header("X-API-ID", apiLog.getApiId().toString())
                        .body(String.format("%s %s Payload received and saved to DB only with Track ID: %s (Routing: %s mode)", 
                                           ledger, transactionType, apiLog.getApiId(), routingService.getRoutingMode()));
                } else if (hasLookupErrors) {
                    log.info("Transaction {} processed: saved to DB only (lookup errors prevent external system send)", transactionNo);
                    return ResponseEntity.accepted()
                        .header("X-Track-ID", apiLog.getActionId().toString())
                        .header("X-API-ID", apiLog.getApiId().toString())
                        .body(String.format("%s %s Payload received and saved to DB only with Track ID: %s (Reason: lookup errors)", 
                                           ledger, transactionType, apiLog.getApiId()));
                }
                
                // Check if Kafka is disabled
                if (!kafkaEnabled || kafkaTemplate == null) {
                    log.info("Transaction {} processed: saved to DB only (Kafka is disabled)", transactionNo);
                    
                    // Update API response to reflect Kafka disabled status
                    apiResponse.put("status", "PARTIAL");
                    apiResponse.put("kafkaEnabled", false);
                    apiResponse.put("reason", "Kafka integration is disabled");
                    
                    apiLog.setApiStatus("PARTIAL");
                    apiLog.setApiResponse(JsonUtils.getJson(apiResponse));
                    
                    return ResponseEntity.accepted()
                        .header("X-Track-ID", apiLog.getActionId().toString())
                        .header("X-API-ID", apiLog.getApiId().toString())
                        .body(String.format("%s %s Payload received and saved to DB only with Track ID: %s (Reason: Kafka is disabled)", 
                                           ledger, transactionType, apiLog.getApiId()));
                }
    
                // Check if payload body is empty before sending to external system
                if (response.getBody() == null || response.getBody().isEmpty()) {
                    log.warn("Transaction {} has empty payload - saved to DB only (likely due to missing VAT IDs)", transactionNo);
                    
                    // Update API response to reflect empty payload status
                    apiResponse.put("status", "PARTIAL");
                    apiResponse.put("emptyPayloadReason", "All charge lines filtered out due to missing VAT IDs");
                    apiResponse.put("savedToDatabase", true);
                    apiResponse.put("sentToExternal", false);
                    apiResponse.put("messageCount", 0);
                    apiResponse.put("executionTime", System.currentTimeMillis() - startTime);
                    
                    apiLog.setApiStatus("PARTIAL");
                    apiLog.setApiResponse(JsonUtils.getJson(apiResponse));
                    apiLogService.saveLog(apiLog);
                    
                    return ResponseEntity.accepted()
                        .header("X-Track-ID", apiLog.getActionId().toString())
                        .header("X-API-ID", apiLog.getApiId().toString())
                        .body(String.format("%s %s Payload saved to DB only - no records qualified for external system (missing VAT IDs) with Track ID: %s",
                                           ledger, transactionType, apiLog.getApiId()));
                }
                
                // Transaction should be sent to external system (China Compliance System)
                log.info("Transaction {} will be sent to China Compliance System (routing decision: send to external)", transactionNo);
                log.info("Payload for calling China Compliance System : ");
                JsonUtils.print(response);
    
                for (TransactionChargeLineRequestBean record : response.getBody()) {
                    // Use RetryRecord to make request universal
                    RetryRecord retryRecord = new RetryRecord(record);
                    retryRecord.setActionId(apiLog.getActionId());
                    retryRecord.setAttempt(1);
                    retryRecord.setNextAttempt(Instant.now());
    
                    // 這裡會將資料傳送到中國稅票系統
                    // topic "invoice-retry" handle by RetryService
                    kafkaTemplate.send(activeProfile + "-invoice-retry", apiLog.getActionId().toString(),  retryRecord);
                }
                
            } catch (NonJobNotSupportedException e) {
                log.error("NONJOB transaction rejected - support disabled: {}", e.getMessage());
                apiLog.setApiStatus("REJECTED");
                
                // Create response in same format as successful processing for consistency
                Map<String, Object> rejectionResponse = new LinkedHashMap<>();
                rejectionResponse.put("status", "REJECTED");
                rejectionResponse.put("savedToDatabase", false);  // NONJOB not saved when disabled
                rejectionResponse.put("readyForExternal", false); // Never sent to external when rejected
                
                // Add detailed rejection information
                rejectionResponse.put("rejectionReason", Map.of(
                    "errorType", "NONJOB_NOT_SUPPORTED",
                    "message", e.getMessage(),
                    "transactionDetails", Map.of(
                        "ledger", e.getLedger(),
                        "transactionType", e.getTransactionType(),
                        "transactionNo", e.getTransactionNo()
                    ),
                    "configurationRequired", "transaction.nonjob.enabled=true",
                    "suggestion", "Enable NONJOB support in configuration or ensure transaction has valid shipment/consol references"
                ));
                
                // Add standard processing fields for consistency
                rejectionResponse.put("transactionProcessing", Map.of(
                    "messageCount", 0,
                    "hasDebugMessages", false,
                    "note", "Transaction rejected due to NONJOB feature disabled"
                ));
                rejectionResponse.put("messageCount", 0);
                rejectionResponse.put("executionTime", System.currentTimeMillis() - startTime);
                
                apiLog.setApiResponse(JsonUtils.getJson(rejectionResponse));
                apiLogService.saveLog(apiLog);
                
                return ResponseEntity.badRequest()
                    .header("X-Track-ID", apiLog.getActionId().toString())
                    .header("X-API-ID", apiLog.getApiId().toString())
                    .body(JsonUtils.getJson(rejectionResponse));
                    
            } catch (Exception e) {
                log.error("Error in processing UniversalTransaction", e);
                apiLog.setApiStatus("ERROR");
                Map<String, Object> apiResponse = new LinkedHashMap<>();
                apiResponse.put("status", "ERROR");
                apiResponse.put("errorMessage", e.getMessage());
                apiResponse.put("errorType", e.getClass().getSimpleName());
                apiResponse.put("transactionProcessing", null);
                apiLog.setApiResponse(JsonUtils.getJson(apiResponse));
            } finally {
                apiLogService.saveLog(apiLog);
            }

        } else if (universalType.equals(UniversalType.UNIVERSAL_TRANSACTION_BATCH)) {
            // 處理 AP PAY | REV Reversed 情境
            try {
                // 解析 JSON 並儲存至資料庫 => 2025/06/10 SOPL-2185 取消由 CPAR 匯入的機制
                CommonRestApiResponse response = transactionService.handleUniversalTransactionBatch(json);
                apiLog.setApiStatus("DONE");
                apiLog.setApiResponse(JsonUtils.getJson(response));

            } catch (NotSupportedTransactionException e) {
                apiLog.setApiStatus("SKIP");
                apiLog.setApiResponse("{\"Reason\": \"SOPL-2185 New PAY|REC data won't be handled by cpar service!\"}");
                return ResponseEntity.badRequest()
                    .header("X-Track-ID", apiLog.getActionId().toString())
                    .header("X-API-ID", apiLog.getApiId().toString())
                    .body("SOPL-2185 PAY|REC data won't import from cpar service! Track ID: " + apiLog.getApiId() );
            } catch (Exception e) {
                log.error("Error in processing UniversalTransactionBatch", e);
                apiLog.setApiStatus("ERROR");
                String correctlyFormattedJsonString = String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage()));
                apiLog.setApiResponse(correctlyFormattedJsonString);
            } finally {
                apiLogService.saveLog(apiLog);
            }
        } else {
            return ResponseEntity.badRequest()
                .header("X-Track-ID", apiLog.getActionId().toString())
                .header("X-API-ID", apiLog.getApiId().toString())
                .body("Unknown data strucutre! Track ID: " + apiLog.getApiId() );
        }

        // 回覆 CWIS with track ID
        return ResponseEntity.accepted()
            .header("X-Track-ID", apiLog.getActionId().toString())
            .header("X-API-ID", apiLog.getApiId().toString())
            .body("Payload received successfully with Track ID: " + apiLog.getApiId());
    }

    @PostMapping("/v1/MTTransaction")
    public ResponseEntity<String> receiveMTPayload(
        @RequestBody Map<String, Object> payload
    ) throws Exception {
        long startTime = System.currentTimeMillis();
        String json = new ObjectMapper().writeValueAsString(payload);
        log.info("Match Transaction outbound payload: \n{}", json);

        // Extract common transaction identifying information
        Configuration lenientConfig = Configuration.defaultConfiguration().addOptions(Option.SUPPRESS_EXCEPTIONS);

        APILog apiLog = APILog.create("CPAR-API-MTTransaction", "API14-MT");
        apiLog.setApiStatus("RECEIVED");
        apiLog.setApiParameters(json);
        apiLog.setUpdateBy("CWIS");
        apiLogService.saveLog(apiLog);

        // Validate UniversalTransactionBatch structure
        Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        Map<String, Object> universalStructure = JsonPath.using(lenientConfig).parse(allDocument).read("$.Body.UniversalTransactionBatch");

        if (universalStructure == null) {
            return ResponseEntity.badRequest()
                .header("X-Track-ID", apiLog.getActionId().toString())
                .header("X-API-ID", apiLog.getApiId().toString())
                .body("Only UniversalTransactionBatch supported! Track ID: " + apiLog.getApiId());
        }

        try {
            // Process match transactions
            CommonRestApiResponse response = matchTransactionService.processUniversalTransactionBatch(json);

            apiLog.setApiStatus("DONE");
            apiLog.setApiResponse(JsonUtils.getJson(response));

        } catch (Exception e) {
            log.error("Error processing MTTransaction", e);
            apiLog.setApiStatus("ERROR");
            Map<String, Object> apiResponse = new LinkedHashMap<>();
            apiResponse.put("status", "ERROR");
            apiResponse.put("errorMessage", e.getMessage());
            apiLog.setApiResponse(JsonUtils.getJson(apiResponse));
        } finally {
            apiLogService.saveLog(apiLog);
        }

        return ResponseEntity.accepted()
            .header("X-Track-ID", apiLog.getActionId().toString())
            .header("X-API-ID", apiLog.getApiId().toString())
            .body("MT Payload received successfully with Track ID: " + apiLog.getApiId());
    }

    /**
     * Extract processing result from RestListResponse debug messages for ApiLog tracking
     * @param response RestListResponse containing debug messages with processing results
     * @return Map containing processing result information
     */
    private Map<String, Object> extractProcessingResult(RestListResponse<TransactionChargeLineRequestBean> response) {
        Map<String, Object> result = new LinkedHashMap<>();
        
        if (response != null && response.getMsg() != null) {
            // Look for structured processing result in debug messages
            for (String msg : response.getMsg()) {
                if (msg.startsWith("PROCESSING_RESULT:")) {
                    try {
                        String jsonStr = msg.substring("PROCESSING_RESULT:".length());
                        @SuppressWarnings("unchecked")
                        Map<String, Object> processingResult = new ObjectMapper().readValue(jsonStr, Map.class);
                        return processingResult;
                    } catch (Exception e) {
                        log.warn("Failed to parse processing result: {}", e.getMessage());
                    }
                }
            }
        }
        
        // Fallback to basic info if structured result not found
        result.put("messageCount", response != null && response.getBody() != null ? response.getBody().size() : 0);
        result.put("hasDebugMessages", response != null && response.getMsg() != null && !response.getMsg().isEmpty());
        result.put("note", "Detailed processing result not available");
        return result;
    }

    /**
     * Extracts specific lookup error details from debug messages to provide actionable information to users
     */
    private Map<String, Object> extractLookupErrorDetails(List<String> debugMessages) {
        Map<String, Object> errorDetails = new LinkedHashMap<>();
        List<Map<String, String>> failedLookups = new ArrayList<>();
        List<String> suggestions = new ArrayList<>();
        
        if (debugMessages != null) {
            for (String message : debugMessages) {
                if (message.contains("Warning:")) {
                    Map<String, String> lookupError = new LinkedHashMap<>();
                    
                    // Parse specific lookup failures with actionable suggestions
                    if (message.contains("getDebiterName() not found for organization code")) {
                        String orgCode = extractValueFromMessage(message, "organization code: \\[([^\\]]+)\\]");
                        lookupError.put("type", "Debiter/Organization Name Lookup");
                        lookupError.put("field", "Organization Code");
                        lookupError.put("value", orgCode);
                        lookupError.put("issue", "Organization not found in cw_org_header table");
                        lookupError.put("suggestion", "Verify organization code '" + orgCode + "' exists in cw_org_header table or exists in Cargowise system and etl synced to erp-portal or update transaction with correct organization code");
                        failedLookups.add(lookupError);
                        suggestions.add("Check if organization '" + orgCode + "' is properly configured in Cargowise");
                        
                    } else if (message.contains("getBuyerOrgInfo") && message.contains("Incorrect result size: expected 1, actual 0")) {
                        String orgCode = extractValueFromMessage(message, "getBuyerOrgInfo \\[([^\\]]+)\\]");
                        lookupError.put("type", "Buyer Organization Info Lookup");
                        lookupError.put("field", "Buyer Organization");
                        lookupError.put("value", orgCode);
                        lookupError.put("issue", "Buyer organization information not found");
                        lookupError.put("suggestion", "Add organization '" + orgCode + "' to the organization master data or verify the organization code is correct");
                        failedLookups.add(lookupError);
                        suggestions.add("Configure buyer organization '" + orgCode + "' in the system");
                        
                    } else if (message.contains("getBuyerTaxNo") && message.contains("Incorrect result size: expected 1, actual 0")) {
                        String orgCode = extractValueFromMessage(message, "getBuyerTaxNo \\[([^\\]]+)\\]");
                        lookupError.put("type", "Buyer Tax Number Lookup");
                        lookupError.put("field", "Tax Number");
                        lookupError.put("value", orgCode);
                        lookupError.put("issue", "Tax number not configured for this organization");
                        lookupError.put("suggestion", "Configure tax registration number for organization '" + orgCode + "' in the system");
                        failedLookups.add(lookupError);
                        suggestions.add("Add tax number for organization '" + orgCode + "'");
                        
                    } else if (message.contains("getBuyerBankInfo") && message.contains("Incorrect result size: expected 1, actual 0")) {
                        String orgCode = extractValueFromMessage(message, "getBuyerBankInfo \\[([^\\]]+)\\] \\[([^\\]]+)\\]");
                        String currency = extractValueFromMessage(message, "getBuyerBankInfo \\[[^\\]]+\\] \\[([^\\]]+)\\]");
                        lookupError.put("type", "Buyer Bank Info Lookup");
                        lookupError.put("field", "Bank Account Information");
                        lookupError.put("value", orgCode + "/" + currency);
                        lookupError.put("issue", "Bank account information not found for this organization and currency");
                        lookupError.put("suggestion", "Configure bank account details for organization '" + orgCode + "' in currency '" + currency + "'");
                        failedLookups.add(lookupError);
                        suggestions.add("Add bank account information for organization '" + orgCode + "' in " + currency);
                        
                    } else if (message.contains("Company UUID not found")) {
                        String companyCode = extractValueFromMessage(message, "Company UUID not found for.*: ([^\\s]+)");
                        lookupError.put("type", "Company Configuration");
                        lookupError.put("field", "Company Code");
                        lookupError.put("value", companyCode);
                        lookupError.put("issue", "Company not configured in system");
                        lookupError.put("suggestion", "Configure company '" + companyCode + "' in the company master data");
                        failedLookups.add(lookupError);
                        suggestions.add("Add company '" + companyCode + "' to system configuration");
                        
                    } else if (message.contains("No SellReference found")) {
                        String transactionNo = extractValueFromMessage(message, "TransactionInfo\\.Number = \\[([^\\]]+)\\]");
                        lookupError.put("type", "Buyer Reference Missing");
                        lookupError.put("field", "SellReference");
                        lookupError.put("value", "null");
                        lookupError.put("transactionNo", transactionNo);
                        lookupError.put("issue", "SellReference field missing from AR transaction charge lines");
                        lookupError.put("suggestion", "Verify if SellReference should be populated in Cargowise or if transaction can proceed without buyer reference");
                        failedLookups.add(lookupError);
                        suggestions.add("Check Cargowise configuration for SellReference field in AR transactions");
                        
                    } else if (message.contains("No SupplierReference found")) {
                        String transactionNo = extractValueFromMessage(message, "TransactionInfo\\.Number = \\[([^\\]]+)\\]");
                        lookupError.put("type", "Buyer Reference Missing");
                        lookupError.put("field", "SupplierReference");
                        lookupError.put("value", "null");
                        lookupError.put("transactionNo", transactionNo);
                        lookupError.put("issue", "SupplierReference field missing from AP transaction charge lines");
                        lookupError.put("suggestion", "Verify if SupplierReference should be populated in Cargowise or if transaction can proceed without buyer reference");
                        failedLookups.add(lookupError);
                        suggestions.add("Check Cargowise configuration for SupplierReference field in AP transactions");
                    }
                }
            }
        }
        
        // Build comprehensive error response
        errorDetails.put("summary", "Transaction saved to database but cannot be sent to external compliance system due to missing configuration data");
        errorDetails.put("failedLookups", failedLookups);
        errorDetails.put("totalErrors", failedLookups.size());
        errorDetails.put("actionRequired", "Fix the configuration issues below and reprocess the transaction");
        errorDetails.put("suggestions", suggestions);
        
        // Add resolution steps
        List<String> resolutionSteps = new ArrayList<>();
        resolutionSteps.add("1. Review the failed lookups listed above");
        resolutionSteps.add("2. Configure missing organization/company/bank data in the respective master data tables");
        resolutionSteps.add("3. Verify data consistency between Cargowise and local system");
        resolutionSteps.add("4. Resubmit the transaction or use the retry mechanism");
        errorDetails.put("resolutionSteps", resolutionSteps);
        
        return errorDetails;
    }
    
    /**
     * Helper method to extract values from error messages using regex
     */
    private String extractValueFromMessage(String message, String pattern) {
        try {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(message);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            log.warn("Failed to extract value from message: {}", e.getMessage());
        }
        return "Unknown";
    }

}
