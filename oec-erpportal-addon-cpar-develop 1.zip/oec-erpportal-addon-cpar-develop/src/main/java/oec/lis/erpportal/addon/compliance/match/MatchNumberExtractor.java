package oec.lis.erpportal.addon.compliance.match;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;

/**
 * Utility class for extracting match numbers from various transaction fields
 */
@Slf4j
public class MatchNumberExtractor {
    private static final Pattern SOPL_MATCH_PATTERN = Pattern.compile("SOPL Match No:([A-Z0-9]+)");

    /**
     * Extract match number from transaction description field
     * Expected format: "SOPL Match No:MSH12510130001" or similar
     *
     * @param description the transaction description containing the match number
     * @return the extracted match number, or null if not found
     */
    public static String extractFromDescription(String description) {
        if (description == null || description.isBlank()) {
            log.warn("Cannot extract match number from null or empty description");
            return null;
        }

        Matcher matcher = SOPL_MATCH_PATTERN.matcher(description);
        if (matcher.find()) {
            String matchNo = matcher.group(1);
            log.debug("Extracted match number from description: {}", matchNo);
            return matchNo;
        }

        log.warn("Failed to extract match number from description: {}", description);
        return null;
    }

    /**
     * Extract match number from check number or payment reference field
     * This is a direct extraction - no regex needed as the field contains the match number directly
     *
     * @param checkNumber the check number or payment reference
     * @return the check number/payment reference as match number, or null if blank
     */
    public static String extractFromCheckNumber(String checkNumber) {
        if (checkNumber == null || checkNumber.isBlank()) {
            log.warn("Cannot extract match number from null or empty check number");
            return null;
        }

        log.debug("Extracted match number from check number: {}", checkNumber);
        return checkNumber.trim();
    }
}
