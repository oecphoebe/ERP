package oec.lis.erpportal.addon.compliance.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jakarta.annotation.PostConstruct;

import oec.lis.erpportal.addon.compliance.config.ShipmentProperties;
import oec.lis.erpportal.addon.compliance.model.transaction.VwShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.repository.VwShipmentInfoRepository;
import oec.lis.erpportal.addon.compliance.service.ShipmentViewService;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of ShipmentViewService for accessing shipment information from vw_shipment_info view.
 * This service provides prefix-based routing logic for 'C' (consolidation) and 'S' (shipment) references,
 * with comprehensive error handling and retry mechanisms.
 *
 * <p>Features:
 * - Prefix-based routing: 'C' -> cnsl_no, 'S' -> shipment_no
 * - Retry mechanism for empty results with configurable attempts
 * - Comprehensive logging for debugging and operational monitoring
 * - Graceful error handling with fallback capabilities
 * - Feature flag controlled activation via @ConditionalOnProperty
 *
 * <p>Activation: Only active when shipment.use-view=true in configuration
 */
@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "shipment.use-view", havingValue = "true")
public class ShipmentViewServiceImpl implements ShipmentViewService {

    private final VwShipmentInfoRepository repository;
    private final ShipmentProperties shipmentProperties;

    /**
     * Bean registration diagnostic method.
     * This confirms that the ShipmentViewServiceImpl bean was successfully created
     * and the conditional property evaluation worked correctly.
     */
    @PostConstruct
    public void logBeanRegistrationDiagnostics() {
        log.info("=== SHIPMENT VIEW SERVICE BEAN DIAGNOSTICS ===");
        log.info("ShipmentViewServiceImpl bean successfully created and registered!");
        log.info("Conditional property 'shipment.use-view' evaluated to: true");
        log.info("VwShipmentInfoRepository injected: {}", repository != null ? "SUCCESS" : "FAILED");
        log.info("ShipmentProperties injected: {}", shipmentProperties != null ? "SUCCESS" : "FAILED");
        if (shipmentProperties != null) {
            log.info("Injected ShipmentProperties.isViewEnabled(): {}", shipmentProperties.isViewEnabled());
        }
        log.info("View-based shipment lookup is now ACTIVE");
        log.info("=== END SHIPMENT VIEW SERVICE BEAN DIAGNOSTICS ===");
    }

    /**
     * Find shipment information by reference number using prefix-based routing.
     * Implements retry mechanism for empty results based on configuration.
     *
     * @param refNo the reference number used for lookup
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    @Override
    public Optional<VwShipmentInfoBean> findShipmentByRefNo(String refNo) {
        log.debug("Starting shipment lookup for refNo: {}", refNo);

        if (!StringUtils.hasText(refNo)) {
            log.warn("RefNo is null or empty, returning empty result");
            return Optional.empty();
        }

        String trimmedRefNo = refNo.trim();
        char prefix = trimmedRefNo.charAt(0);

        log.debug("Analyzing refNo '{}' with prefix '{}'", trimmedRefNo, prefix);

        Optional<VwShipmentInfoBean> result = Optional.empty();
        int maxRetries = shipmentProperties.getRetryAttempts();

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            log.debug("Attempt {}/{} for refNo '{}'", attempt, maxRetries, trimmedRefNo);

            try {
                switch (prefix) {
                    case 'C':
                    case 'c':
                        log.debug("Using consolidation routing for refNo '{}'", trimmedRefNo);
                        result = findShipmentByConsolNo(trimmedRefNo);
                        break;
                    case 'S':
                    case 's':
                        log.debug("Using shipment routing for refNo '{}'", trimmedRefNo);
                        result = findShipmentByShipmentNo(trimmedRefNo);
                        break;
                    default:
                        log.warn("Unsupported prefix '{}' for refNo '{}'. Supported prefixes: C, S", prefix, trimmedRefNo);
                        return Optional.empty();
                }

                if (result.isPresent()) {
                    log.info("Successfully found shipment data for refNo '{}' on attempt {}", trimmedRefNo, attempt);
                    return result;
                } else if (attempt < maxRetries) {
                    log.debug("No data found for refNo '{}' on attempt {}, retrying...", trimmedRefNo, attempt);
                    // Add small delay between retries if configured
                    if (shipmentProperties.getRetryDelayMs() > 0) {
                        try {
                            Thread.sleep(shipmentProperties.getRetryDelayMs());
                        } catch (InterruptedException e) {
                            log.warn("Retry delay interrupted for refNo '{}'", trimmedRefNo);
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                log.error("Error during shipment lookup for refNo '{}' on attempt {}: {}",
                         trimmedRefNo, attempt, e.getMessage(), e);
                if (attempt >= maxRetries) {
                    throw e;
                }
            }
        }

        log.info("No shipment data found for refNo '{}' after {} attempts", trimmedRefNo, maxRetries);
        return Optional.empty();
    }

    /**
     * Find shipment information by consolidation number.
     * Direct query against vw_shipment_info.cnsl_no field.
     *
     * @param consolNo the consolidation number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    @Override
    public Optional<VwShipmentInfoBean> findShipmentByConsolNo(String consolNo) {
        if (!StringUtils.hasText(consolNo)) {
            log.warn("ConsolNo is null or empty, returning empty result");
            return Optional.empty();
        }

        String trimmedConsolNo = consolNo.trim();
        log.debug("Querying vw_shipment_info by cnsl_no: {}", trimmedConsolNo);

        try {
            Optional<VwShipmentInfoBean> result = repository.findByConsolNo(trimmedConsolNo);
            if (result.isPresent()) {
                log.debug("Found shipment data for consolNo '{}'", trimmedConsolNo);
            } else {
                log.debug("No shipment data found for consolNo '{}'", trimmedConsolNo);
            }
            return result;
        } catch (DataAccessException e) {
            log.error("Database error while querying by consolNo '{}': {}", trimmedConsolNo, e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Find shipment information by shipment number.
     * Direct query against vw_shipment_info.shipment_no field.
     *
     * @param shipmentNo the shipment number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    @Override
    public Optional<VwShipmentInfoBean> findShipmentByShipmentNo(String shipmentNo) {
        if (!StringUtils.hasText(shipmentNo)) {
            log.warn("ShipmentNo is null or empty, returning empty result");
            return Optional.empty();
        }

        String trimmedShipmentNo = shipmentNo.trim();
        log.debug("Querying vw_shipment_info by shipment_no: {}", trimmedShipmentNo);

        try {
            Optional<VwShipmentInfoBean> result = repository.findByShipmentNo(trimmedShipmentNo);
            if (result.isPresent()) {
                log.debug("Found shipment data for shipmentNo '{}'", trimmedShipmentNo);
            } else {
                log.debug("No shipment data found for shipmentNo '{}'", trimmedShipmentNo);
            }
            return result;
        } catch (DataAccessException e) {
            log.error("Database error while querying by shipmentNo '{}': {}", trimmedShipmentNo, e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Find all shipment information records matching the given consolidation number.
     * This method returns multiple records in case of data duplication scenarios.
     *
     * @param consolNo the consolidation number to search for
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    @Override
    public List<VwShipmentInfoBean> findAllShipmentsByConsolNo(String consolNo) {
        if (!StringUtils.hasText(consolNo)) {
            log.warn("ConsolNo is null or empty, returning empty list");
            return Collections.emptyList();
        }

        String trimmedConsolNo = consolNo.trim();
        log.debug("Querying all shipments by cnsl_no: {}", trimmedConsolNo);

        try {
            List<VwShipmentInfoBean> results = repository.findAllByConsolNo(trimmedConsolNo);
            log.debug("Found {} shipment records for consolNo '{}'", results.size(), trimmedConsolNo);
            return results;
        } catch (DataAccessException e) {
            log.error("Database error while querying all by consolNo '{}': {}", trimmedConsolNo, e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Find all shipment information records matching the given shipment number.
     * This method returns multiple records in case of data duplication scenarios.
     *
     * @param shipmentNo the shipment number to search for
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    @Override
    public List<VwShipmentInfoBean> findAllShipmentsByShipmentNo(String shipmentNo) {
        if (!StringUtils.hasText(shipmentNo)) {
            log.warn("ShipmentNo is null or empty, returning empty list");
            return Collections.emptyList();
        }

        String trimmedShipmentNo = shipmentNo.trim();
        log.debug("Querying all shipments by shipment_no: {}", trimmedShipmentNo);

        try {
            List<VwShipmentInfoBean> results = repository.findAllByShipmentNo(trimmedShipmentNo);
            log.debug("Found {} shipment records for shipmentNo '{}'", results.size(), trimmedShipmentNo);
            return results;
        } catch (DataAccessException e) {
            log.error("Database error while querying all by shipmentNo '{}': {}", trimmedShipmentNo, e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Find shipment information by job number using intelligent routing.
     * Job numbers can correspond to either shipment numbers or consolidation numbers,
     * so this method attempts to find the shipment using both strategies.
     *
     * @param jobNumber the job number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    @Override
    public Optional<VwShipmentInfoBean> findShipmentByJobNumber(String jobNumber) {
        log.debug("Starting job number lookup for jobNumber: {}", jobNumber);

        if (!StringUtils.hasText(jobNumber)) {
            log.warn("JobNumber is null or empty, returning empty result");
            return Optional.empty();
        }

        String trimmedJobNumber = jobNumber.trim();
        log.debug("Searching for jobNumber '{}' using intelligent routing", trimmedJobNumber);

        try {
            // Strategy 1: Try finding by shipment number first
            log.debug("Attempting to find jobNumber '{}' as shipment_no", trimmedJobNumber);
            Optional<VwShipmentInfoBean> result = findShipmentByShipmentNo(trimmedJobNumber);
            if (result.isPresent()) {
                log.info("Found jobNumber '{}' as shipment_no", trimmedJobNumber);
                return result;
            }

            // Strategy 2: Try finding by consolidation number
            log.debug("Attempting to find jobNumber '{}' as cnsl_no", trimmedJobNumber);
            result = findShipmentByConsolNo(trimmedJobNumber);
            if (result.isPresent()) {
                log.info("Found jobNumber '{}' as cnsl_no", trimmedJobNumber);
                return result;
            }

            // Strategy 3: If job number has a prefix, try using prefix-based routing
            if (trimmedJobNumber.length() > 1) {
                char prefix = trimmedJobNumber.charAt(0);
                log.debug("Attempting prefix-based routing for jobNumber '{}' with prefix '{}'", trimmedJobNumber, prefix);
                result = findShipmentByRefNo(trimmedJobNumber);
                if (result.isPresent()) {
                    log.info("Found jobNumber '{}' using prefix-based routing", trimmedJobNumber);
                    return result;
                }
            }

            log.info("JobNumber '{}' not found using any routing strategy", trimmedJobNumber);
            return Optional.empty();

        } catch (DataAccessException e) {
            log.error("Database error while searching for jobNumber '{}': {}", trimmedJobNumber, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while searching for jobNumber '{}': {}", trimmedJobNumber, e.getMessage(), e);
            throw new RuntimeException("Error searching for job number: " + trimmedJobNumber, e);
        }
    }

    /**
     * Check if the view-based shipment service is available and accessible.
     * This method performs a basic health check on the view access.
     *
     * @return true if the view is accessible, false otherwise
     */
    @Override
    public boolean isViewAvailable() {
        log.debug("Checking view availability for vw_shipment_info");

        try {
            // Perform a simple count query to test view accessibility
            long count = repository.count();
            log.debug("View health check successful, total records: {}", count);
            return true;
        } catch (Exception e) {
            log.warn("View health check failed: {}", e.getMessage());
            return false;
        }
    }
}