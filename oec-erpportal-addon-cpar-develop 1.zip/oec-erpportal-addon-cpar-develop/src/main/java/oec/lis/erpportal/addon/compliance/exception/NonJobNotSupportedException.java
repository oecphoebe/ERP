package oec.lis.erpportal.addon.compliance.exception;

/**
 * Exception thrown when NONJOB transaction processing is attempted but not supported.
 * This occurs when transaction.nonjob.enabled is false and a NONJOB transaction is received.
 */
public class NonJobNotSupportedException extends RuntimeException {
    
    private final String ledger;
    private final String transactionType;
    private final String transactionNo;
    
    /**
     * Constructs a new NonJobNotSupportedException with the specified detail message
     * and transaction information.
     * 
     * @param message the detail message explaining why NONJOB is not supported
     * @param ledger the transaction ledger (AR, AP)
     * @param transactionType the transaction type (INV, CRD)
     * @param transactionNo the transaction number
     */
    public NonJobNotSupportedException(String message, String ledger, 
                                      String transactionType, String transactionNo) {
        super(message);
        this.ledger = ledger;
        this.transactionType = transactionType;
        this.transactionNo = transactionNo;
    }
    
    /**
     * Gets the transaction ledger.
     * 
     * @return the ledger (AR, AP)
     */
    public String getLedger() {
        return ledger;
    }
    
    /**
     * Gets the transaction type.
     * 
     * @return the transaction type (INV, CRD)
     */
    public String getTransactionType() {
        return transactionType;
    }
    
    /**
     * Gets the transaction number.
     * 
     * @return the transaction number
     */
    public String getTransactionNo() {
        return transactionNo;
    }
}