package oec.lis.erpportal.addon.compliance.schedule;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class ComparisonService {
    public ComparisonResult compareData(List<DataRecord> sourceData, List<DataRecord> targetData) {
        // Implementation for comparison logic
        // Example: Compare by Id
        // Set<UUID> sourceIds = sourceData.stream()
        //     .map(DataRecord::id)
        //     .collect(Collectors.toSet());
        // List<DataRecord> missingInSource = targetData.stream()
        //     .filter(record -> !sourceIds.contains(record.id()))
        //     .collect(Collectors.toList());

        // Compare by transaction no
        // Set<String> sourceTransactionNos = new HashSet<>();
        // for( DataRecord aRecord : sourceData ) {
        //     sourceTransactionNos.add(aRecord.getAttribute("transaction_no", String.class));
        // }
        // Compare by Id = transaction_no
        Set<String> sourceTransactionNos = sourceData.stream()
            .map(DataRecord::id)
            .collect(Collectors.toSet());

        List<DataRecord> missingInSource = targetData.stream()
            // .filter(record -> !sourceTransactionNos.contains(record.getAttribute("transaction_no")))
            .filter(record -> !sourceTransactionNos.contains(record.id()))
            .collect(Collectors.toList());
            
        return new ComparisonResult(sourceData, targetData, missingInSource);
    }
}