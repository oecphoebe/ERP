package oec.lis.erpportal.addon.compliance.api12.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthResponse {

	@JsonProperty("access_token")
	private String accessToken;

	/**
	 * expires in n seconds
	 */
	@JsonProperty("expires_in")
	private long expiresIn;

	@JsonProperty("refresh_expires_in")
	private long refreshExpiresIn;

	@JsonProperty("refresh_token")
	private String refreshToken;

	@JsonProperty("token_type")
	private String tokenType;

	@JsonProperty("not-before-policy")
	private long notBeforePolicy;

	@JsonProperty("session_state")
	private String sessionState;

	@JsonProperty("scope")
	private String scope;

}
