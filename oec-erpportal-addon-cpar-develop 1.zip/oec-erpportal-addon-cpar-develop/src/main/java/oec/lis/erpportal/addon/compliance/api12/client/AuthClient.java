package oec.lis.erpportal.addon.compliance.api12.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import oec.lis.erpportal.addon.compliance.api12.model.request.AuthRequest;
import oec.lis.erpportal.addon.compliance.api12.model.response.AuthResponse;
import oec.lis.erpportal.addon.compliance.common.api.config.BasicFeignConfig;

@FeignClient(name = "cwisAuthClient", url = "${external.cwis.url}", configuration = BasicFeignConfig.class)
public interface AuthClient {
    @PostMapping("/auth/token")
    // @PostMapping("/rest/token")
    public AuthResponse authenticate(@RequestBody AuthRequest request);
}
