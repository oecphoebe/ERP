package oec.lis.erpportal.addon.compliance.model.transaction;

import lombok.Data;

/**
 * Bean representing the vw_shipment_info view.
 * This view contains a reduced set of shipment information (10 columns vs 24 in at_shipment_info table).
 * Used as part of the migration strategy from table-based to view-based shipment data access.
 */
@Data
public class VwShipmentInfoBean {

    // View columns mapping:
    // shipment_no         -> shipmentNo
    // cnsl_no            -> consolNo
    // hbl_no             -> hblNo
    // mbl_no             -> mblNo
    // master_mbl         -> masterMbl
    // carrier_book_no    -> carrierBookNo
    // shipment_type      -> shipmentType
    // cnsl_type          -> consolType
    // cnsl_first_leg_vssl -> consolFirstLegVessel
    // cnsl_first_leg_voy  -> consolFirstLegVoyage

    /**
     * Shipment number (max 20 characters)
     */
    private String shipmentNo;

    /**
     * Consolidation number (max 20 characters)
     */
    private String consolNo;

    /**
     * House Bill of Lading number (max 20 characters)
     */
    private String hblNo;

    /**
     * Master Bill of Lading number (max 35 characters)
     */
    private String mblNo;

    /**
     * Master MBL (max 35 characters)
     */
    private String masterMbl;

    /**
     * Carrier booking number (max 35 characters)
     */
    private String carrierBookNo;

    /**
     * Shipment type (max 3 characters)
     */
    private String shipmentType;

    /**
     * Consolidation type (max 3 characters)
     */
    private String consolType;

    /**
     * Consolidation first leg vessel (max 35 characters)
     */
    private String consolFirstLegVessel;

    /**
     * Consolidation first leg voyage (max 10 characters)
     */
    private String consolFirstLegVoyage;
}