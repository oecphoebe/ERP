package oec.lis.erpportal.addon.compliance.common.api.client;

import org.springframework.context.annotation.Bean;

import feign.Logger;
import feign.RequestInterceptor;
import feign.codec.ErrorDecoder;
import oec.lis.erpportal.addon.compliance.common.api.config.TokenAuthInterceptor;
import oec.lis.erpportal.addon.compliance.common.api.service.TokenService;

public class FeignConfigFactory {
    public static class BasicConfig {
        @Bean
        public Logger.Level feignLoggerLevel() {
            return Logger.Level.BASIC;
        }
    }

    // public static class TokenAuthConfig extends BasicConfig {
    //     private final TokenService tokenService;
        
    //     public TokenAuthConfig(TokenService tokenService) {
    //         this.tokenService = tokenService;
    //     }
        
    //     @Bean
    //     public RequestInterceptor requestInterceptor() {
    //         return new TokenAuthInterceptor(tokenService);
    //     }
        
    //     @Bean
    //     public ErrorDecoder errorDecoder() {
    //         return new TokenExpirationErrorDecoder(tokenService);
    //     }
    // }
}