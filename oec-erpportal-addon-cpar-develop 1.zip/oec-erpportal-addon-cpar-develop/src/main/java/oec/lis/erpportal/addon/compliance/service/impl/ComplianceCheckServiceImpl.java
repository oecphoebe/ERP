package oec.lis.erpportal.addon.compliance.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.compliance.CheckResponseBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceRequestBean;
import oec.lis.erpportal.addon.compliance.service.ComplianceCheckService;
import oec.lis.sopl.common.model.RestListResponse;

@Service
@Slf4j
public class ComplianceCheckServiceImpl implements ComplianceCheckService {

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;
    private NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate;

    public ComplianceCheckServiceImpl( 
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate,
        @Qualifier("cargowiseNamedJdbcTemplate") NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate 
    ) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
        this.cargowiseNamedJdbcTemplate = cargowiseNamedJdbcTemplate;
    }

    private String logMessage( String message ) {
        log.debug(message);
        return message;
    }

    /**
     * 當China稅票系統作廢已開立的稅票時，需檢核該筆稅票關聯的Invoice在CW系統中
     * (1) 是否Match 或
     * (2) Post Date的period的Sub Ledger已關帳，
     * 若已Match或Sub Ledger已關帳則回覆China稅票系統每張帳單Match和Sub Ledger關帳的狀態，回傳China稅票系統的檢核欄位資訊
     */
    @Override
    public RestListResponse<CheckResponseBean> checkComplianceNoIfMatchedOrClosed( String branchCode, String complianceNo ) {
        Instant instant = Instant.now();
        long methodBeginTimeStampMillis = instant.toEpochMilli();
        log.debug("checkComplianceNoIfMatchedOrClosed()");

        ArrayList<String> debugMsg = new ArrayList<>();

        // 先取得稅票對應的Transaction ID
        List<String> transactionIdList = fetchTransactionIdList( branchCode, complianceNo );
        debugMsg.add(logMessage(String.format("transactionIdList() size = %d", transactionIdList.isEmpty()?0:transactionIdList.size())));

        RestListResponse<CheckResponseBean> result = new RestListResponse<>();

        List<CheckResponseBean> checkResultList = Collections.emptyList();
        if (transactionIdList.isEmpty()) {
            result.setStatus(String.valueOf(HttpStatus.NOT_FOUND.value()));
        } else {
            // 再回CargoWise查詢 Match 或 關帳 的狀態
            checkResultList = checkMatchedOrClosed(transactionIdList);
            debugMsg.add(logMessage(String.format("checkResultList() size = %d", checkResultList.isEmpty()?0:checkResultList.size())));
        }
        checkResultList.forEach(checkResult -> {
            // 填入稅票號碼
            checkResult.setComplianceNo(complianceNo);
            // 填入分公司代碼
            checkResult.setCreateBranch(branchCode);
        });

        result.setBody(checkResultList);
        // Profiling section
        instant = Instant.now();
        long methodEndTimeStampMillis = instant.toEpochMilli();
        debugMsg.add(logMessage(String.format("execution time = %d ms", methodEndTimeStampMillis - methodBeginTimeStampMillis)));
        // 填入 debug messages
        result.setMsg(debugMsg);
        // 填入執行時間 (ms)
        result.setExecTime(methodEndTimeStampMillis - methodBeginTimeStampMillis);
        return result;
    }

    private List<String> fetchTransactionIdList( String branchCode, String complianceNo ) {

        String query = new StringBuilder()
            .append("select aath.cw_acc_trans_header_pk as TransactionID ")
            .append("from at_account_transaction_header aath ")
            .append("inner join cp_compliance_acct_trans_header_line_link ccl on ccl.acct_trans_header_id = aath.acct_trans_header_id ")
            .append("where ccl.compliance_id in ")
            .append("  (select cc.compliance_id from cp_compliance cc ")
            .append("  where cc.compliance_no = :complianceNo ")
            .append("  and cc.create_branch = :branchCode) ")
            .toString();

        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("complianceNo", complianceNo)
            .addValue("branchCode", branchCode)
            ;
        
        return soplNamedJdbcTemplate.query(query, namedParameters, (rs, rowNum) -> rs.getString("TransactionID"));
    }

    // a.判斷是否Match : 
    // 若diff < 0，則回傳Match=Y，diff >= 0，則回傳Match=N

    // b.判斷是否關帳 : 
    // 若SubLedgerClosed = 1，則關帳=Y，SubLedgerClosed=0，則關帳=N

    private List<CheckResponseBean> checkMatchedOrClosed( List<String> transasctionIdList ) {
        if (transasctionIdList.isEmpty()) {
            return Collections.emptyList();
        }
        // Object[] parameterValue = null;
        // int[] parameterType = null;
        // ArrayList<Object> parameterValueList = new ArrayList<>();
        // ArrayList<Integer> parameterTypeList = new ArrayList<>();

        // StringBuilder transactionIdCondition = new StringBuilder();
        // int count = 0;
        // for (String keyword : transasctionIdList ) {
        //     transactionIdCondition.append("?");
        //     if (count<transasctionIdList.size()-1) {
        //         transactionIdCondition.append(",");
        //     }
        //     log.debug("transactionId : [{}]", keyword);
        //     parameterValueList.add(keyword);
        //     parameterTypeList.add(Integer.valueOf(Types.VARCHAR));
        //     count++;
        // }
        // // 將查詢參數(List)轉成 query 需要的 array
        // if (!parameterValueList.isEmpty()) {
        //     // convert parameterValue List to Object[]
        //     parameterValue = parameterValueList.stream().toArray(Object[]::new);
        //     // convert parameterType List to int[]
        //     parameterType = new int[parameterTypeList.size()];
        //     for(int i = 0; i < parameterTypeList.size(); i++) {
        //         parameterType[i] = parameterTypeList.get(i);
        //     }
        // }

        StringBuilder querySql = new StringBuilder()
            .append("select ")
            .append("ath.aH_PK ")
            .append(", AH_TransactionNum as INVOICE_NO ")
            .append(", ath.AH_OutstandingAmount - ath.AH_InvoiceAmount as difference ")
            .append(", apm.AM_IsSubLedgerClosed as Sub_Ledger_Closed ")
            .append("from AccPeriodManagement apm ")
            .append("inner join AccTransactionHeader ath on ath.AH_PostDate between apm.AM_StartDate and apm.AM_EndDate ")
            .append("and ath.AH_GC = apm.AM_GC_Company ")
            .append("and ath.AH_PK in (:accountTransactionHeaderPk) ")
            ;
        // if (transactionIdCondition.length() > 0) {
        //     querySql.append("and ath.AH_PK in (")
        //         .append(transactionIdCondition)
        //         .append(") ");
        // }
        
        return cargowiseNamedJdbcTemplate.query(
            querySql.toString(),
            Map.of("accountTransactionHeaderPk", transasctionIdList), //parameterValue,parameterType,
            new BeanPropertyRowMapper<CheckResponseBean>(CheckResponseBean.class));
    }

    /**
     * 上傳多筆 compliance 對應 account transaction no 資料
     */
    @Override
    @Transactional(transactionManager = "soplTransactionManager")
    public void saveComplianceAndLink(List<ComplianceRequestBean> createList, List<ComplianceRequestBean> deleteList) {
        log.debug("saveComplianceAndLink()");

        // Process each list
        if (!deleteList.isEmpty()) {
            // Extract complianceNo values from deleteList
            List<UUID> complianceIds = new ArrayList<>();
            for (ComplianceRequestBean bean : deleteList) {
                complianceIds.add(bean.getComplianceId());
            }
            batchDeleteComplianceLink(deleteList);
            // Pass the complianceIds list to batchDeleteCompliance
            batchDeleteCompliance(complianceIds, deleteList);
        }
        if (!createList.isEmpty()) {
            // 刪除原資料
            batchDeleteComplianceAndLink(createList);
            // 儲存 cp_compliance & cp_account_transaction_header_lines_link
            batchSaveComplianceAndLink(createList);
        }
    }

    public void batchDeleteComplianceAndLink( List<ComplianceRequestBean> deleteList ) {
        // Extract complianceNo values from deleteList
        List<UUID> complianceIds = new ArrayList<>();
        for (ComplianceRequestBean bean : deleteList) {
            complianceIds.add(bean.getComplianceId());
        }
        batchDeleteComplianceLink(deleteList);
        // Pass the complianceIds list to batchDeleteCompliance
        batchDeleteCompliance(complianceIds, deleteList);
    }

    public void batchSaveComplianceAndLink(List<ComplianceRequestBean> complianceList) {
        // cp_compliance
        // (誤)一筆 complianceNo 僅寫入一次; compliance_id 由稅票系統帶過來
        // (正)一筆 complianceNo + linesId 僅寫入一次
        // String findSql = new StringBuilder()
        //     .append("SELECT compliance_id FROM cp_compliance WHERE compliance_id = :compliance_id")
        //     .toString();
		String insertSql = new StringBuilder()
            .append("INSERT INTO cp_compliance(compliance_id, compliance_no, compliance_date, tax_posting_date, create_cmpny, create_branch, create_dept, create_by, create_time, update_cmpny, update_branch, update_dept, update_by, update_time, compliance_code, buyer_branch, vendor_org_code, crncy_code, compliance_amt, compliance_rmk, src_sys, compliance_status_code, compliance_tax_amt, compliance_extax_amt, compliance_exrate, compliance_inv_note) ")
            .append("VALUES(:complianceId, :complianceNo")
            .append(", :complianceDateDate, :complianceDateDate") // tax_posting_date 與 compliance_date 相同值
            .append(", :createCompany, :createBranch, :createDepartment, :createBy, :createTimeTimeStamp")
            .append(", :createCompany, :createBranch, :createDepartment, :createBy, :createTimeTimeStamp") // update 系列欄位與 create 相同值
            .append(", :complianceCode, :buyerBranch, :vendorOrgCode, :currencyCode, :amount, :remark")
            .append(", :sourceSystem, :statusCode, :taxAmount, :excludeTaxAmount")
            .append(", :exchangeRate, :invoiceNote) ")
            .append("ON CONFLICT (compliance_id) DO UPDATE SET ") // DO UPDATE SET or DO NOTHING
            .append("compliance_no = EXCLUDED.compliance_no")
            .append(", compliance_date = EXCLUDED.compliance_date")
            .append(", update_cmpny = EXCLUDED.create_cmpny, update_branch = EXCLUDED.create_branch, update_dept = EXCLUDED.create_dept, update_by = EXCLUDED.create_by, update_time = EXCLUDED.create_time")
            .append(", compliance_code = EXCLUDED.compliance_code, buyer_branch = EXCLUDED.buyer_branch, vendor_org_code = EXCLUDED.vendor_org_code, crncy_code = EXCLUDED.crncy_code, compliance_amt = EXCLUDED.compliance_amt, compliance_rmk = EXCLUDED.compliance_rmk")
            .append(", src_sys = EXCLUDED.src_sys, compliance_status_code = EXCLUDED.compliance_status_code, compliance_tax_amt = EXCLUDED.compliance_tax_amt, compliance_extax_amt = EXCLUDED.compliance_extax_amt")
            .append(", compliance_exrate = EXCLUDED.compliance_exrate, compliance_inv_note = EXCLUDED.compliance_inv_note ")
            .toString();
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(complianceList.toArray());
		int[] complianceSaved = new int[0];
        try {
            complianceSaved = soplNamedJdbcTemplate.batchUpdate(insertSql, batch);
        } catch (DataIntegrityViolationException e) {
            log.info("Cannot batchUpdate cp_compliance(DataIntegrityViolationException)! {}", e.getMessage());
        } catch (UncategorizedSQLException e) {
            log.info("Cannot batchUpdate cp_compliance(UncategorizedSQLException)! {}", e.getMessage());
        } finally {
            log.debug("cp_compliance batchUpdate = [{}]", complianceSaved);
        }

        // String updateSql = new StringBuilder()
        //     .append("UPDATE cp_compliance SET ") 
        //     .append("compliance_no = :complianceNo")
        //     .append(", compliance_date = :complianceDateDate")
        //     .append(", update_cmpny = :createCompany, update_branch = :createBranch, update_dept = :createDepartment, update_by = :createBy, update_time = :createTimeTimeStamp")
        //     .append(", compliance_code = :complianceCode, buyer_branch = :buyerBranch, vendor_org_code = :vendorOrgCode, crncy_code = :currencyCode, compliance_amt = :amount, compliance_rmk = :remark")
        //     .append(", src_sys = :sourceSystem, compliance_status_code = :statusCode, compliance_tax_amt = :taxAmount, compliance_extax_amt = :excludeTaxAmount")
        //     .append(", compliance_exrate = :exchangeRate, compliance_inv_note = :invoiceNote ")
        //     .toString();
        // String sql = null;
        // int updated = 0;
        // int complianceSaved = 0;
        // for (ComplianceRequestBean compliance : complianceList) {
        //     sql = insertSql;
        //     updated = 0;
        //     List<UUID> complianceIdList = soplNamedJdbcTemplate.query(
        //         findSql, 
        //         new MapSqlParameterSource().addValue("compliance_id", compliance.getComplianceId()), 
        //         (rs, rowNum) -> {
        //             return rs.getObject("compliance_id", UUID.class);
        //         }
        //     );
        //     if (complianceIdList!=null && !complianceIdList.isEmpty()) {
        //         sql = updateSql;
        //     }
        //     MapSqlParameterSource params = new MapSqlParameterSource()
        //         .addValue("complianceId", compliance.getComplianceId(), java.sql.Types.OTHER)
        //         .addValue("complianceNo", compliance.getComplianceNo())
        //         .addValue("complianceDateDate", compliance.getComplianceDateDate(), java.sql.Types.DATE)
        //         .addValue("createCompany", compliance.getCreateCompany())
        //         .addValue("createBranch", compliance.getCreateBranch())
        //         .addValue("createDepartment", compliance.getCreateDepartment())
        //         .addValue("createBy", compliance.getCreateBy())
        //         .addValue("createTimeTimeStamp", compliance.getCreateTimeTimeStamp(), java.sql.Types.TIMESTAMP)
        //         .addValue("complianceCode", compliance.getComplianceCode())
        //         .addValue("buyerBranch", compliance.getBuyerBranch())
        //         .addValue("vendorOrgCode", compliance.getVendorOrgCode())
        //         .addValue("currencyCode", compliance.getCurrencyCode())
        //         .addValue("amount", compliance.getAmount(), java.sql.Types.DECIMAL)
        //         .addValue("remark", compliance.getRemark())
        //         .addValue("sourceSystem", compliance.getSourceSystem())
        //         .addValue("statusCode", compliance.getStatusCode())
        //         .addValue("taxAmount", compliance.getTaxAmount(), java.sql.Types.DECIMAL)
        //         .addValue("excludeTaxAmount", compliance.getExcludeTaxAmount(), java.sql.Types.DECIMAL)
        //         .addValue("exchangeRate", compliance.getExchangeRate(), java.sql.Types.DECIMAL)
        //         .addValue("invoiceNote", compliance.getInvoiceNote())
        //         ;
        //     updated = soplNamedJdbcTemplate.update(sql, params);
        //     complianceSaved += updated;
        // }
        log.debug("cp_compliance saved = [{}]", complianceSaved);

        String insertLinkSql = new StringBuilder()
            .append("INSERT INTO cp_compliance_acct_trans_header_line_link (")
            .append("compliance_acct_trans_header_line_link_id")
            .append(", compliance_id")
            .append(", acct_trans_header_id")
            .append(", acct_trans_lines_id")
            .append(")VALUES(")
            .append("  :complianceAcctTransHeaderLineLinkId ")
            .append(", :complianceId ")
            // .append(", (select acct_trans_header_id from at_account_transaction_header where inv_no = :accountTransactionNo) ")
            .append(", (select h.acct_trans_header_id from at_account_transaction_lines l inner join at_account_transaction_header h on h.acct_trans_header_id = l.acct_trans_header_id where l.acc_trans_lines_id = :accountTransactionLinesId)")
            .append(", :accountTransactionLinesId ")
            .append(") ")
            .toString();
        SqlParameterSource[] batchLink = SqlParameterSourceUtils.createBatch(complianceList.toArray());
        int[] linkSaved = new int[0];
        try {
            linkSaved = soplNamedJdbcTemplate.batchUpdate(insertLinkSql, batchLink);
        } catch (DataIntegrityViolationException e) {
            log.info("Cannot linkSaved cp_compliance_acct_trans_header_line_link(DataIntegrityViolationException)! {}", e.getMessage());
        } catch (UncategorizedSQLException e) {
            log.info("Cannot linkSaved cp_compliance_acct_trans_header_line_link(UncategorizedSQLException)! {}", e.getMessage());
        } finally {
            log.debug("cp_compliance_acct_trans_header_line_link saved = [{}]", linkSaved);
        }
    
        // History 寫入一樣的資料
		String historySql = new StringBuilder()
            .append("INSERT INTO cp_compliance_history(compliance_chg_time, compliance_id, compliance_no, compliance_date, tax_posting_date, create_cmpny, create_branch, create_dept, create_by, create_time, update_cmpny, update_branch, update_dept, update_by, update_time, compliance_code, buyer_branch, vendor_org_code, crncy_code, compliance_amt, compliance_rmk, src_sys, compliance_status_code, compliance_tax_amt, compliance_extax_amt, compliance_exrate, compliance_inv_note) ")
            .append("VALUES(CURRENT_TIMESTAMP, :complianceId, :complianceNo")
            .append(", :complianceDateDate, :complianceDateDate") // tax_posting_date 與 compliance_date 相同值
            .append(", :createCompany, :createBranch, :createDepartment, :createBy, :createTimeTimeStamp")
            .append(", :createCompany, :createBranch, :createDepartment, :createBy, :createTimeTimeStamp") // update 系列欄位與 create 相同值
            .append(", :complianceCode, :buyerBranch, :vendorOrgCode, :currencyCode, :amount, :remark")
            .append(", :sourceSystem, :statusCode, :taxAmount, :excludeTaxAmount")
            .append(", :exchangeRate, :invoiceNote) ")
            .append("ON CONFLICT (compliance_chg_time, compliance_id, compliance_no) DO NOTHING ") // DO UPDATE SET or DO NOTHING
            .toString();
		SqlParameterSource[] historyBatch = SqlParameterSourceUtils.createBatch(complianceList.toArray());
		int[] historySaved = soplNamedJdbcTemplate.batchUpdate(historySql, historyBatch);
        log.debug("batchSaveComplianceAndLink() cp_compliance_history saved = [{}]", historySaved);
	}

    /**
     * 
     * 2025/05/14 改為以 compliance_id, lines_id 刪除, 而非全面刪除 compliance_id 所有資料
     * @param deleteList 要刪除的 compliance_id, lines_id 資料
     */
    public void batchDeleteComplianceLink(List<ComplianceRequestBean> deleteList) {
        // String sql = "DELETE FROM cp_compliance_acct_trans_header_line_link WHERE compliance_id in (:complianceIds)";
        // Map<String, Object> params = Collections.singletonMap("complianceIds", complianceIds);
        // int linkDeleted = soplNamedJdbcTemplate.update(sql, params);
        String sql = "DELETE FROM cp_compliance_acct_trans_header_line_link WHERE compliance_id = :complianceId and acct_trans_lines_id = :accountTransactionLinesId"; 
        SqlParameterSource[] batchParam = SqlParameterSourceUtils.createBatch(deleteList.toArray());
		int[] linkDeleted = soplNamedJdbcTemplate.batchUpdate(sql, batchParam);
        log.debug("cp_compliance_acct_trans_header_line_link deleted = [{}]", linkDeleted);
    }

    public void batchDeleteCompliance( List<UUID> complianceIds, List<ComplianceRequestBean> complianceList ) {
String deleteSql = """
DELETE FROM sopl.cp_compliance
WHERE compliance_id = :complianceId
AND NOT EXISTS (
  SELECT 1 
  FROM sopl.cp_compliance_acct_trans_header_link 
  WHERE compliance_id = :complianceId
)
AND NOT EXISTS (
  SELECT 1 
  FROM sopl.cp_compliance_acct_trans_header_line_link 
  WHERE compliance_id = :complianceId
)
""";
        SqlParameterSource[] deleteBatch = SqlParameterSourceUtils.createBatch(complianceList.toArray());
        int[] complianceDeleted = soplNamedJdbcTemplate.batchUpdate(deleteSql, deleteBatch);
        log.debug("batchDeleteCompliance() cp_compliance deleted = [{}]", complianceDeleted);

        // String sql = "DELETE FROM cp_compliance WHERE compliance_id IN (:complianceIds)";
        // Map<String, Object> params = Collections.singletonMap("complianceIds", complianceIds);
        // int complianceDeleted = 0;
        // try {
        //     complianceDeleted = soplNamedJdbcTemplate.update(sql, params);
        // } catch (DataIntegrityViolationException e) {
        //     log.info("Cannot delete cp_compliance(DataIntegrityViolationException)! {}", e.getMessage());
        // } catch (UncategorizedSQLException e) {
        //     log.info("Cannot delete cp_compliance(UncategorizedSQLException)! {}", e.getMessage());
        // } finally {
        //     log.debug("cp_compliance deleted = [{}]", complianceDeleted);
        // }

        if (Arrays.stream(complianceDeleted).sum()>0) {
            // History 寫入一樣的資料
            String historySql = new StringBuilder()
                .append("INSERT INTO cp_compliance_history(compliance_chg_time, compliance_id, compliance_no, compliance_date, tax_posting_date, create_cmpny, create_branch, create_dept, create_by, create_time, update_cmpny, update_branch, update_dept, update_by, update_time, compliance_code, buyer_branch, vendor_org_code, crncy_code, compliance_amt, compliance_rmk, src_sys, compliance_status_code, compliance_tax_amt, compliance_extax_amt, compliance_exrate, compliance_inv_note) ")
                .append("VALUES(CURRENT_TIMESTAMP, :complianceId, :complianceNo")
                .append(", :complianceDateDate, :complianceDateDate") // tax_posting_date 與 compliance_date 相同值
                .append(", :createCompany, :createBranch, :createDepartment, :createBy, :createTimeTimeStamp")
                .append(", :createCompany, :createBranch, :createDepartment, :createBy, CURRENT_TIMESTAMP") // update 系列欄位與 create 相同值
                .append(", :complianceCode, :buyerBranch, :vendorOrgCode, :currencyCode, :amount, :remark")
                .append(", :sourceSystem, :statusCode, :taxAmount, :excludeTaxAmount")
                .append(", :exchangeRate, :invoiceNote) ")
                .toString();
            SqlParameterSource[] historyBatch = SqlParameterSourceUtils.createBatch(complianceList.toArray());
            int[] historySaved = soplNamedJdbcTemplate.batchUpdate(historySql, historyBatch);
            log.debug("batchDeleteCompliance() cp_compliance_history saved = [{}]", historySaved);
        }
    }
}
