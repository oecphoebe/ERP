package oec.lis.erpportal.addon.compliance.service;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.config.TransactionRoutingConfig;

/**
 * Service for determining transaction routing decisions.
 * Provides centralized logic for deciding whether transactions should be sent to external systems.
 * Includes comprehensive audit logging for all routing decisions.
 */
@Service
@Slf4j
public class TransactionRoutingService {
    
    private final TransactionRoutingConfig config;
    
    public TransactionRoutingService(TransactionRoutingConfig config) {
        this.config = config;
    }
    
    /**
     * Determines if a transaction should be sent to external system and logs the decision for audit.
     * 
     * @param ledger Transaction ledger (AR, AP)
     * @param transactionType Transaction type (INV, CRD)
     * @param transactionNo Transaction number for logging
     * @return true if transaction should be sent to external system, false otherwise
     */
    public boolean shouldSendToExternalSystem(String ledger, String transactionType, String transactionNo) {
        boolean shouldSend = config.shouldSendToExternal(ledger, transactionType);
        
        // Comprehensive audit logging
        if (config.isEnableLegacyMode()) {
            log.info("ROUTING_AUDIT [LEGACY_MODE]: Transaction={}, Ledger={}, Type={}, Decision={}, Reason={}",
                    transactionNo, 
                    ledger, 
                    transactionType, 
                    shouldSend ? "SEND_EXTERNAL" : "DB_ONLY",
                    shouldSend ? "AR ledger always sent in legacy mode" : "Non-AR ledger not sent in legacy mode");
        } else {
            String ruleDesc = config.findRuleDescription(ledger, transactionType);
            log.info("ROUTING_AUDIT [CONFIG_MODE]: Transaction={}, Ledger={}, Type={}, Decision={}, Rule={}",
                    transactionNo, 
                    ledger, 
                    transactionType, 
                    shouldSend ? "SEND_EXTERNAL" : "DB_ONLY", 
                    ruleDesc);
        }
        
        return shouldSend;
    }
    
    /**
     * Determines if a transaction should be sent to external system without transaction number.
     * Used for testing or when transaction number is not yet available.
     * 
     * @param ledger Transaction ledger (AR, AP)
     * @param transactionType Transaction type (INV, CRD)
     * @return true if transaction should be sent to external system, false otherwise
     */
    public boolean shouldSendToExternalSystem(String ledger, String transactionType) {
        return shouldSendToExternalSystem(ledger, transactionType, "UNKNOWN");
    }
    
    /**
     * Gets the current routing mode for logging purposes.
     * 
     * @return "LEGACY" if legacy mode is enabled, "CONFIG" otherwise
     */
    public String getRoutingMode() {
        return config.isEnableLegacyMode() ? "LEGACY" : "CONFIG";
    }
    
    /**
     * Checks if legacy mode is enabled.
     * 
     * @return true if legacy mode is enabled, false otherwise
     */
    public boolean isLegacyModeEnabled() {
        return config.isEnableLegacyMode();
    }
}