package oec.lis.erpportal.addon.compliance.model.outbound;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostedTransaction {
    @JsonProperty("DueDate")
    private String dueDate;
    @JsonProperty("FullyPaidDate")
    private String fullyPaidDate;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("OutstandingAmount")
    private BigDecimal outstandingAmount;
    @JsonProperty("TransactionDate")
    private String transactionDate;
    @JsonProperty("TransactionType")
    private String transactionType;
}
