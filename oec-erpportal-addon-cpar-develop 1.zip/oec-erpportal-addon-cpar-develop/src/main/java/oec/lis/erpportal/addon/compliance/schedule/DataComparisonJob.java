package oec.lis.erpportal.addon.compliance.schedule;

import java.io.File;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DataComparisonJob {
    
    private final SourceDataService sourceDataService;
    private final TargetDataService targetDataService;
    private final ComparisonService comparisonService;
    private final ExcelReportGenerator excelGenerator;
    private final EmailService emailService;
    private final MetricsService metricsService;
    
    @Value("${job.email.fromemail}")
    private String fromEmail;

    @Value("${job.email.recipients}")
    private String recipients;

    @Value("${spring.profiles.active}")
    private String activeProfile;
    
    public DataComparisonJob(SourceDataService sourceDataService,
                          TargetDataService targetDataService,
                          ComparisonService comparisonService,
                          ExcelReportGenerator excelGenerator,
                          EmailService emailService,
                          MetricsService metricsService) {
        this.sourceDataService = sourceDataService;
        this.targetDataService = targetDataService;
        this.comparisonService = comparisonService;
        this.excelGenerator = excelGenerator;
        this.emailService = emailService;
        this.metricsService = metricsService;
    }
    
    @Scheduled(cron = "0 0 14 * * ?")  // Runs at 22:00 every day "0 0 22 * * ?"
    public void executeDataComparison() {
        long startTime = System.currentTimeMillis();
        metricsService.recordJobStart("data_comparison_job");
        
        try {
            log.info("Data comparison job started");
            
            // Fetch data from both sources
            List<DataRecord> sourceData = sourceDataService.fetchData();
            List<DataRecord> targetData = targetDataService.fetchData();

            log.info("Fetched {} records from source and {} records from target", sourceData.size(), targetData.size());
            
            // Compare data
            ComparisonResult result = comparisonService.compareData(sourceData, targetData);

            if (sourceData.isEmpty() && targetData.isEmpty()) {
                return;
            }

            // Generate Excel report
            File excelReport = excelGenerator.generateReport(result);
            
            log.debug("current active profile : {}", activeProfile);
            if (!StringUtils.equals("local", activeProfile)) {
                // Send email with report
                emailService.sendReportEmail(
                    recipients, 
                    fromEmail,
                    activeProfile + "-Data Comparison Report", 
                    "Please find attached the daily data comparison report", 
                    excelReport);
            }
            
            log.info("Data comparison job completed successfully");
        } catch (Exception e) {
            log.error("Error executing data comparison job", e);
            metricsService.recordJobError("data_comparison_job", e.getMessage());
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            metricsService.recordJobEnd("data_comparison_job", duration);
        }
    }
}