package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Body {
	@JsonProperty("UniversalTransaction")
	private UniversalTransaction universalTransaction;
}
