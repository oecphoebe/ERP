package oec.lis.erpportal.addon.compliance.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.config.ShipmentProperties;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.model.transaction.VwShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.service.AtAccountTransactionTableService;
import oec.lis.erpportal.addon.compliance.service.ShipmentViewService;
import oec.lis.sopl.common.util.JsonUtils;

@Service
@Slf4j
public class AtAccountTransactionTableServiceImpl implements AtAccountTransactionTableService {

    public static final String SQL_FETCH_AT_ACCOUNT_TRANSACTION_HEADER_ID_BY_TRANSACTION_NO = 
        "SELECT acct_trans_header_id FROM at_account_transaction_header WHERE trans_no in (:transactionNoList)";

    public static final String SQL_FETCH_SHIPMENT_INFO_BY_TRANSACTION_NO = """
-- SHIPMENT
SELECT DISTINCT 
    --gc.gc_code AS companyCode,
    --gb.gb_code AS branchCode,
    --gd.ge_code AS departmentCode,
    js.js_uniqueconsignref AS ref_No,
    jc.jk_uniqueconsignref AS consol_No,
    js.js_uniqueconsignref AS shipment_No,
    --js.JS_PK AS shipment_id,
    CAST(js.JS_PK AS varchar(36)) AS shipment_id,
    jc.jk_masterbillnum AS mbl_No,
    js.js_housebill AS hbl_No,
    jc.jk_bookingreference AS carrier_Booking_No,
    jct.jw_vessel AS consol_first_leg_vessel,
    jct.jw_voyageflight AS consol_first_leg_voyage,
    '' AS container_No,
    jc.JK_CoLoadMasterBill AS master_mbl,
    --js.JS_JS_ColoadMasterShipment AS master_shipment_id,
    CAST(js.JS_JS_ColoadMasterShipment AS varchar(36)) AS master_shipment_id,
    js.JS_E_DEP AS etd,
    jct.JW_ATD AS atd,
    jct.JW_ATA AS ata,
    js.JS_PackingMode AS shipment_type,
    jc.JK_AgentType AS consol_type,
    js.JS_PackingMode AS container_mode,
    '' AS container_list,
    gc.gc_code AS create_company,
    gb.gb_code AS create_branch,
    '' AS create_department,
    '' AS creat_by,    --API
    '' AS creat_time   --系統時間
FROM AccTransactionHeader a
INNER JOIN GlbCompany gc ON gc.gc_pk = a.ah_gc
INNER JOIN GlbBranch gb ON gb.gb_pk = a.ah_gb
INNER JOIN GlbDepartment gd ON gd.ge_pk = a.ah_ge
INNER JOIN AccTransactionLines b ON a.ah_pk = b.al_ah
LEFT JOIN JobHeader jh ON jh.jh_pk = b.AL_JH AND jh.jh_gc = b.AL_GC
INNER JOIN JobShipment js ON js.js_pk = jh.jh_parentid
LEFT JOIN JobConShipLink jcsl ON jcsl.jn_js = js.js_pk
LEFT JOIN JobConsol jc ON jc.jk_pk = jcsl.jn_jk
LEFT JOIN JobConsolTransport jct ON jct.jw_parentguid = jc.jk_pk AND jw_legorder = 1
WHERE a.AH_TransactionNum = :transactionNo
    AND a.ah_transactionType = :transactionType
    AND a.AH_IsCancelled = :isCancelled
    AND gc.gc_code = :companyCode
    AND gb.GB_Code = :branchCode

UNION

-- CONSOL
SELECT DISTINCT
    --gc.gc_code AS companyCode,
    --gb.gb_code AS branchCode,
    --gd.ge_code AS departmentCode,
    jc.jk_uniqueconsignref AS ref_No,
    jc.jk_uniqueconsignref AS consol_No,
    '' AS shipment_No,
    '' AS shipment_id,
    jc.jk_masterbillnum AS mbl_No,
    '' AS hbl_No,
    jc.jk_bookingreference AS carrier_Booking_No,
    jct.jw_vessel AS consol_first_leg_vssl,
    jct.jw_voyageflight AS consol_first_leg_voy,
    '' AS container_No,
    jc.JK_CoLoadMasterBill AS master_mbl,
    '' AS master_shipment_id,
    jct.JW_ETD AS etd,
    jct.JW_ATD AS atd,
    jct.JW_ATA AS ata,
    '' AS shipment_type,
    jc.JK_AgentType AS consol_type,
    '' AS container_mode,
    '' AS container_list,
    gc.gc_code AS create_company,
    gb.gb_code AS create_branch,
    '' AS create_department,
    '' AS create_by,    --API
    '' AS create_time   --系統時間
FROM AccTransactionHeader a
INNER JOIN GlbCompany gc ON gc.gc_pk = a.ah_gc
INNER JOIN GlbBranch gb ON gb.gb_pk = a.ah_gb
INNER JOIN GlbDepartment gd ON gd.ge_pk = a.ah_ge
INNER JOIN JobConsolCost jcl ON jcl.e6_ah_apinvoice = a.ah_pk
INNER JOIN JobConsol jc ON jc.jk_pk = jcl.e6_parentid
LEFT JOIN JobConsolTransport jct ON jct.jw_parentguid = jc.jk_pk AND jw_legorder = 1
WHERE a.AH_TransactionNum = :transactionNo
    AND a.ah_transactionType = :transactionType
    AND a.AH_IsCancelled = :isCancelled
    AND gc.gc_code = :companyCode
    AND gb.GB_Code = :branchCode
   ;
        """;

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;
    private NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate;
    private ShipmentViewService shipmentViewService;
    private ShipmentProperties shipmentProperties;


    public AtAccountTransactionTableServiceImpl(
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate,
        @Qualifier("cargowiseNamedJdbcTemplate") NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate,
        Optional<ShipmentViewService> shipmentViewService,
        ShipmentProperties shipmentProperties
    ) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
        this.cargowiseNamedJdbcTemplate = cargowiseNamedJdbcTemplate;
        this.shipmentViewService = shipmentViewService.orElse(null);
        this.shipmentProperties = shipmentProperties;
    }

    /**
     * Service dependency diagnostic method.
     * This validates that all shipment-related dependencies are correctly injected
     * and reports the effective configuration for shipment lookup strategy.
     */
    @PostConstruct
    public void logServiceDependencyDiagnostics() {
        log.info("=== SHIPMENT SERVICE DEPENDENCY DIAGNOSTICS ===");
        log.info("AtAccountTransactionTableServiceImpl initialized successfully");
        log.info("ShipmentProperties injected: {}", shipmentProperties != null ? "SUCCESS" : "FAILED");
        if (shipmentProperties != null) {
            log.info("ShipmentProperties.isViewEnabled(): {}", shipmentProperties.isViewEnabled());
        }
        log.info("ShipmentViewService injected: {}", shipmentViewService != null ? "SUCCESS" : "FAILED (will use table-based implementation)");

        // Determine effective implementation strategy
        boolean willUseView = shipmentProperties != null && shipmentProperties.isViewEnabled() && shipmentViewService != null;
        log.info("Effective shipment lookup strategy: {}", willUseView ? "VIEW-BASED" : "TABLE-BASED");

        if (shipmentProperties != null && shipmentProperties.isViewEnabled() && shipmentViewService == null) {
            log.warn("CONFIGURATION ISSUE: shipment.use-view=true but ShipmentViewService bean not available!");
            log.warn("This indicates a conditional property evaluation problem or bean loading issue.");
            log.warn("Will fall back to table-based implementation.");
        }

        log.info("=== END SHIPMENT SERVICE DEPENDENCY DIAGNOSTICS ===");
    }

    @Transactional(transactionManager = "soplTransactionManager", isolation = Isolation.SERIALIZABLE)
    public List<TransactionChargeLineRequestBean> saveSoplAccountTransactionTables( 
        AtAccountTransactionHeaderBean headerBean, 
        List<AtAccountTransactionLinesBean> linesBeanList, 
        final List<TransactionChargeLineRequestBean> requestBeanList, 
        final boolean forceUpdate
    ) {
        log.debug("saveSoplAccountTransactionTables()");
        List<TransactionChargeLineRequestBean> resultList = new ArrayList<>();
        // 先確認相同的資料是否已存在
        List<AtAccountTransactionHeaderBean> existheaderList = getAtAccountTransactionHeader( headerBean.getCwAccTransHeaderPk() );
        UUID headerIdInDB = null;
        if (!existheaderList.isEmpty()) {
            headerIdInDB = existheaderList.get(0).getAcctTransHeaderId();

            // If data exist, lins ID = "itemGuid" in requestBean should be updated.
            List<AtAccountTransactionLinesBean> existLinesList = fetchAtAccountTransactionLines( headerBean.getCwAccTransHeaderPk() );
            // log.debug("existLinesList.size() = [{}]", existLinesList!=null? existLinesList.size() : 0);
            Map<UUID,UUID> existLinesMap = existLinesList.stream()
                .collect(Collectors.toMap(
                        AtAccountTransactionLinesBean::getCwAccountTransactionLinesPk,
                        AtAccountTransactionLinesBean::getAccountTransactionLinesId,
                        (existingValue, newValue) -> newValue // Merge function: if duplicate key, keep the new value
                ));
            // log.debug("existLinesMap.size() = [{}]", existLinesMap!=null? existLinesMap.size() : 0);
            // 從 linesBean 找 accountTransactionLinesId(=itemGuid) 與 cwAccountTransactionLinesPk
            // 用 accountTransactionLinesId(=itemGuid) 從 requestBeanList 中 找到 requestBean
            // 從 existLinesList 找到 cwAccountTransactionLinesPk 對應的 已存在的 accountTransactionLinesId (A)
            // 將 已存在的 accountTransactionLinesId (A) 設定到 requestBean 的 itemGuid
            for (AtAccountTransactionLinesBean linesBean : linesBeanList) {
                UUID accountTransactionLinesIdNew = linesBean.getAccountTransactionLinesId();
                UUID cwAccountTransactionLinesPk = linesBean.getCwAccountTransactionLinesPk();
                UUID accountTransactionLinesIdOld = existLinesMap.get(cwAccountTransactionLinesPk);
                log.debug("Handling linesBean currentLinesId=[{}], cwLinesPk=[{}], oldLinesId=[{}]", accountTransactionLinesIdNew, cwAccountTransactionLinesPk, accountTransactionLinesIdOld );
                // log.debug("cwAccountTransactionLinesPk=[{}], accountTransactionLinesIdOld = [{}]", cwAccountTransactionLinesPk, accountTransactionLinesIdOld);
                for (TransactionChargeLineRequestBean requestBean : requestBeanList) {
                    // log.debug("requestBean.getItemGuid()=[{}]", requestBean.getItemGuid());
                    if (requestBean.getItemGuid().equals(accountTransactionLinesIdNew)) {
                        TransactionChargeLineRequestBean requestBeanReturn = new TransactionChargeLineRequestBean(requestBean);
                        if (accountTransactionLinesIdOld!=null) {
                            requestBeanReturn.setItemGuid(accountTransactionLinesIdOld);
                        }
                        resultList.add(requestBeanReturn);
                        log.debug("Found matching requestBean, updated itemCode=[{}]", accountTransactionLinesIdOld);
                        break;
                    }
                }
            }

            // 比對 update_time = UniversalTransaction 中的 TriggerDate, 
            // 若要更新的資料時間(headerBean)比 DB 中的時間還要舊的話，就不更新 at_account_transaction_header & lines
            AtAccountTransactionHeaderBean existheader = existheaderList.get(0);
            log.info("table.update_time = [{}], headerBean.update_time = [{}], headerBean <= existing record : [{}], forceUpdate = [{}]", 
                existheader.getUpdateTime(), 
                headerBean.getUpdateTime(),
                existheader.getUpdateTime()!=null ? headerBean.getUpdateTime().compareTo(existheader.getUpdateTime()) <= 0 : false,
                forceUpdate
            );
            if (Boolean.FALSE.equals(forceUpdate) && existheaderList.get(0).getUpdateTime()!=null && headerBean.getUpdateTime().compareTo(existheader.getUpdateTime()) <= 0) {
                log.info("headerBean's TriggerDate is earlier than or equal to existing record(update_time). DO NOTHING. (won't save or update at_account_transaction_header & lines)");
                return resultList;
            }
        } else {
            for (TransactionChargeLineRequestBean requestBean : requestBeanList) {
                TransactionChargeLineRequestBean requestBeanReturn = new TransactionChargeLineRequestBean(requestBean);
                resultList.add(requestBeanReturn);
            }
        }
        if (headerBean.getRefNo()!=null && !headerBean.getRefNo().isEmpty()) {
            // Feature flag check: use view-based implementation if enabled and available
            if (shipmentProperties.isViewEnabled() && shipmentViewService != null) {
                log.info("SHIPMENT_LOOKUP_DECISION: Using view-based shipment lookup for refNo: {}", headerBean.getRefNo());
                log.debug("Decision factors - isViewEnabled: {}, shipmentViewService available: {}",
                         shipmentProperties.isViewEnabled(), shipmentViewService != null);
                processShipmentInfoWithView(headerBean);
            } else {
                // Fallback to existing table-based implementation
                log.info("SHIPMENT_LOOKUP_DECISION: Using table-based shipment lookup for refNo: {}", headerBean.getRefNo());
                log.debug("Decision factors - isViewEnabled: {}, shipmentViewService available: {}",
                         shipmentProperties != null ? shipmentProperties.isViewEnabled() : "null_properties",
                         shipmentViewService != null);
                List<AtShipmentInfoBean> availableShipmentInfoList = fetchShipmentInfoFromCW( headerBean.getTransactionNo(), headerBean.getTransactionType(), headerBean.isCancelled(), headerBean.getCompanyCode(), headerBean.getCompanyBranch() );
                log.debug("availableShipmentInfoList.size() = [{}] at_shipment_info :", availableShipmentInfoList.isEmpty() ? 0 : availableShipmentInfoList.size());
                JsonUtils.print(availableShipmentInfoList);
                if (!availableShipmentInfoList.isEmpty()) {
                    int[] result = saveAtShipmentInfo( availableShipmentInfoList );
                    log.debug("result of saveAtShipmentInfo() [{}]", result);
                }
            }
        }
        // 執行 upsert
        int headerSaved = saveAtAccountTransactionHeader( headerIdInDB, headerBean );
        log.info("at_account_transaction_header inserted or updated : [{}]", headerSaved);
        // 寫入 Lines 資料 (upsert): 若相同的 header 資料已存在 2025/05/08 改為 存在就 update, 不存在才 insert
        int linesSaved = saveAtAccountTransactionLines( linesBeanList, headerIdInDB, headerBean.getInvoiceNo() );
        log.info("at_account_transaction_lines inserted or updated : [{}]", linesSaved);

        return resultList;
    }

    private int saveAtAccountTransactionHeader( UUID headerIdInDB, AtAccountTransactionHeaderBean headerBean ) {
        String insertSql = new StringBuilder()
            .append("INSERT INTO at_account_transaction_header ")
            .append("(acct_trans_header_id, ref_no, cw_acc_trans_header_pk, ledger, trans_type, inv_no, inv_date, due_date, crncy_code, inv_amt, outstanding_amt, cmpny_dept, exchg_rate, inv_org_code, local_crncy_code, cmpny_branch, trans_desc, total_vat_amt, local_total_vat_amt, cmpny_code, trans_no, chequeorreference, create_by, create_time, update_by, update_time)")
            .append("VALUES (:acctTransHeaderId, :refNo, :cwAccTransHeaderPk, :ledger, :transType, :invNo, :invDate, :dueDate, :crncyCode, :invAmt, :outstandingAmt, :cmpnyDept, :exchgRate, :invOrgCode, :localCrncyCode, :cmpnyBranch, :transDesc, :totalVatAmt, :localTotalVatAmt, :cmpnyCode, :transNo, :chequeOrReference, :createBy, now(), :updateBy, :updateTime ) ")
            .append("ON CONFLICT (cw_acc_trans_header_pk) DO UPDATE SET ")
            .append("  ref_no=EXCLUDED.ref_no")
            // .append(", cw_acc_trans_header_pk=EXCLUDED.cw_acc_trans_header_pk")
            .append(", ledger=EXCLUDED.ledger")
            .append(", trans_type=EXCLUDED.trans_type")
            .append(", inv_no=EXCLUDED.inv_no")
            .append(", inv_date=EXCLUDED.inv_date")
            .append(", due_date=EXCLUDED.due_date")
            .append(", crncy_code=EXCLUDED.crncy_code")
            .append(", inv_amt=EXCLUDED.inv_amt")
            .append(", outstanding_amt=EXCLUDED.outstanding_amt")
            .append(", cmpny_dept=EXCLUDED.cmpny_dept")
            .append(", exchg_rate=EXCLUDED.exchg_rate")
            .append(", inv_org_code=EXCLUDED.inv_org_code")
            .append(", local_crncy_code=EXCLUDED.local_crncy_code")
            .append(", cmpny_branch=EXCLUDED.cmpny_branch")
            .append(", trans_desc=EXCLUDED.trans_desc")
            .append(", total_vat_amt=EXCLUDED.total_vat_amt")
            .append(", local_total_vat_amt=EXCLUDED.local_total_vat_amt")
            .append(", cmpny_code=EXCLUDED.cmpny_code")
            .append(", trans_no=EXCLUDED.trans_no")
            .append(", chequeorreference=EXCLUDED.chequeorreference")
            // .append(", create_by=EXCLUDED.create_by") // update 時不更新 createBy
            // .append(", create_time=EXCLUDED.create_time") // update 時不更新 createTime
            .append(", update_by=EXCLUDED.update_by")
            .append(", update_time=EXCLUDED.update_time")
            .toString();

        // 使用上述優雅防撞版之後, 就用不到這個 update 敘述了
        // String updateSql = new StringBuilder()
        //     .append("UPDATE at_account_transaction_header SET ")
        //     .append(" ref_no=:refNo")
        //     .append(", ledger=:ledger")
        //     .append(", trans_type=:transType")
        //     .append(", trans_no=:transNo")
        //     .append(", inv_no=:invNo")
        //     .append(", inv_date=:invDate")
        //     .append(", due_date=:dueDate")
        //     .append(", crncy_code=:crncyCode")
        //     .append(", inv_amt=:invAmt")
        //     .append(", outstanding_amt=:outstandingAmt")
        //     .append(", cmpny_dept=:cmpnyDept")
        //     .append(", exchg_rate=:exchgRate")
        //     .append(", inv_org_code=:invOrgCode")
        //     .append(", local_crncy_code=:localCrncyCode")
        //     .append(", cmpny_branch=:cmpnyBranch")
        //     .append(", trans_desc=:transDesc")
        //     .append(", total_vat_amt=:totalVatAmt")
        //     .append(", local_total_vat_amt=:localTotalVatAmt")
        //     .append(", cmpny_code=:cmpnyCode")
        //     .append(", update_time=:updateTime ")
        //     .append(" WHERE cw_acc_trans_header_pk = :cwAccTransHeaderPk")
        //     .toString();

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("acctTransHeaderId", headerBean.getAcctTransHeaderId())
            .addValue("refNo", headerBean.getRefNo())
            .addValue("cwAccTransHeaderPk", headerBean.getCwAccTransHeaderPk())
            .addValue("ledger", headerBean.getLedger())
            .addValue("transType", headerBean.getTransactionType())
            .addValue("invNo", headerBean.getInvoiceNo())
            .addValue("invDate", java.sql.Date.valueOf(headerBean.getInvoiceDate().substring(0, 10)))
            .addValue("dueDate", java.sql.Date.valueOf(headerBean.getDueDate().substring(0, 10)))
            .addValue("crncyCode", headerBean.getCurrencyCode())
            .addValue("invAmt", headerBean.getInvoiceAmount())
            .addValue("outstandingAmt", headerBean.getOutstandingAmount())
            .addValue("cmpnyDept", headerBean.getCompanyDepartment())
            .addValue("exchgRate", headerBean.getExchangeRate())
            .addValue("invOrgCode", headerBean.getInvoiceOrgCode())
            .addValue("localCrncyCode", headerBean.getLocalCurrencyCode())
            .addValue("cmpnyBranch", headerBean.getCompanyBranch())
            .addValue("transDesc", headerBean.getTransactionDescription())
            .addValue("totalVatAmt", headerBean.getTotalVatAmount())
            .addValue("localTotalVatAmt", headerBean.getLocalTotalVatAmount())
            .addValue("cmpnyCode", headerBean.getCompanyCode())
            .addValue("transNo", headerBean.getTransactionNo())
            .addValue("chequeOrReference", headerBean.getChequeOrReference())
            .addValue("createBy", headerBean.getCreateBy())
            .addValue("updateBy", headerBean.getUpdateBy())
            .addValue("updateTime", java.sql.Timestamp.from(headerBean.getUpdateTime()))
            ;

        // return soplNamedJdbcTemplate.update(headerIdInDB==null? insertSql : updateSql, params);
        return soplNamedJdbcTemplate.update(insertSql, params);
    }

    private int saveAtAccountTransactionLines( List<AtAccountTransactionLinesBean> linesBeanList, UUID accountTransactionHeaderId, String invoiceNo ) {

        String existSql = new StringBuilder()
            .append("SELECT acc_trans_lines_id as accountTransactionLinesId, cw_acct_trans_lines_pk as cwAccountTransactionLinesPk from at_account_transaction_lines aatl ")
            .append("INNER JOIN at_account_transaction_header aath  on aath.acct_trans_header_id = aatl.acct_trans_header_id ")
            .append("WHERE aath.acct_trans_header_id = :accountTransactionHeaderId AND aath.inv_no = :invoiceNo ")
            .toString();

        List<AtAccountTransactionLinesBean> existingLinesList = soplNamedJdbcTemplate.query(
            existSql, 
            new MapSqlParameterSource().addValue("accountTransactionHeaderId", accountTransactionHeaderId).addValue("invoiceNo", invoiceNo), 
            new BeanPropertyRowMapper<AtAccountTransactionLinesBean>(AtAccountTransactionLinesBean.class)
        );

        log.debug("accountTransactionHeaderId = [{}], invoiceNo = [{}]", accountTransactionHeaderId, invoiceNo);
        // Collect all existing PKs for quick lookup
        // Set<String> existingPkSet = existingLinesList.stream()
        //     .map(AtAccountTransactionLinesBean::getCwAccountTransactionLinesPk)
        //     .filter(Objects::nonNull)
        //     .map(Object::toString)
        //     .collect(Collectors.toSet());
        // log.debug("existingLinesList.size() = [{}], existingPkSet = [{}]", existingLinesList.size(), existingPkSet);

        String insertSql = new StringBuilder()
            .append("INSERT INTO at_account_transaction_lines ")
            .append("(acc_trans_lines_id, acct_trans_header_id, cw_acct_trans_lines_pk, chrg_code_id, crncy_code, chrg_amt, vat_amt, total_amt, exchg_rate, local_crncy_code, local_vat_amt, cmpny_code, cmpny_branch, cmpny_dept, trans_line_desc)")
            .append("VALUES (:accTransLinesId, :acctTransHeaderId, :cwAcctTransLinesPk, :chrgCodeId, :crncyCode, :chrgAmt, :vatAmt, :totalAmt, :exchgRate, :localCrncyCode, :localVatAmt, :cmpnyCode, :cmpnyBranch, :cmpnyDept, :transactionLineDescription) ")
            // .append("ON CONFLICT (acc_trans_lines_id) DO UPDATE ")
            // .append("SET acct_trans_header_id=EXCLUDED.acct_trans_header_id, cw_acct_trans_lines_pk=EXCLUDED.cw_acct_trans_lines_pk, chrg_code_id=EXCLUDED.chrg_code_id, crncy_code=EXCLUDED.crncy_code, chrg_amt=EXCLUDED.chrg_amt, vat_amt=EXCLUDED.vat_amt, total_amt=EXCLUDED.total_amt, exchg_rate=EXCLUDED.exchg_rate, local_crncy_code=EXCLUDED.local_crncy_code, local_vat_amt=EXCLUDED.local_vat_amt, cmpny_code=EXCLUDED.cmpny_code, cmpny_branch=EXCLUDED.cmpny_branch, cmpny_dept=EXCLUDED.cmpny_dept")
            .toString()
            ;

        String updateSql = new StringBuilder()
            .append("UPDATE at_account_transaction_lines ")
            .append("SET ")
            .append("  acct_trans_header_id = :acctTransHeaderId, ")
            // .append("  cw_acct_trans_lines_pk = :cwAcctTransLinesPk, ")
            .append("  chrg_code_id = :chrgCodeId, ")
            .append("  crncy_code = :crncyCode, ")
            .append("  chrg_amt = :chrgAmt, ")
            .append("  vat_amt = :vatAmt, ")
            .append("  total_amt = :totalAmt, ")
            .append("  exchg_rate = :exchgRate, ")
            .append("  local_crncy_code = :localCrncyCode, ")
            .append("  local_vat_amt = :localVatAmt, ")
            .append("  cmpny_code = :cmpnyCode, ")
            .append("  cmpny_branch = :cmpnyBranch, ")
            .append("  cmpny_dept = :cmpnyDept, ")
            .append("  trans_line_desc = :transactionLineDescription ")
            .append("WHERE acc_trans_lines_id = :accTransLinesId ")
            .toString();

        int totalUpdated = 0;
        int updated = 0;
        for (AtAccountTransactionLinesBean lineBean : linesBeanList) {
            // Determine is lineBean.getCwAccountTransactionLinesPk() is in the List existingLinesList
            // boolean exists = existingPkSet.contains(
            //     lineBean.getCwAccountTransactionLinesPk() != null ? lineBean.getCwAccountTransactionLinesPk().toString() : null
            // );
            boolean exists = false;
            UUID accountTransactionLinesIdToBeUpdated = null;
            for (AtAccountTransactionLinesBean existLinesBean : existingLinesList) {
                log.debug("existLinesBean.getAccountTransactionLinesId() = [{}], lineBean.getCwAccountTransactionLinesPk() = [{}]", existLinesBean.getAccountTransactionLinesId(), lineBean.getCwAccountTransactionLinesPk());

                // Handle NONJOB transactions where lineBean.getCwAccountTransactionLinesPk() is null
                // If existLinesBean has a CW PK but lineBean doesn't (NONJOB case), treat as existing record
                if (existLinesBean.getCwAccountTransactionLinesPk() != null && lineBean.getCwAccountTransactionLinesPk() == null) {
                    accountTransactionLinesIdToBeUpdated = existLinesBean.getAccountTransactionLinesId();
                    exists = true;
                    log.debug("NONJOB transaction - matched existing line with CW PK, will update existing record");
                    break;
                }

                // Regular comparison for non-null CW PKs
                if (existLinesBean.getCwAccountTransactionLinesPk() != null &&
                    lineBean.getCwAccountTransactionLinesPk() != null &&
                    existLinesBean.getCwAccountTransactionLinesPk().compareTo(lineBean.getCwAccountTransactionLinesPk()) == 0) {
                    accountTransactionLinesIdToBeUpdated = existLinesBean.getAccountTransactionLinesId();
                    exists = true;
                    log.debug("accountTransactionLinesIdToBeUpdated is set");
                    break;
                }
            }
            log.debug("lineBean.getCwAccountTransactionLinesPk()=[{}] exists? [{}]", lineBean.getCwAccountTransactionLinesPk(), exists);

            MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("accTransLinesId", accountTransactionLinesIdToBeUpdated!=null? accountTransactionLinesIdToBeUpdated : lineBean.getAccountTransactionLinesId())
                .addValue("acctTransHeaderId", (accountTransactionHeaderId!=null)? accountTransactionHeaderId : lineBean.getAccountTransactionHeaderId())
                .addValue("cwAcctTransLinesPk", lineBean.getCwAccountTransactionLinesPk())
                .addValue("chrgCodeId", lineBean.getChargeCodeId())
                .addValue("crncyCode", lineBean.getCurrencyCode())
                .addValue("chrgAmt", lineBean.getChargeAmount())
                .addValue("vatAmt", lineBean.getVatAmount())
                .addValue("totalAmt", lineBean.getTotalAmount())
                .addValue("exchgRate", lineBean.getExchangeRate())
                .addValue("localCrncyCode", lineBean.getLocalCurrencyCode())
                .addValue("localVatAmt", lineBean.getLocalVatAmount())
                .addValue("cmpnyCode", lineBean.getCompanyCode())
                .addValue("cmpnyBranch", lineBean.getCompanyBranch())
                .addValue("cmpnyDept", lineBean.getCompanyDept())
                .addValue("transactionLineDescription", lineBean.getTransactionLineDescription());
            String sql = exists ? updateSql : insertSql;
            updated = soplNamedJdbcTemplate.update(sql, params);
            totalUpdated += updated;
        }
        return totalUpdated;
    }

    @Override
    public int updateAccountTransactionHeader(AtAccountTransactionHeaderBean headerBean) {
        final String sql = "UPDATE at_account_transaction_header SET is_cancel = true, outstanding_amt = 0, update_time=:updateTime WHERE cw_acc_trans_header_pk = :cwAccTransHeaderPk"; // acct_trans_header_id = :accountTransactionHeaderId // 2025/05/22 加上 outstanding_amt = 0 的處理 -> 才能讓 PR inquiry 的時候不要被選到
        // MapSqlParameterSource params = new MapSqlParameterSource().addValue("accountTransactionHeaderId", headerBean.getAcctTransHeaderId(), java.sql.Types.OTHER);
        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("cwAccTransHeaderPk", headerBean.getCwAccTransHeaderPk(), java.sql.Types.OTHER)
            .addValue("updateTime", java.sql.Timestamp.from(headerBean.getUpdateTime()))
            ;
        return soplNamedJdbcTemplate.update(sql, params);
    }

    @Override
    public int updateAccountTransactionHeaderWithOutstandingAmount(AtAccountTransactionHeaderBean headerBean) {
        final String sql = "UPDATE at_account_transaction_header SET outstanding_amt=:outstandingAmt WHERE cw_acc_trans_header_pk = :cwAccTransHeaderPk";
        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("outstandingAmt", headerBean.getOutstandingAmount(), java.sql.Types.DECIMAL)
            .addValue("cwAccTransHeaderPk", headerBean.getCwAccTransHeaderPk(), java.sql.Types.OTHER);
        return soplNamedJdbcTemplate.update(sql, params);
    }

    public int[] saveAtShipmentInfo( List<AtShipmentInfoBean> shipmentInfoBeanList ) {
        log.info("saveAtShipmentInfo() is deprecated by vw_shipment_info implementation.");
        return new int[]{0};
        // log.debug("saveAtShipmentInfo() shipmentInfoBeanList.size() = [{}]", shipmentInfoBeanList.isEmpty() ? 0 : shipmentInfoBeanList.size());
        // String sql = new StringBuilder()
        //     .append("INSERT INTO at_shipment_info ")
        //     .append("(ref_no, shipment_no, cnsl_no, hbl_no, mbl_no, master_mbl, shipment_id, master_shipment_id, carrier_book_no, etd, atd, ata, shipment_type, cnsl_type, cntr_mode, cntr_list, cnsl_first_leg_vssl, cnsl_first_leg_voy, create_cmpny, create_branch, create_dept, create_by, create_time) ") // , container_no
        //     .append("VALUES (:refNo, :shipmentNo, :consolNo, :hblNo, :mblNo, :masterMbl, :shipmentId, :masterShipmentId, :carrierBookingNo, :etd, :atd, :ata, :shipmentType, :consolType, :containerMode, :containerList, :consolFirstLegVessel, :consolFirstLegVoyage, :createCompany, :createBranch, :createDepartment, 'CPAR-API', CURRENT_TIMESTAMP) ") // , :containerNo
        //     .append("ON CONFLICT (ref_no) DO UPDATE SET ")
        //     .append(" shipment_no=EXCLUDED.shipment_no")
        //     .append(", cnsl_no=EXCLUDED.cnsl_no")
        //     .append(", hbl_no=EXCLUDED.hbl_no")
        //     .append(", mbl_no=EXCLUDED.mbl_no")
        //     .append(", master_mbl=EXCLUDED.master_mbl")
        //     .append(", shipment_id=EXCLUDED.shipment_id")
        //     .append(", master_shipment_id=EXCLUDED.master_shipment_id")
        //     .append(", carrier_book_no=EXCLUDED.carrier_book_no")
        //     .append(", etd=EXCLUDED.etd")
        //     .append(", atd=EXCLUDED.atd")
        //     .append(", ata=EXCLUDED.ata")
        //     .append(", shipment_type=EXCLUDED.shipment_type")
        //     .append(", cnsl_type=EXCLUDED.cnsl_type")
        //     .append(", cntr_mode=EXCLUDED.cntr_mode")
        //     .append(", cntr_list=EXCLUDED.cntr_list")
        //     .append(", cnsl_first_leg_vssl=EXCLUDED.cnsl_first_leg_vssl")
        //     .append(", cnsl_first_leg_voy=EXCLUDED.cnsl_first_leg_voy")
        //     .append(", create_cmpny=EXCLUDED.create_cmpny")
        //     .append(", create_branch=EXCLUDED.create_branch")
        //     .append(", create_dept=EXCLUDED.create_dept")
        //     .append(", create_by='CPAR-API'")
        //     .append(", create_time=CURRENT_TIMESTAMP")
        //     .toString();
		// SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(shipmentInfoBeanList.toArray());
		// return soplNamedJdbcTemplate.batchUpdate(sql, batch);
    }

    private List<AtShipmentInfoBean> fetchShipmentInfoFromCW( String transactionNo, String transactionType, boolean isCancelled, String companyCode, String branchCode ) {
        log.debug("fetchShipmentInfoFromCW() transactionNo = [{}], transactionType = [{}], isCancelled = [{}], companyCode = [{}], branchCode = [{}]", 
            transactionNo, transactionType, isCancelled, companyCode, branchCode);

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("transactionNo", transactionNo)
            .addValue("transactionType", transactionType)
            .addValue("isCancelled", (isCancelled?1:0))
            .addValue("companyCode", companyCode)
            .addValue("branchCode", branchCode)
            ;
        return cargowiseNamedJdbcTemplate.query(
            SQL_FETCH_SHIPMENT_INFO_BY_TRANSACTION_NO, 
            params, 
            new BeanPropertyRowMapper<AtShipmentInfoBean>(AtShipmentInfoBean.class)
        );
    }

    //-------- below methods are for query --------//

    private List<AtAccountTransactionHeaderBean> getAtAccountTransactionHeader( UUID cwAccTransHeaderPk ) {
        String sql = new StringBuilder()
            .append("SELECT acct_trans_header_id, create_time, update_time from at_account_transaction_header ")
            .append("WHERE cw_acc_trans_header_pk = :cwAccTransHeaderPk ")
            // .append(" AND trans_no = :transNo ") // 2025/05/05 以 cw_acc_trans_header_pk 為唯一 key 值, 重複則更新, 包含 trans_no
            .toString();

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("cwAccTransHeaderPk", cwAccTransHeaderPk)
            // .addValue("transNo", transactionNo)
            ;

        return soplNamedJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<AtAccountTransactionHeaderBean>(AtAccountTransactionHeaderBean.class));
    }

    private List<AtAccountTransactionLinesBean> fetchAtAccountTransactionLines( UUID cwAccTransHeaderPk ) {
        String sql = new StringBuilder()
            .append("select acc_trans_lines_id as ACCOUNT_TRANSACTION_LINES_ID, cw_acct_trans_lines_pk as CW_ACCOUNT_TRANSACTION_LINES_PK from at_account_transaction_lines aatl ")
            .append("where aatl.acct_trans_header_id in ( ")
            .append("select acct_trans_header_id from at_account_transaction_header aath where cw_acc_trans_header_pk = :cwAccTransHeaderPk ")
            .append(")")
            .toString();

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("cwAccTransHeaderPk", cwAccTransHeaderPk)
            ;

        return soplNamedJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<AtAccountTransactionLinesBean>(AtAccountTransactionLinesBean.class));
    }

    public Optional<Integer> countAtAccountTransactionHeaderByTranNo( String transactionNo ) {
        String sql = new StringBuilder()
            .append("SELECT count(*) from at_account_transaction_header ")
            .append("WHERE trans_no = :transNo ")
            .toString();

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("transNo", transactionNo)
            ;

        try {
            return Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(sql, params, Integer.class));
        } catch (EmptyResultDataAccessException e) {
            log.info("countAtAccountTransactionHeaderByTranNo() no existing record found : transNo=[{}]; {}", transactionNo, e.getMessage());
        }
        return Optional.empty();
    }

    // @Deprecated
    // public Optional<AtAccountTransactionHeaderBean> getAtAccountTransactionHeaderByTransactionNo( String transactionNo ) {
    //     String sql = new StringBuilder()
    //         .append("SELECT acct_trans_header_id, ref_no, cw_acc_trans_header_pk, ledger,")
    //         .append(" trans_type as TRANSACTION_TYPE,")
    //         .append(" inv_no as INVOICE_NO, inv_date as INVOICE_DATE,")
    //         .append(" due_date, crncy_code as CURRENCY_CODE,")
    //         .append(" inv_amt as INVOICE_AMOUNT, outstanding_amt as OUTSTANDING_AMOUNT,")
    //         .append(" cmpny_dept as COMPANY_DEPARTMENT, exchg_rate as EXCHANGE_RATE,")
    //         .append(" inv_org_code as INVOICE_ORG_CODE, local_crncy_code as LOCAL_CURRENCY_CODE,")
    //         .append(" cmpny_branch as COMPANY_BRANCH, trans_desc as TRANSACTION_DESCRIPTION,")
    //         .append(" total_vat_amt as TOTAL_VAT_AMOUNT, local_total_vat_amt as LOCAL_TOTAL_VAT_AMOUNT,")
    //         .append(" cmpny_code as COMPANY_CODE, trans_no as TRANSACTION_NO,")
    //         .append(" is_cancel, create_time, update_time ")
    //         .append("from at_account_transaction_header ")
    //         .append("WHERE trans_no = :transNo ")
    //         .toString();

    //     MapSqlParameterSource params = new MapSqlParameterSource()
    //         .addValue("transNo", transactionNo)
    //         ;

    //     try {
    //         return Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(sql, params, new BeanPropertyRowMapper<>(AtAccountTransactionHeaderBean.class)));
    //     } catch (EmptyResultDataAccessException e) {
    //         log.info("getAtAccountTransactionHeaderByTransactionNo() no existing record found : transNo=[{}]; {}", transactionNo, e.getMessage());
    //     }
    //     return Optional.empty();
    // }

    public List<UUID> fetchAtAccountTransactionHeaderIdByTransactionNo( List<String> transactionNoList ) {
        log.debug("fetchAtAccountTransactionHeaderIdByTransactionNo() transactionNoList.size() = [{}]", transactionNoList.isEmpty() ? 0 : transactionNoList.size());
        if (transactionNoList.isEmpty()) { return Collections.emptyList(); }

        return soplNamedJdbcTemplate.query(
            SQL_FETCH_AT_ACCOUNT_TRANSACTION_HEADER_ID_BY_TRANSACTION_NO, 
            Map.of("transactionNoList", transactionNoList), 
            (rs, rowNum) -> {
                return rs.getObject("acct_trans_header_id", UUID.class);
            }
        );
    }

    @Override
    public List<AtAccountTransactionHeaderBean> findHeadersByTransactionNo(String transactionNo) {
        String sql = """
            SELECT acct_trans_header_id, ref_no, cw_acc_trans_header_pk, ledger,
                   trans_type as TRANSACTION_TYPE, inv_no as INVOICE_NO, inv_date as INVOICE_DATE,
                   due_date, crncy_code as CURRENCY_CODE, inv_amt as INVOICE_AMOUNT, 
                   outstanding_amt as OUTSTANDING_AMOUNT, cmpny_dept as COMPANY_DEPARTMENT, 
                   exchg_rate as EXCHANGE_RATE, inv_org_code as INVOICE_ORG_CODE, 
                   local_crncy_code as LOCAL_CURRENCY_CODE, cmpny_branch as COMPANY_BRANCH, 
                   trans_desc as TRANSACTION_DESCRIPTION, total_vat_amt as TOTAL_VAT_AMOUNT, 
                   local_total_vat_amt as LOCAL_TOTAL_VAT_AMOUNT, cmpny_code as COMPANY_CODE, 
                   trans_no as TRANSACTION_NO, is_cancel, create_by, create_time, update_by, update_time
            FROM at_account_transaction_header 
            WHERE trans_no = :transactionNo
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("transactionNo", transactionNo);

        return soplNamedJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(AtAccountTransactionHeaderBean.class));
    }

    @Override
    public List<AtAccountTransactionLinesBean> findLinesByHeaderPk(Long headerPk) {
        String sql = """
            SELECT acc_trans_lines_id as ACCOUNT_TRANSACTION_LINES_ID, 
                   acct_trans_header_id as ACCOUNT_TRANSACTION_HEADER_ID,
                   cw_acct_trans_lines_pk as CW_ACCOUNT_TRANSACTION_LINES_PK,
                   chrg_code_id as CHARGE_CODE_ID, crncy_code as CURRENCY_CODE,
                   chrg_amt as CHARGE_AMOUNT, vat_amt as VAT_AMOUNT, total_amt as TOTAL_AMOUNT,
                   exchg_rate as EXCHANGE_RATE, local_crncy_code as LOCAL_CURRENCY_CODE,
                   local_vat_amt as LOCAL_VAT_AMOUNT, cmpny_code as COMPANY_CODE,
                   cmpny_branch as COMPANY_BRANCH, cmpny_dept as COMPANY_DEPT,
                   trans_line_desc as TRANSACTION_LINE_DESCRIPTION
            FROM at_account_transaction_lines 
            WHERE acct_trans_header_id = (
                SELECT acct_trans_header_id FROM at_account_transaction_header 
                WHERE acct_trans_header_id = :headerPk
            )
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("headerPk", headerPk);

        return soplNamedJdbcTemplate.query(sql, params, new BeanPropertyRowMapper<>(AtAccountTransactionLinesBean.class));
    }

    @Override
    public AtShipmentInfoBean findShipmentByJobNumber(String jobNumber) {
        log.debug("findShipmentByJobNumber() called with jobNumber: {}", jobNumber);

        if (jobNumber == null || jobNumber.trim().isEmpty()) {
            log.warn("findShipmentByJobNumber() jobNumber is null or empty");
            return null;
        }

        // Feature flag check: use view-based implementation if enabled and available
        if (shipmentProperties.isViewEnabled() && shipmentViewService != null) {
            log.debug("Using view-based shipment lookup for jobNumber: {}", jobNumber);
            try {
                // Check if view service is available
                if (!shipmentViewService.isViewAvailable()) {
                    log.warn("Shipment view is not available, falling back to table implementation for jobNumber: {}", jobNumber);
                    return findShipmentByJobNumberFallback(jobNumber);
                }

                // Attempt view-based lookup
                Optional<VwShipmentInfoBean> viewResult = shipmentViewService.findShipmentByJobNumber(jobNumber);
                if (viewResult.isPresent()) {
                    VwShipmentInfoBean shipmentInfo = viewResult.get();
                    log.info("Successfully retrieved shipment data from view for jobNumber: {}", jobNumber);
                    log.debug("Shipment info from view: shipment_no={}, cnsl_no={}, hbl_no={}, mbl_no={}",
                             shipmentInfo.getShipmentNo(), shipmentInfo.getConsolNo(),
                             shipmentInfo.getHblNo(), shipmentInfo.getMblNo());

                    // Convert view bean to AtShipmentInfoBean and return
                    AtShipmentInfoBean atShipmentInfo = convertViewToAtShipmentInfoForJobNumber(shipmentInfo, jobNumber);
                    if (atShipmentInfo != null) {
                        log.info("Successfully converted view result to AtShipmentInfoBean for jobNumber: {}", jobNumber);
                        return atShipmentInfo;
                    } else {
                        log.warn("Failed to convert view result to AtShipmentInfoBean for jobNumber: {}", jobNumber);
                    }
                } else {
                    log.info("No shipment data found in view for jobNumber: {}", jobNumber);
                }

                // Fallback to table implementation if view returns no data and fallback is enabled
                if (shipmentProperties.isFallbackEnabled()) {
                    log.info("Falling back to table implementation for jobNumber: {}", jobNumber);
                    return findShipmentByJobNumberFallback(jobNumber);
                } else {
                    log.warn("Fallback disabled, no shipment data will be returned for jobNumber: {}", jobNumber);
                    return null;
                }

            } catch (Exception e) {
                log.error("Error during view-based shipment lookup for jobNumber: {}", jobNumber, e);
                if (shipmentProperties.isFallbackEnabled()) {
                    log.info("Exception occurred, falling back to table implementation for jobNumber: {}", jobNumber);
                    return findShipmentByJobNumberFallback(jobNumber);
                } else {
                    log.error("Fallback disabled, shipment lookup failed for jobNumber: {}", jobNumber);
                    throw new RuntimeException("View-based shipment lookup failed for jobNumber: " + jobNumber, e);
                }
            }
        } else {
            // Use existing table-based implementation
            log.debug("Using table-based shipment lookup for jobNumber: {}", jobNumber);
            return findShipmentByJobNumberFallback(jobNumber);
        }
    }

    /**
     * Fallback method using the original table-based implementation.
     * This method provides backward compatibility and graceful degradation.
     *
     * @param jobNumber the job number to search for
     * @return AtShipmentInfoBean if found, null otherwise
     */
    private AtShipmentInfoBean findShipmentByJobNumberFallback(String jobNumber) {
        log.debug("Using fallback table-based lookup for jobNumber: {}", jobNumber);
        String sql = """
            SELECT ref_no, shipment_no, cnsl_no as CONSOL_NO, hbl_no, mbl_no, master_mbl,
                   shipment_id, master_shipment_id, carrier_book_no as CARRIER_BOOKING_NO,
                   etd, atd, ata, shipment_type, cnsl_type as CONSOL_TYPE, cntr_mode as CONTAINER_MODE,
                   cntr_list as CONTAINER_LIST, cnsl_first_leg_vssl as CONSOL_FIRST_LEG_VESSEL,
                   cnsl_first_leg_voy as CONSOL_FIRST_LEG_VOYAGE, create_cmpny as CREATE_COMPANY,
                   create_branch, create_dept as CREATE_DEPARTMENT, create_by, create_time
            FROM at_shipment_info
            WHERE ref_no = :jobNumber
            LIMIT 1
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("jobNumber", jobNumber);

        try {
            AtShipmentInfoBean result = soplNamedJdbcTemplate.queryForObject(sql, params, new BeanPropertyRowMapper<>(AtShipmentInfoBean.class));
            log.debug("Found shipment in table for jobNumber: {}", jobNumber);
            return result;
        } catch (EmptyResultDataAccessException e) {
            log.debug("findShipmentByJobNumber() no shipment found for jobNumber=[{}]", jobNumber);
            return null;
        }
    }

    /**
     * Convert VwShipmentInfoBean to AtShipmentInfoBean for job number lookup.
     * This version of the converter preserves the original jobNumber as ref_no.
     *
     * @param viewBean the VwShipmentInfoBean from the view
     * @param jobNumber the original job number used for lookup
     * @return AtShipmentInfoBean or null if conversion fails
     */
    private AtShipmentInfoBean convertViewToAtShipmentInfoForJobNumber(VwShipmentInfoBean viewBean, String jobNumber) {
        try {
            AtShipmentInfoBean atBean = new AtShipmentInfoBean();

            // Map view fields to AtShipmentInfoBean fields
            atBean.setRefNo(jobNumber); // Preserve the original job number as ref_no
            atBean.setConsolNo(viewBean.getConsolNo());
            atBean.setShipmentNo(viewBean.getShipmentNo());
            atBean.setMblNo(viewBean.getMblNo());
            atBean.setHblNo(viewBean.getHblNo());
            atBean.setMasterMbl(viewBean.getMasterMbl());
            atBean.setCarrierBookingNo(viewBean.getCarrierBookNo());
            atBean.setShipmentType(viewBean.getShipmentType());
            atBean.setConsolType(viewBean.getConsolType());
            atBean.setConsolFirstLegVessel(viewBean.getConsolFirstLegVessel());
            atBean.setConsolFirstLegVoyage(viewBean.getConsolFirstLegVoyage());

            // Set creation/update metadata
            atBean.setCreateBy("SYSTEM_VIEW_JOB");

            log.debug("Successfully converted view bean to AtShipmentInfoBean for jobNumber: {}", jobNumber);
            return atBean;
        } catch (Exception e) {
            log.error("Error converting VwShipmentInfoBean to AtShipmentInfoBean for jobNumber: {}",
                     jobNumber, e);
            return null;
        }
    }

    /**
     * Process shipment information using the view-based implementation.
     * This method implements prefix-based routing with retry mechanism and comprehensive logging.
     *
     * @param headerBean the transaction header bean containing refNo for lookup
     */
    private void processShipmentInfoWithView(AtAccountTransactionHeaderBean headerBean) {
        String refNo = headerBean.getRefNo();
        log.info("Starting view-based shipment processing for refNo: {}", refNo);

        try {
            // Check if view service is available
            if (!shipmentViewService.isViewAvailable()) {
                log.warn("Shipment view is not available, falling back to table implementation for refNo: {}", refNo);
                processShipmentInfoFallback(headerBean);
                return;
            }

            // Attempt view-based lookup with retry mechanism
            Optional<VwShipmentInfoBean> viewResult = processWithRetry(refNo);

            if (viewResult.isPresent()) {
                VwShipmentInfoBean shipmentInfo = viewResult.get();
                log.info("Successfully retrieved shipment data from view for refNo: {}", refNo);
                log.debug("Shipment info from view: shipment_no={}, cnsl_no={}, hbl_no={}, mbl_no={}",
                         shipmentInfo.getShipmentNo(), shipmentInfo.getConsolNo(),
                         shipmentInfo.getHblNo(), shipmentInfo.getMblNo());

                // Convert view bean to AtShipmentInfoBean and save
                AtShipmentInfoBean atShipmentInfo = convertViewToAtShipmentInfo(shipmentInfo, headerBean);
                if (atShipmentInfo != null) {
                    List<AtShipmentInfoBean> shipmentInfoList = Collections.singletonList(atShipmentInfo);
                    int[] result = saveAtShipmentInfo(shipmentInfoList);
                    log.info("Saved shipment info from view for refNo: {}, result: {}", refNo, result);
                } else {
                    log.warn("Failed to convert view result to AtShipmentInfoBean for refNo: {}", refNo);
                }
            } else {
                log.info("No shipment data found in view for refNo: {}", refNo);
                if (shipmentProperties.isFallbackEnabled()) {
                    log.info("Falling back to table implementation for refNo: {}", refNo);
                    processShipmentInfoFallback(headerBean);
                } else {
                    log.warn("Fallback disabled, no shipment data will be processed for refNo: {}", refNo);
                }
            }

        } catch (Exception e) {
            log.error("Error during view-based shipment processing for refNo: {}", refNo, e);
            if (shipmentProperties.isFallbackEnabled()) {
                log.info("Exception occurred, falling back to table implementation for refNo: {}", refNo);
                processShipmentInfoFallback(headerBean);
            } else {
                log.error("Fallback disabled, shipment processing failed for refNo: {}", refNo);
                throw new RuntimeException("View-based shipment processing failed for refNo: " + refNo, e);
            }
        }
    }

    /**
     * Process shipment lookup with retry mechanism for empty results.
     *
     * @param refNo the reference number for lookup
     * @return Optional containing VwShipmentInfoBean if found
     */
    private Optional<VwShipmentInfoBean> processWithRetry(String refNo) {
        int maxRetries = shipmentProperties.getRetryAttempts();
        long retryDelay = shipmentProperties.getRetryDelayMs();

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            log.debug("View lookup attempt {}/{} for refNo: {}", attempt, maxRetries, refNo);

            try {
                Optional<VwShipmentInfoBean> result = shipmentViewService.findShipmentByRefNo(refNo);

                if (result.isPresent()) {
                    log.debug("Found shipment data on attempt {} for refNo: {}", attempt, refNo);
                    return result;
                } else if (attempt < maxRetries) {
                    log.debug("No data found on attempt {}, retrying after {}ms for refNo: {}",
                             attempt, retryDelay, refNo);
                    if (retryDelay > 0) {
                        try {
                            Thread.sleep(retryDelay);
                        } catch (InterruptedException e) {
                            log.warn("Retry delay interrupted for refNo: {}", refNo);
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                log.warn("Exception during view lookup attempt {} for refNo: {}: {}",
                        attempt, refNo, e.getMessage());
                if (attempt >= maxRetries) {
                    throw e;
                }
            }
        }

        log.info("No shipment data found after {} retry attempts for refNo: {}", maxRetries, refNo);
        return Optional.empty();
    }

    /**
     * Fallback to table-based shipment processing when view implementation fails.
     *
     * @param headerBean the transaction header bean
     */
    private void processShipmentInfoFallback(AtAccountTransactionHeaderBean headerBean) {
        log.debug("Executing fallback table-based shipment lookup for refNo: {}", headerBean.getRefNo());
        List<AtShipmentInfoBean> availableShipmentInfoList = fetchShipmentInfoFromCW(
            headerBean.getTransactionNo(), headerBean.getTransactionType(),
            headerBean.isCancelled(), headerBean.getCompanyCode(), headerBean.getCompanyBranch()
        );

        log.debug("Fallback availableShipmentInfoList.size() = [{}] at_shipment_info :",
                 availableShipmentInfoList.isEmpty() ? 0 : availableShipmentInfoList.size());
        JsonUtils.print(availableShipmentInfoList);

        if (!availableShipmentInfoList.isEmpty()) {
            int[] result = saveAtShipmentInfo(availableShipmentInfoList);
            log.debug("Fallback result of saveAtShipmentInfo() [{}]", result);
        }
    }

    /**
     * Convert VwShipmentInfoBean from view to AtShipmentInfoBean for database storage.
     *
     * @param viewBean the shipment info from view
     * @param headerBean the transaction header bean for context
     * @return converted AtShipmentInfoBean or null if conversion fails
     */
    private AtShipmentInfoBean convertViewToAtShipmentInfo(VwShipmentInfoBean viewBean, AtAccountTransactionHeaderBean headerBean) {
        try {
            AtShipmentInfoBean atBean = new AtShipmentInfoBean();

            // Map view fields to AtShipmentInfoBean fields
            atBean.setRefNo(viewBean.getShipmentNo()); // Use shipment_no as primary ref_no
            atBean.setConsolNo(viewBean.getConsolNo());
            atBean.setShipmentNo(viewBean.getShipmentNo());
            atBean.setMblNo(viewBean.getMblNo());
            atBean.setHblNo(viewBean.getHblNo());
            atBean.setMasterMbl(viewBean.getMasterMbl());
            atBean.setCarrierBookingNo(viewBean.getCarrierBookNo());

            // Set creation/update metadata
            atBean.setCreateBy("SYSTEM_VIEW");

            log.debug("Successfully converted view bean to AtShipmentInfoBean for refNo: {}", headerBean.getRefNo());
            return atBean;

        } catch (Exception e) {
            log.error("Error converting VwShipmentInfoBean to AtShipmentInfoBean for refNo: {}",
                     headerBean.getRefNo(), e);
            return null;
        }
    }

}
