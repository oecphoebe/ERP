package oec.lis.erpportal.addon.compliance.common.api.service;

import java.time.Duration;
import java.time.Instant;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.common.api.model.TokenInfo;

@Slf4j
public abstract class AbstractTokenService implements TokenService {
    protected final Cache<String, TokenInfo> tokenCache;
    protected final String cacheKey;
    
    public AbstractTokenService(String cacheKey, Duration cacheDuration) {
        this.cacheKey = cacheKey;
        this.tokenCache = Caffeine.newBuilder()
            .expireAfterWrite(cacheDuration)
            .build();
    }
    
    @Override
    public String getValidToken() {
        TokenInfo tokenInfo = tokenCache.getIfPresent(cacheKey);
        
        if (tokenInfo == null || isExpiringSoon(tokenInfo)) {
            return refreshToken();
        }
        
        return tokenInfo.getToken();
    }

    protected boolean isExpiringSoon(TokenInfo tokenInfo) {
        // Consider token as expiring if less than 2 minutes remaining
        Instant currentTime = Instant.now();
        log.debug("current time = [{}] expiryTime = [{}] seconds, isExpiringSoon=[{}]", 
            currentTime, 
            tokenInfo.getExpiryTime(), 
            tokenInfo.getExpiryTime().isBefore(currentTime.plusSeconds(120))
        );
        return tokenInfo.getExpiryTime().isBefore(currentTime.plusSeconds(120));
    }

    protected abstract String refreshToken();
}