package oec.lis.erpportal.addon.compliance.common.api.util;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import feign.Response;

public class FeignUtil {
    public static String toString(Response response) throws IOException {
        if (response != null && response.body() != null) {
            try (InputStreamReader reader = new InputStreamReader(response.body().asInputStream(), StandardCharsets.UTF_8)) {
                StringBuilder stringBuilder = new StringBuilder();
                char[] buffer = new char[8192];
                int bytesRead;
                while ((bytesRead = reader.read(buffer)) != -1) {
                    stringBuilder.append(buffer, 0, bytesRead);
                }
                return stringBuilder.toString();
            }
        }
        return ""; // Or handle the null case as needed
    }   
}
