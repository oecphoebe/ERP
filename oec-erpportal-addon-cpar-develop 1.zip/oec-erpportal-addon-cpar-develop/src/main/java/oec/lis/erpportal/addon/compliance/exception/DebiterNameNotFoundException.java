package oec.lis.erpportal.addon.compliance.exception;

public class DebiterNameNotFoundException extends Exception {
    public DebiterNameNotFoundException(String message) {
        super(message);
    }

    public DebiterNameNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public DebiterNameNotFoundException(Throwable cause) {
        super(cause);
    }

}
