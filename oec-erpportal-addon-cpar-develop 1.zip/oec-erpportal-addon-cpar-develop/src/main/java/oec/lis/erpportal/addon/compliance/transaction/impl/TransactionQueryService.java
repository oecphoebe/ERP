package oec.lis.erpportal.addon.compliance.transaction.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.exception.DebiterNameNotFoundException;
import oec.lis.erpportal.addon.compliance.model.transaction.BuyerInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.CwAccountTransactionInfo;
import oec.lis.erpportal.addon.compliance.model.transaction.RefNoInfo;

@Service
@Slf4j
public class TransactionQueryService {

    // SQL(A)
    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_SHIPMENT = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append(", ath.AH_TransactionNum as invoice_no ")
        .append(", oh.OH_Code as creditor ")
        .append(", atl.AL_Sequence as display_Sequence ")
        .append(", jh.JH_JobNum as job_Number ")
        .append(", atl.AL_PK as account_Transaction_Lines_Pk ")
        .append(", acc.AC_PK as account_Charge_Code_Pk ")
        .append(", acc.AC_Code as charge_Code ")
        .append("FROM AccTransactionHeader ath ")
        .append("INNER JOIN AccTransactionLines atl on atl.AL_AH = ath.AH_PK ")
        .append("INNER JOIN AccChargeCode acc on acc.AC_PK = atl.AL_AC ")
        .append("INNER JOIN JobHeader jh on jh.JH_PK = atl.AL_JH ")
        .append("INNER JOIN OrgHeader oh on atl.AL_OH = oh.OH_PK ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .append(" AND oh.OH_Code = :organizationCode ")
        .toString();

    // SQL(A+)
    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_CONSOL = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append(", ath.AH_TransactionNum as invoice_no ")
        .append(", jcl.e6_pk as account_Transaction_Lines_Pk ")
        .append(", acc.AC_PK as account_Charge_Code_Pk ")
        .append(", acc.AC_Code as charge_Code ")
        .append("FROM AccTransactionHeader ath ")
        .append("INNER JOIN JobConsolCost jcl ON jcl.e6_ah_apinvoice = ath.ah_pk ")
        .append("INNER JOIN AccChargeCode acc on acc.AC_PK = jcl.E6_AC_ChargeCode ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .toString();

    // SQL(A) 對應 AP [INV][CRD] Reversed 僅需要 header 資料的情境
    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_HEADER = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append("FROM AccTransactionHeader ath ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .toString();

    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_PAY_REC = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append("FROM AccTransactionHeader ath ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .toString();

    // SQL for NONJOB transactions - Job-Invoice type (has JobInvoiceNumber, AccTransactionLines exists)
    // Fetches AccTransactionLines data directly without JobHeader dependencies
    // Includes organizationCode filter for Job-Invoice type NONJOB
    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_NONJOB = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append(", ath.AH_TransactionNum as invoice_no ")
        .append(", atl.AL_PK as account_Transaction_Lines_Pk ")
        .append(", atl.AL_Sequence as display_Sequence ")
        .append(", acc.AC_PK as account_Charge_Code_Pk ")
        .append(", acc.AC_Code as charge_Code ")
        .append(", oh.OH_Code as creditor ")
        .append(", atl.AL_OSAmount as os_amount ")
        .append(", atl.AL_GSTVAT as gst_vat_amount ")
        .append(", atl.AL_LineAmount as line_amount ")
        .append(", atl.AL_ExchangeRate as exchange_rate ")
        .append(", atl.AL_RX_NKTransactionCurrency as currency_code ")
        .append("FROM AccTransactionHeader ath ")
        .append("LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK ")
        .append("LEFT JOIN AccChargeCode acc ON acc.AC_PK = atl.AL_AC ")
        .append("LEFT JOIN AccGLHeader ag on ag.AG_PK = atl.AL_AG ")
        .append("LEFT JOIN OrgHeader oh ON atl.AL_OH = oh.OH_PK ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .append(" AND oh.OH_Code = :organizationCode ")
        .toString();

    // SQL for NONJOB transactions - GL-Account type (no JobInvoiceNumber, AccTransactionLines may not exist)
    // Fetches GL account transaction data WITHOUT organizationCode filter
    // Returns ALL rows for multi-line GL-Account processing
    // AL_PK may be NULL for GL-Account type (requires composite key generation)
    public static final String QUERY_CW_ACCOUNT_TRANSACTION_INFO_GL_ACCOUNT = new StringBuilder()
        .append("SELECT DISTINCT ")
        .append("ath.AH_PK as account_Transaction_Header_Pk ")
        .append(", ath.AH_Ledger ")
        .append(", ath.AH_TransactionType ")
        .append(", ath.AH_TransactionNum ")
        .append(", oh.OH_Code ")
        .append(", ath.AH_TransactionNum as invoice_no ")
        .append(", atl.AL_PK as account_Transaction_Lines_Pk ")
        .append(", atl.AL_Sequence as display_Sequence ")
        .append(", acc.AC_PK as account_Charge_Code_Pk ")
        .append(", acc.AC_Code as charge_Code ")
        .append(", ag.AG_AccountNum as gl_Account ")
        .append(", oh.OH_Code as creditor ")
        .append(", atl.AL_OSAmount as os_amount ")
        .append(", atl.AL_GSTVAT as gst_vat_amount ")
        .append(", atl.AL_LineAmount as line_amount ")
        .append(", atl.AL_ExchangeRate as exchange_rate ")
        .append(", atl.AL_RX_NKTransactionCurrency as currency_code ")
        .append("FROM AccTransactionHeader ath ")
        .append("LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK ")
        .append("LEFT JOIN AccChargeCode acc ON acc.AC_PK = atl.AL_AC ")
        .append("LEFT JOIN AccGLHeader ag on ag.AG_PK = atl.AL_AG ")
        .append("LEFT JOIN OrgHeader oh ON atl.AL_OH = oh.OH_PK ")
        .append("WHERE ath.AH_Ledger = :ledger ")
        .append(" AND ath.AH_TransactionType = :transactionType ")
        .append(" AND ath.AH_TransactionNum = :transactionNo ")
        .toString();

    private final NamedParameterJdbcTemplate soplNamedJdbcTemplate;
    private final NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate;

    public TransactionQueryService(
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate, 
        @Qualifier("cargowiseNamedJdbcTemplate") NamedParameterJdbcTemplate cargowiseNamedJdbcTemplate
    ) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
        this.cargowiseNamedJdbcTemplate = cargowiseNamedJdbcTemplate;
    }

    public String getDebiterName(String organizationCode) throws DebiterNameNotFoundException {
        String query = "select oh.full_name from cw_org_header oh where oh.org_code = :organizationCode";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("organizationCode", organizationCode);
        try {
            return soplNamedJdbcTemplate.queryForObject(query, namedParameters, String.class);
        } catch (EmptyResultDataAccessException e) {
            throw new DebiterNameNotFoundException("getDebiterName() not found for organization code: ["+ organizationCode +"]", e);
        }
    }

    public Optional<BuyerInfo> getBuyerOrgInfo(String organizationCode) {
        String query = new StringBuilder()
            .append("select oh.org_code, cn_oa.ovr_cmpny_name as COMPANY_NAME, cn_oa.addr1, cn_oa.addr2, cn_oa.phone, cn_oa.email ")
            .append("from cw_org_address cn_oa ")
            .append("inner join cw_org_header oh on oh.org_header_id = cn_oa.org_header_id ")
            .append("where upper((cn_oa.addr_code)::text) = 'LOCAL'::text ")
            .append("and oh.org_code = :organizationCode")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("organizationCode", organizationCode);

        Optional<BuyerInfo> buyerInfo = Optional.empty();
        try {
            buyerInfo = Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, new BeanPropertyRowMapper<BuyerInfo>(BuyerInfo.class)));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getBuyerOrgInfo [{}] {}", organizationCode, e.getMessage());
        }
        return buyerInfo;
    }

    public Optional<String> getBuyerTaxNo(String organizationCode) {
        String query = new StringBuilder()
            .append("select a.cus_code_value from cw_org_cus_code a ")
            .append("inner join cw_org_header b on a.org_header_id = b.org_header_id ")
            .append("where a.cus_code_type = 'VAT' ")
            .append("and b.org_code = :organizationCode")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("organizationCode", organizationCode);

        Optional<String> buyerTaxNo = Optional.empty();
        try {
            buyerTaxNo = Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, String.class));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getBuyerTaxNo [{}] {}", organizationCode, e.getMessage());
        }
        return buyerTaxNo;
    }

    public Optional<BuyerInfo> getBuyerBankInfo(String organizationCode, String currencyCode) {
        String query = new StringBuilder()
            .append("select a.A1_AccountName as BANK_NAME, a.A1_BankAccount as BANK_ACCOUNT from AccAPAccountDetails a ")
            .append("inner join OrgCompanyData b on a.A1_OB = b.OB_PK ")
            .append("inner join OrgHeader c on c.OH_PK = b.OB_OH ")
            .append("where c.OH_Code = :organizationCode")
            .append(" and a.A1_RX_NKAccountCurrency = :currencyCode")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("organizationCode", organizationCode)
            .addValue("currencyCode", currencyCode);

        Optional<BuyerInfo> buyerBankInfo = Optional.empty();
        try {
            buyerBankInfo = Optional.ofNullable(cargowiseNamedJdbcTemplate.queryForObject(query, namedParameters, new BeanPropertyRowMapper<BuyerInfo>(BuyerInfo.class)));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getBuyerBankInfo [{}] [{}] {}", organizationCode, currencyCode, e.getMessage());
        }
        return buyerBankInfo;
    }

    public List<CwAccountTransactionInfo> getCWAccountTransactionInfo(String querySql, String ledger, String transactionType, String transactionNo, String organizationCode) {
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("ledger", ledger)
            .addValue("transactionType", transactionType)
            .addValue("transactionNo", transactionNo)
            .addValue("organizationCode", organizationCode);

        return cargowiseNamedJdbcTemplate.query(querySql, namedParameters, new BeanPropertyRowMapper<CwAccountTransactionInfo>(CwAccountTransactionInfo.class));
    }

    /**
     * Query Cargowise for GL-Account type NONJOB transactions WITHOUT organizationCode filter.
     *
     * This method is specifically for GL-Account type NONJOB transactions where:
     * - JobInvoiceNumber is null/missing in the payload
     * - AccTransactionLines may not exist in Cargowise (AL_PK may be NULL)
     * - No organization association (query returns ALL rows without org filter)
     * - Multiple rows may be returned and should all be processed
     *
     * @param ledger Transaction ledger (e.g., "AR", "AP")
     * @param transactionType Transaction type (e.g., "INV", "CRD")
     * @param transactionNo Transaction number from AccTransactionHeader.AH_TransactionNum
     * @return List of CwAccountTransactionInfo - ALL rows returned (not filtered by org)
     */
    public List<CwAccountTransactionInfo> getCwTransactionInfoForGLAccount(String ledger, String transactionType, String transactionNo) {
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("ledger", ledger)
            .addValue("transactionType", transactionType)
            .addValue("transactionNo", transactionNo);

        log.debug("Querying GL-Account NONJOB transaction [{}][{}][{}] - NO organizationCode filter",
                 ledger, transactionType, transactionNo);

        List<CwAccountTransactionInfo> resultList = cargowiseNamedJdbcTemplate.query(
            QUERY_CW_ACCOUNT_TRANSACTION_INFO_GL_ACCOUNT,
            namedParameters,
            new BeanPropertyRowMapper<CwAccountTransactionInfo>(CwAccountTransactionInfo.class)
        );

        log.info("GL-Account NONJOB query returned {} row(s) for [{}][{}][{}]",
                resultList.size(), ledger, transactionType, transactionNo);

        return resultList;
    }

    public Optional<String> getItemName(UUID companyUUID, String transportMode, UUID accountChargeCodeId) {

        String noteContext = "AAS"; // for SEA
        if (StringUtils.equalsIgnoreCase("AIR", transportMode)) {
            noteContext = "AAI";
        }

        String query = new StringBuilder()
            .append("select sn.ST_NoteText from StmNote sn ")
            .append(" INNER JOIN AccChargeCode acc on acc.AC_PK = sn.ST_ParentID ")
            .append(" WHERE sn.ST_Description = 'VAT Description' ")
            .append(" AND sn.ST_NoteContext = :noteContext ")
            .append(" AND acc.AC_GC = :companyUUID ")
            .append(" AND acc.AC_PK = :accountChargeCodeId")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("noteContext", noteContext)
            .addValue("companyUUID", companyUUID)
            .addValue("accountChargeCodeId", accountChargeCodeId);
        
        Optional<String> itemName = Optional.empty();
        try {
            itemName = Optional.ofNullable(cargowiseNamedJdbcTemplate.queryForObject(query, namedParameters, String.class));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getItemName() companyUUID=[{}], transportMode=[{}], accountChargeCodeId=[{}] {}", companyUUID, transportMode, accountChargeCodeId, e.getMessage());
        }
        return itemName;
    }

    public List<RefNoInfo> getRefNo(String ledger, String transactionType, String transactionNo) {
        String query = new StringBuilder()
            .append("SELECT DISTINCT ")
            .append(" jc2.jr_e6 as JOB_HEADER,")
            .append(" CASE ")
            .append("  WHEN jc2.jr_e6 IS NULL THEN js.JS_UniqueConsignRef ")
            .append("  ELSE jc.JK_UniqueConsignRef ")
            .append(" END AS REF_NO ")
            .append(" FROM AccTransactionHeader ath ")
            .append(" LEFT JOIN AccTransactionLines atl ON atl.AL_AH = ath.AH_PK ")
            .append(" LEFT JOIN JobHeader jh ON jh.JH_PK = atl.AL_JH ")
            .append(" LEFT JOIN JobShipment js ON js.JS_PK = jh.JH_ParentID ")
            .append(" LEFT JOIN JobConShipLink jsl ON jsl.JN_JS = js.JS_PK ")
            .append(" LEFT JOIN JobConsol jc ON jsl.JN_JK = jc.JK_PK ")
            .append(" INNER JOIN AccChargeCode c ON c.ac_pk = atl.al_ac ")
            .append(" LEFT JOIN JobCharge jc2 ON jc2.JR_JH = jh.jh_pk AND jc2.jr_ac = c.ac_pk AND jc2.JR_APInvoiceNum = ath.AH_TransactionNum ")
            .append("WHERE ath.AH_Ledger = :ledger ")
            .append(" AND ath.AH_TransactionType = :transactionType ")
            .append(" AND ath.AH_TransactionNum = :transactionNo ")
                .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("ledger", ledger)
            .addValue("transactionType", transactionType)
            .addValue("transactionNo", transactionNo);

        List<RefNoInfo> refNoList = cargowiseNamedJdbcTemplate.query(query, namedParameters, new BeanPropertyRowMapper<RefNoInfo>(RefNoInfo.class));
        
        // Determine refNoType based on jobHeader (jr_e6) as per enhanced Shipment vs Consol differentiation
        if (refNoList.isEmpty()) {
            // No records found - this is a NONJOB transaction
            RefNoInfo nonjobRefNo = new RefNoInfo();
            nonjobRefNo.setRefNoType("NONJOB");
            refNoList = new ArrayList<>();
            refNoList.add(nonjobRefNo);
            log.info("NONJOB transaction detected (empty result): [{}][{}][{}]", ledger, transactionType, transactionNo);
        } else if (refNoList.get(0).getJobHeader() == null && refNoList.get(0).getRefNo() == null) {
            // Record exists but both jobHeader and refNo are null - this is a NONJOB transaction
            refNoList.get(0).setRefNoType("NONJOB");
            log.info("NONJOB transaction detected (null fields): [{}][{}][{}]", ledger, transactionType, transactionNo);
        } else if (refNoList.get(0).getJobHeader() == null) {
            // jobHeader (jr_e6) is null - this is a SHIPMENT transaction
            refNoList.get(0).setRefNoType("SHIPMENT");
            log.debug("SHIPMENT transaction detected: [{}][{}][{}]", ledger, transactionType, transactionNo);
        } else {
            // jobHeader (jr_e6) is not null - this is a CONSOL transaction
            refNoList.get(0).setRefNoType("CONSOL");
            log.debug("CONSOL transaction detected: [{}][{}][{}]", ledger, transactionType, transactionNo);
        }
        
        return refNoList;
    }

    public Optional<UUID> getCompanyUUID(String companyCode) {
        String query = new StringBuilder()
            .append("select c.global_cmpny_id from cw_global_company c ")
            .append("where c.cmpny_code = :companyCode ")
            .append("limit 1")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("companyCode", companyCode);

        Optional<UUID> companyUUID = Optional.empty();
        try {
            companyUUID = Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, UUID.class));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getCompanyUUID [{}] {}", companyCode, e.getMessage());
        }
        return companyUUID;
    }

    public Optional<String> getLocalCurrencyCode(String branchCode) {
        String query = new StringBuilder()
            .append("select cgc.crncy_code from cw_global_branch cgb ")
            .append("inner join cw_global_company cgc on cgc.global_cmpny_id = cgb.global_cmpny_id ")
            .append("where branch_code = :branchCode")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("branchCode", branchCode);

        Optional<String> localCurrencyCode = Optional.empty();
        try {
            localCurrencyCode = Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, String.class));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getLocalCurrencyCode [{}] {}", branchCode, e.getMessage());
        }
        return localCurrencyCode;
    }

    public Optional<String> getOldBillType(String ledger, String transactionNo) {
        String query = new StringBuilder()
            .append("select aath.trans_type from at_account_transaction_header aath ")
            .append("WHERE aath.ledger = :ledger ")
            .append(" AND aath.trans_no = :transactionNo ")
            .toString();
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("ledger", ledger)
            .addValue("transactionNo", transactionNo);

        Optional<String> oldBillType = Optional.empty();
        try {
            oldBillType = Optional.ofNullable(soplNamedJdbcTemplate.queryForObject(query, namedParameters, String.class));
        } catch (EmptyResultDataAccessException e) {
            log.warn("EmptyResultDataAccessException in getOldBillType [{}][{}] {}", ledger, transactionNo, e.getMessage());
        }
        return oldBillType;
    }
}