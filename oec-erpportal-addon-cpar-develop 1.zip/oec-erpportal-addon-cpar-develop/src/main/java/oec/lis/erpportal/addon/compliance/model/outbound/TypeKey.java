package oec.lis.erpportal.addon.compliance.model.outbound;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TypeKey {
    @JsonProperty("Type")
    private String type;

    @JsonProperty("Key")
    private String key;
}
