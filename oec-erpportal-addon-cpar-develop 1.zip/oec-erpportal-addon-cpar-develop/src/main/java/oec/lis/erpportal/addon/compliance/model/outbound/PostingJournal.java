package oec.lis.erpportal.addon.compliance.model.outbound;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostingJournal {
    @JsonProperty("Branch")
    private CodeName branch;

    @JsonProperty("ChargeCode")
    private ChargeCode chargeCode;

    @JsonProperty("ChargeCurrency")
    private CodeDescription chargeCurrency;

    @JsonProperty("ChargeExchangeRate")
    private BigDecimal chargeExchangeRate;

    @JsonProperty("ChargeTotalAmount")
    private BigDecimal chargeTotalAmount;

    @JsonProperty("ChargeTotalExVatAmount")
    private BigDecimal chargeTotalExVatAmount;

    @JsonProperty("Department")
    private CodeName department;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("GLAccount")
    private GLAccount glAccount;

    @JsonProperty("GLPostDate")
    private String glPostDate;

    @JsonProperty("IsFinalCharge")
    private boolean isFinalCharge;

    @JsonProperty("Job")
    private TypeKey job;

    @JsonProperty("JobRecognitionDate")
    private String jobRecognitionDate;

    @JsonProperty("LocalAmount")
    private BigDecimal localAmount;

    @JsonProperty("LocalCurrency")
    private CodeDescription localCurrency;

    @JsonProperty("LocalGstVatAmount")
    private BigDecimal localGstVatAmount;

    @JsonProperty("localTotalAmount")
    private BigDecimal localTotalAmount;

    @JsonProperty("Organization")
    private TypeKey organization;

    @JsonProperty("OsAmount")
    private BigDecimal osAmount;

    @JsonProperty("OsCurrency")
    private CodeDescription osCurrency;

    @JsonProperty("OsGstVatAmount")
    private BigDecimal osGstVatAmount;

    @JsonProperty("osTotalAmount")
    private BigDecimal osTotalAmount;

    @JsonProperty("RevenueRecognitionType")
    private String revenueRecognitionType;

    @JsonProperty("Sequence")
    private int sequence;

    @JsonProperty("TaxDate")
    private String taxDate;

    @JsonProperty("TransactionCategory")
    private String transactionCategory;

    @JsonProperty("TransactionType")
    private String transactionType;

    @JsonProperty("VattaxID")
    private VATTax vatTaxId;

    @JsonProperty("PostingJournalDetailCollection")
    private PostingJournalDetailCollection postingJournalDetailCollection;
}
