package oec.lis.erpportal.addon.compliance.common.api.exception;

public class AuthenticationFailedException extends Exception {
    public AuthenticationFailedException( String message, Throwable e) {
        super( message, e);
    }
}
