package oec.lis.erpportal.addon.compliance.model.compliance;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties("difference, subLedgerClose")
@Data
public class CheckResponseBean {

    // @JsonProperty("compliance_no")
    private String complianceNo;

    // @JsonProperty("create_cmpny")
    // private String createCompany;

    // @JsonProperty("create_branch")
    private String createBranch;

    // @JsonProperty("inv_no")
    private String invoiceNo;

    @JsonIgnore
    private BigDecimal difference;

    // @JsonProperty("match_status")
    private String matchStatus = "N";

    @JsonIgnore
    private int subLedgerClosed;

    // @JsonProperty("subledger_status")
    private String subledgerStatus = "N";

    public void setDifference( BigDecimal difference ) {
        // a.判斷是否Match : 
        // 若diff < 0，則回傳Match=Y，diff >= 0，則回傳Match=N
        if (difference.compareTo(BigDecimal.ZERO)<0) {
            matchStatus = "Y";
        }
    }

    public void setSubLedgerClosed( int subLedgerClosed ) {
        // b.判斷是否關帳 : 
        // 若SubLedgerClosed = 1，則關帳=Y，SubLedgerClosed=0，則關帳=N
        if (subLedgerClosed==1) {
            subledgerStatus = "Y";
        }
    }
}
