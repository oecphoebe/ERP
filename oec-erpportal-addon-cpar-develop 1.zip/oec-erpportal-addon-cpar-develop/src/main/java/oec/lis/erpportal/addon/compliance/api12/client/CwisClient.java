package oec.lis.erpportal.addon.compliance.api12.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import oec.lis.erpportal.addon.compliance.api12.config.CwisFeignConfig;
import oec.lis.sopl.external.inbound.bo.CWISShipmentInbound;
import oec.lis.sopl.external.inbound.vo.ComlianceCompleteInbound;

@FeignClient(name = "cwisClient", url = "${external.cwis.url}", configuration = CwisFeignConfig.class)
public interface CwisClient  {
    @PostMapping(value = "/inbound/universal")
	// @PostMapping("/cpar-api/compliance/v1/complianceInfo") // for local test endpoint use
	public ResponseEntity<CWISShipmentInbound> sendComplianceData(@RequestBody ComlianceCompleteInbound comlianceCompleteInbound, @RequestParam String serverId);
}
