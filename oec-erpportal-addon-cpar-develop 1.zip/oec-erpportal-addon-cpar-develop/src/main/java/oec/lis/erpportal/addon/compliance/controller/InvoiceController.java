package oec.lis.erpportal.addon.compliance.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api15.client.InvoiceClient;
import oec.lis.erpportal.addon.compliance.common.controller.AbstractController;
import oec.lis.erpportal.addon.compliance.model.api.APILog;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;
import oec.lis.erpportal.addon.compliance.service.ApiLogService;
import oec.lis.sopl.common.util.JsonUtils;

@RestController
@RequestMapping("/compliance")
@Slf4j
public class InvoiceController extends AbstractController {
    private InvoiceClient invoiceClient;
    private ApiLogService apiLogService;

    public InvoiceController(InvoiceClient invoiceClient, ApiLogService apiLogService) {
        this.invoiceClient = invoiceClient;
        this.apiLogService = apiLogService;
    }

    @PostMapping("/v1/InvoiceBill")
    public ResponseEntity<Object> sendInvoice(
        @Valid 
        @RequestBody TransactionChargeLineRequestBean model
    ) throws Exception {
        log.debug("Input model for sending invoice to compliance system:");
        JsonUtils.print(model);

        APILog apiLog = APILog.create("CPAR-API-SendTransactionInfo", "API15");
        apiLog.setApiStatus("SENDING");
        apiLog.setApiParameters(JsonUtils.getJson(model));
        apiLogService.saveLog(apiLog);

        Object response = null;
        // ResponseEntity<CWISShipmentInbound> result = null;
        try {
            response = invoiceClient.sendInvoice(model);
            log.debug("response from compliance system:");
            JsonUtils.print(response);

            String json = new ObjectMapper().writeValueAsString(response);
            Object allDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
    
            Integer statusCode = JsonPath.read(allDocument, "$.statusCode");
            Boolean succeeded = JsonPath.read(allDocument, "$.succeeded");
            log.debug("Response with statusCode=[{}] and succeeded=[{}]", statusCode.toString(), succeeded.toString());
    
            if (statusCode == 200 && succeeded.booleanValue()) {
                apiLog.setApiStatus("DONE");
            } else {
                apiLog.setApiStatus("ERROR");
            }
            apiLog.setCwStatus(statusCode.toString());        

            apiLog.setApiResponse(JsonUtils.getJson(response));
        } catch (Exception e) {
            log.error("Error sending compliance data to compliance system: {}", e.getMessage());
            apiLog.setApiStatus("ERROR");
            String correctlyFormattedJsonString = String.format("{\"Exception\": \"%s\"}", getStringForJson(e.getMessage()));
            apiLog.setApiResponse(correctlyFormattedJsonString);
        }
        apiLogService.saveLog(apiLog);

        return ResponseEntity.ok(response);
    }
}
