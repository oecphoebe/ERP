package oec.lis.erpportal.addon.compliance.common.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DateTimeUtil {
    private DateTimeUtil() {}
    public static Date convertToDate(String iso8601String) {
        try {
            // 1. Parse using the modern java.time API
            // OffsetDateTime handles ISO strings with 'Z' (Zulu/UTC) or offsets like +02:00
            // The default parser for OffsetDateTime understands common ISO 8601 formats.
            OffsetDateTime offsetDateTime = OffsetDateTime.parse(iso8601String);

            // For conversion to legacy types, it's often easiest to go via Instant
            Instant instant = offsetDateTime.toInstant();

            // 2. Convert Instant to java.util.Date
            // Date.from(Instant) is the standard conversion method.
            return Date.from(instant);

        } catch (DateTimeParseException e) {
            log.warn("Error parsing string '{}': {}",iso8601String, e.getMessage());
        } catch (Exception e) {
            log.warn("An unexpected error occurred for string '{}': {}", iso8601String, e.getMessage());
            log.info("StackTrace: ", e);
        }
        return null;
    }

    public static Timestamp convertToTimeStamp(String iso8601String) {
        try {
            // --- Below is old implementation
            // 1. Parse using the modern java.time API
            // OffsetDateTime handles ISO strings with 'Z' (Zulu/UTC) or offsets like +02:00
            // The default parser for OffsetDateTime understands common ISO 8601 formats.
            // OffsetDateTime offsetDateTime = OffsetDateTime.parse(iso8601String);

            // // For conversion to legacy types, it's often easiest to go via Instant
            // Instant instant = offsetDateTime.toInstant();

            // // 3. Convert Instant to java.sql.Timestamp
            // // Timestamp.from(Instant) is the standard conversion method.
            // return Timestamp.from(instant);
            // --- Above is old implementation

            // Parse the ISO 8601 string to an Instant
            Instant instant = Instant.parse(iso8601String);

            // Convert the Instant to a Timestamp
            return Timestamp.from(instant);

        } catch (DateTimeParseException e) {
            log.warn("Error parsing string '{}': {}",iso8601String, e.getMessage());
        } catch (Exception e) {
            log.warn("An unexpected error occurred for string '{}': {}", iso8601String, e.getMessage());
            log.info("StackTrace: ", e); // Print full stack trace for unexpected errors
        }
        return null;
    }
}
