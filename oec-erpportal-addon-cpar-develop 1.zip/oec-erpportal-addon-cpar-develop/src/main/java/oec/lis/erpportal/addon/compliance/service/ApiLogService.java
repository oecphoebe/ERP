package oec.lis.erpportal.addon.compliance.service;

import java.util.List;
import java.util.UUID;

import oec.lis.erpportal.addon.compliance.model.api.APILog;

public interface ApiLogService {

    /**
     * Save single record, including insert or update
     * @param apiLog
     */
    public void saveLog(APILog apiLog);

    /**
     * Fetch APILog by actionId and apiId
     * @param actionId
     * @param apiId
     * @return
     */
    public List<APILog> fetchByUniqueKey( UUID actionId, UUID apiId );
    
    /**
     * Fetch APILog by actionId only
     * @param actionId
     * @return
     */
    public List<APILog> fetchByActionId( UUID actionId );
}
