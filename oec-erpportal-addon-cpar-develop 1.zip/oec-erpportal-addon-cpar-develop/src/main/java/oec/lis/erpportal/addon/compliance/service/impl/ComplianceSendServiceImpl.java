package oec.lis.erpportal.addon.compliance.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.api12.client.CwisClient;
import oec.lis.erpportal.addon.compliance.exception.AtAccountTransactionNotFoundException;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceRequestMetaBean;
import oec.lis.erpportal.addon.compliance.service.ComplianceSendService;
import oec.lis.sopl.common.util.JsonUtils;
import oec.lis.sopl.external.Code;
import oec.lis.sopl.external.CpTypeValue;
import oec.lis.sopl.external.inbound.bo.CWISShipmentInbound;
import oec.lis.sopl.external.inbound.vo.AdditionalFieldsToUpdateCollection;
import oec.lis.sopl.external.inbound.vo.ComlianceCompleteInbound;
import oec.lis.sopl.external.inbound.vo.CpEventVo;
import oec.lis.sopl.external.inbound.vo.DataTarget;
import oec.lis.sopl.external.inbound.vo.DataTargetCollection;
import oec.lis.sopl.external.inbound.vo.InboundDataContext;
import oec.lis.sopl.external.inbound.vo.UniversalEvent;


@Service
@Slf4j
public class ComplianceSendServiceImpl implements ComplianceSendService {

    public static final int LENGTH_OF_AH_TransactionReference = 20; // 20 chars for AH_TransactionReference

    @Value("${external.cwis.serverId}")
    private String serverId;

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    private CwisClient cwisClient;
    public ComplianceSendServiceImpl(
        CwisClient cwisClient, 
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate
    ) {
        this.cwisClient = cwisClient;
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    /**
     * Send compliance data to CWIS system.
     * 
     * @param complianceInfo ComplianceRequestBean object containing compliance information
     * @return ResponseEntity<CWISShipmentInbound> response from CWIS system
     */
    @Override
    public ResponseEntity<CWISShipmentInbound> sendComplianceData( ComlianceCompleteInbound complianceCompleteInbound ) throws Exception {
        log.debug( "sendComplianceData() called.");
    
        return cwisClient.sendComplianceData(complianceCompleteInbound, serverId);
    }

    /**
     * Find out compliance-invoice data for sending to CWIS API-12.
     * All new situation : compliance-A -> invoice-X => send one record to CWIS API-12
     * invoice changed compliance no situation: compliance-B -> invoice-X => send one record to CWIS API-12
     * add new invoice to the same compliance situation: compliance-A -> invoice-Y => send two records to CWIS API-12
     * 
     * @param complianceInfoList List<ComplianceRequestBean> complianceInfoList List of ComplianceRequestBean objects containing compliance information
     * @return List of ComlianceCompleteInbound objects
     * @throws AtAccountTransactionNotFoundException if account transaction header is not found
     */
    @Override
    public List<ComlianceCompleteInbound> generateComplianceData(List<UUID> accountTransactionHeaderIdList) { // throws AtAccountTransactionNotFoundException
        log.debug("generateComplianceData() accountTransactionHeaderIdList.size() = {}", accountTransactionHeaderIdList.size());
        JsonUtils.print(accountTransactionHeaderIdList);
        // 從 complianceInfoList 取得資料，並產生 ComlianceCompleteInbound
        // 1. 找出這張 complianceNo 對應的所有 invoice(s)
        //   1.1. 如果找不到，直接新增一筆 generateSingleComplianceData(ComplianceRequestBean complianceInfo)
        //   1.2. 不會找不到。前面的 saveComplianceAndLink() 會將 complianceNo 與 invoiceNo 的關聯資料存到 cp_compliance_acct
        // 2. 將這次的 invoiceNo 加入前述 invoice清單中(去除重複)
        // 3. 以 invoiceNo 為主體，找出各自對應的最小 complianceNo (Define 最小 = createTime 最早的 cp_compliance 資料)

      //   SELECT 
      //   sac.acct_trans_header_id, 
      //   sac.create_time, 
      //   sac.compliance_id,
      //   lath.ledger,
      //   lath.trans_type as transaction_type,
      //   lath.trans_no as account_transaction_no,
      //   lc.compliance_no,
      //   lc.compliance_code,
      //   lc.create_cmpny AS create_company,
      //   sac.distinct_compliance_records_count
      // FROM (
      //   SELECT 
      //     dac.acct_trans_header_id, 
      //     dac.compliance_id,
      //     dac.create_time,
      //     COUNT(*) OVER (PARTITION BY dac.acct_trans_header_id) as distinct_compliance_records_count
      //   FROM (
      //     SELECT distinct aath.acct_trans_header_id, cc.compliance_id, cc.create_time
      //     FROM at_account_transaction_header aath 
      //     LEFT JOIN cp_compliance_acct_trans_header_line_link link on link.acct_trans_header_id = aath.acct_trans_header_id
      //     LEFT JOIN cp_compliance cc on cc.compliance_id = link.compliance_id
      //     ) dac
      //   ) sac
      // INNER JOIN at_account_transaction_header lath on lath.acct_trans_header_id = sac.acct_trans_header_id
      // INNER JOIN cp_compliance lc on lc.compliance_id = sac.compliance_id
      // WHERE sac.acct_trans_header_id in (:accountTransactionHeaderIdList) and sac.create_time = (
      //   SELECT MIN(cp.create_time)
      //   FROM at_account_transaction_header ath
      //   LEFT JOIN cp_compliance_acct_trans_header_line_link link2 ON ath.acct_trans_header_id = link2.acct_trans_header_id
      //   LEFT JOIN cp_compliance cp ON link2.compliance_id = cp.compliance_id
      //   WHERE ath.acct_trans_header_id = sac.acct_trans_header_id
      // )

        // 以下 SQL 取得的清單會有 (acct_trans_header_id, compliance_id) 的重複資料，但是會依照 cp_compliance.create_time 排序; 依照 BRD 需求，送出最早的一筆 compliance_no 資料
        String query = """
SELECT 
  dac.acct_trans_header_id, 
  ath.ledger,
  ath.trans_type as transaction_type,
  ath.trans_no as account_transaction_no,
  dac.compliance_id,
  cc2.compliance_no,
  cc2.compliance_code,
  ath.cmpny_code AS create_company,
  cc2.create_time,
  COUNT(*) OVER (PARTITION BY dac.acct_trans_header_id) as distinct_compliance_records_count
 FROM (
  SELECT distinct aath.acct_trans_header_id, cc.compliance_id
  FROM at_account_transaction_header aath 
  LEFT JOIN cp_compliance_acct_trans_header_line_link link on link.acct_trans_header_id = aath.acct_trans_header_id
  LEFT JOIN cp_compliance cc on cc.compliance_id = link.compliance_id
) dac
 INNER JOIN at_account_transaction_header ath on ath.acct_trans_header_id = dac.acct_trans_header_id
 LEFT JOIN cp_compliance cc2 on cc2.compliance_id = dac.compliance_id
 WHERE dac.acct_trans_header_id in (:accountTransactionHeaderIdList)
ORDER BY dac.acct_trans_header_id, cc2.create_time, cc2.compliance_id
        """;

        List<ComplianceRequestMetaBean> requestList = soplNamedJdbcTemplate.query(
            query, 
            Map.of("accountTransactionHeaderIdList", accountTransactionHeaderIdList), 
            new BeanPropertyRowMapper<ComplianceRequestMetaBean>(ComplianceRequestMetaBean.class)
        );
        log.debug("requestList.size() = {}", requestList.size());

        // 安全作法
        // 1. 由 accountTransactionHeaderIdList 取得 link 中的不重複 (acct_transaction_header_id, compliance_id with null)
        // 2. 取得 這些 acct_transaction_header_id 在 link 內的不重複 lines 的 count(*) = 同一張 invoice 有多少張 compliance_id
        // 3. 取得最早 compliance 資料 (依照 cp_compliance.create_time 判斷)
        // 4. 設定 invoice_no, header.ledger, header.transaction_type, compliance_no, compliance_type, cp.create_company

        UUID previousAccountTransactionId = UUID.randomUUID();
        List<ComlianceCompleteInbound> resultList = new ArrayList<>();
        for (ComplianceRequestMetaBean bean : requestList) {
            if (previousAccountTransactionId.equals(bean.getAcctTransHeaderId())) {
              continue;
            }
            ComlianceCompleteInbound result = generateSingleComplianceData(bean);
            resultList.add(result);
            previousAccountTransactionId = bean.getAcctTransHeaderId();
        }
        return resultList;
    }

    /**
     * Generate single request data for CWIS API-12.
     * Actually use following fields within ComplianceRequestBean to fill in ComlianceCompleteInbound:
     * 1. ComplianceNo -> fill in AccTransactionHeader.AH_TransactionReference
     * 2. ComplianceCode -> fill in AccTransactionHeader.AH_ComplianceSubType
     * 3. CreateCompany -> fill in company
     * 4. AccountTransactionNo -> fill in key, and help to get ledger, transaction_type from at_account_transaction_header
     * @param complianceInfo
     * @return
     * @throws AtAccountTransactionNotFoundException
     */
    private ComlianceCompleteInbound generateSingleComplianceData(ComplianceRequestMetaBean complianceInfo) { // throws AtAccountTransactionNotFoundException
        // --- Event.AdditionalFieldsToUpdate --- for single record
        List<CpTypeValue> additionalFieldsList = new ArrayList<>();
        CpTypeValue additionalField1 = new CpTypeValue();
        additionalField1.setType("AccTransactionHeader.AH_TransactionReference");
        String complianceNo = complianceInfo.getComplianceNo();
        if (complianceInfo.getComplianceId() == null) {
            complianceNo = " ";
        } else if (complianceInfo.getDistinctComplianceRecordsCount()>1) {
            if (complianceNo.length()+1 > LENGTH_OF_AH_TransactionReference) {
                complianceNo = "*" + complianceNo.substring(2); // 20250429 決議: 去掉前兩碼 YY 部分
            } else {
                complianceNo = "*" + complianceNo;
            }
        }
        if (complianceNo.length() > LENGTH_OF_AH_TransactionReference) {
            complianceNo = complianceNo.substring(0, LENGTH_OF_AH_TransactionReference);
        }
        additionalField1.setValue(complianceNo);
        additionalFieldsList.add(additionalField1);
        CpTypeValue additionalField2 = new CpTypeValue();
        additionalField2.setType("AccTransactionHeader.AH_ComplianceSubType");
        String complianceCode = complianceInfo.getComplianceCode();
        if (complianceInfo.getComplianceId() == null) {
            complianceCode = " ";
        }
        additionalField2.setValue(complianceCode);
        additionalFieldsList.add(additionalField2);
    
        AdditionalFieldsToUpdateCollection additionalFieldsToUpdateCollection = new AdditionalFieldsToUpdateCollection();
        additionalFieldsToUpdateCollection.setAdditionalFieldsToUpdateList(additionalFieldsList);
        
        // --- Event.DataContext ---
        List<DataTarget> dataTargetList = new ArrayList<>();
        DataTarget dataTarget = new DataTarget();
        dataTarget.setType("AccountingInvoice");
        // Key = ledger + trans_type + transaction_no
        // 用 complianceInfo.getAccountTransactionNo() 從 at_account_transaction_header 取得 ledger & trans_type
        // Optional<AtAccountTransactionHeaderBean> headerBeanOptional = accountTransactionTableService.getAtAccountTransactionHeaderByTransactionNo(complianceInfo.getAccountTransactionNo());
        // if (headerBeanOptional.isEmpty()) {
        //     // No match record found, throw an exception
        //     throw new AtAccountTransactionNotFoundException("Error: cannot found account transaction header info by transaction no = ["+complianceInfo.getAccountTransactionNo()+"]");
        // }
        // AtAccountTransactionHeaderBean headerBean = headerBeanOptional.get();
        // dataTarget.setKey(String.format("%s %s %s", headerBean.getLedger(), headerBean.getTransactionType(), complianceInfo.getAccountTransactionNo() ));
        dataTarget.setKey(String.format("%s %s %s", complianceInfo.getLedger(), complianceInfo.getTransactionType(), complianceInfo.getAccountTransactionNo() ));
        dataTargetList.add(dataTarget);
    
        DataTargetCollection dataTargetCollection = new DataTargetCollection();
        dataTargetCollection.setDataTargetList(dataTargetList);

        Code company = new Code();
        company.setCode( complianceInfo.getCreateCompany() );

        InboundDataContext dataContext = new InboundDataContext();
        dataContext.setDataTargetCollection(dataTargetCollection);
        dataContext.setCompany( company );
        dataContext.setEnterpriseId("OEC");
        dataContext.setServerID(serverId);

        // --- Event ---
        CpEventVo event = new CpEventVo();
        event.setAdditionalFieldsToUpdateCollection(additionalFieldsToUpdateCollection);
        event.setDataContext(dataContext);
        event.setEventTime(Instant.now().toString()); // Use current time in ISO 8601 format
        event.setEventType("DIM");
        event.setIsEstimate("false");

        // UniversalEvent
        UniversalEvent universalEvent = new UniversalEvent();
        universalEvent.setEventVo( event );

        ComlianceCompleteInbound comlianceCompleteInbound = new ComlianceCompleteInbound();
        comlianceCompleteInbound.setUniversalEvent(universalEvent);

        return comlianceCompleteInbound;
    }
}
