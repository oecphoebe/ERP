package oec.lis.erpportal.addon.compliance.schedule;

import java.io.File;
import java.nio.charset.StandardCharsets;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    private static final String DEFAULT_MAIL_ENCODE = StandardCharsets.UTF_8.name();
    private final JavaMailSender mailSender;
    
    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }
    
    public void sendReportEmail(String recipients, String fromEmail, String subject, String text, File attachment) {
        MimeMessage message = mailSender.createMimeMessage();
        
        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true, DEFAULT_MAIL_ENCODE);
            helper.setFrom(fromEmail);
            helper.setTo(recipients.split(","));
            helper.setSubject(subject);
            helper.setText(text);
            helper.addAttachment("comparison-report.xlsx", attachment);
            
            mailSender.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException("Failed to send email", e);
        }
    }
}