package oec.lis.erpportal.addon.compliance.common.api.model;

public interface AuthRequestModel {
    String getUserId();
    String getPassword();
}