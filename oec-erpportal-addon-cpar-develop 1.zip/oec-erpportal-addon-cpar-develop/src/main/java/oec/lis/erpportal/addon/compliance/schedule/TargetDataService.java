package oec.lis.erpportal.addon.compliance.schedule;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TargetDataService {

    @Value("${job.email.retrieve_days:1}")
    private int days;

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    public TargetDataService(
        @Qualifier("soplNamedJdbcTemplate") NamedParameterJdbcTemplate soplNamedJdbcTemplate) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    final Map<String,Class<?>> desiredColumns = Map.of(
        "id", UUID.class,
        "transaction_type", String.class,
        "transaction_no", String.class,
        "update_time", java.sql.Timestamp.class
    );

    public List<DataRecord> fetchData() {
        String query = new StringBuilder()
            .append("select acct_trans_header_id as id, trans_type as transaction_type, trans_no as transaction_no, update_time at time zone 'UTC' at time zone 'Asia/Taipei' as update_time ")
            .append("from at_account_transaction_header aath ")
            .append("where aath.ledger = 'AR' and aath.update_time > date_trunc('day', CURRENT_DATE - INTERVAL '").append(days).append(" day') ")
            .toString();
        // return soplNamedJdbcTemplate.query(query, new BeanPropertyRowMapper<DataRecord>(DataRecord.class));
        return soplNamedJdbcTemplate.query(query, 
            rs -> {
                // log.debug("Target ResultSet handling()");
                List<DataRecord> results = new ArrayList<>();
                String id = null;
                // int loopCounter = 0;
                Set<String> columnsToExtract = desiredColumns.keySet();
                while (rs.next()) {
                    // log.debug("Target ResultSet loop [{}]", loopCounter++);
                    id = null;
                    Map<String, Object> rowData = new HashMap<>();
                    for (String columnName : columnsToExtract) {
                        try {
                            Object value = rs.getObject(columnName);
                            rowData.put(columnName, value);
                            if (StringUtils.equals(columnName, "transaction_no")) {
                                id = rs.getObject(columnName, String.class);
                            }
                        } catch (SQLException e) {
                            log.error("Warning: Column '{}}' not found or error reading it: {}", columnName, e.getMessage());
                            // Optionally put null: rowData.put(columnName, null);
                            rowData.put(columnName, null);
                        }
                    }
                    if (!rowData.isEmpty()) {
                        results.add(new DataRecord(id, rowData));
                    }
                }
                return results;
            }
        );
    }
}
