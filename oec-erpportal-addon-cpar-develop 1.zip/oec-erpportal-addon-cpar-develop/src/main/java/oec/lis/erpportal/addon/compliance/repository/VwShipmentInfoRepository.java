package oec.lis.erpportal.addon.compliance.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.dao.EmptyResultDataAccessException;

import oec.lis.erpportal.addon.compliance.model.transaction.VwShipmentInfoBean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JDBC repository for accessing vw_shipment_info view.
 * This repository provides both single and multiple record retrieval methods
 * for shipment and consolidation number lookups.
 *
 * <p>Key Features:
 * - Single record retrieval with Optional return types
 * - Multiple record retrieval for data duplication scenarios
 * - Custom query methods with proper parameter binding
 * - Support for both exact match and case-insensitive searches
 * - Performance optimized queries for large datasets
 *
 * <p>Note: This repository operates on a database view, ensuring read-only access
 * and optimal query performance for shipment information lookups.
 */
@Slf4j
@Repository
@RequiredArgsConstructor
public class VwShipmentInfoRepository {

    @Qualifier("soplNamedJdbcTemplate")
    private final NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    /**
     * Find a single shipment record by consolidation number.
     * Returns the first matching record if multiple exist.
     *
     * @param consolNo the consolidation number to search for (exact match)
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    public Optional<VwShipmentInfoBean> findByConsolNo(String consolNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE cnsl_no = :consolNo
            LIMIT 1
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("consolNo", consolNo);

        try {
            VwShipmentInfoBean result = soplNamedJdbcTemplate.queryForObject(
                sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
            log.debug("Found shipment record by consolNo: {}", consolNo);
            return Optional.of(result);
        } catch (EmptyResultDataAccessException e) {
            log.debug("No shipment found for consolNo: {}", consolNo);
            return Optional.empty();
        }
    }

    /**
     * Find a single shipment record by shipment number.
     * Returns the first matching record if multiple exist.
     *
     * @param shipmentNo the shipment number to search for (exact match)
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    public Optional<VwShipmentInfoBean> findByShipmentNo(String shipmentNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE shipment_no = :shipmentNo
            LIMIT 1
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("shipmentNo", shipmentNo);

        try {
            VwShipmentInfoBean result = soplNamedJdbcTemplate.queryForObject(
                sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
            log.debug("Found shipment record by shipmentNo: {}", shipmentNo);
            return Optional.of(result);
        } catch (EmptyResultDataAccessException e) {
            log.debug("No shipment found for shipmentNo: {}", shipmentNo);
            return Optional.empty();
        }
    }

    /**
     * Find all shipment records matching the given consolidation number.
     * Returns all matching records in case of data duplication.
     *
     * @param consolNo the consolidation number to search for (exact match)
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    public List<VwShipmentInfoBean> findAllByConsolNo(String consolNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE cnsl_no = :consolNo
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("consolNo", consolNo);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for consolNo: {}", results.size(), consolNo);
        return results;
    }

    /**
     * Find all shipment records matching the given shipment number.
     * Returns all matching records in case of data duplication.
     *
     * @param shipmentNo the shipment number to search for (exact match)
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    public List<VwShipmentInfoBean> findAllByShipmentNo(String shipmentNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE shipment_no = :shipmentNo
            ORDER BY cnsl_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("shipmentNo", shipmentNo);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for shipmentNo: {}", results.size(), shipmentNo);
        return results;
    }

    /**
     * Find shipment records by HBL (House Bill of Lading) number.
     * Useful for alternative shipment lookup strategies.
     *
     * @param hblNo the HBL number to search for (exact match)
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    public List<VwShipmentInfoBean> findAllByHblNo(String hblNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE hbl_no = :hblNo
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("hblNo", hblNo);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for hblNo: {}", results.size(), hblNo);
        return results;
    }

    /**
     * Find shipment records by MBL (Master Bill of Lading) number.
     * Useful for alternative shipment lookup strategies.
     *
     * @param mblNo the MBL number to search for (exact match)
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    public List<VwShipmentInfoBean> findAllByMblNo(String mblNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE mbl_no = :mblNo
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("mblNo", mblNo);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for mblNo: {}", results.size(), mblNo);
        return results;
    }

    /**
     * Find shipment records by carrier booking number.
     * Useful for carrier-specific lookup strategies.
     *
     * @param carrierBookNo the carrier booking number to search for (exact match)
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    public List<VwShipmentInfoBean> findAllByCarrierBookNo(String carrierBookNo) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE carrier_book_no = :carrierBookNo
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("carrierBookNo", carrierBookNo);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for carrierBookNo: {}", results.size(), carrierBookNo);
        return results;
    }

    /**
     * Count total records in the view.
     * Useful for health checks and monitoring.
     *
     * @return total number of records in vw_shipment_info view
     */
    public long count() {
        String sql = "SELECT COUNT(*) FROM vw_shipment_info";

        try {
            Long count = soplNamedJdbcTemplate.queryForObject(sql, new MapSqlParameterSource(), Long.class);
            return count != null ? count : 0L;
        } catch (Exception e) {
            log.warn("Error counting records in vw_shipment_info: {}", e.getMessage());
            return 0L;
        }
    }

    /**
     * Check if any records exist for the given consolidation number.
     * Optimized query for existence checks without data retrieval.
     *
     * @param consolNo the consolidation number to check
     * @return true if at least one record exists, false otherwise
     */
    public boolean existsByConsolNo(String consolNo) {
        String sql = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM vw_shipment_info WHERE cnsl_no = :consolNo";

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("consolNo", consolNo);

        try {
            Boolean exists = soplNamedJdbcTemplate.queryForObject(sql, params, Boolean.class);
            return Boolean.TRUE.equals(exists);
        } catch (Exception e) {
            log.warn("Error checking existence for consolNo {}: {}", consolNo, e.getMessage());
            return false;
        }
    }

    /**
     * Check if any records exist for the given shipment number.
     * Optimized query for existence checks without data retrieval.
     *
     * @param shipmentNo the shipment number to check
     * @return true if at least one record exists, false otherwise
     */
    public boolean existsByShipmentNo(String shipmentNo) {
        String sql = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END FROM vw_shipment_info WHERE shipment_no = :shipmentNo";

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("shipmentNo", shipmentNo);

        try {
            Boolean exists = soplNamedJdbcTemplate.queryForObject(sql, params, Boolean.class);
            return Boolean.TRUE.equals(exists);
        } catch (Exception e) {
            log.warn("Error checking existence for shipmentNo {}: {}", shipmentNo, e.getMessage());
            return false;
        }
    }

    /**
     * Find shipment records by shipment type and consolidation type.
     * Useful for filtered searches based on transport and consolidation modes.
     *
     * @param shipmentType the shipment type (e.g., 'SEA', 'AIR')
     * @param consolType the consolidation type (e.g., 'LCL', 'FCL')
     * @return List of VwShipmentInfoBean records matching the criteria
     */
    public List<VwShipmentInfoBean> findByShipmentTypeAndConsolType(String shipmentType, String consolType) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE shipment_type = :shipmentType AND cnsl_type = :consolType
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("shipmentType", shipmentType)
            .addValue("consolType", consolType);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for shipmentType: {} and consolType: {}",
                 results.size(), shipmentType, consolType);
        return results;
    }

    /**
     * Find shipment records by vessel and voyage information.
     * Useful for vessel-specific lookup strategies.
     *
     * @param vessel the vessel name for first leg
     * @param voyage the voyage number for first leg
     * @return List of VwShipmentInfoBean records matching the criteria
     */
    public List<VwShipmentInfoBean> findByVesselAndVoyage(String vessel, String voyage) {
        String sql = """
            SELECT shipment_no AS shipmentNo,
                   cnsl_no AS consolNo,
                   hbl_no AS hblNo,
                   mbl_no AS mblNo,
                   master_mbl AS masterMbl,
                   carrier_book_no AS carrierBookNo,
                   shipment_type AS shipmentType,
                   cnsl_type AS consolType,
                   cnsl_first_leg_vssl AS consolFirstLegVessel,
                   cnsl_first_leg_voy AS consolFirstLegVoyage
            FROM vw_shipment_info
            WHERE cnsl_first_leg_vssl = :vessel AND cnsl_first_leg_voy = :voyage
            ORDER BY shipment_no
            """;

        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("vessel", vessel)
            .addValue("voyage", voyage);

        List<VwShipmentInfoBean> results = soplNamedJdbcTemplate.query(
            sql, params, new BeanPropertyRowMapper<>(VwShipmentInfoBean.class));
        log.debug("Found {} shipment records for vessel: {} and voyage: {}",
                 results.size(), vessel, voyage);
        return results;
    }
}