package oec.lis.erpportal.addon.compliance.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionHeaderBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtAccountTransactionLinesBean;
import oec.lis.erpportal.addon.compliance.model.transaction.AtShipmentInfoBean;
import oec.lis.erpportal.addon.compliance.model.transaction.TransactionChargeLineRequestBean;

public interface AtAccountTransactionTableService {
    public List<TransactionChargeLineRequestBean> saveSoplAccountTransactionTables( AtAccountTransactionHeaderBean headerBean, List<AtAccountTransactionLinesBean> linesBeanList, List<TransactionChargeLineRequestBean> requestBeanList, boolean forceUpdate );
    public Optional<Integer> countAtAccountTransactionHeaderByTranNo( String transactionNo );
    // public Optional<AtAccountTransactionHeaderBean> getAtAccountTransactionHeaderByTransactionNo( String transactionNo );
    public List<UUID> fetchAtAccountTransactionHeaderIdByTransactionNo( List<String> transactionNoList );
    public int updateAccountTransactionHeader( AtAccountTransactionHeaderBean headerBean );
    public int updateAccountTransactionHeaderWithOutstandingAmount(AtAccountTransactionHeaderBean headerBean);
    
    public List<AtAccountTransactionHeaderBean> findHeadersByTransactionNo(String transactionNo);
    public List<AtAccountTransactionLinesBean> findLinesByHeaderPk(Long headerPk);
    public AtShipmentInfoBean findShipmentByJobNumber(String jobNumber);
}
