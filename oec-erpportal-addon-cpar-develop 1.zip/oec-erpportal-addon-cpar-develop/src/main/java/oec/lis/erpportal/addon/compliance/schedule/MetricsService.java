package oec.lis.erpportal.addon.compliance.schedule;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import io.micrometer.core.instrument.MeterRegistry;

@Service
public class MetricsService {
    
    private final MeterRegistry meterRegistry;
    
    public MetricsService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }
    
    public void recordJobStart(String jobName) {
        meterRegistry.counter(jobName + ".start").increment();
        meterRegistry.gauge(jobName + ".last_start_time", System.currentTimeMillis() / 1000.0);
    }
    
    public void recordJobEnd(String jobName, long durationMs) {
        meterRegistry.counter(jobName + ".complete").increment();
        meterRegistry.gauge(jobName + ".last_end_time", System.currentTimeMillis() / 1000.0);
        meterRegistry.timer(jobName + ".duration").record(durationMs, TimeUnit.MILLISECONDS);
    }
    
    public void recordJobError(String jobName, String errorMessage) {
        meterRegistry.counter(jobName + ".error").increment();
        // You might need additional instrumentation for error details
    }
}