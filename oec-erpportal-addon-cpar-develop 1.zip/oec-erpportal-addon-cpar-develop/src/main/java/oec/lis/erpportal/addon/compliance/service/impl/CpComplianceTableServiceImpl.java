package oec.lis.erpportal.addon.compliance.service.impl;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPRequestBean;
import oec.lis.erpportal.addon.compliance.model.compliance.ComplianceAPResponseBean;
import oec.lis.erpportal.addon.compliance.service.CpComplianceTableService;
import oec.lis.sopl.common.model.RestListResponse;
import oec.lis.sopl.common.model.RestRequest;

@Service
@Slf4j
public class CpComplianceTableServiceImpl implements CpComplianceTableService {

    private NamedParameterJdbcTemplate soplNamedJdbcTemplate;

    public static final String SQL_FETCH_ACCOUNT_TRANSACTION_HEADER_ID_BY_COMPLIANCE_ID = 
        "SELECT acct_trans_header_id FROM cp_compliance_acct_trans_header_line_link WHERE compliance_id in (:complianceId)";

    public static final String SQL_UPDATE_COMPLIANCE_SYNC_STATUS_AND_TIME_BY_COMPLIANCE_ID =
        "UPDATE cp_compliance SET external_sync_status = 'Y', external_sync_time = current_timestamp WHERE compliance_id in (:complianceIdList)";

    public CpComplianceTableServiceImpl(NamedParameterJdbcTemplate soplNamedJdbcTemplate) {
        this.soplNamedJdbcTemplate = soplNamedJdbcTemplate;
    }

    @Override
    public List<UUID> getAccountTransactionHeaderIdByComplianceId(List<UUID> complianceId) {
        log.debug("getAccountTransactionHeaderIdByComplianceId() complianceId.size() = [{}]", complianceId.isEmpty() ? 0 : complianceId.size());
        if (complianceId.isEmpty()) { return Collections.emptyList(); }

        return soplNamedJdbcTemplate.query(
            SQL_FETCH_ACCOUNT_TRANSACTION_HEADER_ID_BY_COMPLIANCE_ID, 
            Map.of("complianceId", complianceId), 
            (rs, rowNum) -> {
                return rs.getObject("acct_trans_header_id", UUID.class);
            }
        );
    }

    @Override
    public RestListResponse<ComplianceAPResponseBean> queryComplianceAPInfo( RestRequest<ComplianceAPRequestBean> model, String companyCode ) {
        log.debug("queryComplianceAPInfo() companyCode=[{}]", companyCode);

        StringBuilder query = new StringBuilder()
            .append("SELECT distinct c.compliance_id, c.compliance_no, c.compliance_code")
            .append(", TO_CHAR(c.compliance_date,'YYYY-MM-DD') as COMPLIANCE_DATE")
            .append(", TO_CHAR(c.compliance_date + INTERVAL '30 days','YYYY-MM-DD') as COMPLIANCE_DATE_PLUS")
            .append(", c.buyer_branch as SETTLE_BRANCH")
            .append(", cn_oa2.ovr_cmpny_name as SETTLE_COMPANY_NAME")
            .append(", c.vendor_org_code as SUPPLIER_COMPANY_ORG_CODE")
            .append(", cn_oa.ovr_cmpny_name as SUPPLIER_COMPANY_NAME") // VENDOR_CN_COMPANY_NAME
            .append(", c.crncy_code as CURRENCY_CODE")
            .append(", c.compliance_amt")
            .append(", c.compliance_local_amt as LOCAL_AMOUNT_FOR")
            .append(", c.compliance_tax_amt as TAX_AMOUNT_FOR")
            .append(", c.compliance_extax_amt as NO_TAX_AMOUNT_FOR")
            .append(", c.compliance_exrate as EXCHANGE_RATE")
            // .append(", c.compliance_rmk, c.compliance_inv_note")
            // .append(", c.create_cmpny, c.create_branch, c.create_dept, c.create_by, c.create_time, c.update_cmpny, c.update_branch, c.update_dept, c.update_by, c.update_time")
            // .append(", c.src_sys, c.compliance_status_code, c.external_sync_status, c.external_sync_time")
            // .append(", c.edit_status_code ")
            .append(" FROM cp_compliance c ")
            .append(" INNER JOIN cp_compliance_acct_trans_header_link link on link.compliance_id = c.compliance_id ")
            .append(" INNER JOIN at_account_transaction_header aath on aath.acct_trans_header_id = link.acct_trans_header_id and aath.ledger = 'AP' ")
            .append("  LEFT JOIN cw_org_header oh on oh.org_code = c.vendor_org_code ") // for oh.full_name = vendor information
            .append("  LEFT JOIN cw_org_address cn_oa ON cn_oa.org_header_id = oh.org_header_id AND upper((cn_oa.addr_code)::text) = 'LOCAL'::text ")
            .append(" INNER JOIN cw_global_branch gb on gb.branch_code = c.buyer_branch ") // for buyer information
            .append("  LEFT JOIN cw_org_header oh2 on oh2.org_header_id = gb.proxy_org_header_id ") // for oh2.full_name
            .append("  LEFT JOIN cw_org_address cn_oa2 ON cn_oa2.org_header_id = oh2.org_header_id AND upper((cn_oa2.addr_code)::text) = 'LOCAL'::text ")

            .append("WHERE c.create_cmpny = :createCompany ")
            // .append(" and c.compliance_date >= date_trunc('day', CURRENT_DATE - INTERVAL '60 days')")
            ;

        MapSqlParameterSource namedParameters = new MapSqlParameterSource().addValue("createCompany", companyCode);
        ComplianceAPRequestBean requestBean = model.getBody();
        if (requestBean.getComplianceDateFrom()!=null && !requestBean.getComplianceDateFrom().isBlank()) {
            query.append(" and c.compliance_date >= TO_DATE(:complianceDateFrom,'YYYY-MM-DD') ");
            namedParameters.addValue("complianceDateFrom", requestBean.getComplianceDateFrom());
        }
        if (requestBean.getComplianceDateTo()!=null && !requestBean.getComplianceDateTo().isBlank()) {
            query.append(" and c.compliance_date < (TO_DATE(:complianceDateTo,'YYYY-MM-DD')+1) ");
            namedParameters.addValue("complianceDateTo", requestBean.getComplianceDateTo());
        }
        if (requestBean.getSettleBranch()!=null && !requestBean.getSettleBranch().isBlank()) {
            query.append(" and c.buyer_branch = :settleBranch ");
            namedParameters.addValue("settleBranch", requestBean.getSettleBranch());
        }
        if (requestBean.getComplianceNo()!=null && !requestBean.getComplianceNo().isBlank()) {
            query.append(" and c.compliance_no = :complianceNo ");
            namedParameters.addValue("complianceNo", requestBean.getComplianceNo());
        }
        if (requestBean.getSupplierCompanyName()!=null && !requestBean.getSupplierCompanyName().isBlank()) {
            query.append(" and cn_oa.ovr_cmpny_name like :supplierCompanyName ");
            namedParameters.addValue("supplierCompanyName", "%" + requestBean.getSupplierCompanyName() + "%");
        }
        if (requestBean.getCurrencyCode()!=null && !requestBean.getCurrencyCode().isBlank()) {
            query.append(" and c.crncy_code = :currencyCode ");
            namedParameters.addValue("currencyCode", requestBean.getCurrencyCode());
        }

        List<ComplianceAPResponseBean> requestList = soplNamedJdbcTemplate.query(
            query.toString(), 
            namedParameters,
            new BeanPropertyRowMapper<ComplianceAPResponseBean>(ComplianceAPResponseBean.class)
        );

        RestListResponse<ComplianceAPResponseBean> result = new RestListResponse<>();
        result.setBody(requestList);

        return result;
    }

    @Override
    public int batchUpdateComplianceSyncStatus(List<UUID> complianceIdList) {
        if (complianceIdList.isEmpty()) { return 0; }
        log.debug("batchUpdateComplianceSyncStatus() complianceIdList.size() = [{}]", complianceIdList.size());

        return soplNamedJdbcTemplate.update(
            SQL_UPDATE_COMPLIANCE_SYNC_STATUS_AND_TIME_BY_COMPLIANCE_ID, 
            Map.of("complianceIdList", complianceIdList)
        );
    }
    
}
