package oec.lis.erpportal.addon.compliance.service;

import java.util.List;
import java.util.Optional;

import oec.lis.erpportal.addon.compliance.model.transaction.VwShipmentInfoBean;

/**
 * Service interface for accessing shipment information from the vw_shipment_info view.
 * This service implements the new view-based approach for shipment data access,
 * providing prefix-based routing and fallback mechanisms.
 */
public interface ShipmentViewService {

    /**
     * Find shipment information by reference number using prefix-based routing.
     *
     * @param refNo the reference number used for lookup
     *              - 'C' prefix: Query vw_shipment_info.cnsl_no = refNo
     *              - 'S' prefix: Query vw_shipment_info.shipment_no = refNo
     *              - Other prefix: Log warning and return empty
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    Optional<VwShipmentInfoBean> findShipmentByRefNo(String refNo);

    /**
     * Find shipment information by consolidation number.
     * Direct query against vw_shipment_info.cnsl_no field.
     *
     * @param consolNo the consolidation number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    Optional<VwShipmentInfoBean> findShipmentByConsolNo(String consolNo);

    /**
     * Find shipment information by shipment number.
     * Direct query against vw_shipment_info.shipment_no field.
     *
     * @param shipmentNo the shipment number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    Optional<VwShipmentInfoBean> findShipmentByShipmentNo(String shipmentNo);

    /**
     * Find all shipment information records matching the given consolidation number.
     * This method returns multiple records in case of data duplication scenarios.
     *
     * @param consolNo the consolidation number to search for
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    List<VwShipmentInfoBean> findAllShipmentsByConsolNo(String consolNo);

    /**
     * Find all shipment information records matching the given shipment number.
     * This method returns multiple records in case of data duplication scenarios.
     *
     * @param shipmentNo the shipment number to search for
     * @return List of VwShipmentInfoBean records, empty list if none found
     */
    List<VwShipmentInfoBean> findAllShipmentsByShipmentNo(String shipmentNo);

    /**
     * Find shipment information by job number using intelligent routing.
     * Job numbers can correspond to either shipment numbers or consolidation numbers,
     * so this method attempts to find the shipment using both strategies.
     *
     * @param jobNumber the job number to search for
     * @return Optional containing VwShipmentInfoBean if found, empty otherwise
     */
    Optional<VwShipmentInfoBean> findShipmentByJobNumber(String jobNumber);

    /**
     * Check if the view-based shipment service is available and accessible.
     * This method can be used for health checks and fallback decision making.
     *
     * @return true if the view is accessible, false otherwise
     */
    boolean isViewAvailable();
}